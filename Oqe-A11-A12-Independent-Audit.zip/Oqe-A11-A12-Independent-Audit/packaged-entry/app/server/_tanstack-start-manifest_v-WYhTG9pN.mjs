//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-WYhTG9pN.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "[REDACTED_LOCAL_WORKSPACE_PATH]/src/routes/__root.tsx",
		children: [
			"/",
			"/about",
			"/automations",
			"/conversations",
			"/evidence",
			"/library",
			"/projector",
			"/settings",
			"/systems-lab",
			"/voice-studio",
			"/api/browser-attest",
			"/api/automations/poll",
			"/api/automations/probe",
			"/api/automations/settle",
			"/api/automations/tick",
			"/api/companion/$",
			"/api/images/generate",
			"/api/ollama/$",
			"/api/storage/artifacts",
			"/api/storage/automation-jobs",
			"/api/storage/conversations",
			"/api/storage/evidence",
			"/api/storage/operation-journal",
			"/api/storage/task-queue",
			"/api/storage/voice-profiles",
			"/api/systems-lab/history",
			"/api/systems-lab/status",
			"/api/tasks/start",
			"/api/tts/$",
			"/api/automations/trigger/$",
			"/api/tasks/cancel/$taskId",
			"/api/tasks/resume/$taskId",
			"/api/tasks/status/$taskId"
		],
		css: ["/assets/index-BfY2OdIN.css"],
		preloads: [
			"/assets/index-BEV_6Cxw.js",
			"/assets/rolldown-runtime-hePW80VL.js",
			"/assets/cn-Bo35moy2.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BEV_6Cxw.js"
		} }]
	},
	"/": {
		filePath: "[REDACTED_LOCAL_WORKSPACE_PATH]/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-DZf7rPy0.js",
			"/assets/use-hold-drag-CMhBl_Xj.js",
			"/assets/chevron-down-Dje9X847.js",
			"/assets/copy-CViBgJMo.js",
			"/assets/session-NufNktji.js",
			"/assets/pencil-CYIs44Ah.js",
			"/assets/input-EcM2CW5S.js",
			"/assets/local-client-ytHvigO2.js",
			"/assets/artifacts-Bp2OvpJc.js"
		]
	},
	"/about": {
		filePath: "[REDACTED_LOCAL_WORKSPACE_PATH]/src/routes/about.tsx",
		children: void 0,
		preloads: ["/assets/about-BBcPbbou.js", "/assets/about-page-CF5k-fd6.js"]
	},
	"/automations": {
		filePath: "[REDACTED_LOCAL_WORKSPACE_PATH]/src/routes/automations.tsx",
		children: void 0,
		preloads: [
			"/assets/automations-Dm4GVO76.js",
			"/assets/copy-CViBgJMo.js",
			"/assets/trash-2-BQVQRuVg.js",
			"/assets/toggle-KbNHucLR.js",
			"/assets/input-EcM2CW5S.js"
		]
	},
	"/conversations": {
		filePath: "[REDACTED_LOCAL_WORKSPACE_PATH]/src/routes/conversations.tsx",
		children: void 0,
		preloads: [
			"/assets/conversations-DnhqbJ4i.js",
			"/assets/pencil-CYIs44Ah.js",
			"/assets/trash-2-BQVQRuVg.js",
			"/assets/input-EcM2CW5S.js"
		]
	},
	"/projector": {
		filePath: "[REDACTED_LOCAL_WORKSPACE_PATH]/src/routes/projector.tsx",
		children: void 0,
		preloads: [
			"/assets/projector-DeLzr4Zv.js",
			"/assets/chevron-down-Dje9X847.js",
			"/assets/session-NufNktji.js",
			"/assets/local-client-ytHvigO2.js"
		]
	},
	"/settings": {
		filePath: "[REDACTED_LOCAL_WORKSPACE_PATH]/src/routes/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-cPBcLXij.js",
			"/assets/chevron-down-Dje9X847.js",
			"/assets/voice-studio-CKezSz-K.js",
			"/assets/about-page-CF5k-fd6.js",
			"/assets/toggle-KbNHucLR.js",
			"/assets/input-EcM2CW5S.js",
			"/assets/artifacts-Bp2OvpJc.js"
		]
	},
	"/systems-lab": {
		filePath: "[REDACTED_LOCAL_WORKSPACE_PATH]/src/routes/systems-lab.tsx",
		children: void 0,
		preloads: ["/assets/systems-lab-WSP1ZaV3.js"]
	},
	"/voice-studio": {
		filePath: "[REDACTED_LOCAL_WORKSPACE_PATH]/src/routes/voice-studio.tsx",
		children: void 0,
		preloads: ["/assets/voice-studio-C3LoWz7i.js", "/assets/voice-studio-CKezSz-K.js"]
	}
} });
//#endregion
export { tsrStartManifest };
