import { t as VoiceStudioPage } from "./voice-studio-e0sKV6ip.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/voice-studio-B4Cqo0Ab.js
var SplitComponent = VoiceStudioPage;
//#endregion
export { SplitComponent as component };
