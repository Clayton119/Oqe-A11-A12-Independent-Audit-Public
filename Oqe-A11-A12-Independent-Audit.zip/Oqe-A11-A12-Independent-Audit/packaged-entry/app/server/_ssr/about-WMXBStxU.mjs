import { H as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as AboutPage } from "./about-page-CVsZVRU7.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/about-WMXBStxU.js
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AboutPage, {});
//#endregion
export { SplitComponent as component };
