import { H as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/toggle-DgNqV39s.js
var import_jsx_runtime = require_jsx_runtime();
/**
* A settings switch.
*
* V10.6 — the description is OPTIONAL. It used to be required, which is what
* filled the settings pages with paragraphs explaining each control to the
* reader; a switch whose label already says what it does should be allowed to
* stand on its own.
*
* The two states read the way the rest of the interface reads: OFF is recessed
* (a well, cut below the surface), ON is the lamp (the same amber gradient as
* the primary action). There is no third look for hover — the knob alone moves.
*/
function Toggle({ id, label, description, checked, disabled, onChange, compact = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		id,
		role: "switch",
		"aria-checked": checked,
		disabled,
		onClick: () => onChange(!checked),
		className: compact ? "flex shrink-0 items-center justify-between gap-2.5 rounded-md px-1 text-left disabled:opacity-40" : "mt-3 flex min-h-14 w-full items-center justify-between gap-4 rounded-md px-1 text-left disabled:opacity-40",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "min-w-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "block text-sm font-medium",
				children: label
			}), description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mt-1 block max-w-[52ch] text-label leading-relaxed text-muted",
				children: description
			}) : null]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "relative h-6 w-10 shrink-0 rounded-full transition-colors duration-150 data-[on=true]:bg-linear-to-b data-[on=true]:from-[#ffce8a] data-[on=true]:to-[#e9a63f] data-[on=false]:bg-surface-3 data-[on=false]:shadow-[inset_0_1px_2px_rgb(0_0_0_/_0.45),0_0_0_1px_rgb(255_255_255_/_0.09)] data-[on=true]:shadow-[inset_0_1px_0_0_rgb(255_240_214_/_0.4),0_0_0_1px_rgb(255_179_71_/_0.3)]",
			"data-on": checked ? "true" : "false",
			"aria-hidden": "true",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "absolute top-0.5 left-0.5 size-5 rounded-full bg-fg shadow-[0_1px_3px_rgb(0_0_0_/_0.45)] transition-transform duration-150 ease-out data-[on=true]:translate-x-4 data-[on=true]:bg-[color:var(--color-on-accent)] data-[on=true]:shadow-[0_1px_2px_rgb(0_0_0_/_0.35)]",
				"data-on": checked ? "true" : "false"
			})
		})]
	});
}
//#endregion
export { Toggle as t };
