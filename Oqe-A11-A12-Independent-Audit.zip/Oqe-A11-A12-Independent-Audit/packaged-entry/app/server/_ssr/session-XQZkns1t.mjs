import { n as removePhrase, t as containsPhrase } from "./local-client-Cqz3VYgc.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/session-XQZkns1t.js
/**
* V10.20 — the wake word is the name, not the greeting in front of it.
*
* The stored phrase is "Hey Oqe", and matching only the whole phrase meant a
* reader who said the name alone — "Oqe, play the next episode" — was ignored.
* The reader asked for exactly that: say "oqe" and the room starts listening.
* So a leading greeting is optional: the name carries the wake.
*
* Only greetings are optional. Nothing else about the phrase is loosened: the
* name still has to be a whole word (see `containsPhrase`), so "Oqes" in other
* speech does not wake the wall.
*
* V10.40 — the name is also heard how it is said. The reader pronounces Oqe as
* "oak-ee" ("oak-e"), and speech-to-text writes those letters, not the app's
* spelling: "oaky", "oakey", "okee". A wall that only matched "Oqe" would
* never wake for the reader saying the name beside it. When the wake or sleep
* phrase contains the name, those spoken spellings are accepted as the same
* word. "okey" is deliberately NOT accepted — "okey-dokey" in normal speech
* must not wake the room. A custom wake phrase without the name gains nothing:
* its wording is the reader's own.
*/
var OPTIONAL_GREETING = /^(?:hey|hi|hello|ok|okay|yo|oi)\b[\s,]*/i;
var NAME_IN_PHRASE_RE = /\bOqe\b/i;
var SPOKEN_NAME_SPELLINGS = [
	"oaky",
	"oakey",
	"okee"
];
/**
* The phrase, plus the same phrase with the name spelled how it sounds — only
* when the name is part of the phrase. The original phrase always rides
* along, so the exact spelling still matches first.
*/
function phraseSpellings(phrase) {
	if (!NAME_IN_PHRASE_RE.test(phrase)) return [phrase];
	return [phrase, ...SPOKEN_NAME_SPELLINGS.map((spoken) => phrase.replace(NAME_IN_PHRASE_RE, spoken))];
}
/** The name inside a stored wake phrase ("Hey Oqe" → "Oqe"). */
function wakeWord(phrase) {
	return phrase.trim().replace(OPTIONAL_GREETING, "").trim();
}
/** Did this transcript contain the wake word (with or without its greeting)?
*
* V10.40 — the match covers the spoken spellings of the name as well, from
* either the full phrase or the bare name.
*/
function heardWakePhrase(transcript, phrase) {
	if (!phrase.trim()) return false;
	if (phraseSpellings(phrase).some((needle) => containsPhrase(transcript, needle))) return true;
	const word = wakeWord(phrase);
	if (word === phrase.trim()) return false;
	return phraseSpellings(word).some((needle) => containsPhrase(transcript, needle));
}
/** Strip the wake word — and the greeting in front of it — from the command.
*
* V10.40 — a spoken spelling of the name is stripped the same way, so the
* command starts with the reader's request, never with "oaky …".
*/
function stripWakePhrase(transcript, phrase) {
	const word = wakeWord(phrase);
	return [phrase, ...word !== phrase.trim() ? [word] : []].flatMap((needle) => phraseSpellings(needle)).reduce((text, needle) => removePhrase(text, needle), transcript).replace(OPTIONAL_GREETING, "").replace(/\s+/g, " ").replace(/^[,.;:—-]+\s*/, "").trim();
}
function routeTranscript(options) {
	const transcript = options.transcript.trim();
	if (!transcript) return {
		kind: "discard",
		reason: "idle"
	};
	if (phraseSpellings(options.sleepPhrase).some((needle) => containsPhrase(transcript, needle))) return {
		kind: "sleep",
		sessionOpen: false
	};
	const woke = heardWakePhrase(transcript, options.wakePhrase);
	if (options.wakeSessionEnabled && !options.sessionOpen && !woke) return {
		kind: "discard",
		reason: "idle"
	};
	const text = stripWakePhrase(transcript, options.wakePhrase);
	if (woke && !text) return {
		kind: "wake",
		sessionOpen: true,
		text: ""
	};
	return {
		kind: woke ? "wake" : "message",
		sessionOpen: true,
		text
	};
}
//#endregion
export { wakeWord as n, routeTranscript as t };
