import { H as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/about-page-CVsZVRU7.js
var import_jsx_runtime = require_jsx_runtime();
function AboutPage({ embedded = false, showTitle = true }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: embedded ? "" : "mx-auto w-full max-w-2xl px-4 py-6",
		children: [
			showTitle ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(embedded ? "h2" : "h1", {
				className: embedded ? "text-base font-semibold tracking-[-0.012em]" : "text-2xl font-semibold tracking-[-0.025em]",
				children: "About and limitations"
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm leading-relaxed text-pretty text-muted",
				children: "Oqe is a local-first conversation website. By default it talks to Ollama running on this machine — no key needed. Ollama Cloud is available in Settings for anyone who'd rather use that instead. It is not a native Android companion, not an accessibility service. The browser-only chat itself cannot control the operating system or other apps. On Windows, a separately installed companion can perform limited desktop actions only after pairing, enabling desktop automation, and confirming the target app; STOP and target-consent gates remain in force."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm leading-relaxed text-pretty text-muted",
				children: "Desktop browser only. Phone support, Android packaging, and mobile access as a native app are not implemented. Large tap targets make the website easier to use on a phone screen; that is not a claim that a phone layout was completed or tested as a product."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-8 text-base font-semibold tracking-[-0.012em]",
				children: "What this website can do"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "mt-3 list-disc space-y-2 pl-4 text-sm leading-relaxed marker:text-faint",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Hold separate local conversation threads, with rename and local delete." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Send the current thread to Ollama on this machine by default, or to Ollama Cloud with an API key you paste in Settings — as a Bearer token, not stored anywhere else." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Stream answers, stop generation, and keep partial text." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Hide model think-blocks unless you opt in." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Optionally use the browser speech APIs, off by default." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Use the optional Browser Assistant extension to work in its dedicated browser tab; this does not grant OS control." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "On Windows only, use the separately installed companion for explicitly authorized desktop actions." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Run local scheduled prompts while an Oqe tab can run timers, and run webhook-triggered prompts when an event is queued locally and an Oqe tab can dispatch it." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Optionally fetch public pages and short search results when Allow web browsing is turned on in Settings." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Open videos, sketches, and walkthroughs on the main chat screen when you paste a link or use Show browsing preview." })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-8 text-base font-semibold tracking-[-0.012em]",
				children: "What is disabled"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "mt-3 list-disc space-y-2 pl-4 text-sm leading-relaxed marker:text-faint",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Browser-only chat controlling the desktop, other Android apps, or arbitrary Chrome controls." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Changing operating-system settings, native Android app control, or installing as an APK." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Timer-based prompts continuing after their browser tab can no longer run. A webhook event can wait in the local queue, but its prompt waits for an online Oqe tab." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Analytics, cloud sync, telemetry, payments, or a hosted credentials service." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Update checks against a remote server." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Phone-native packaging. This is a website, not an APK." })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-8 text-base font-semibold tracking-[-0.012em]",
				children: "Windows desktop control"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm leading-relaxed text-pretty text-muted",
				children: "Desktop input is not part of browser-only chat. On Windows it requires the optional companion, an explicit Pair, enabling Allow desktop automation, and consent for each target app. Esc or Ctrl+Alt+K latches STOP and revokes target consent; clearing STOP leaves automation disabled until you enable it again and reconfirm targets. An input batch already handed to Windows may finish, but no further actions are dispatched. Without the companion, or on Android, desktop control is unavailable."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-8 text-base font-semibold tracking-[-0.012em]",
				children: "Local schedules and webhooks"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm leading-relaxed text-pretty text-muted",
				children: "Scheduled prompts are kept by the local Oqe server, which decides what is due, claims each occurrence once and records its run history; they are not OS Task Scheduler jobs. The prompt itself runs through Oqe on this machine, and occurrences that pass while Oqe is not running are recorded as missed rather than replayed in a burst. A webhook event is queued by the local server and runs only when an Oqe tab is online, the job is enabled, and the app/model path can accept the prompt. The named page or service must POST the event; Oqe does not poll it. Neither feature bypasses desktop-control permissions. If a prompt requests a Windows desktop action, the companion must be paired and enabled, the target must have current consent, and STOP must not be latched."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-8 text-base font-semibold tracking-[-0.012em]",
				children: "Other explicit permissions"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm leading-relaxed text-pretty text-muted",
				children: "Android app control, native Android packaging, and changing operating-system settings are unsupported. Microphone access is requested only after you enable speech-to-text and tap the microphone button. Web browsing is off until you enable it."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-8 text-base font-semibold tracking-[-0.012em]",
				children: "Ollama connection notes"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm leading-relaxed text-pretty text-muted",
				children: "Local mode is on by default and talks to Ollama at the local address shown in Settings — 127.0.0.1:11434 unless you change it. No key is sent or required in this mode. Ollama Cloud mode requires a key from Ollama; the default key is empty, and the key stays in this browser until you clear local data. Either mode lists the models it can see, then chats with /api/chat or the OpenAI-compatible /v1 route. Model IDs should come from that list whenever possible."
			})
		]
	});
}
//#endregion
export { AboutPage as t };
