import { H as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { w as cn } from "./router-CiIP6cPA.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/input-CURER8tx.js
var import_jsx_runtime = require_jsx_runtime();
var fieldClass = "w-full min-h-10 rounded-md bg-well px-3 text-[0.9375rem] text-fg shadow-[inset_0_0_0_1px_var(--color-border)] placeholder:text-faint transition-[box-shadow] duration-150 ease-out focus-visible:shadow-[inset_0_0_0_1px_var(--color-accent),0_0_0_3px_rgb(255_179_71_/_0.12)]";
function Input({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		className: cn(fieldClass, className),
		...props
	});
}
function Textarea({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		className: cn(fieldClass, "min-h-24 py-2.5 resize-y", className),
		...props
	});
}
function Select({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
		className: cn(fieldClass, className),
		...props
	});
}
//#endregion
export { Select as n, Textarea as r, Input as t };
