import { i as __toESM } from "../_runtime.mjs";
import { H as require_jsx_runtime, V as require_react, y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { A as RefreshCw, At as AudioLines, D as Save, F as Pencil, K as MicVocal, M as Play, Ot as Check, f as Trash2, h as Square, l as Upload } from "../_libs/lucide-react.mjs";
import { Jn as stopSpeaking, Nt as fetchLocalTtsStatus, Un as speak, Wn as speakLocal, at as analyzeVoiceSample, er as useAppStore, et as STORAGE_KEYS, gt as createId, h as Button, lt as bytesToBase64, qn as stopLocalSpeak, tr as voiceProfileSampleUrl, w as cn, x as OqeMark, xn as profileEngineParams } from "./router-CiIP6cPA.mjs";
import { r as Textarea, t as Input } from "./input-CURER8tx.mjs";
import { r as transcribeAudio } from "./local-client-Cqz3VYgc.mjs";
import { t as useHoldDrag } from "./use-hold-drag-E5tQGD5V.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/voice-studio-e0sKV6ip.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/** The built-in voice's name, shown on its row. */
var OQE_VOICE_NAME = "Oqe voice";
/**
* Build the rows to render.
*
* 1. The stored order is authoritative for valid ids; duplicates collapse and
*    ids that no longer exist (a deleted preset) are dropped.
* 2. Every saved profile the order misses is appended in its stored order, so
*    a stale order can never hide a voice.
* 3. The built-in Oqe voice is always present.
* 4. The active voice moves to the top — the top row IS the active voice,
*    even when the selection was last made somewhere else (a saved clone, an
*    older settings file, the browser-voice select).
*/
function orderedVoiceRows(profiles, order, activeId) {
	const byId = new Map(profiles.map((profile) => [profile.id, profile]));
	const valid = (id) => id === "" || byId.has(id);
	const seen = /* @__PURE__ */ new Set();
	const ids = [];
	for (const id of order ?? []) {
		if (!valid(id) || seen.has(id)) continue;
		seen.add(id);
		ids.push(id);
	}
	if (!seen.has("")) ids.unshift("");
	for (const profile of profiles) {
		if (seen.has(profile.id)) continue;
		seen.add(profile.id);
		ids.push(profile.id);
	}
	const active = valid(activeId) ? activeId : "";
	const activeIndex = ids.indexOf(active);
	if (activeIndex > 0) ids.unshift(ids.splice(activeIndex, 1)[0]);
	return ids.map((id) => {
		const profile = byId.get(id);
		return profile ? {
			id,
			name: profile.name,
			builtIn: false
		} : {
			id: "",
			name: OQE_VOICE_NAME,
			builtIn: true
		};
	});
}
/**
* V10.38 — the DROP the studio's hold-and-drag ends with: the voice lands ON
* the row it was released over, the way dragging down takes that row's place
* and dragging up takes its place instead. One removal then one insertion, so
* the list can never gain or lose a voice. Returns null when the gesture would
* change nothing (unknown id, same position, or a target outside the list), so
* the caller leaves settings untouched rather than writing an identical order.
*/
function moveVoiceRowTo(ids, id, targetIndex) {
	const from = ids.indexOf(id);
	if (from < 0) return null;
	const to = Math.max(0, Math.min(ids.length - 1, Math.trunc(targetIndex)));
	if (to === from) return null;
	const next = [...ids];
	next.splice(from, 1);
	next.splice(to, 0, id);
	return next;
}
/**
* The order with `id` first — "use this voice" without stepping it up past
* every row above it. An id the list does not contain still comes first.
*/
function voiceFirst(ids, id) {
	return [id, ...ids.filter((entry) => entry !== id)];
}
/**
* V7.9.1 — importing a voice profile sample from a FILE.
*
* Recording into the microphone was the only way to create a named voice
* profile. This module adds the other honest path: pick an audio file, or a
* video file whose audio track is extracted locally, and the same measured
* pitch/pace analysis runs on it.
*
* Rules this file must keep:
* - Nothing leaves the device. The browser's own AudioContext decodes the
*   file; there is no upload and no cloud service. The one optional step that
*   touches a process is the LOCAL Whisper bridge (src/lib/stt/local-client.ts),
*   which is loopback-only.
* - A video becomes an audio-only 16-bit mono WAV in memory, so the stored
*   sample is something the browser can actually play and decode later.
* - A transcript is optional and always attributed: when the local STT bridge
*   is missing the profile is still saved and the caller reports that the
*   transcript was skipped. No text is ever invented.
* - Samples are bounded: only the first MAX_VOICE_SAMPLE_SECONDS are kept, so a
*   long video cannot blow the localStorage quota (the profile store caps a
*   sample at MAX_VOICE_PROFILE_BYTES).
*
* The measurement helpers (resample, mono mix, WAV encode, word rate) are pure
* so they can be unit-tested without a browser or a media file.
*/
/** What the file picker offers: any audio, any video. */
var VOICE_UPLOAD_ACCEPT = "audio/*,video/*";
/**
* Source-file ceiling. Decoding happens in memory, so a multi-GB recording is
* refused with an honest message instead of hanging the tab.
*/
var MAX_VOICE_UPLOAD_BYTES = 209715200;
/** Analysis rate. 20 s mono 16-bit at 16 kHz ≈ 640 KB, ~853 KB as base64. */
var VOICE_SAMPLE_RATE = 16e3;
var VIDEO_EXTENSIONS = [
	".mp4",
	".m4v",
	".mov",
	".webm",
	".mkv",
	".avi",
	".wmv",
	".flv",
	".mpeg",
	".mpg",
	".3gp",
	".ts"
];
var AUDIO_EXTENSIONS = [
	".mp3",
	".m4a",
	".aac",
	".wav",
	".wave",
	".ogg",
	".oga",
	".opus",
	".flac",
	".weba",
	".wma",
	".aiff"
];
/**
* Classify a picked file as audio or video. The MIME type wins when the OS
* provides one; the extension is the fallback for the many Windows files whose
* `type` is empty (Windows maps most extensions, but not all).
*/
function mediaKindForFile(file) {
	const type = (file.type ?? "").toLowerCase();
	if (type.startsWith("video/")) return "video";
	if (type.startsWith("audio/")) return "audio";
	const name = file.name.toLowerCase();
	if (VIDEO_EXTENSIONS.some((extension) => name.endsWith(extension))) return "video";
	if (AUDIO_EXTENSIONS.some((extension) => name.endsWith(extension))) return "audio";
	return null;
}
/** Human-readable refusal reason, or null when the file is acceptable. */
function voiceUploadProblem(file) {
	if (mediaKindForFile(file) === null) return `"${file.name}" is not an audio or video file.`;
	if (typeof file.size === "number" && file.size > 209715200) return `"${file.name}" is larger than ${Math.round(MAX_VOICE_UPLOAD_BYTES / 1048576)} MB — trim it to about 20 seconds first.`;
	return null;
}
/**
* Profile name derived from a file name when the name field is empty, so
* picking `Clayton-intro.mp4` does not force a trip back to the text box.
*/
function profileNameFromFile(fileName) {
	return fileName.replace(/^.*[\\/]/, "").replace(/\.[^.]*$/, "").replace(/[_-]+/g, " ").replace(/\s+/g, " ").trim().slice(0, 48);
}
/** Average the channels down to one mono track. */
function mixToMono(channels) {
	const first = channels[0];
	if (!first) return /* @__PURE__ */ new Float32Array(0);
	if (channels.length === 1) return first;
	const mono = new Float32Array(first.length);
	for (let i = 0; i < first.length; i += 1) {
		let sum = 0;
		for (const channel of channels) sum += channel[i] ?? 0;
		mono[i] = sum / channels.length;
	}
	return mono;
}
/** Samples in a `maxSeconds` window at `sampleRate`. Pure. */
function windowSamples(sampleRate, maxSeconds = 20) {
	return Math.max(1, Math.floor(sampleRate * maxSeconds));
}
/** Keep at most `maxSeconds` from the front. `trimmed` is true when it cut. */
function trimToSeconds(samples, sampleRate, maxSeconds = 20) {
	const limit = windowSamples(sampleRate, maxSeconds);
	if (samples.length <= limit) return {
		samples,
		trimmed: false
	};
	return {
		samples: samples.subarray(0, limit),
		trimmed: true
	};
}
/**
* Linear resample. Not studio quality, but this sample only feeds a pitch/pace
* estimate and a browser read-aloud shaping value — and it is exact enough to
* keep the stored bytes small and predictable.
*/
function resampleLinear(samples, fromRate, toRate) {
	if (fromRate === toRate || samples.length === 0 || fromRate <= 0 || toRate <= 0) return samples;
	const outLength = Math.max(1, Math.round(samples.length * toRate / fromRate));
	const out = new Float32Array(outLength);
	const ratio = fromRate / toRate;
	for (let i = 0; i < outLength; i += 1) {
		const position = i * ratio;
		const left = Math.floor(position);
		const right = Math.min(samples.length - 1, left + 1);
		const fraction = position - left;
		const a = samples[left] ?? 0;
		const b = samples[right] ?? a;
		out[i] = a + (b - a) * fraction;
	}
	return out;
}
/** 16-bit mono PCM WAV encoder. Pure so the header math is unit-testable. */
function encodeWav(samples, sampleRate) {
	const dataBytes = samples.length * 2;
	const buffer = new ArrayBuffer(44 + dataBytes);
	const view = new DataView(buffer);
	const writeAscii = (offset, text) => {
		for (let i = 0; i < text.length; i += 1) view.setUint8(offset + i, text.charCodeAt(i));
	};
	writeAscii(0, "RIFF");
	view.setUint32(4, 36 + dataBytes, true);
	writeAscii(8, "WAVE");
	writeAscii(12, "fmt ");
	view.setUint32(16, 16, true);
	view.setUint16(20, 1, true);
	view.setUint16(22, 1, true);
	view.setUint32(24, sampleRate, true);
	view.setUint32(28, sampleRate * 2, true);
	view.setUint16(32, 2, true);
	view.setUint16(34, 16, true);
	writeAscii(36, "data");
	view.setUint32(40, dataBytes, true);
	let offset = 44;
	for (let i = 0; i < samples.length; i += 1) {
		const clamped = Math.max(-1, Math.min(1, samples[i] ?? 0));
		view.setInt16(offset, clamped < 0 ? clamped * 32768 : clamped * 32767, true);
		offset += 2;
	}
	return new Uint8Array(buffer);
}
/**
* Speaking rate from a real transcript: words divided by the real duration.
* Returns undefined when either side is missing, so the profile falls back to
* the measured syllable estimate rather than a made-up number.
*/
function wordsPerMinuteFromTranscript(transcript, durationMs) {
	if (!Number.isFinite(durationMs) || durationMs <= 0) return void 0;
	const words = transcript.trim().split(/\s+/).filter(Boolean).length;
	if (words < 2) return void 0;
	const rate = Math.round(words / (durationMs / 1e3) * 60);
	return Number.isFinite(rate) && rate > 0 ? rate : void 0;
}
/**
* Decode a picked audio or video file and return an audio-only WAV blob.
*
* `decodeAudioData` reads only the audio track of a video container, which is
* exactly the conversion we want: an .mp4/.webm/.mov voice note becomes a
* plain audio sample with no video data retained.
*/
async function extractSampleFromFile(file, options = {}) {
	const problem = voiceUploadProblem(file);
	if (problem) return {
		ok: false,
		error: problem
	};
	const kind = mediaKindForFile(file);
	if (!kind) return {
		ok: false,
		error: `"${file.name}" is not an audio or video file.`
	};
	if (typeof window === "undefined" || typeof AudioContext === "undefined") return {
		ok: false,
		error: "This browser cannot decode media files for a voice sample."
	};
	let decoded;
	try {
		const bytes = await file.arrayBuffer();
		const ctx = new AudioContext();
		try {
			decoded = await ctx.decodeAudioData(bytes);
		} finally {
			ctx.close().catch(() => {});
		}
	} catch {
		return {
			ok: false,
			error: `"${file.name}" could not be decoded. Supported audio and video files (MP3, M4A, WAV, OGG, MP4, MOV, WebM) work; other containers may not.`
		};
	}
	const maxSeconds = options.maxSeconds ?? 20;
	const windowLength = windowSamples(decoded.sampleRate, maxSeconds);
	const channels = [];
	for (let i = 0; i < decoded.numberOfChannels; i += 1) channels.push(decoded.getChannelData(i).subarray(0, windowLength));
	const { samples: kept, trimmed } = trimToSeconds(mixToMono(channels), decoded.sampleRate, maxSeconds);
	const resampled = resampleLinear(kept, decoded.sampleRate, VOICE_SAMPLE_RATE);
	const wav = encodeWav(resampled, VOICE_SAMPLE_RATE);
	const durationMs = Math.round(resampled.length / VOICE_SAMPLE_RATE * 1e3);
	if (durationMs < 500) return {
		ok: false,
		error: `"${file.name}" has no usable audio in its first ${maxSeconds} seconds.`
	};
	return {
		ok: true,
		kind,
		blob: new Blob([wav], { type: "audio/wav" }),
		durationMs,
		trimmed: trimmed || decoded.duration * 1e3 - durationMs > 1e3
	};
}
/**
* Voice Studio — service layer.
*
* Two honest jobs, no theatre:
*
*  1. Engine control metadata: which speech settings the SELECTED engine
*     actually supports. A control that is not in this table is disabled and
*     explained in the UI — never a decorative slider that does nothing.
*
*  2. Resumable voice-clone jobs: the clone workflow (validate → extract →
*     analyze → generate → preview → save) is persisted step by step, so a
*     model download, a validation failure or an interrupted generation can
*     resume from the last completed step instead of starting over — and a
*     profile that was not actually generated is never reported as saved.
*
* Large audio never lives here: the validated sample is written into the
* clone-job record only as the small 16 kHz mono WAV needed to resume, and
* generated profiles are stored by voice-profiles.ts. Model weights stay on
* disk in the local TTS root, outside browser storage.
*/
/**
* What each engine really supports. Only `browser` changes pitch natively
* (SpeechSynthesisUtterance). The local engines synthesize audio we can
* re-play at a different speed while preserving pitch (HTMLMediaElement
* preservesPitch), but pitch itself is fixed by the model — so the pitch
* control is disabled and explained, not faked.
*/
var ENGINE_CONTROLS = {
	browser: {
		speed: true,
		pitch: true,
		note: "Browser voices support speed and pitch natively."
	},
	kokoro: {
		speed: true,
		pitch: false,
		note: "kokoro changes speed at playback with pitch preserved; pitch is fixed by the model."
	},
	qwen3: {
		speed: true,
		pitch: false,
		note: "Cloned voices change speed at playback; pitch is fixed by the clone reference."
	},
	openvoice: {
		speed: false,
		pitch: false,
		note: "OpenVoice is not installed — no voice controls claim to exist."
	}
};
function engineControls(engine) {
	return ENGINE_CONTROLS[engine] ?? ENGINE_CONTROLS.openvoice;
}
var MIN_SPEED = .5;
var MIN_PITCH = .5;
/** Default preview text — a sentence the user can hear and judge. */
var STUDIO_PREVIEW_TEXT = "This is how Oqe will sound when reading your answers aloud.";
function clampSpeed(value) {
	return clampFinite(value, MIN_SPEED, 2, 1);
}
function clampPitch(value) {
	return clampFinite(value, MIN_PITCH, 2, 1);
}
function clampFinite(value, min, max, fallback) {
	if (!Number.isFinite(value)) return fallback;
	return Math.min(max, Math.max(min, value));
}
/**
* The clone-job key comes from the one storage registry so "Clear local data"
* removes it. It previously lived outside the registry and survived a clear,
* leaving the recorded sample (and its transcript) on disk.
*/
var CLONE_JOB_STORAGE_KEY = STORAGE_KEYS.voiceCloneJob;
/** The five visible workflow steps, in order. */
var CLONE_STEPS = [
	"Validate recording",
	"Extract sample",
	"Analyze voice",
	"Preview clone",
	"Save preset"
];
var CLONE_TOTAL_STEPS = CLONE_STEPS.length;
function idleCloneJob() {
	return {
		status: "idle",
		step: 1,
		totalSteps: CLONE_TOTAL_STEPS,
		fileName: null,
		profileName: null,
		sampleWavBase64: null,
		analysis: null,
		transcript: null,
		transcriptNote: null,
		error: null,
		updatedAt: 0
	};
}
function isStatus(value) {
	return value === "idle" || value === "validating" || value === "extracting" || value === "analyzing" || value === "generating" || value === "previewing" || value === "saved" || value === "failed" || value === "interrupted";
}
function parseCloneJob(raw) {
	if (!raw) return idleCloneJob();
	try {
		const rec = JSON.parse(raw);
		if (typeof rec !== "object" || rec === null) return idleCloneJob();
		const r = rec;
		const step = typeof r.step === "number" && Number.isInteger(r.step) && r.step >= 1 && r.step <= CLONE_TOTAL_STEPS ? r.step : 1;
		return {
			status: isStatus(r.status) ? r.status : "idle",
			step,
			totalSteps: CLONE_TOTAL_STEPS,
			fileName: typeof r.fileName === "string" ? r.fileName : null,
			profileName: typeof r.profileName === "string" ? r.profileName : null,
			sampleWavBase64: typeof r.sampleWavBase64 === "string" ? r.sampleWavBase64 : null,
			analysis: parseAnalysis(r.analysis),
			transcript: typeof r.transcript === "string" && r.transcript.trim() ? r.transcript : null,
			transcriptNote: typeof r.transcriptNote === "string" && r.transcriptNote ? r.transcriptNote : null,
			error: typeof r.error === "string" ? r.error : null,
			updatedAt: typeof r.updatedAt === "number" && Number.isFinite(r.updatedAt) ? r.updatedAt : 0
		};
	} catch {
		return idleCloneJob();
	}
}
function parseAnalysis(value) {
	if (typeof value !== "object" || value === null) return null;
	const a = value;
	if (typeof a.durationMs !== "number" || !Number.isFinite(a.durationMs)) return null;
	return {
		durationMs: a.durationMs,
		medianPitchHz: typeof a.medianPitchHz === "number" && Number.isFinite(a.medianPitchHz) ? a.medianPitchHz : void 0,
		wordsPerMinute: typeof a.wordsPerMinute === "number" && Number.isFinite(a.wordsPerMinute) ? a.wordsPerMinute : void 0
	};
}
/**
* V10.7 — decode a stored base64 payload back to bytes. The resume path and
* the re-analysis path must decode the stored sample exactly the same way, so
* the decoding lives here rather than in each caller. Throws on malformed
* input (atob), so a caller that reads untrusted storage handles it.
*/
function decodeBase64Bytes(base64) {
	const binary = atob(base64);
	const bytes = new Uint8Array(binary.length);
	for (let index = 0; index < binary.length; index += 1) bytes[index] = binary.charCodeAt(index);
	return bytes;
}
function serializeCloneJob(job) {
	return JSON.stringify({
		status: job.status,
		step: job.step,
		totalSteps: CLONE_TOTAL_STEPS,
		fileName: job.fileName,
		profileName: job.profileName,
		sampleWavBase64: job.sampleWavBase64,
		analysis: job.analysis,
		transcript: job.transcript,
		transcriptNote: job.transcriptNote,
		error: job.error,
		updatedAt: job.updatedAt
	});
}
function readCloneJob(storage) {
	if (!storage) return idleCloneJob();
	try {
		return parseCloneJob(storage.getItem(CLONE_JOB_STORAGE_KEY));
	} catch {
		return idleCloneJob();
	}
}
function writeCloneJob(storage, job) {
	const next = {
		...job,
		totalSteps: CLONE_TOTAL_STEPS,
		updatedAt: Date.now()
	};
	if (!storage) return next;
	try {
		storage.setItem(CLONE_JOB_STORAGE_KEY, serializeCloneJob(next));
	} catch {
		try {
			storage.setItem(CLONE_JOB_STORAGE_KEY, serializeCloneJob({
				...next,
				sampleWavBase64: null
			}));
		} catch {}
	}
	return next;
}
function clearCloneJob(storage) {
	if (storage) try {
		storage.removeItem(CLONE_JOB_STORAGE_KEY);
	} catch {}
	return idleCloneJob();
}
function cloneResumePlan(job) {
	if (job.status === "idle") return { kind: "none" };
	if (job.status === "saved") return {
		kind: "done",
		profileName: job.profileName
	};
	if (job.status === "previewing") return {
		kind: "preview",
		profileName: job.profileName
	};
	if (job.status === "failed") return {
		kind: "start-over",
		reason: job.error ?? "The previous attempt failed."
	};
	if (job.status === "interrupted") {
		if (job.sampleWavBase64) return {
			kind: "continue",
			step: 3,
			label: CLONE_STEPS[2],
			hasSample: true
		};
		return {
			kind: "continue",
			step: 2,
			label: CLONE_STEPS[1],
			hasSample: false
		};
	}
	const step = job.sampleWavBase64 && job.step < 3 ? 3 : job.step;
	return {
		kind: "continue",
		step,
		label: CLONE_STEPS[step - 1] ?? CLONE_STEPS[0],
		hasSample: Boolean(job.sampleWavBase64)
	};
}
/**
* Rebuild the pending profile from a resumed job. Returns null until the
* analysis step has really produced measurements — a profile is never
* invented from a file name.
*/
function cloneProfileDraft(job) {
	if (!job.sampleWavBase64 || !job.analysis) return null;
	return {
		id: createId("voice"),
		name: (job.profileName ?? "").trim() || "Voice",
		createdAt: job.updatedAt || Date.now(),
		mimeType: "audio/wav",
		sampleBase64: job.sampleWavBase64,
		sampleDurationMs: job.analysis.durationMs,
		medianPitchHz: job.analysis.medianPitchHz,
		wordsPerMinute: job.analysis.wordsPerMinute,
		...job.transcript ? { transcript: job.transcript } : {}
	};
}
/**
* The single validation gate for imported recordings. Returns an
* understandable problem string, or null when the file may proceed to
* extraction. Corrupt-file detection happens later (decode failure) and is
* reported the same way.
*/
function cloneFileProblem(file) {
	const problem = voiceUploadProblem(file);
	if (problem) return problem;
	return null;
}
/**
* Oqe Voice studio — the ONE place voices are added, cloned and chosen.
*
* There is no voice skill and no separate voice category: every voice
* capability is here — the built-in Oqe voice, saved presets, the reorderable
* voice list, speech speed, engine-honest audio controls, live preview, and
* the resumable voice-cloning workflow. Every control performs its documented
* action; controls the selected engine cannot honour are disabled with the
* reason spelled out — there are no decorative sliders here.
*
* All playback routes through the same TTS service the app's responses use
* (speakLocal for local engines, speak for browser voices), so the preset and
* speech settings selected here are exactly what Oqe speaks with.
*/
function activeEngineOf(settings) {
	if (!settings.localTtsEnabled) return "browser";
	return settings.localTtsProfile ? "qwen3" : "kokoro";
}
var PANEL = "rounded-lg border border-border bg-surface p-4 sm:p-5 shadow-[var(--shadow-panel)]";
var HINT = "text-xs leading-relaxed text-muted";
/**
* V10.6 — the one heading treatment for every section on this screen. It is
* the app's existing label class rather than a new heading style, so a section
* title here reads exactly like a section title in Settings instead of like a
* third kind of heading.
*/
var SECTION_TITLE = "group-label";
/** The engine answering, named for the readout badge that reports it. */
var ENGINE_LABEL = {
	browser: "browser speech",
	kokoro: "kokoro",
	qwen3: "cloned voice",
	openvoice: "openvoice"
};
/**
* The measured facts of a saved voice, formatted for the mono readout.
*
* These come from the analysis the clone pipeline really ran, so a preset that
* was cloned has numbers here and a preset that predates measurements simply
* has none — nothing is filled in from the file name or from a default.
*/
function profileMetrics(profile) {
	const metrics = [];
	if (typeof profile.sampleDurationMs === "number" && profile.sampleDurationMs > 0) metrics.push({
		label: "sample",
		value: `${(profile.sampleDurationMs / 1e3).toFixed(1)}s`
	});
	if (typeof profile.medianPitchHz === "number" && profile.medianPitchHz > 0) metrics.push({
		label: "pitch",
		value: `${Math.round(profile.medianPitchHz)} Hz`
	});
	if (typeof profile.wordsPerMinute === "number" && profile.wordsPerMinute > 0) metrics.push({
		label: "pace",
		value: `${Math.round(profile.wordsPerMinute)} wpm`
	});
	return metrics;
}
/**
* Where the clone workflow stands, from the job's own step.
*
* The rule is the one the old pill row used and is unchanged: a saved job is
* entirely done, a step the job has moved past is done, the step it is working
* on is current, and everything ahead is still ahead.
*/
function stageState(job, index) {
	if (job.status === "saved") return "done";
	if (job.step > index) return "done";
	if (job.step === index && job.status !== "idle") return "current";
	return "todo";
}
/**
* One stage of the clone sequence.
*
* This content IS a sequence — name it, hand it a recording, have it measured,
* hear it, save it — so it is the one place in this screen where a number
* carries information instead of decorating a card. The lit marker is the
* page's single piece of attention: where the work is right now is answered by
* the light, not by reading the copy.
*/
function Stage({ index, label, state, children }) {
	const lit = state === "current";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "relative flex gap-3 sm:gap-4",
		"aria-current": lit ? "step" : void 0,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				"aria-hidden": "true",
				className: cn("absolute bottom-0 left-[13px] top-8 w-px", state === "todo" ? "bg-[var(--color-border)]" : "bg-[var(--color-border-strong)]")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: cn("readout relative z-1 mt-0.5 flex size-7 shrink-0 items-center justify-center rounded-full", lit ? "bg-user text-accent shadow-[0_0_0_1px_var(--color-user-border)]" : state === "done" ? "bg-surface-2 text-accent" : "bg-surface-2 text-muted"),
				children: state === "done" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
					className: "size-3.5",
					"aria-hidden": "true"
				}) : index
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 flex-1 pb-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: cn("text-[0.8125rem] font-semibold", state === "todo" ? "text-muted" : "text-fg"),
					children: label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-1.5",
					children
				})]
			})
		]
	});
}
/** A measured fact: cold mono beside its label, never the accent. */
function Metric({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-baseline gap-1.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-meta text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "readout text-signal",
			children: value
		})]
	});
}
function VoiceStudioPage() {
	const settings = useAppStore((s) => s.settings);
	const voiceProfiles = useAppStore((s) => s.voiceProfiles);
	const voiceProfilesError = useAppStore((s) => s.voiceProfilesError);
	const saveVoiceProfile = useAppStore((s) => s.saveVoiceProfile);
	const deleteVoiceProfileAction = useAppStore((s) => s.deleteVoiceProfile);
	const updateSettings = useAppStore((s) => s.updateSettings);
	const ttsSpeaking = useAppStore((s) => s.ttsSpeaking);
	const navigate = useNavigate();
	const engine = activeEngineOf(settings);
	const controls = engineControls(engine);
	const modelLabel = ENGINE_LABEL[engine];
	const [previewText, setPreviewText] = (0, import_react.useState)(STUDIO_PREVIEW_TEXT);
	const [previewError, setPreviewError] = (0, import_react.useState)(null);
	const [renamingId, setRenamingId] = (0, import_react.useState)(null);
	const [renameValue, setRenameValue] = (0, import_react.useState)("");
	const [pendingDeleteId, setPendingDeleteId] = (0, import_react.useState)(null);
	const [confirmWipe, setConfirmWipe] = (0, import_react.useState)(false);
	const [localStatus, setLocalStatus] = (0, import_react.useState)(null);
	const [job, setJob] = (0, import_react.useState)(() => idleCloneJob());
	const [cloneName, setCloneName] = (0, import_react.useState)("");
	const [cloneMessage, setCloneMessage] = (0, import_react.useState)(null);
	const [cloneBusy, setCloneBusy] = (0, import_react.useState)(false);
	const fileRef = (0, import_react.useRef)(null);
	const [sampleRecording, setSampleRecording] = (0, import_react.useState)(false);
	const recorderRef = (0, import_react.useRef)(null);
	const chunksRef = (0, import_react.useRef)([]);
	const samplePlayerRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		setJob(readCloneJob(window.localStorage));
	}, []);
	(0, import_react.useEffect)(() => {
		if (!settings.localTtsEnabled) return;
		let cancelled = false;
		fetchLocalTtsStatus().then((status) => {
			if (!cancelled) setLocalStatus(status);
		});
		return () => {
			cancelled = true;
		};
	}, [settings.localTtsEnabled]);
	const persistJob = (0, import_react.useCallback)((next) => {
		setJob(writeCloneJob(window.localStorage, next));
	}, []);
	/**
	* Release the microphone for real: stop the recorder AND its live track.
	*
	* V10.7 — the TRACK is the device handle, so stopping it is what actually
	* ends the capture. Stopping the recorder alone was not enough: a recorder
	* that threw on `start()`, or a page that navigated away mid-recording, left
	* the device open with nothing left holding it.
	*/
	const releaseRecording = (0, import_react.useCallback)(() => {
		const recorder = recorderRef.current;
		recorderRef.current = null;
		if (recorder && recorder.state !== "inactive") try {
			recorder.stop();
		} catch {}
		recorder?.stream.getTracks().forEach((track) => track.stop());
		setSampleRecording(false);
	}, []);
	/** Release the raw-sample player: stop the audio and drop its blob URL. */
	const releaseSamplePlayer = (0, import_react.useCallback)((player) => {
		try {
			player.audio.pause();
		} catch {}
		URL.revokeObjectURL(player.url);
		if (samplePlayerRef.current === player) samplePlayerRef.current = null;
	}, []);
	(0, import_react.useEffect)(() => () => {
		releaseRecording();
		const player = samplePlayerRef.current;
		if (player) releaseSamplePlayer(player);
	}, [releaseRecording, releaseSamplePlayer]);
	const resume = cloneResumePlan(job);
	const voiceRows = (0, import_react.useMemo)(() => orderedVoiceRows(voiceProfiles, settings.voiceOrder, settings.ttsProfileId), [
		voiceProfiles,
		settings.voiceOrder,
		settings.ttsProfileId
	]);
	const activeVoiceId = voiceRows[0]?.id ?? "";
	const selectedProfile = (0, import_react.useMemo)(() => activeVoiceId ? voiceProfiles.find((p) => p.id === activeVoiceId) : void 0, [voiceProfiles, activeVoiceId]);
	const playPreview = (0, import_react.useCallback)((overrides) => {
		setPreviewError(null);
		const text = overrides?.text ?? previewText;
		if (!text.trim()) {
			setPreviewError("Enter some sample text to preview.");
			return;
		}
		const profile = overrides?.profile ?? selectedProfile;
		if (settings.localTtsEnabled) speakLocal({
			text,
			profile: profile ? profile.name : settings.localTtsProfile || void 0,
			localAddress: settings.mode === "local" ? settings.localAddress : void 0,
			rate: clampSpeed(settings.ttsRate),
			onEvent: (event) => {
				if (event.type === "error") setPreviewError(event.message);
			}
		});
		else {
			const result = speak({
				text,
				voiceURI: profile ? void 0 : settings.ttsVoice || void 0,
				profile,
				rate: clampSpeed(settings.ttsRate),
				pitch: clampPitch(settings.ttsPitch),
				onEnd: (info) => {
					if (info.error) setPreviewError(info.error);
				}
			});
			if ("error" in result) setPreviewError(result.error);
		}
	}, [
		previewText,
		selectedProfile,
		settings
	]);
	const stopPreview = (0, import_react.useCallback)(() => {
		stopSpeaking();
		stopLocalSpeak();
	}, []);
	/** Make a voice Oqe's: it moves to the top of the one list. */
	const selectProfile = (0, import_react.useCallback)((id) => {
		updateSettings({
			ttsProfileId: id,
			voiceOrder: voiceFirst(voiceRows.map((row) => row.id), id)
		});
	}, [updateSettings, voiceRows]);
	/** Drop a voice where the drag released it. The new top row becomes Oqe's. */
	const moveVoiceTo = (0, import_react.useCallback)((id, targetIndex) => {
		const next = moveVoiceRowTo(voiceRows.map((row) => row.id), id, targetIndex);
		if (!next) return;
		updateSettings({
			voiceOrder: next,
			ttsProfileId: next[0] ?? ""
		});
	}, [updateSettings, voiceRows]);
	const { dragging, over, rowProps } = useHoldDrag({
		count: voiceRows.length,
		attribute: "data-voice-index",
		ignore: "button, a, input, textarea, select",
		onMove: (from, to) => {
			const row = voiceRows[from];
			if (row) moveVoiceTo(row.id, to);
		}
	});
	const commitRename = (0, import_react.useCallback)((profile) => {
		const name = renameValue.trim();
		if (!name) return;
		saveVoiceProfile({
			...profile,
			sampleBase64: void 0,
			name
		});
		setRenamingId(null);
	}, [renameValue, saveVoiceProfile]);
	async function importProfileFile(file) {
		setCloneMessage(null);
		const problem = cloneFileProblem(file);
		if (problem) {
			persistJob({
				...idleCloneJob(),
				status: "failed",
				step: 1,
				fileName: file.name,
				error: problem
			});
			setCloneMessage(problem);
			return;
		}
		const name = cloneName.trim() || profileNameFromFile(file.name);
		if (!name) {
			setCloneMessage("Name the voice first, then pick a recording.");
			return;
		}
		setCloneBusy(true);
		try {
			persistJob({
				...idleCloneJob(),
				status: "extracting",
				step: 2,
				fileName: file.name,
				profileName: name
			});
			const extracted = await extractSampleFromFile(file);
			if (!extracted.ok) {
				persistJob({
					...readCloneJob(window.localStorage),
					status: "failed",
					step: 2,
					fileName: file.name,
					profileName: name,
					error: extracted.error
				});
				setCloneMessage(extracted.error);
				return;
			}
			persistJob({
				...readCloneJob(window.localStorage),
				status: "analyzing",
				step: 3,
				sampleWavBase64: bytesToBase64(new Uint8Array(await extracted.blob.arrayBuffer()))
			});
			let transcript = null;
			let transcriptNote = null;
			try {
				const result = await transcribeAudio({
					blob: extracted.blob,
					tier: settings.sttTier
				});
				if (result.text.trim()) transcript = result.text.trim();
				else transcriptNote = " The local transcript came back empty, so pitch and pace were measured from the audio alone.";
			} catch (error) {
				transcriptNote = ` No transcript — ${(error instanceof Error ? error.message : "the local STT bridge did not answer").slice(0, 200)}`;
			}
			const analysis = await analyzeVoiceSample(extracted.blob);
			const wordsPerMinute = (transcript ? wordsPerMinuteFromTranscript(transcript, extracted.durationMs) : void 0) ?? analysis.wordsPerMinute;
			const withAnalysis = {
				...readCloneJob(window.localStorage),
				status: "previewing",
				step: 4,
				analysis: {
					durationMs: analysis.durationMs,
					medianPitchHz: analysis.medianPitchHz,
					wordsPerMinute
				},
				transcript,
				transcriptNote
			};
			persistJob(withAnalysis);
			setCloneMessage([extracted.trimmed ? `Voice analyzed from the first 20 seconds. Preview it below, then save.` : "Voice analyzed. Preview it below, then save.", transcriptNote ?? ""].join(""));
		} catch (error) {
			const detail = error instanceof Error ? error.message : "the recording could not be processed";
			persistJob({
				...readCloneJob(window.localStorage),
				status: "failed",
				step: 2,
				fileName: file.name,
				profileName: name,
				error: detail
			});
			setCloneMessage(detail);
		} finally {
			setCloneBusy(false);
		}
	}
	function onPickFile(file) {
		if (!file) return;
		if (!cloneName.trim()) setCloneName(profileNameFromFile(file.name));
		importProfileFile(file);
	}
	/**
	* Wire a recorder onto an ALREADY-OPEN microphone and start capturing.
	*
	* V10.7 — everything between `getUserMedia` and a running recorder must
	* either finish or hand the device back. A browser without `MediaRecorder`
	* support for this stream, or a `start()` that throws, used to leave the
	* microphone open with no handler left to close it (the browser kept showing
	* its recording indicator).
	*/
	function makeRecorder(stream) {
		try {
			const mimeType = MediaRecorder.isTypeSupported("audio/webm") ? "audio/webm" : "";
			return new MediaRecorder(stream, mimeType ? { mimeType } : void 0);
		} catch {
			return null;
		}
	}
	function beginRecording(stream) {
		const recorder = makeRecorder(stream);
		if (!recorder) {
			stream.getTracks().forEach((track) => track.stop());
			setCloneMessage("This browser could not start a recorder for the microphone.");
			return;
		}
		chunksRef.current = [];
		recorder.ondataavailable = (event) => {
			if (event.data.size > 0) chunksRef.current.push(event.data);
		};
		recorder.onstop = () => {
			stream.getTracks().forEach((track) => track.stop());
			const type = chunksRef.current[0]?.type || "audio/webm";
			const blob = new Blob(chunksRef.current, { type });
			chunksRef.current = [];
			recorderRef.current = null;
			setSampleRecording(false);
			if (blob.size === 0) {
				setCloneMessage("The recording was empty. Try again.");
				return;
			}
			importProfileFile(new File([blob], "recording.webm", { type }));
		};
		try {
			recorder.start();
		} catch (error) {
			stream.getTracks().forEach((track) => track.stop());
			setCloneMessage(error instanceof Error ? `Recording could not start: ${error.message}` : "Recording could not start.");
			return;
		}
		recorderRef.current = recorder;
		setSampleRecording(true);
	}
	async function startProfileRecording() {
		setCloneMessage(null);
		if (!cloneName.trim()) {
			setCloneMessage("Name the voice first — e.g. Clayton.");
			return;
		}
		if (typeof MediaRecorder === "undefined") {
			setCloneMessage("This browser cannot record audio. Upload a file instead.");
			return;
		}
		try {
			beginRecording(await navigator.mediaDevices.getUserMedia({ audio: true }));
		} catch (error) {
			setCloneMessage(error instanceof Error && error.name === "NotAllowedError" ? "Microphone permission was denied. Allow it in the browser to record a voice sample." : "Recording could not start.");
		}
	}
	function stopProfileRecording() {
		releaseRecording();
	}
	/**
	* Play the raw stored sample of a preset — the recording itself, not a TTS
	* rendering. V8.6 P2-4: every exit (ended, decode error, rejected play())
	* releases the blob URL; revoking twice is a no-op so the paths may overlap.
	*
	* V10.7 — the player is kept in `samplePlayerRef`, so playing another preset
	* stops the one already sounding (two overlapped before) and unmounting the
	* studio releases the audio and its URL instead of leaving them running.
	*/
	async function playVoiceProfile(profile) {
		const playing = samplePlayerRef.current;
		if (playing) releaseSamplePlayer(playing);
		let objectUrl = null;
		try {
			const response = profile.sampleBase64 ? await fetch(`data:${profile.mimeType};base64,${profile.sampleBase64}`) : await fetch(voiceProfileSampleUrl(profile.id), { cache: "no-store" });
			if (!response.ok) throw new Error(`HTTP ${response.status}`);
			const blob = await response.blob();
			const url = URL.createObjectURL(blob);
			objectUrl = url;
			const audio = new Audio(url);
			const player = {
				audio,
				url
			};
			samplePlayerRef.current = player;
			audio.onended = () => releaseSamplePlayer(player);
			audio.onerror = () => releaseSamplePlayer(player);
			await audio.play();
		} catch {
			if (objectUrl) URL.revokeObjectURL(objectUrl);
			setCloneMessage("The sample could not be played.");
		}
	}
	/**
	* Re-measure the sample an interrupted job already extracted.
	*
	* V10.7 — this button used to say "Re-run analysis" and only relabel the job
	* (`status: "analyzing"`); nothing was ever re-measured. The stored sample is
	* a real 16 kHz WAV, so the analysis genuinely runs again from the audio —
	* the user does not have to find the original file a second time.
	*/
	async function rerunAnalysis() {
		if (cloneBusy) return;
		const sample = job.sampleWavBase64;
		if (!sample) {
			setCloneMessage("There is no stored sample to analyze — pick the recording again.");
			return;
		}
		setCloneBusy(true);
		setCloneMessage(null);
		try {
			const blob = new Blob([decodeBase64Bytes(sample)], { type: "audio/wav" });
			const analysis = await analyzeVoiceSample(blob);
			const wordsPerMinute = (job.transcript ? wordsPerMinuteFromTranscript(job.transcript, analysis.durationMs) : void 0) ?? analysis.wordsPerMinute;
			persistJob({
				...job,
				status: "previewing",
				step: 4,
				analysis: {
					durationMs: analysis.durationMs,
					medianPitchHz: analysis.medianPitchHz,
					wordsPerMinute
				},
				error: null
			});
			setCloneMessage("Analysis re-run from the stored sample. Preview it below, then save.");
		} catch {
			setCloneMessage("The stored sample could not be analyzed again. Pick the recording again.");
		} finally {
			setCloneBusy(false);
		}
	}
	const saveClone = (0, import_react.useCallback)(async () => {
		const draft = cloneProfileDraft(job);
		if (!draft) {
			setCloneMessage("No analyzed voice is ready to save yet.");
			return;
		}
		const error = await saveVoiceProfile(draft);
		if (error) {
			setCloneMessage(error);
			return;
		}
		persistJob({
			...job,
			status: "saved",
			step: 5,
			profileName: draft.name,
			error: null
		});
		setCloneMessage(`Saved “${draft.name}” as a reusable preset.`);
		selectProfile(draft.id);
	}, [
		job,
		persistJob,
		saveVoiceProfile,
		selectProfile
	]);
	const cloneDraft = cloneProfileDraft(job);
	/**
	* The engine's real state as separate statements rather than one dotted
	* string: which engine answers, whether the local service replied, and which
	* model files are actually on disk. Every value here was observed.
	*/
	const engineFacts = !settings.localTtsEnabled ? [] : localStatus ? [
		{
			label: "local service",
			value: localStatus.available ? "ready" : "incomplete",
			tone: localStatus.available ? "text-ok" : "text-warn"
		},
		{
			label: "kokoro",
			value: localStatus.kokoroFound ? "on disk" : "missing",
			tone: localStatus.kokoroFound ? "text-fg" : "text-muted"
		},
		{
			label: "qwen3",
			value: localStatus.qwen3Found ? "on disk" : "missing",
			tone: localStatus.qwen3Found ? "text-fg" : "text-muted"
		},
		{
			label: "voice files",
			value: String(localStatus.voices.length),
			tone: "text-signal"
		}
	] : [{
		label: "local service",
		value: "status unavailable",
		tone: "text-warn"
	}];
	/**
	* What the clone job is doing, in the job's own words. Derived from real
	* status only — there is no background progress and nothing here is timed.
	*/
	const jobStatusLine = job.status === "idle" ? "Waiting for a recording." : job.status === "validating" ? "Checking the recording against the upload rules." : job.status === "extracting" ? `Reading the recording and keeping the first 20 seconds.` : job.status === "analyzing" ? "Measuring pitch and pace on this machine." : job.status === "generating" ? "Building the voice from the sample." : job.status === "previewing" ? "Measured. Hear it, then save it." : job.status === "saved" ? "Saved as a preset." : job.status === "interrupted" ? "Interrupted. The processed sample is still stored, so it does not need picking again." : "The last attempt failed.";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex w-full max-w-3xl flex-col gap-4 px-4 py-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-start gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OqeMark, { className: "mt-0.5 size-9 shrink-0 text-fg" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-2xl font-semibold tracking-[-0.025em] text-fg",
						children: "Voice studio"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: cn(HINT, "max-w-xl"),
						children: "Hand Oqe a recording of a voice once, and it answers in that voice from then on."
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: PANEL,
				"aria-label": "Voice engine status",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: SECTION_TITLE,
							children: "Voice engine"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: cn(HINT, "mt-1"),
							children: controls.note
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 text-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: cn("rounded-full px-2.5 py-1", ttsSpeaking ? "bg-user text-accent" : "bg-surface-2 text-muted"),
							children: ttsSpeaking ? "Speaking" : "Idle"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "readout text-meta text-faint",
							children: modelLabel
						})]
					})]
				}), engineFacts.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
					className: "mt-3 flex flex-wrap gap-x-4 gap-y-1.5 border-t border-border pt-3",
					children: engineFacts.map((fact) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: fact.label,
						value: fact.value
					}, fact.label))
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: PANEL,
				"aria-label": "Voices",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: SECTION_TITLE,
						children: "Voices"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: cn(HINT, "mt-1 max-w-prose"),
						children: "Oqe speaks with the voice at the top. Hold a voice and drag it up or down — change it at any time."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
						className: "mt-3 flex flex-col gap-2",
						"aria-label": "Oqe voices, in order",
						children: voiceRows.map((row, index) => {
							const profile = row.builtIn ? void 0 : voiceProfiles.find((entry) => entry.id === row.id);
							const active = index === 0;
							const isDragging = dragging === index;
							const isTarget = dragging !== null && over === index && over !== dragging;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								...rowProps(index),
								tabIndex: 0,
								"aria-label": `${row.name}, ${index + 1} of ${voiceRows.length}${active ? ", Oqe's voice" : ""}`,
								title: active ? "Oqe's voice. Hold another voice and drag it here to change it." : "Hold, then drag up or down to move this voice",
								style: { touchAction: isDragging ? "none" : "pan-y" },
								className: cn("group relative flex flex-wrap cursor-grab items-start gap-2.5 rounded-md border px-3 py-2.5 pl-4 transition-[background-color,border-color,box-shadow] focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-accent/60", isDragging ? "z-10 cursor-grabbing select-none border-accent/60 bg-surface shadow-[0_10px_24px_rgba(0,0,0,0.45)]" : active ? "border-accent/40 bg-accent/8" : isTarget ? "border-accent/30 bg-surface-2" : "border-border bg-surface-2"),
								onKeyDown: (event) => {
									if (!event.altKey) return;
									if (event.key === "ArrowUp" && index > 0) {
										event.preventDefault();
										moveVoiceTo(row.id, index - 1);
									} else if (event.key === "ArrowDown" && index < voiceRows.length - 1) {
										event.preventDefault();
										moveVoiceTo(row.id, index + 1);
									}
								},
								children: [
									isTarget ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "pointer-events-none absolute inset-x-2 -top-[5px] h-0.5 rounded-full bg-accent",
										"aria-hidden": "true"
									}) : null,
									active ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										"aria-hidden": "true",
										className: "pointer-events-none absolute inset-y-2 left-0 w-[3px] rounded-full bg-accent"
									}) : null,
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										"aria-hidden": "true",
										className: cn("mt-1 flex shrink-0 flex-col items-center gap-[3px] transition-colors", isDragging ? "text-accent" : "text-faint group-hover:text-muted"),
										children: [
											0,
											1,
											2
										].map((dot) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "flex gap-[3px]",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-[3px] rounded-full bg-current" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-[3px] rounded-full bg-current" })]
										}, dot))
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "min-w-[11rem] flex-1",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex flex-wrap items-center gap-x-2 gap-y-1",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "truncate text-sm font-medium text-fg",
														children: row.name
													}),
													active ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "inline-flex items-center gap-1.5 text-meta font-medium text-accent",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															"aria-hidden": "true",
															className: "size-1.5 rounded-full bg-accent"
														}), "Oqe's voice"]
													}) : null,
													row.builtIn ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-meta text-muted",
														children: "built in · no recording needed"
													}) : null
												]
											}),
											profile?.transcript ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "mt-1 truncate text-meta text-muted",
												title: profile.transcript,
												children: ["Transcript: ", profile.transcript]
											}) : null,
											profile ? profileMetrics(profile).length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
												className: "mt-1 flex flex-wrap gap-x-3 gap-y-1",
												children: profileMetrics(profile).map((metric) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
													label: metric.label,
													value: metric.value
												}, metric.label))
											}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-1 text-meta text-muted",
												children: profileEngineParams(profile).note
											}) : null,
											active && isTarget ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-1 text-meta font-medium text-accent",
												children: "Release to make this Oqe's voice"
											}) : null
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex shrink-0 items-center gap-0.5",
										children: [!active ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											size: "sm",
											variant: "secondary",
											"aria-label": `Use ${row.name} as Oqe's voice`,
											onClick: () => selectProfile(row.id),
											children: "Use"
										}) : null, profile ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
												size: "sm",
												variant: "ghost",
												title: "Preview in Oqe's voice",
												"aria-label": `Preview ${profile.name}`,
												onClick: () => playPreview({ profile }),
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4" })
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
												size: "sm",
												variant: "ghost",
												title: "Play the recorded sample",
												"aria-label": `Play sample of ${profile.name}`,
												onClick: () => void playVoiceProfile(profile),
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AudioLines, { className: "size-4" })
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
												size: "sm",
												variant: "ghost",
												title: "Rename",
												"aria-label": `Rename ${profile.name}`,
												onClick: () => {
													setRenamingId(profile.id);
													setRenameValue(profile.name);
												},
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-4" })
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
												size: "sm",
												variant: pendingDeleteId === profile.id ? "danger" : "ghost",
												title: "Delete",
												"aria-label": `Delete ${profile.name}`,
												onClick: () => {
													if (pendingDeleteId === profile.id) {
														deleteVoiceProfileAction(profile.id);
														setPendingDeleteId(null);
													} else setPendingDeleteId(profile.id);
												},
												children: pendingDeleteId === profile.id ? "Confirm delete" : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
											})
										] }) : null]
									}),
									profile && renamingId === profile.id && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-2 flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											value: renameValue,
											onChange: (e) => setRenameValue(e.target.value),
											"aria-label": "New profile name"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
											size: "sm",
											variant: "secondary",
											onClick: () => commitRename(profile),
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" }), " Save name"]
										})]
									})
								]
							}, row.id || "oqe");
						})
					}),
					voiceProfiles.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: cn(HINT, "mt-3"),
						children: "No saved voices yet. Record or clone one below — it joins this list."
					}) : null,
					voiceProfilesError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-xs text-danger",
						children: voiceProfilesError
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: PANEL,
				"aria-label": "Speech settings",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: SECTION_TITLE,
					children: "Speech settings"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex flex-col gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								htmlFor: "voice-speed",
								className: cn("text-sm", controls.speed ? "text-fg" : "text-muted"),
								children: "Speech speed"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "readout text-meta text-muted",
									children: [settings.ttsRate.toFixed(2), "×"]
								}), settings.ttsRate !== 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "text-meta text-faint underline-offset-2 hover:text-fg hover:underline",
									onClick: () => updateSettings({ ttsRate: 1 }),
									children: "Reset"
								}) : null]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "voice-speed",
							type: "range",
							min: .5,
							max: 2,
							step: .05,
							value: settings.ttsRate,
							disabled: !controls.speed,
							onChange: (e) => updateSettings({ ttsRate: clampSpeed(Number(e.target.value)) }),
							className: "mt-2 w-full accent-[var(--color-accent)] disabled:opacity-40",
							"aria-describedby": controls.speed ? void 0 : "voice-speed-note"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-1 flex justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: HINT,
								children: "Slower"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: HINT,
								children: "Faster"
							})]
						}),
						!controls.speed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							id: "voice-speed-note",
							className: HINT,
							children: `Speed unavailable: ${controls.note}`
						}) : null
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								htmlFor: "voice-pitch",
								className: cn("text-sm", controls.pitch ? "text-fg" : "text-muted"),
								children: "Pitch"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-muted",
								children: settings.ttsPitch.toFixed(2)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "voice-pitch",
							type: "range",
							min: .5,
							max: 2,
							step: .05,
							value: settings.ttsPitch,
							disabled: !controls.pitch,
							onChange: (e) => updateSettings({ ttsPitch: clampPitch(Number(e.target.value)) }),
							className: "mt-2 w-full accent-[var(--color-accent)] disabled:opacity-40",
							"aria-describedby": controls.pitch ? void 0 : "voice-pitch-note"
						}),
						!controls.pitch ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							id: "voice-pitch-note",
							className: HINT,
							children: `Pitch unavailable: ${controls.note}`
						}) : null
					] })]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: PANEL,
				"aria-label": "Voice preview",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: SECTION_TITLE,
						children: "Preview"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						className: "mt-3 min-h-20",
						value: previewText,
						onChange: (e) => setPreviewText(e.target.value),
						"aria-label": "Preview text",
						placeholder: "Type what Oqe should say…"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "primary",
								size: "sm",
								onClick: () => playPreview(),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4" }), " Listen"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "secondary",
								size: "sm",
								onClick: stopPreview,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Square, { className: "size-4" }), " Stop"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: HINT,
								children: [
									"Uses ",
									selectedProfile ? `“${selectedProfile.name}”` : "the Oqe voice",
									" at",
									" ",
									settings.ttsRate.toFixed(2),
									"× speed."
								]
							})
						]
					}),
					previewError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-xs text-danger",
						children: previewError
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: PANEL,
				"aria-label": "Voice cloning",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MicVocal, { className: "size-4 text-accent" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: SECTION_TITLE,
							children: "Voice cloning"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: cn(HINT, "mt-1"),
						children: "Import a recording you own or have permission to use, or record one here. Audio is analyzed locally and is kept on this computer. Nothing is uploaded. A voice match is never security authorization."
					}),
					resume.kind !== "none" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 rounded-md border border-user-border bg-user px-3 py-2 text-xs text-fg",
						children: [
							resume.kind === "continue" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
								"An interrupted clone of “",
								job.fileName ?? "recording",
								"” can resume at step ",
								resume.step,
								" (",
								resume.label,
								") — the recording is already processed, so it does not need to be picked again."
							] }),
							resume.kind === "preview" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
								"The clone of “",
								job.fileName ?? "recording",
								"” is analyzed and waiting for preview."
							] }),
							resume.kind === "done" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
								"The “",
								job.profileName ?? "voice",
								"” preset was saved."
							] }),
							resume.kind === "start-over" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
								"Previous attempt: ",
								resume.reason,
								" Start again below."
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-2 flex gap-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "ghost",
									onClick: () => {
										setJob(clearCloneJob(window.localStorage));
										setCloneMessage(null);
									},
									children: "Dismiss"
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex flex-col gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-end gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "min-w-48 flex-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											htmlFor: "clone-name",
											className: HINT,
											children: "Voice name"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											id: "clone-name",
											value: cloneName,
											onChange: (e) => setCloneName(e.target.value),
											placeholder: "e.g. Clayton"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										variant: "secondary",
										size: "sm",
										onClick: () => fileRef.current?.click(),
										disabled: cloneBusy || sampleRecording,
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "size-4" }),
											" ",
											cloneBusy ? "Working…" : "Upload audio or video"
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										ref: fileRef,
										id: "profile-file",
										type: "file",
										accept: VOICE_UPLOAD_ACCEPT,
										className: "hidden",
										"aria-label": "Upload an audio or video file to use as a voice sample",
										onChange: (e) => {
											const file = e.target.files?.[0];
											e.target.value = "";
											onPickFile(file);
										}
									}),
									sampleRecording ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										variant: "danger",
										size: "sm",
										onClick: stopProfileRecording,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Square, { className: "size-4" }), " Stop recording"]
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										variant: "secondary",
										size: "sm",
										onClick: () => void startProfileRecording(),
										disabled: cloneBusy,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MicVocal, { className: "size-4" }), " Record sample"]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: cn(HINT, "mt-1"),
								children: [
									"Audio files are used as they are. A video (MP4, MOV, WebM…) has its audio track extracted here on this device and the first ",
									20,
									" seconds are kept. Nothing is uploaded. When the local Whisper bridge is installed, the sample is also transcribed on this machine."
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
								className: "mt-1 flex flex-col",
								"aria-label": "Clone progress",
								children: CLONE_STEPS.map((label, index) => {
									const stepNumber = index + 1;
									const state = stageState(job, stepNumber);
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Stage, {
										index: stepNumber,
										label,
										state,
										children: [
											stepNumber === 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: HINT,
												children: job.fileName ? `Recording: ${job.fileName} — checked against the upload rules.` : "Nothing chosen yet. Name the voice and give it a recording above."
											}) : null,
											stepNumber === 2 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: HINT,
												children: job.sampleWavBase64 ? `Sample ready — the first 20 seconds were kept.` : `The first 20 seconds of the recording become the sample.`
											}) : null,
											stepNumber === 3 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex flex-col gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: cn(HINT, state === "current" ? "text-fg" : void 0),
													children: jobStatusLine
												}), resume.kind === "continue" && cloneDraft ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
													size: "sm",
													variant: "secondary",
													onClick: () => void rerunAnalysis(),
													disabled: cloneBusy,
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "size-4" }), cloneBusy ? "Analyzing…" : "Re-run analysis"]
												}) }) : null]
											}) : null,
											stepNumber === 4 ? cloneDraft ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
												variant: "secondary",
												size: "sm",
												onClick: () => playPreview({
													profile: cloneDraft,
													text: previewText
												}),
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4" }), " Preview clone"]
											}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: HINT,
												children: "Available once the voice has been measured."
											}) : null,
											stepNumber === 5 ? cloneDraft ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
												variant: "primary",
												size: "sm",
												onClick: saveClone,
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, { className: "size-4" }), " Save preset"]
											}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: HINT,
												children: "The preset is saved only when you say so."
											}) : null
										]
									}, label);
								})
							}),
							job.transcript ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-muted",
								title: job.transcript,
								children: [
									"Transcript: “",
									job.transcript,
									"”"
								]
							}) : null,
							cloneMessage && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-fg",
								children: cloneMessage
							}),
							job.error && job.status === "failed" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-danger",
								children: job.error
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: PANEL,
				"aria-label": "Voice data",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: SECTION_TITLE,
						children: "Voice data"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: cn(HINT, "mt-1"),
						children: "Presets and recordings are stored on this computer, in Oqe's own data folder. Local voice models are files on this computer; downloading or updating them needs network access and is never automatic."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex flex-wrap gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "secondary",
							size: "sm",
							onClick: () => void navigate({ to: "/settings" }),
							children: "Open speech settings"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "danger",
							size: "sm",
							onClick: () => setConfirmWipe(true),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" }), " Delete all voice data"]
						})]
					}),
					confirmWipe ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 rounded-md bg-surface-2 p-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "Deletes every saved voice preset and the current recording job from this browser. Cannot be undone."
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "danger",
								onClick: () => {
									const wiped = [...voiceProfiles].map((profile) => deleteVoiceProfileAction(profile.id));
									Promise.all(wiped).then(() => {
										setCloneMessage("All saved voice data was deleted.");
									});
									setJob(clearCloneJob(window.localStorage));
									setConfirmWipe(false);
								},
								children: "Confirm delete"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								onClick: () => setConfirmWipe(false),
								children: "Cancel"
							})]
						})]
					}) : null
				]
			})
		]
	});
}
//#endregion
export { VoiceStudioPage as t };
