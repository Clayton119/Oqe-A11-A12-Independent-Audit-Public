//#region node_modules/.nitro/vite/services/ssr/assets/copy-D7bd_Qke.js
/** Copy text without throwing when clipboard permission is unavailable. */
async function copyText(text) {
	if (typeof navigator === "undefined" || !navigator.clipboard?.writeText) return {
		ok: false,
		error: "Clipboard access is unavailable."
	};
	try {
		await navigator.clipboard.writeText(text);
		return { ok: true };
	} catch {
		return {
			ok: false,
			error: "Clipboard access was blocked. Select and copy the text manually."
		};
	}
}
//#endregion
export { copyText as t };
