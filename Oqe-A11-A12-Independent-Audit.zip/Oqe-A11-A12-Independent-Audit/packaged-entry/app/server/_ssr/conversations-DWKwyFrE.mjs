import { i as __toESM } from "../_runtime.mjs";
import { H as require_jsx_runtime, V as require_react, y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { F as Pencil, f as Trash2, j as Plus } from "../_libs/lucide-react.mjs";
import { Hn as sortConversations, er as useAppStore, h as Button } from "./router-CiIP6cPA.mjs";
import { t as Input } from "./input-CURER8tx.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/conversations-DWKwyFrE.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ConversationsPage() {
	const conversations = useAppStore((s) => s.conversations);
	const activeId = useAppStore((s) => s.activeId);
	const newConversation = useAppStore((s) => s.newConversation);
	const selectConversation = useAppStore((s) => s.selectConversation);
	const renameConversation = useAppStore((s) => s.renameConversation);
	const deleteConversation = useAppStore((s) => s.deleteConversation);
	const navigate = useNavigate();
	const [editingId, setEditingId] = (0, import_react.useState)(null);
	const [draft, setDraft] = (0, import_react.useState)("");
	const [pendingDelete, setPendingDelete] = (0, import_react.useState)(null);
	const list = sortConversations(conversations);
	function onNew() {
		newConversation();
		navigate({ to: "/" });
	}
	function onSelect(id) {
		selectConversation(id);
		navigate({ to: "/" });
	}
	function startRename(id, title) {
		setEditingId(id);
		setDraft(title);
	}
	function commitRename() {
		if (!editingId) return;
		renameConversation(editingId, draft);
		setEditingId(null);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto w-full max-w-5xl px-4 py-7 sm:px-6 lg:px-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col items-start justify-between gap-5 border-b border-border pb-6 sm:flex-row sm:items-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-semibold tracking-[-0.02em]",
				children: "Conversations"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 max-w-xl text-sm text-muted",
				children: "Local threads, kept on this device. Pick up where you left off, or start with a clean workspace."
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				variant: "primary",
				onClick: onNew,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
					className: "size-4",
					"aria-hidden": "true"
				}), "New"]
			})]
		}), list.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-10 max-w-md text-sm text-muted",
			children: "Nothing here yet. Start a conversation with New and it will be listed on this device, ready to pick up again."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-6 divide-y divide-border overflow-hidden rounded-lg bg-surface shadow-[inset_0_0_0_1px_var(--color-border)]",
			children: list.map((conv) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "group",
				children: [editingId === conv.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "flex flex-col gap-2 px-3 py-2 sm:flex-row sm:items-center",
					onSubmit: (e) => {
						e.preventDefault();
						commitRename();
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: draft,
						onChange: (e) => setDraft(e.target.value),
						"aria-label": "Conversation name",
						autoFocus: true
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							variant: "primary",
							size: "sm",
							children: "Save"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							size: "sm",
							onClick: () => setEditingId(null),
							children: "Cancel"
						})]
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-1 pr-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => onSelect(conv.id),
							className: "flex min-h-14 min-w-0 flex-1 items-center gap-3 px-4 py-2.5 text-left transition-colors hover:bg-surface-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "min-w-0 flex-1 truncate text-[0.9375rem] text-fg",
									children: conv.title
								}),
								conv.id === activeId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "shrink-0 text-meta text-accent",
									children: "Open"
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "readout shrink-0 text-meta text-faint",
									children: [
										conv.messages.length,
										" message",
										conv.messages.length === 1 ? "" : "s"
									]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "inline-flex size-8 shrink-0 items-center justify-center rounded-md text-faint opacity-0 transition-opacity hover:bg-surface-2 hover:text-fg focus-visible:opacity-100 group-hover:opacity-100 group-focus-within:opacity-100",
							"aria-label": `Rename ${conv.title}`,
							onClick: () => startRename(conv.id, conv.title),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "inline-flex size-8 shrink-0 items-center justify-center rounded-md text-faint opacity-0 transition-opacity hover:bg-surface-2 hover:text-danger focus-visible:opacity-100 group-hover:opacity-100 group-focus-within:opacity-100",
							"aria-label": `Delete ${conv.title}`,
							onClick: () => setPendingDelete(conv.id),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
						})
					]
				}), pendingDelete === conv.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					role: "group",
					"aria-label": `Confirm deleting ${conv.title}`,
					className: "flex flex-wrap items-center gap-2 border-t border-border bg-surface-2 px-4 py-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "flex-1 text-xs text-muted",
							children: "Delete this thread and its messages from this device?"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "danger",
							onClick: () => {
								deleteConversation(conv.id);
								setPendingDelete(null);
							},
							children: "Delete"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							onClick: () => setPendingDelete(null),
							children: "Cancel"
						})
					]
				}) : null]
			}, conv.id))
		})]
	});
}
var SplitComponent = ConversationsPage;
//#endregion
export { SplitComponent as component };
