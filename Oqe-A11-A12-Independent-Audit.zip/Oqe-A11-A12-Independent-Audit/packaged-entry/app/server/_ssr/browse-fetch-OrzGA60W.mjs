import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
import { a as decorateSource, c as htmlToText, d as isSafeHttpUrl, g as shouldSearchWeb, h as safeFetchText, l as isBlockedHost, o as extractHttpUrls, p as ogImageFromHtml, r as classifyMedia, s as formatBrowseContext, t as assertPublicUrl, v as titleFromHtml } from "./safe-fetch.server-CPmpHsTy.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/browse-fetch-OrzGA60W.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var FETCH_MS = 8e3;
var MAX_BYTES = 28e4;
var MAX_REDIRECTS = 5;
function parseInput(data) {
	if (typeof data !== "object" || data === null) throw new Error("Browse request was empty.");
	const rec = data;
	if (typeof rec.query !== "string") throw new Error("Browse request needs a query string.");
	return { query: rec.query };
}
var browseWeb_createServerFn_handler = createServerRpc({
	id: "f2b6f275944456dccb24667df129fb193346e4044533c04601d4345adea3c13f",
	name: "browseWeb",
	filename: "src/lib/browse-fetch.ts"
}, (opts) => browseWeb.__executeServer(opts));
var browseWeb = createServerFn({ method: "POST" }).validator(parseInput).handler(browseWeb_createServerFn_handler, async ({ data }) => {
	const query = data.query.trim();
	if (!query) return {
		ok: false,
		searched: false,
		sources: [],
		context: "",
		detail: "Nothing to browse."
	};
	const direct = extractHttpUrls(query);
	let searched = false;
	let urls = direct;
	if (urls.length === 0 && shouldSearchWeb(query)) {
		searched = true;
		urls = await searchPublicUrls(query);
	}
	if (urls.length === 0) return {
		ok: true,
		searched,
		sources: [],
		context: "",
		detail: searched ? "Web search returned no public pages." : "No public URLs in this message, and nothing in it worth searching for."
	};
	const sources = [];
	for (const url of urls.slice(0, 3)) sources.push(await fetchPublicPage(url));
	const context = formatBrowseContext({
		query,
		searched,
		sources
	});
	const okCount = sources.filter((s) => s.ok).length;
	const detail = okCount > 0 ? `Fetched ${okCount} page${okCount === 1 ? "" : "s"}${searched ? " from web search" : ""}.` : "Pages were found but none could be read.";
	return {
		ok: okCount > 0,
		searched,
		sources,
		context,
		detail
	};
});
async function searchPublicUrls(query) {
	const ddg = await searchDuckDuckGo(query);
	if (ddg.length > 0) return ddg;
	return searchWikipedia(query);
}
async function searchDuckDuckGo(query) {
	const fetched = await fetchText(`https://html.duckduckgo.com/html/?q=${encodeURIComponent(query)}`);
	if (!fetched.ok) return [];
	const hrefs = [...fetched.text.matchAll(/class="result__a"[^>]*href="([^"]+)"/gi)];
	const out = [];
	const seen = /* @__PURE__ */ new Set();
	for (const match of hrefs) {
		const resolved = unwrapDdgHref(match[1] ?? "");
		if (!resolved || seen.has(resolved)) continue;
		seen.add(resolved);
		out.push(resolved);
		if (out.length >= 3) break;
	}
	return out;
}
function unwrapDdgHref(href) {
	let raw = href.replace(/&/g, "&");
	try {
		const parsed = new URL(raw, "https://html.duckduckgo.com/");
		const uddg = parsed.searchParams.get("uddg");
		if (uddg) raw = uddg;
		else raw = parsed.href;
	} catch {
		return null;
	}
	if (!isSafeHttpUrl(raw)) return null;
	try {
		const next = new URL(raw);
		if (isBlockedHost(next.hostname)) return null;
		return next.href;
	} catch {
		return null;
	}
}
async function searchWikipedia(query) {
	const fetched = await fetchText("https://en.wikipedia.org/w/api.php?action=opensearch&limit=3&namespace=0&format=json&search=" + encodeURIComponent(query));
	if (!fetched.ok) return [];
	try {
		const json = JSON.parse(fetched.text);
		if (!Array.isArray(json) || !Array.isArray(json[3])) return [];
		const urls = [];
		for (const item of json[3]) {
			if (typeof item !== "string") continue;
			if (!isSafeHttpUrl(item)) continue;
			const parsed = new URL(item);
			if (isBlockedHost(parsed.hostname)) continue;
			urls.push(parsed.href);
			if (urls.length >= 3) break;
		}
		return urls;
	} catch {
		return [];
	}
}
async function fetchPublicPage(url) {
	const media = classifyMedia(url);
	const blocked = await assertPublicUrl(url);
	if (blocked) return decorateSource({
		url,
		title: url,
		ok: false,
		error: blocked,
		kind: media?.kind
	});
	if (media?.kind === "video" && media.provider !== "file") return decorateSource({
		url,
		title: media.provider === "youtube" ? "YouTube video" : "Vimeo video",
		ok: true,
		kind: "video",
		embedUrl: media.embedUrl,
		excerpt: "Embedded video. Play it on the main screen."
	});
	if (media?.kind === "image") return decorateSource({
		url,
		title: "Image",
		ok: true,
		kind: "image",
		imageUrl: url
	});
	if (media?.kind === "video" && media.provider === "file") return decorateSource({
		url,
		title: "Video file",
		ok: true,
		kind: "video",
		excerpt: "Direct video file. Play it on the main screen."
	});
	const fetched = await fetchText(url);
	if (!fetched.ok) return decorateSource({
		url,
		title: url,
		ok: false,
		error: fetched.error
	});
	const html = fetched.text;
	const title = titleFromHtml(html, url);
	const excerpt = htmlToText(html);
	const imageUrl = ogImageFromHtml(html);
	if (!excerpt && !imageUrl) return decorateSource({
		url,
		title,
		ok: false,
		error: "The page had no readable text."
	});
	return decorateSource({
		url,
		title,
		ok: true,
		excerpt,
		imageUrl,
		kind: imageUrl && !excerpt ? "image" : "page"
	});
}
/**
* change sugg v3 IMP-9 — every hop runs through the shared safe-fetch
* primitive: per-hop validation, streaming cap that REJECTS over cap (no
* more silent truncation), structured errors.
*
* V8.7 P0-2 — the browse wall budget is now a real `AbortSignal` carried by
* `safeFetchText` into the PINNED transport. The old `fetchImpl` wrapper around
* global `fetch` re-resolved the hostname after `assertPublicUrl`, which
* reopened the resolve-then-rebind window; there is no transport override left.
*/
async function fetchText(url) {
	const controller = new AbortController();
	const timer = setTimeout(() => controller.abort(), FETCH_MS);
	try {
		return await safeFetchText(url, {
			maxBytes: MAX_BYTES,
			maxRedirects: MAX_REDIRECTS,
			assertUrl: assertPublicUrl,
			signal: controller.signal,
			headers: {
				accept: "text/html,application/xhtml+xml,application/json,text/plain;q=0.9,*/*;q=0.8",
				"user-agent": "OqeLocalBrowse/1.0"
			}
		});
	} catch (error) {
		return {
			ok: false,
			error: error instanceof Error ? error.message : "The page did not respond."
		};
	} finally {
		clearTimeout(timer);
	}
}
//#endregion
export { browseWeb_createServerFn_handler };
