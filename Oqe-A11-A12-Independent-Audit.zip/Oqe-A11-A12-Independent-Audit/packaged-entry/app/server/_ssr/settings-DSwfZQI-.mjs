import { i as __toESM } from "../_runtime.mjs";
import { H as require_jsx_runtime, V as require_react, y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as AboutPage } from "./about-page-CVsZVRU7.mjs";
import { Dt as ChevronDown } from "../_libs/lucide-react.mjs";
import { $n as triggerCollision, $t as listLoadedModels, An as removeKey, At as discoverModels, Cn as profileTurnContent, Ct as describeProjectionPlan, D as CompanionClient, E as BUILT_IN_SKILLS, F as MAX_INSTRUCTION_CHARS, Fn as sameModel, G as MULTI_AGENT_RUN_OPTIONS, Ht as isConnectionConfigured, I as MAX_MA_INSTRUCTIONS_CHARS, J as PREFERRED_CHAT_MODEL, K as PARAMETER_CLASS_ORDER, L as MAX_MA_MISSION_CHARS, Mn as resolveModelTags, Nn as resolveRosterModel, Nt as fetchLocalTtsStatus, On as readWallTextPolicy, Ot as detectSpeechSupport, P as EXPENSIVE_OUTPUT_JOBS, Qn as toggleModelTag, Qt as leadFirstRoster, R as MAX_MA_ROLE_SYSTEM_CHARS, Sn as profileFor, Tn as readJson, Tt as describeSkillSettings, Vn as sortChatModelIds, Vt as imageGenerationStatus, W as MULTI_AGENT_MODEL_HELP, X as PREFERRED_VISION_MODEL, Xn as syncConsentedTargetsFromCompanion, Y as PREFERRED_CODER_MODEL, Z as PROFILES, _n as parameterClassLabel, an as modelMismatch, b as OqeCharacter, ct as buildAutoCapabilities, dn as normalizeUserSkill, dt as capacityConfidenceLabel, en as listVoices, er as useAppStore, et as STORAGE_KEYS, ft as checkMeasuredCapacity, gn as outputSettingsGroups, gt as createId, h as Button, ht as coerceContextOptimizeAt, in as modelClassRecordFor, ir as withOutputCapability, it as allSkills, j as DEFAULT_SETTINGS, jn as resolveContextCapacityWithLimits, jt as enabledOutputCount, k as DEFAULT_LOCAL_ADDRESS, kn as referencedSkillTrigger, ln as normalizeApiKey, mn as optimizeAtTrigger, mt as classMeasurementReuse, nn as measuredCapacityFor, nt as accessRequirementLine, o as TRANSIENT_ARTIFACT_TTL_MS, on as modelTagLabels, or as writeJson, q as PLAN_SECTIONS, qt as isVisionCapable, rn as measurementHostLabel, rt as activeRoster, sn as multiAgentSkillRunnable, st as autoCapabilitiesContext, tn as maskApiKey, tt as WEATHER_LOCATIONS, un as normalizeMultiAgentSkill, ut as capabilityLabels, w as cn, wn as projectorCountFromSig, wt as describeSkillCapabilities, yn as pickPreferredChatModel, zt as heavyMultipleModelsWarning } from "./router-CiIP6cPA.mjs";
import { t as Toggle } from "./toggle-DgNqV39s.mjs";
import { n as Select, r as Textarea, t as Input } from "./input-CURER8tx.mjs";
import { n as companionStatusLine, t as companionPairingStatus } from "./status-CNfpf13v.mjs";
import { t as VoiceStudioPage } from "./voice-studio-e0sKV6ip.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/settings-DSwfZQI-.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* V7.9.1 — creating a skill from a FILE instead of typing it.
*
* Settings → Skills could only be filled by hand. This module reads a picked
* text file (Markdown, plain text, JSON, code) and turns it into a skill draft
* that the user reviews and saves.
*
* Rules this file must keep:
* - Local only. The file is read in the browser with `File.text()`; nothing is
*   uploaded, and the resulting skill is still stored in localStorage exactly
*   like a typed one.
* - Honest derivation. Every field comes from something really in the file —
*   a `/create-skill` JSON block, YAML front matter, a Markdown heading, or the
*   file name. The returned `notes` say which, so the UI never implies more
*   than the file contained.
* - Bounded. The instruction body is trimmed to the same 4000-character limit
*   `normalizeUserSkill` enforces, and oversized files are refused instead of
*   silently truncated.
*/
/** Any text-ish file the browser can read as UTF-8. */
var SKILL_FILE_ACCEPT = ".txt,.md,.markdown,.mdx,.json,.csv,.tsv,.yaml,.yml,.toml,.ini,.cfg,.conf,.log,.c,.cc,.cpp,.cs,.css,.go,.h,.hpp,.html,.java,.js,.jsx,.mjs,.py,.ps1,.rs,.sh,.sql,.ts,.tsx,.vue,.xml,text/*";
/** Source-file ceiling — a skill body is 4000 characters, so this is generous. */
var MAX_SKILL_FILE_BYTES = 524288;
/** Trigger pattern shared with `normalizeUserSkill` (kept in sync by tests). */
var TRIGGER_BODY = /^[a-z0-9][a-z0-9-]{0,31}$/;
/** Appended when a body has to be cut, so the edit is visible in the prompt. */
var TRUNCATION_MARKER = "\n\n[Truncated from a longer file.]";
/** The extensions the picker offers, kept in one list with the accept string. */
var SKILL_FILE_EXTENSIONS = new Set(SKILL_FILE_ACCEPT.split(",").map((entry) => entry.trim().toLowerCase()).filter((entry) => entry.startsWith(".")));
/** MIME types that are unambiguously text even without a known extension. */
var TEXTUAL_MIME_PREFIXES = [
	"text/",
	"application/json",
	"application/xml",
	"application/yaml",
	"application/x-yaml",
	"application/toml",
	"application/javascript",
	"application/x-sh"
];
function extensionOf(fileName) {
	const base = fileName.trim().toLowerCase().replace(/^.*[\\/]/, "");
	const dot = base.lastIndexOf(".");
	return dot > 0 ? base.slice(dot) : "";
}
/**
* Refusal reason for a picked file, or null when it is acceptable.
*
* The `accept` attribute only nudges the file picker — a dragged or force-
* picked PNG would otherwise be read as UTF-8 and become a wall of replacement
* characters as the skill's "instructions". So the file is checked against the
* same text list the picker offers, or a text-ish MIME type.
*/
function skillFileProblem(file) {
	if (!file.name.trim()) return "That file has no name.";
	const type = (file.type ?? "").toLowerCase();
	if (!(SKILL_FILE_EXTENSIONS.has(extensionOf(file.name)) || TEXTUAL_MIME_PREFIXES.some((prefix) => type.startsWith(prefix)))) return `"${file.name}" does not look like a text file. Skills hold prompt text — use Markdown, plain text, JSON, or code.`;
	if (typeof file.size === "number" && file.size > 524288) return `"${file.name}" is larger than ${Math.round(MAX_SKILL_FILE_BYTES / 1024)} KB — skills hold prompt text, not data dumps.`;
	return null;
}
/** `/name` (max 32 for the body) derived from any text, or null when unusable. */
function triggerFromText(value) {
	const body = value.trim().toLowerCase().replace(/^\//, "").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 32).replace(/-+$/g, "");
	if (!TRIGGER_BODY.test(body)) return null;
	return `/${body}`;
}
/** Human name derived from a file name (`code-review.md` → `code review`). */
function nameFromFileName(fileName) {
	return fileName.replace(/^.*[\\/]/, "").replace(/\.[^.]*$/, "").replace(/[_-]+/g, " ").replace(/\s+/g, " ").trim().slice(0, 60);
}
function asRecord(value) {
	return typeof value === "object" && value !== null ? value : null;
}
/**
* `/create-skill` prints exactly `{"id","trigger","name","instructions"}` — so a
* saved block is the best possible import. Accept the whole object or a single
* element of an array of them.
*/
function parseSkillJson(contents) {
	const trimmed = contents.trim();
	if (!trimmed.startsWith("{") && !trimmed.startsWith("[")) return null;
	let parsed;
	try {
		parsed = JSON.parse(trimmed);
	} catch {
		return null;
	}
	const record = asRecord(Array.isArray(parsed) ? parsed[0] : parsed);
	if (!record) return null;
	const instructions = typeof record.instructions === "string" ? record.instructions : typeof record.body === "string" ? record.body : void 0;
	if (instructions === void 0) return null;
	return {
		trigger: typeof record.trigger === "string" ? record.trigger : void 0,
		name: typeof record.name === "string" ? record.name : void 0,
		instructions
	};
}
/** Optional `---` front matter carrying `name:` / `trigger:` lines. */
function parseFrontMatter(contents) {
	const match = /^---\r?\n([\s\S]*?)\r?\n---\r?\n?([\s\S]*)$/.exec(contents);
	if (!match) return null;
	const values = {};
	for (const line of (match[1] ?? "").split(/\r?\n/)) {
		const separator = line.indexOf(":");
		if (separator <= 0) continue;
		const key = line.slice(0, separator).trim().toLowerCase();
		const value = line.slice(separator + 1).trim().replace(/^["']|["']$/g, "");
		if (key && value) values[key] = value;
	}
	return {
		values,
		body: (match[2] ?? "").trim()
	};
}
/**
* Build a skill draft from a file name and its text.
*
* Precedence: `/create-skill` JSON → YAML front matter → first Markdown
* heading for the name → file name. The trigger always comes from an explicit
* `trigger`/`id` field when one exists, otherwise from the file name.
*/
function skillDraftFromFile(fileName, contents) {
	const notes = [];
	const fallbackName = nameFromFileName(fileName) || "New skill";
	let name = "";
	let trigger = "";
	let body = contents.trim();
	let described = false;
	const json = parseSkillJson(contents);
	if (json) {
		described = true;
		if (json.name?.trim()) {
			name = json.name.trim().slice(0, 60);
			notes.push("Name read from the JSON block.");
		}
		if (json.trigger?.trim()) {
			trigger = triggerFromText(json.trigger) ?? "";
			if (trigger) notes.push("Trigger read from the JSON block.");
		}
		body = (json.instructions ?? "").trim();
		notes.push("Instructions read from the JSON block.");
	} else {
		const front = parseFrontMatter(contents);
		const source = front ? front.values : {};
		if (front) body = front.body;
		if (source.name) {
			name = source.name.slice(0, 60);
			notes.push("Name read from the file's front matter.");
		}
		if (source.trigger || source.id) {
			trigger = triggerFromText(source.trigger ?? source.id ?? "") ?? "";
			if (trigger) notes.push("Trigger read from the file's front matter.");
		}
	}
	if (!name) {
		const heading = /^#{1,3}\s+(.+)$/m.exec(body);
		if (heading?.[1]?.trim()) {
			name = heading[1].trim().slice(0, 60);
			notes.push("Name read from the file's first heading.");
		}
	}
	if (!name) {
		name = fallbackName;
		notes.push("Name taken from the file name.");
	}
	if (!trigger) {
		trigger = triggerFromText(fallbackName) ?? "/skill";
		notes.push("Trigger taken from the file name — change it if you like.");
	}
	if (!body) {
		body = name;
		notes.push("The file had no body text, so the name is the instruction.");
	}
	const truncated = body.length > MAX_INSTRUCTION_CHARS;
	if (truncated) {
		const room = Math.max(0, MAX_INSTRUCTION_CHARS - 33);
		body = `${body.slice(0, room).trimEnd()}${TRUNCATION_MARKER}`;
		notes.push(`The body was cut to ${MAX_INSTRUCTION_CHARS} characters, the skill limit.`);
	}
	if (!described) notes.push("Review the instructions before saving — skills are local prompt playbooks.");
	return {
		trigger,
		name,
		instructions: body,
		notes,
		truncated
	};
}
/**
* V7.7 — the Multi-agent FEATURE panel (Settings → Multi-agent).
*
* Multi-agent is not a skill: there is no /council trigger. This panel owns the
* feature switch, the arm control, and the roster: one row per agent carrying
* the four things a role actually needs — a NAME, a ROLE TYPE (main agent or
* sub-agent), a MODEL, and a SYSTEM PROMPT.
*
* V10.6 — the panel no longer offers any turn-taking control. The run has ONE
* shape: a main agent that leads, delegates when it decides to, and delivers
* the answer; how many turns that takes is the main agent's decision, not a
* number in Settings.
*
* V10.7 — three removals and one addition, all following the same rule: a
* control that does not change what runs does not belong here.
*   • The Mode select is gone. "Collaborate" and "debate" described how the
*     main agent works with its sub-agents, and that is the main agent's own
*     decision — it is what its role prompt is for. The feature is now simply
*     on or off. A saved style from an older version still reads as ON.
*   • The "one model for everyone / one model per agent" switch is gone. It
*     hid each role's model field whenever the shared option was selected, so
*     a role could not say which model runs it. Every role now states its own
*     model, and the two real choices live on the role: Suggested (Oqe picks
*     the installed model that fits) or Enforced (that exact model runs).
*   • The roster-drafting model call is gone entirely: it spent a model call to
*     draft roles the user then edited by hand anyway.
*
* V10.19 — the roster is EDITED AS A DRAFT and committed with one Save.
*   Every keystroke used to write settings immediately, so a half-typed role
*   looked like a role that already existed, and there was no moment that said
*   "this is now saved". Rows are staged here, `Save roles` writes them (with
*   the main agent first), `Discard` restores the saved roster.
*
*   The main agent's model is now ONE select per role — `Suggested — <model>`
*   or any installed model by name — instead of a mode select that had to be
*   switched to "Enforce" before a model could be picked at all. That is the
*   control the reader asked for: pick what the lead runs.
*
*   The main agent always renders above its sub-agents, and saving stores that
*   order, so the list reads lead-then-team everywhere it is drawn.
*/
function MultiAgentPanel() {
	const settings = useAppStore((s) => s.settings);
	const updateSettings = useAppStore((s) => s.updateSettings);
	const models = useAppStore((s) => s.discoveredModels);
	const capabilityCache = useAppStore((s) => s.capabilityCache);
	const runChoice = useAppStore((s) => s.multiAgentChoice);
	const setRunChoice = useAppStore((s) => s.setMultiAgentChoice);
	const council = settings.council;
	const savedRoster = council.roster;
	const savedKey = JSON.stringify(savedRoster);
	const [draft, setDraft] = (0, import_react.useState)(savedRoster);
	const [baseline, setBaseline] = (0, import_react.useState)(savedKey);
	(0, import_react.useEffect)(() => {
		setDraft((current) => JSON.stringify(current) === baseline ? savedRoster : current);
		setBaseline(savedKey);
	}, [
		savedKey,
		baseline,
		savedRoster
	]);
	const dirty = JSON.stringify(draft) !== savedKey;
	const enabledCount = activeRoster(council.roster).length;
	const disabledCount = council.roster.length - enabledCount;
	const ready = council.mode !== "off" && enabledCount >= 2;
	/** The installed models WITH their capability labels — one list, both jobs. */
	const installed = models.map((model) => ({
		id: model.id,
		capabilities: capabilityLabels(model.id, capabilityCache, settings.modelTags)
	}));
	function writeRoster(roster) {
		updateSettings({ council: {
			...council,
			roster
		} });
	}
	/** Commit the draft: the main agent first, then the sub-agents as ordered. */
	function saveRoster() {
		const ordered = leadFirstRoster(draft);
		setDraft(ordered);
		setBaseline(JSON.stringify(ordered));
		writeRoster(ordered);
	}
	function newRole(index, lead) {
		return {
			id: `role-${createId().slice(0, 6)}`,
			name: `Role ${index}`,
			system: "",
			model: "",
			modelMode: "suggested",
			...lead ? { lead: true } : {}
		};
	}
	function addRole() {
		if (draft.length >= 8) return;
		const leadMissing = draft.every((entry) => entry.lead !== true);
		setDraft([...draft, newRole(draft.length + 1, leadMissing)]);
	}
	/**
	* V7.9.1 — the one click that makes the feature runnable. Multi-agent will
	* not run with fewer than two roles, and the roster deliberately starts
	* EMPTY (Oqe ships no personas), so "turn it on" needs a starting roster.
	* These are blank, renamable rows — not shipped personas.
	*/
	function addStarterRoles() {
		const missing = Math.min(Math.max(0, 2 - draft.length), 8 - draft.length);
		if (missing <= 0) return;
		const next = [...draft];
		const leadMissing = next.every((entry) => entry.lead !== true);
		for (let i = 0; i < missing; i += 1) next.push(newRole(next.length + 1, leadMissing && i === 0));
		setDraft(next);
	}
	function setFeatureEnabled(on) {
		updateSettings({ council: {
			...council,
			mode: on ? "on" : "off"
		} });
	}
	function updateRole(index, patch) {
		setDraft(draft.map((entry, i) => i === index ? {
			...entry,
			...patch
		} : entry));
	}
	/** V7.8.4 — mark one role as the main agent; every other role is a sub-agent. */
	function setLeadRole(index, lead) {
		setDraft(draft.map((entry, i) => ({
			...entry,
			lead: i === index ? lead : false
		})));
	}
	function removeRole(id) {
		setDraft(draft.filter((entry) => entry.id !== id));
	}
	const leadCount = draft.filter((entry) => entry.lead === true).length;
	/** Main agent first, then the sub-agents in their stored order. */
	const orderedDraft = leadFirstRoster(draft.map((role, index) => ({
		role,
		index,
		lead: role.lead
	})));
	const heavyWarning = heavyMultipleModelsWarning(draft.map((entry) => resolveRosterModel(entry, installed).model).filter(Boolean));
	const pickerMissing = council.leadPickerModel.trim().length > 0 && models.length > 0 && !models.some((model) => model.id === council.leadPickerModel);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm leading-relaxed text-muted",
			children: "One main agent leads: it writes the reply itself and hands work to a sub-agent when it decides to. A run takes as many turns as the main agent asks for — not a fixed number of passes."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
			id: "multi-agent-enabled",
			label: "Multi-agent",
			description: council.mode === "off" ? "Off — every reply is a single model pass" : enabledCount >= 2 ? "On — armed from here or the composer for one run" : `On — but a run needs two enabled roles (the roster has ${enabledCount})`,
			checked: council.mode !== "off",
			onChange: setFeatureEnabled
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block text-xs font-medium text-muted",
				htmlFor: "multi-agent-between",
				children: ["Sub-agent turns", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					id: "multi-agent-between",
					className: "mt-1.5",
					value: council.betweenAgents,
					onChange: (e) => updateSettings({ council: {
						...council,
						betweenAgents: e.target.value
					} }),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "auto",
						children: "Run straight through"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "pause",
						children: "Pause for me between turns"
					})]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mt-1 block text-meta font-normal leading-snug text-muted",
				children: council.betweenAgents === "pause" ? "You get the last turn and a Continue button before the next one starts." : "The main agent keeps going until it delivers the answer."
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block text-xs font-medium text-muted",
				htmlFor: "multi-agent-lead-picker",
				children: ["What model picks the lead", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					id: "multi-agent-lead-picker",
					className: "mt-1.5",
					value: council.leadPickerModel,
					onChange: (e) => updateSettings({ council: {
						...council,
						leadPickerModel: e.target.value
					} }),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "Off — the main agent marked below leads"
						}),
						pickerMissing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: council.leadPickerModel,
							children: `${council.leadPickerModel} — not installed`
						}) : null,
						models.map((model) => {
							const alias = settings.modelAliases[model.id];
							const caps = capabilityLabels(model.id, capabilityCache, settings.modelTags);
							const capsText = caps.length > 0 ? ` — ${caps.join(", ")}` : "";
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: model.id,
								children: alias ? `${alias} · ${model.id}${capsText}` : `${model.id}${capsText}`
							}, model.id);
						})
					]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mt-1 block text-meta font-normal leading-snug text-muted",
				children: pickerMissing ? `${council.leadPickerModel} is not in the installed list — a run says so and keeps the marked main agent.` : council.leadPickerModel ? "One turn before the first agent: it chooses which roster role leads this message. It never answers the task, and a run that cannot get a clear pick keeps the marked main agent." : "Off: the main agent marked below leads every run. Pick a model to let one choose the lead for each message instead."
			})]
		}),
		council.mode !== "off" && enabledCount < 2 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 rounded-md bg-surface-2 px-3 py-2.5 shadow-[0_0_0_1px_var(--color-border)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs leading-relaxed text-muted",
					role: "status",
					children: disabledCount > 0 ? `Multi-agent is on but cannot be armed yet: ${disabledCount} of ${council.roster.length} roles are switched off, leaving ${enabledCount} enabled, and the run needs at least two enabled roles.` : `Multi-agent is on but cannot be armed yet: the roster has ${enabledCount} role${enabledCount === 1 ? "" : "s"} and the run needs at least two.`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					className: "mt-2",
					onClick: addStarterRoles,
					children: "Add 2 roles"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-meta leading-snug text-muted",
					children: "The rows appear below — press Save roles to keep them."
				})
			]
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 rounded-md bg-surface-2 px-3.5 py-3 shadow-[inset_0_0_0_1px_var(--color-border)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium",
					children: "Run on next send"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					role: "radiogroup",
					"aria-label": "Multi-agent run",
					className: "mt-2 flex flex-wrap gap-1",
					children: MULTI_AGENT_RUN_OPTIONS.map((option) => {
						const selected = runChoice === option.value;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							role: "radio",
							"aria-checked": selected,
							disabled: !ready,
							title: option.help,
							onClick: () => setRunChoice(option.value),
							className: cn("min-h-8 rounded-md px-3 text-label font-medium transition-colors disabled:cursor-not-allowed disabled:opacity-50", selected ? "bg-accent/10 text-accent shadow-[inset_0_0_0_1px_var(--color-accent)]" : "text-muted hover:bg-surface hover:text-fg"),
							children: option.label
						}, option.value);
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-xs leading-relaxed text-muted",
					role: "status",
					children: !ready ? "Needs Multi-agent on and at least two roster roles." : runChoice === "on" ? "On — your next message runs Multi-agent, then this returns to Off." : runChoice === "auto" ? "Auto — Oqe starts the agent group only when a message has many items, or several fields to decide plus more than one kind of work, then checks and repairs its own result before answering." : "Off — one model answers. Choose On for one run, or Auto to let Oqe decide per message."
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-5 border-t border-border pt-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "group-label",
					children: "Roster"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-xs leading-relaxed text-muted",
					children: MULTI_AGENT_MODEL_HELP
				}),
				draft.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 rounded-md bg-surface-2 px-3.5 py-3 text-label leading-relaxed text-muted",
					children: "No roles yet. Add a role below, then press Save roles."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 flex flex-col gap-2",
					children: orderedDraft.map(({ role, index }) => {
						const choice = resolveRosterModel(role, installed);
						const enforcedMissing = choice.source === "enforced" && models.length > 0 && !models.some((model) => model.id === choice.model);
						const suggestion = resolveRosterModel({
							...role,
							modelMode: "suggested",
							model: ""
						}, installed).model;
						const typeLabel = role.lead ? "Main agent" : "Sub-agent";
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "rounded-md bg-surface-2 p-3.5 shadow-[inset_0_0_0_1px_var(--color-border)]",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											id: `roster-${role.id}-name`,
											className: "text-sm",
											value: role.name,
											maxLength: 48,
											placeholder: `Role ${index + 1} name`,
											"aria-label": `Role ${index + 1} name`,
											onChange: (e) => updateRole(index, { name: e.target.value })
										}),
										role.lead ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "shrink-0 rounded-sm bg-accent/10 px-1.5 py-0.5 text-meta text-accent",
											title: "Main agent — it leads, decides which sub-agents to call, and delivers the answer",
											children: "main"
										}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "shrink-0 rounded-sm bg-surface px-1.5 py-0.5 text-meta text-faint shadow-[inset_0_0_0_1px_var(--color-border)]",
											title: "Sub-agent — it answers when the main agent asks it",
											children: "sub"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											size: "sm",
											variant: "danger",
											"aria-label": `Remove ${role.name || `role ${index + 1}`}`,
											onClick: () => removeRole(role.id),
											children: "Remove"
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-1.5 flex",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
										compact: true,
										id: `roster-${role.id}-enabled`,
										label: role.enabled === false ? "Off — kept in the roster, never called" : "On — a run can use this role",
										checked: role.enabled !== false,
										onChange: (on) => updateRole(index, { enabled: on })
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "mt-2 block text-xs font-medium text-muted",
									htmlFor: `roster-${role.id}-type`,
									children: ["Role type", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
										id: `roster-${role.id}-type`,
										className: "mt-1",
										value: role.lead ? "lead" : "sub",
										onChange: (e) => setLeadRole(index, e.target.value === "lead"),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "sub",
											children: "Sub-agent — answers when the main agent asks"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "lead",
											children: "Main agent — leads and delegates to sub-agents"
										})]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "mt-2 block text-xs font-medium text-muted",
									htmlFor: `roster-${role.id}-model`,
									children: ["Model", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
										id: `roster-${role.id}-model`,
										className: "mt-1",
										"aria-label": `${role.name || `Role ${index + 1}`} model`,
										value: role.modelMode === "enforced" ? role.model : "",
										onChange: (e) => {
											const value = e.target.value;
											updateRole(index, value === "" ? {
												modelMode: "suggested",
												model: ""
											} : {
												modelMode: "enforced",
												model: value
											});
										},
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "",
												children: suggestion ? `Suggested — ${suggestion}` : "Suggested — chat model"
											}),
											enforcedMissing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: role.model,
												children: `${role.model} — not installed`
											}) : null,
											models.map((model) => {
												const alias = settings.modelAliases[model.id];
												const caps = capabilityLabels(model.id, capabilityCache, settings.modelTags);
												const capsText = caps.length > 0 ? ` — ${caps.join(", ")}` : "";
												const text = alias ? `${alias} · ${model.id}${capsText}` : `${model.id}${capsText}`;
												return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: model.id,
													children: text
												}, model.id);
											})
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-meta leading-snug text-muted",
									children: role.modelMode === "enforced" ? role.model.trim() ? `This role runs ${role.model}.` : "No model picked yet, so it runs the chat model." : choice.source === "suggested" ? `Oqe runs ${choice.model} for this role.` : "No installed model fits this role, so it runs the chat model."
								}),
								enforcedMissing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-meta leading-snug text-warn",
									role: "status",
									children: `${choice.model} is not in the installed list — this role will run the chat model instead.`
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
									className: "mt-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("summary", {
											className: "cursor-pointer text-xs font-medium text-fg",
											children: [`System prompt — ${typeLabel.toLowerCase()}`, role.system.trim() ? "" : " (empty)"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "mt-2 block text-xs font-medium text-muted",
											htmlFor: `roster-${role.id}-system`,
											children: "System prompt"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
											id: `roster-${role.id}-system`,
											className: "mt-1 text-sm",
											value: role.system,
											placeholder: role.lead ? "How the main agent should lead, delegate and answer" : "What this sub-agent is for, and what it should return",
											onChange: (e) => updateRole(index, { system: e.target.value })
										})
									]
								})
							]
						}, role.id);
					})
				}),
				heavyWarning ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 rounded-md bg-surface-2 px-3 py-2 text-meta leading-relaxed text-warn",
					role: "status",
					children: heavyWarning
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex flex-wrap items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							disabled: !dirty,
							onClick: saveRoster,
							children: "Save roles"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "secondary",
							disabled: !dirty,
							onClick: () => setDraft(savedRoster),
							children: "Discard"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "secondary",
							disabled: draft.length >= 8,
							onClick: addRole,
							children: "Add role"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "secondary",
							disabled: draft.length === 0,
							onClick: () => setDraft([]),
							children: "Clear roster"
						})
					]
				}),
				dirty ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-meta leading-relaxed text-muted",
					role: "status",
					children: "Unsaved role changes — Save roles applies them; a run uses the saved roster."
				}) : null,
				council.mode !== "off" && leadCount === 0 && draft.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-meta leading-relaxed text-warn",
					children: "No main agent marked — set \"Main agent\" on one role above so the run has a lead that delegates and delivers."
				}) : null,
				council.mode !== "off" && leadCount > 0 && activeRoster(draft).length > 0 && activeRoster(draft).every((entry) => entry.lead !== true) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-meta leading-relaxed text-warn",
					role: "status",
					children: "The main agent is switched off — the first enabled role leads the run."
				}) : null
			]
		})
	] });
}
var EMPTY_ROLES = [{
	name: "Lead",
	system: "",
	model: "",
	modelMode: "suggested",
	callable: true
}, {
	name: "",
	system: "",
	model: "",
	modelMode: "suggested",
	callable: true
}];
/**
* V10.37 — MULTI-AGENT SKILLS (Settings → Multi-agent).
*
* A normal skill changes ONE reply. A multi-agent skill is a whole run: it
* carries its own mission, instructions, lead model and roster — including
* reusable snapshots of roles from the roster above.
* The sub-agents it may call are switched on per row; an unchecked role is not
* on the run, so the lead's ASK lines cannot reach it.
*
* It is a DRAFT until Save, for the same reason the roster above is: every
* keystroke writing settings made a half-typed skill look finished.
*/
function MultiAgentSkillsPanel() {
	const skills = useAppStore((s) => s.multiAgentSkills);
	const addMultiAgentSkill = useAppStore((s) => s.addMultiAgentSkill);
	const removeMultiAgentSkill = useAppStore((s) => s.removeMultiAgentSkill);
	const toggleMultiAgentSkill = useAppStore((s) => s.toggleMultiAgentSkill);
	const userSkills = useAppStore((s) => s.userSkills);
	const skillsState = useAppStore((s) => s.skillsState);
	const models = useAppStore((s) => s.discoveredModels);
	const chatModel = useAppStore((s) => s.settings.model);
	const capabilityCache = useAppStore((s) => s.capabilityCache);
	const modelTags = useAppStore((s) => s.settings.modelTags);
	const existingRoles = useAppStore((s) => s.settings.council.roster);
	const usableRoles = activeRoster(existingRoles);
	const [editing, setEditing] = (0, import_react.useState)(null);
	const [trigger, setTrigger] = (0, import_react.useState)("");
	const [mission, setMission] = (0, import_react.useState)("");
	const [instructions, setInstructions] = (0, import_react.useState)("");
	const [leadModel, setLeadModel] = (0, import_react.useState)("");
	const [roles, setRoles] = (0, import_react.useState)(EMPTY_ROLES);
	const [message, setMessage] = (0, import_react.useState)(null);
	const regularSkills = (0, import_react.useMemo)(() => allSkills(userSkills), [userSkills]);
	const linkedSkillsHelp = (instructionsText) => {
		const calledTrigger = referencedSkillTrigger(instructionsText);
		if (!calledTrigger) return null;
		const isRegularEnabled = regularSkills.some((skill) => skill.trigger.toLowerCase() === calledTrigger && skillsState[skill.id]);
		const isMultiEnabled = skills.some((skill) => skill.trigger.toLowerCase() === calledTrigger && skill.enabled);
		return isRegularEnabled || isMultiEnabled ? `Calls enabled skill ${calledTrigger}; it contributes instructions without starting a nested run.` : `${calledTrigger} is missing or disabled. Enable it in Prompts & skills to link it.`;
	};
	const availableModels = (0, import_react.useMemo)(() => models.map((model) => ({
		id: model.id,
		capabilities: capabilityLabels(model.id, capabilityCache, modelTags)
	})), [
		models,
		capabilityCache,
		modelTags
	]);
	const modelOptions = (0, import_react.useMemo)(() => {
		const ids = new Set(models.map((model) => model.id));
		if (chatModel.trim()) ids.add(chatModel.trim());
		for (const skill of skills) {
			if (skill.leadModel.trim()) ids.add(skill.leadModel.trim());
			for (const role of skill.roles) if (role.model.trim()) ids.add(role.model.trim());
		}
		return [...ids].sort((a, b) => a.localeCompare(b));
	}, [
		models,
		chatModel,
		skills
	]);
	function suggestedModel(role) {
		return resolveRosterModel({
			id: role.name,
			name: role.name,
			model: "",
			modelMode: "suggested"
		}, availableModels).model || void 0;
	}
	function resetForm() {
		setEditing(null);
		setTrigger("");
		setMission("");
		setInstructions("");
		setLeadModel("");
		setRoles(EMPTY_ROLES);
	}
	function editSkill(skill) {
		setEditing(skill.id);
		setTrigger(skill.trigger);
		setMission(skill.mission);
		setInstructions(skill.instructions);
		setLeadModel(skill.leadModel);
		setRoles(skill.roles.map((role) => ({ ...role })));
		setMessage(null);
	}
	function setRole(index, patch) {
		setRoles((current) => current.map((role, i) => i === index ? {
			...role,
			...patch
		} : role));
	}
	function existingRoleDraft(role) {
		return {
			sourceRoleId: role.id,
			name: role.name,
			system: role.system,
			model: role.model,
			modelMode: role.modelMode,
			callable: true
		};
	}
	function addExistingRole(role, asLead = false) {
		const alreadyAdded = roles.some((entry) => entry.sourceRoleId === role.id);
		if (asLead) {
			if (roles[0]?.sourceRoleId === role.id) return;
			setRoles((current) => {
				const remaining = current.filter((entry) => entry.sourceRoleId !== role.id);
				const priorLead = remaining[0];
				const subAgents = [...Boolean(priorLead && (priorLead.sourceRoleId || priorLead.name.trim() !== "Lead" || priorLead.system.trim() || priorLead.model.trim())) && priorLead ? [priorLead] : [], ...remaining.slice(1).filter((entry) => entry.name.trim() || entry.sourceRoleId || entry.system.trim())];
				return [existingRoleDraft(role), ...subAgents.slice(0, 7)];
			});
			return;
		}
		if (alreadyAdded) return;
		const emptySubIndex = roles.findIndex((entry, index) => index > 0 && !entry.sourceRoleId && !entry.name.trim());
		if (emptySubIndex >= 0) {
			setRoles((current) => current.map((entry, index) => index === emptySubIndex ? existingRoleDraft(role) : entry));
			return;
		}
		if (roles.length >= 8) return;
		setRoles((current) => [...current, existingRoleDraft(role)]);
	}
	function save() {
		setMessage(null);
		const normalized = normalizeMultiAgentSkill({
			trigger,
			name: trigger,
			mission,
			instructions,
			leadModel,
			roles,
			availableRoles: usableRoles
		});
		if (!normalized.ok) {
			setMessage(normalized.message);
			return;
		}
		const skill = normalized.skill;
		const takenBy = BUILT_IN_SKILLS.some((builtin) => builtin.trigger.toLowerCase() === skill.trigger.toLowerCase()) ? "a built-in skill" : userSkills.some((other) => other.trigger.toLowerCase() === skill.trigger.toLowerCase() && other.id !== editing) ? "a normal skill in Settings → Prompts" : skills.some((other) => other.trigger.toLowerCase() === skill.trigger.toLowerCase() && other.id !== editing) ? "another multi-agent skill" : null;
		if (takenBy) {
			setMessage(`${skill.trigger} is already used by ${takenBy}. Pick another name.`);
			return;
		}
		if (!editing && skills.length >= 12) {
			setMessage(`Keep the list at 12 skills or fewer.`);
			return;
		}
		if (editing && editing !== skill.id) removeMultiAgentSkill(editing);
		const error = addMultiAgentSkill(skill);
		if (error) {
			setMessage(error);
			return;
		}
		setMessage(multiAgentSkillRunnable(skill) ? `Saved ${skill.trigger} — ${skill.roles.filter((r, i) => i === 0 || r.callable).length} agents will run.` : `Saved ${skill.trigger}. It has no callable sub-agent, so it runs as instructions on one model.`);
		resetForm();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-6 border-t border-border pt-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "group-label",
				children: "Multi-agent skills"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1.5 max-w-[64ch] text-xs leading-relaxed text-muted",
				children: [
					"A multi-agent skill runs its own mission, lead model and roster. It can also call one enabled regular skill. Start it with",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-mono text-fg",
						children: "/name"
					}),
					" or write",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "rounded bg-surface-2 px-1 py-0.5 font-mono text-fg",
						children: "use /name skill"
					}),
					". To make a regular skill start a team, set its instructions to call a multi-agent skill."
				]
			}),
			skills.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 flex flex-col gap-2",
				children: skills.map((skill) => {
					const callable = skill.roles.filter((role, index) => index === 0 || role.callable);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-md bg-surface-2 px-3 py-2.5 shadow-[inset_0_0_0_1px_var(--color-border)]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "block truncate text-sm font-medium text-fg",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "mr-2 font-mono text-xs text-accent",
											children: skill.trigger
										}), skill.name !== skill.trigger ? skill.name : null]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "mt-0.5 block truncate text-meta text-muted",
										children: [
											"Lead ",
											skill.roles[0]?.name ?? "—",
											" ·",
											" ",
											callable.length - 1 === 0 ? "no callable sub-agents" : `${callable.length - 1} sub-agent${callable.length - 1 === 1 ? "" : "s"}`,
											" ",
											"· lead",
											" ",
											skill.roles[0]?.modelMode === "enforced" ? skill.roles[0].model || "current chat model" : "suggested"
										]
									}),
									skill.mission ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mt-1 block line-clamp-2 text-xs leading-relaxed text-muted",
										children: skill.mission
									}) : null
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex shrink-0 items-center gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "ghost",
									onClick: () => editSkill(skill),
									children: "Edit"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "danger",
									onClick: () => removeMultiAgentSkill(skill.id),
									children: "Delete"
								})]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 flex items-center justify-between gap-3 border-t border-border/60 pt-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-meta text-muted",
								children: !skill.enabled ? "Disabled — its trigger is ordinary text." : multiAgentSkillRunnable(skill) ? "Runs its own roster." : "Falls back to one model — enable a sub-agent."
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
								compact: true,
								id: `multi-skill-${skill.id}`,
								label: "Enabled",
								checked: skill.enabled,
								onChange: (next) => toggleMultiAgentSkill(skill.id, next)
							})]
						})]
					}, skill.id);
				})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 rounded-md bg-well px-3 py-3 text-xs leading-relaxed text-muted",
				children: [
					"No multi-agent skills yet. The form below makes one — for example",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-mono text-fg",
						children: "/test"
					}),
					": a lead that runs the change and a verifier that hunts for what broke."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 rounded-md bg-surface-2 px-3 py-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-baseline justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
							className: "text-xs font-medium text-fg",
							children: editing ? `Edit ${trigger || "skill"}` : "New multi-agent skill"
						}), editing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "text-meta text-muted underline-offset-2 hover:underline",
							onClick: resetForm,
							children: "Cancel edit"
						}) : null]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "mt-3 block text-xs font-medium text-muted",
						htmlFor: "ma-skill-trigger",
						children: "Name"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "ma-skill-trigger",
						className: "mt-1.5 font-mono sm:max-w-56",
						value: trigger,
						placeholder: "/test",
						spellCheck: false,
						"aria-label": "Multi-agent skill name — the /trigger that runs it",
						onChange: (event) => setTrigger(event.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "mt-3 block text-xs font-medium text-muted",
						htmlFor: "ma-skill-mission",
						children: "Mission — what this run is for"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						id: "ma-skill-mission",
						className: "mt-1.5 min-h-20 text-sm",
						value: mission,
						maxLength: MAX_MA_MISSION_CHARS,
						placeholder: "Verify the change actually behaves correctly, then report every flaw for a redo.",
						onChange: (event) => setMission(event.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "mt-3 block text-xs font-medium text-muted",
						htmlFor: "ma-skill-instructions",
						children: "Instructions — how the run behaves"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						id: "ma-skill-instructions",
						className: "mt-1.5 text-sm",
						value: instructions,
						maxLength: MAX_MA_INSTRUCTIONS_CHARS,
						placeholder: "Run the build and tests, exercise the real surface, and fix what fails before reporting.",
						onChange: (event) => setInstructions(event.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-meta text-muted",
						children: [
							instructions.length,
							"/",
							MAX_MA_INSTRUCTIONS_CHARS,
							" characters. Mission and instructions go to the lead; each sub-agent gets its own prompt below."
						]
					}),
					linkedSkillsHelp(instructions) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-meta leading-relaxed text-muted",
						role: "status",
						children: linkedSkillsHelp(instructions)
					}) : null,
					referencedSkillTrigger(instructions) ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-meta leading-relaxed text-muted",
						children: "To call another skill, add “use /trigger skill” to these instructions."
					}),
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "mt-3 block text-xs font-medium text-muted",
						htmlFor: "ma-skill-model",
						children: "Legacy skill-wide model — leave unset to choose each role below"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						id: "ma-skill-model",
						className: "mt-1.5",
						value: leadModel,
						onChange: (event) => setLeadModel(event.target.value),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "Use each role's model choice below"
						}), modelOptions.map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: id,
							children: id
						}, id))]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-meta leading-relaxed text-muted",
						children: "This older skill-wide setting is only a fallback for saved skills. Choose a model separately for the lead and each sub-agent below."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex items-center justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
							className: "text-xs font-medium text-fg",
							children: "Roster — shared and skill-only roles"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-meta text-muted",
							children: [
								roles.length,
								"/",
								8
							]
						})]
					}),
					usableRoles.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 rounded-md bg-well px-3 py-2.5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-medium text-fg",
								children: "Use an existing role"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-0.5 text-meta leading-relaxed text-muted",
								children: "Add a saved role as a prompt snapshot, then choose its model for this skill independently."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-2 flex flex-wrap gap-2",
								children: usableRoles.map((role) => {
									const added = roles.some((entry) => entry.sourceRoleId === role.id);
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-wrap gap-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											size: "sm",
											variant: "secondary",
											disabled: added || roles.length >= 8,
											onClick: () => addExistingRole(role),
											children: added ? `Added ${role.name}` : `Add ${role.name} as sub-agent`
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											size: "sm",
											variant: "ghost",
											disabled: roles[0]?.sourceRoleId === role.id,
											onClick: () => addExistingRole(role, true),
											children: roles[0]?.sourceRoleId === role.id ? "Selected lead" : `Use ${role.name} as lead`
										})]
									}, role.id);
								})
							})
						]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-2 flex flex-col gap-2",
						children: roles.map((role, index) => {
							const isLead = index === 0;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: cn("rounded-md bg-well px-2.5 py-2 shadow-[inset_0_0_0_1px_var(--color-border)]", isLead && "shadow-[inset_0_0_0_1px_rgb(255_179_71_/_0.35)]"),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between gap-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: cn("rounded px-1.5 py-0.5 text-meta font-medium", isLead ? "bg-accent/15 text-accent" : "bg-surface-2 text-muted"),
												children: isLead ? "Lead" : `Sub-agent ${index}`
											}),
											role.sourceRoleId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-meta text-muted",
												children: "Settings prompt snapshot"
											}) : null,
											isLead ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-meta text-muted",
													children: "Opens and closes the run"
												}), index === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
													size: "sm",
													variant: "ghost",
													"aria-label": "Remove lead role",
													onClick: () => setRoles((current) => current.slice(1)),
													children: "Remove"
												}) : null]
											}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
													compact: true,
													id: `ma-role-${index}-callable`,
													label: "Can be called",
													checked: role.callable,
													onChange: (next) => setRole(index, { callable: next })
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
													size: "sm",
													variant: "ghost",
													"aria-label": `Remove sub-agent ${index}`,
													onClick: () => setRoles((current) => current.filter((_, i) => i !== index)),
													children: "Remove"
												})]
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										className: "mt-1.5",
										value: role.name,
										placeholder: isLead ? "Lead" : "Verifier",
										"aria-label": isLead ? "Lead role name" : `Sub-agent ${index} name`,
										onChange: (event) => setRole(index, {
											name: event.target.value,
											sourceRoleId: void 0
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "mt-2 block text-xs font-medium text-muted",
										htmlFor: `ma-role-${index}-model`,
										children: [
											"Model",
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
												id: `ma-role-${index}-model`,
												className: "mt-1",
												"aria-label": `${role.name || (isLead ? "Lead" : `Sub-agent ${index}`)} model`,
												value: role.modelMode === "enforced" ? role.model : "",
												onChange: (event) => {
													const value = event.target.value;
													setRole(index, value ? {
														model: value,
														modelMode: "enforced",
														sourceRoleId: void 0
													} : {
														model: "",
														modelMode: "suggested",
														sourceRoleId: role.sourceRoleId
													});
												},
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
														value: "",
														children: suggestedModel(role) ? `Suggested — ${suggestedModel(role)}` : "Suggested — current chat model"
													}),
													role.modelMode === "enforced" && role.model && !models.some((model) => model.id === role.model) ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
														value: role.model,
														children: [role.model, " — not installed"]
													}) : null,
													modelOptions.map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
														value: id,
														children: id
													}, id))
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "mt-1 block text-meta font-normal text-muted",
												children: "Choose Suggested to let Oqe pick the best installed model for this role, or select a model to pin it."
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
										className: "mt-1.5 min-h-14 text-xs",
										value: role.system,
										maxLength: MAX_MA_ROLE_SYSTEM_CHARS,
										placeholder: isLead ? "Optional. Added after the mission and instructions." : "What this sub-agent is for, and what it must not do.",
										"aria-label": isLead ? "Lead role prompt" : `Sub-agent ${index} prompt`,
										onChange: (event) => setRole(index, {
											system: event.target.value,
											sourceRoleId: void 0
										})
									})
								]
							}, index);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 flex flex-wrap items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "secondary",
							disabled: roles.length >= 8,
							onClick: () => setRoles((current) => [...current, {
								name: "",
								system: "",
								model: "",
								modelMode: "suggested",
								callable: true
							}]),
							children: "Add sub-agent"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "primary",
							onClick: save,
							children: editing ? "Save changes" : "Save skill"
						})]
					}),
					message ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-xs leading-relaxed text-muted",
						role: "status",
						children: message
					}) : null,
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-meta leading-relaxed text-muted",
						children: "A sub-agent switched off is not on the run, so the lead cannot call it. Save writes this skill only — your roster above and your Settings are never changed."
					})
				]
			})
		]
	});
}
/**
* V10.15 — the capability tags, editable per model.
* V10.18 — five of them: Desktop control joins Tool calls / Reasoning / Code /
* Vision, and is deliberately NOT the vision tag (see model-capabilities.ts).
*
* A tag's state comes from the runtime's own metadata first, then from the
* app's family research. The reader has the last word: one click forces the
* opposite of what is shown, and a second click returns it to automatic. The
* chip says which it is (`· you`), so a hand-set tag can never be mistaken for
* something the runtime declared.
*/
function ModelTagEditor({ modelId, className }) {
	const settings = useAppStore((s) => s.settings);
	const capabilityCache = useAppStore((s) => s.capabilityCache);
	const updateSettings = useAppStore((s) => s.updateSettings);
	const id = modelId.trim();
	if (!id) return null;
	const tags = resolveModelTags(id, settings.modelTags, capabilityCache);
	function edit(tag) {
		updateSettings({ modelTags: toggleModelTag(settings.modelTags, id, tag) });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		role: "group",
		"aria-label": `Capability tags for ${id}`,
		className: cn("flex flex-wrap items-center gap-1.5", className),
		children: tags.map((tag) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			"aria-pressed": tag.on,
			title: `${tag.detail} Click to ${tag.origin === "you" ? "return to automatic" : tag.on ? "turn it off" : "turn it on"}.`,
			onClick: () => edit(tag),
			className: cn("inline-flex items-center rounded-sm px-2 py-1 text-meta leading-4 transition-colors", tag.on ? "bg-accent/10 font-medium text-accent shadow-[inset_0_0_0_1px_var(--color-accent)]" : "text-muted shadow-[inset_0_0_0_1px_var(--color-border)] hover:text-fg"),
			children: [tag.label, tag.origin === "you" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "ml-1 opacity-70",
				children: "· you"
			}) : tag.origin === "guess" || tag.origin === "none" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "ml-1 opacity-50",
				children: "?"
			}) : null]
		}, tag.name))
	});
}
/**
* V10.5 — Settings → Appearance.
*
* Everything here changes the interface itself and is wired to something real:
* three of the four write a data attribute on `<html>` that the theme in
* src/styles.css reacts to (see src/lib/appearance.ts), and the cursor choice
* is read by the two surfaces that own a pointer. Nothing on this panel is
* decoration dressed as a setting.
*
* The character preview is the SAME component the app renders elsewhere, so
* turning the orb's animation off is visible here immediately — the preview is
* evidence, not an illustration.
*/
function AppearancePanel({ category }) {
	const settings = useAppStore((s) => s.settings);
	const updateSettings = useAppStore((s) => s.updateSettings);
	const shipped = settings.reduceMotion === DEFAULT_SETTINGS.reduceMotion && settings.orbAnimation === DEFAULT_SETTINGS.orbAnimation && settings.orbCursor === DEFAULT_SETTINGS.orbCursor && settings.compactMessages === DEFAULT_SETTINGS.compactMessages;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "settings-appearance",
		className: cn("settings-panel scroll-mt-20", category !== "appearance" && "hidden"),
		"aria-labelledby": "settings-appearance-heading",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				id: "settings-appearance-heading",
				className: "text-base font-semibold tracking-[-0.012em]",
				children: "Appearance"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 flex items-center justify-center rounded-md bg-well bg-[radial-gradient(circle_at_50%_46%,rgb(255_179_71_/_0.07),transparent_62%)] px-3 py-5 shadow-[inset_0_0_0_1px_var(--color-border)]",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OqeCharacter, { className: "size-16" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
				id: "appearance-reduce-motion",
				label: "Reduce motion",
				description: "Stops all motion, including the orb's blink",
				checked: settings.reduceMotion,
				onChange: (reduceMotion) => updateSettings({ reduceMotion })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
				id: "appearance-orb-animation",
				label: "Animate the orb",
				description: settings.reduceMotion ? "Unavailable while Reduce motion is on — turn that off to animate the orb" : "Blinks on its own, glows while a task runs",
				checked: settings.orbAnimation,
				onChange: (orbAnimation) => updateSettings({ orbAnimation }),
				disabled: settings.reduceMotion
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
				id: "appearance-orb-cursor",
				label: "Show Oqe's own cursor",
				description: "Marks the surface Oqe is working, with its last action",
				checked: settings.orbCursor,
				onChange: (orbCursor) => updateSettings({ orbCursor })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
				id: "appearance-compact-messages",
				label: "Compact transcript",
				description: "Tighter spacing between turns, same text size",
				checked: settings.compactMessages,
				onChange: (compactMessages) => updateSettings({ compactMessages })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 flex flex-wrap items-center gap-3 border-t border-border pt-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					disabled: shipped,
					onClick: () => updateSettings({
						reduceMotion: DEFAULT_SETTINGS.reduceMotion,
						orbAnimation: DEFAULT_SETTINGS.orbAnimation,
						orbCursor: DEFAULT_SETTINGS.orbCursor,
						compactMessages: DEFAULT_SETTINGS.compactMessages
					}),
					children: "Reset to shipped appearance"
				})
			})
		]
	});
}
function formatTokens(tokens) {
	return `${tokens.toLocaleString()} tokens`;
}
/** Why a climb ended, in the panel's words. */
var STOP_REASON_LABELS = {
	edge: "stopped at the first window that failed",
	"model-limit": "stopped at the model's advertised window",
	device: "stopped at this machine's memory guard rail",
	time: "stopped because the next step would take too long"
};
function formatWhen(at) {
	if (!Number.isFinite(at) || at <= 0) return "at an unknown time";
	return new Date(at).toLocaleString();
}
/**
* V10.11 — Settings → Context.
*
* The reader's rule: the context window that matters is the one this DEVICE
* can actually run, not the one the model advertises — and once the request
* reaches a chosen share of it, older material should be shortened, dropped,
* or held as a note for later.
*
* Every number on this panel comes from a probe that really ran (or from the
* runtime's own /api/tags report). A run that fails stores nothing, and the
* panel says so rather than showing a guess as a limit.
*/
function ContextPanel({ category }) {
	const settings = useAppStore((s) => s.settings);
	const updateSettings = useAppStore((s) => s.updateSettings);
	const stress = useAppStore((s) => s.contextStress);
	const runStress = useAppStore((s) => s.runContextStressTest);
	const cancelStress = useAppStore((s) => s.cancelContextStressTest);
	const refreshModelClasses = useAppStore((s) => s.refreshModelClasses);
	const clearMeasurement = useAppStore((s) => s.clearContextMeasurement);
	(0, import_react.useEffect)(() => {
		refreshModelClasses();
	}, [
		refreshModelClasses,
		settings.localAddress,
		settings.mode
	]);
	const capacity = (0, import_react.useMemo)(() => resolveContextCapacityWithLimits(settings.model, settings.contextLimits), [settings.model, settings.contextLimits]);
	const measured = measuredCapacityFor(settings.contextLimits, settings.model);
	const classRecord = modelClassRecordFor(settings.contextLimits, settings.model);
	const optimizeAt = coerceContextOptimizeAt(settings.contextOptimizeAt);
	const optimizeTrigger = optimizeAtTrigger(capacity.tokens, optimizeAt);
	const optimizeChars = optimizeTrigger.chars;
	const measuredModels = Object.values(settings.contextLimits.models).sort((a, b) => b.testedAt - a.testedAt);
	const selectedMeasurement = settings.contextLimits.models[settings.model];
	const running = Boolean(stress?.running);
	const canRun = settings.mode === "local" && Boolean(settings.model.trim()) && !running;
	const reuse = (0, import_react.useMemo)(() => classMeasurementReuse(settings.contextLimits, settings.model, classRecord?.nominalTokens), [
		settings.contextLimits,
		settings.model,
		classRecord?.nominalTokens
	]);
	const classLimit = reuse.reuse ? reuse.limit : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "settings-context",
		className: cn("settings-panel scroll-mt-20", category !== "context" && "hidden"),
		"aria-labelledby": "settings-context-heading",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				id: "settings-context-heading",
				className: "text-base font-semibold tracking-[-0.012em]",
				children: "Context"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 max-w-[60ch] text-sm leading-relaxed text-muted",
				children: "Measure the window this machine can actually run, then choose how full it may get before older material is compacted."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 rounded-md bg-well px-3.5 py-3 shadow-[inset_0_0_0_1px_var(--color-border)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "group-label",
						children: "Current model"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1.5 truncate font-mono text-sm text-fg",
						title: settings.model || void 0,
						children: settings.model.trim() || "none selected"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-2 grid grid-cols-[auto_minmax(0,1fr)] gap-x-4 gap-y-1 text-xs",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "Usable window"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "readout text-signal",
								children: formatTokens(capacity.tokens)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "Source"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "text-fg",
								children: capacity.source === "measured" ? capacity.confidence === "verified" ? "measured on this device" : "measurement on file" : capacity.source === "category" ? "parameter-class ceiling" : capacity.source === "configured" ? "configured" : "conservative estimate"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "Confidence"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "text-fg",
								children: capacityConfidenceLabel(capacity)
							}),
							selectedMeasurement ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-muted",
									children: "Measured for"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "truncate font-mono text-fg",
									title: selectedMeasurement.model,
									children: selectedMeasurement.model
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-muted",
									children: "Measured host"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "truncate font-mono text-fg",
									title: measurementHostLabel(selectedMeasurement),
									children: measurementHostLabel(selectedMeasurement)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-muted",
									children: "Current host"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "truncate font-mono text-fg",
									title: settings.contextLimits.hostIdentity ?? settings.contextLimits.hostOrigin ?? "not observed",
									children: settings.contextLimits.hostIdentity ?? settings.contextLimits.hostOrigin ?? "not observed"
								}),
								checkMeasuredCapacity(settings.contextLimits, settings.model) ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-muted",
									children: "Measurement status"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "text-danger",
									children: "Not measured on the current host"
								})] })
							] }) : null,
							classRecord ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "Size class"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
								className: "text-fg",
								children: [parameterClassLabel(classRecord.parameterClass), classRecord.parameterSize ? ` · ${classRecord.parameterSize}` : ""]
							})] }) : null,
							classRecord?.nominalTokens ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "Model advertises"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "text-fg",
								children: formatTokens(classRecord.nominalTokens)
							})] }) : null,
							measured ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "Last measured"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "text-fg",
								children: formatWhen(measured.testedAt)
							})] }) : null
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-xs leading-relaxed text-muted",
						children: capacity.note
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 border-t border-border pt-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "group-label",
						children: "Stress test"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1.5 max-w-[60ch] text-xs leading-relaxed text-muted",
						children: "Sends a prompt with a code at its start and asks the model to repeat it, then doubles the window and tries again — as high as the window goes, with no ceiling to choose. It stops at the first failure, at the window the model advertises, or at this machine's guard rail, whichever comes first. A window only counts if the runtime evaluated the prompt and the model still had the code — a truncated request cannot fake either. A failed run stores nothing."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1.5 max-w-[60ch] text-xs leading-relaxed text-muted",
						children: [
							"Results are stored per size class as well as per model, because two models of the same size are climbing the same window on this device. The climb starts at",
							" ",
							formatTokens(512),
							"; the model runs at full tilt while it measures, so the fans may get louder for a few minutes."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex flex-wrap items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "primary",
								disabled: !canRun,
								onClick: () => void runStress(),
								children: running ? "Measuring…" : "Run stress test"
							}),
							running ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								onClick: cancelStress,
								children: "Cancel"
							}) : null,
							!running && classLimit ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								onClick: () => void runStress({ force: true }),
								children: "Measure this model anyway"
							}) : null
						]
					}),
					!running && classLimit ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-xs leading-relaxed text-muted",
						children: [
							"Nothing to run: ",
							reuse.reason,
							". The stored class ceiling is used unless you measure this model anyway."
						]
					}) : null,
					settings.mode !== "local" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-xs text-muted",
						children: "Local mode only — this measures this device's Ollama, not a provider's window."
					}) : !settings.model.trim() ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-xs text-muted",
						children: "Choose a model first."
					}) : null,
					stress ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 rounded-md bg-surface-2 px-3 py-2.5",
						children: [
							stress.error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs leading-relaxed text-danger",
								children: stress.error
							}) : null,
							stress.note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs leading-relaxed text-fg",
								children: stress.note
							}) : null,
							stress.probes.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-2 flex flex-col gap-1",
								children: stress.probes.map((probe, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "grid grid-cols-[auto_auto_minmax(0,1fr)] items-baseline gap-2 text-meta",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: cn("readout text-meta", probe.ok ? "text-signal" : "text-danger"),
											children: probe.ok ? "pass" : "fail"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "readout text-muted",
											children: formatTokens(probe.tokens)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "leading-snug text-muted",
											children: probe.note
										})
									]
								}, `${probe.tokens}-${index}`))
							}) : null
						]
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 border-t border-border pt-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "group-label",
						children: "Optimize at"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 flex items-baseline gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "readout text-lg text-signal",
							children: [optimizeAt, "%"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-muted",
							children: optimizeTrigger.capped ? `→ ≈ ${optimizeChars.toLocaleString()} characters (${optimizeTrigger.effectiveWindowPercent}% of the window) — the most this window can send` : `≈ ${optimizeChars.toLocaleString()} characters of a ${formatTokens(capacity.tokens)} window`
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: "context-optimize-at",
						type: "range",
						className: "mt-2 w-full accent-[var(--color-accent)]",
						min: 20,
						max: 95,
						step: 5,
						value: optimizeAt,
						"aria-label": "Optimization trigger as a percentage of the measured window",
						onChange: (event) => updateSettings({ contextOptimizeAt: Number(event.target.value) })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1.5 max-w-[60ch] text-xs leading-relaxed text-muted",
						children: "When a request would pass this share, older material is compacted before sending: exact duplicates and finished task chatter are removed, superseded page dumps and long old turns keep a marked head and tail, and a note of what left is kept with the thread (Context control → Kept for later). Nothing the current request depends on is touched."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 border-t border-border pt-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "group-label",
						children: "Measured models"
					}),
					measuredModels.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1.5 text-xs leading-relaxed text-muted",
						children: "Nothing measured yet on this device. Until a stress test runs, requests are planned against the conservative estimate and compacted at the trigger above."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-2 flex flex-col gap-1.5",
						children: measuredModels.map((entry) => {
							const identity = checkMeasuredCapacity(settings.contextLimits, entry.model)?.identity;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex flex-wrap items-center justify-between gap-2 rounded-md bg-surface-2 px-3 py-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "min-w-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block truncate font-mono text-xs text-fg",
										children: entry.model
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "mt-0.5 block text-meta text-muted",
										children: [
											formatTokens(entry.tokens),
											" ·",
											" ",
											entry.stopReason ? `${STOP_REASON_LABELS[entry.stopReason]} · ` : "",
											entry.parameterClass ? parameterClassLabel(entry.parameterClass) : "size not reported",
											" ·",
											" ",
											formatWhen(entry.testedAt),
											" · ",
											identity === "verified" ? "digest verified" : identity === "stale" ? "digest changed — NOT used, re-run the stress test" : identity === void 0 ? "not measured on the current Ollama host — NOT used" : "digest unverified",
											" · ",
											measurementHostLabel(entry)
										]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "danger",
									onClick: () => clearMeasurement(entry.model),
									title: "Forget this measurement; the next budget falls back to the estimate",
									children: "Forget"
								})]
							}, entry.model);
						})
					}),
					PARAMETER_CLASS_ORDER.some((name) => settings.contextLimits.categories[name]) ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "group-label",
								children: "Class ceilings"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-1.5 flex flex-col gap-1",
								children: PARAMETER_CLASS_ORDER.map((name) => {
									const limit = settings.contextLimits.categories[name];
									if (!limit) return null;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "grid grid-cols-[auto_minmax(0,1fr)] items-baseline gap-2 text-xs",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "readout text-signal",
											children: formatTokens(limit.tokens)
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-muted",
											children: [
												parameterClassLabel(name),
												" — smallest of ",
												limit.sampleCount,
												" measured",
												limit.sampleCount === 1 ? " model" : " models",
												limit.model ? ` (${limit.model})` : "",
												limit.stopReason ? `, ${STOP_REASON_LABELS[limit.stopReason]}` : ""
											]
										})]
									}, name);
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1.5 text-meta leading-relaxed text-muted",
								children: "An unmeasured model whose runtime-reported size falls in one of these classes uses that ceiling. It never overrides a model's own measurement. A ceiling that stopped at one model's advertised window is only reused by peers that advertise no more — a peer with a bigger advertised window is climbed on its own."
							})
						]
					}) : null
				]
			})
		]
	});
}
/**
* Prompt 34 — Settings → Prompts: the work-profile selector.
*
* The five profiles ship in the repo (`profiles.ts`), so this panel chooses and
* explains; it does not author prompt text. Three things are shown for each
* profile so the reader knows what they are picking: the one-line shape, the
* stages it works through, and the fact that it grants nothing. The composed
* block is rendered read-only below — the same text `promptTurns` sends, so the
* page cannot describe a request that is not the one made.
*
* The control itself is not a permission switch and is deliberately NOT in the
* access/companion area: switching to Product Research must never read as
* "now it may publish something".
*/
function ProfilePanel({ category }) {
	const settings = useAppStore((s) => s.settings);
	const updateSettings = useAppStore((s) => s.updateSettings);
	const active = profileFor(settings.profile);
	const activeBlock = profileTurnContent(settings.profile);
	function choose(id) {
		updateSettings({ profile: id });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "settings-profile",
		className: cn("settings-panel scroll-mt-20 rounded-lg bg-surface p-4 shadow-[0_0_0_1px_var(--color-border)]", category !== "prompts" && "hidden"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-sm font-medium",
				children: "Profile"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: "How Oqe works on your next message — not what it may reach."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1.5 text-meta leading-relaxed text-muted",
				children: "The active profile is added to the request as one instruction block, behind your System prompt. It cannot enable browsing, desktop control, the companion, file access or an account action, and it cannot raise a permission: those stay exactly where they are, in Access and Computer control. Switching keeps this conversation, your draft and every other setting unchanged."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				role: "radiogroup",
				"aria-label": "Work profile",
				className: "mt-3 grid gap-1.5",
				children: PROFILES.map((profile) => {
					const selected = settings.profile === profile.id;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						role: "radio",
						"aria-checked": selected,
						id: `profile-${profile.id}`,
						onClick: () => choose(profile.id),
						className: cn("rounded-md px-3 py-2.5 text-left transition-colors", selected ? "bg-accent/10 shadow-[inset_0_0_0_1px_var(--color-accent)]" : "bg-surface-2 shadow-[inset_0_0_0_1px_var(--color-border)] hover:bg-surface"),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: cn("text-sm font-medium", selected ? "text-accent" : "text-fg"),
									children: profile.name
								}), selected ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "shrink-0 rounded-sm bg-accent/10 px-1.5 py-0.5 text-meta text-accent",
									children: "active"
								}) : null]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-0.5 block text-xs leading-relaxed text-muted",
								children: profile.short
							}),
							profile.workflow.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-1 block text-meta leading-relaxed text-muted",
								children: profile.workflow.join(" → ")
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-1 block text-meta leading-relaxed text-muted",
								children: "No extra instruction — ordinary chat, unchanged."
							})
						]
					}, profile.id);
				})
			}),
			active.id === "planner" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 rounded-md bg-well px-3 py-2.5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium text-fg",
						children: "A plan must contain"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-1 list-disc pl-4 text-meta leading-relaxed text-muted",
						children: PLAN_SECTIONS.map((section) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: section }, section))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-meta leading-relaxed text-muted",
						children: "Executed work is tracked in the task queue and its checkpoints; an unexecuted plan stays in the conversation and is never reported as done."
					})
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
				className: "mt-3",
				open: false,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
					className: "cursor-pointer text-xs font-medium text-fg",
					children: activeBlock ? `What this profile adds to the request (${active.name})` : `What ${active.name} adds to the request`
				}), activeBlock ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-meta leading-relaxed text-muted",
					children: "One line is the app's own boundary note; the rest is the profile's instructions. Both are shown exactly as they are sent."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
					id: "profile-instruction",
					"aria-readonly": "true",
					"aria-label": "Profile instruction block",
					className: "mt-2 max-h-72 overflow-auto rounded-md bg-surface-2 p-3 font-mono text-meta leading-relaxed whitespace-pre-wrap text-fg shadow-[0_0_0_1px_var(--color-border)]",
					children: activeBlock
				})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-xs leading-relaxed text-muted",
					children: "General adds nothing at all, so an ordinary reply is composed exactly as it would be with no profile chosen."
				})]
			})
		]
	});
}
/**
* Prompt 46 — Settings → Output.
*
* WHAT THIS PANEL IS. One switch per renderer this build actually has, one switch for
* whether a reply may choose a visual form at all, and one for whether a job that would
* start an engine may begin without asking. Nothing here grants a permission, and the panel
* says so where a reader might assume otherwise.
*
* WHAT IT DELIBERATELY DOES NOT HAVE:
*  - a switch for a type this build cannot draw. The rows come from the renderer registry,
*    so a missing renderer cannot appear as an option;
*  - a switch for image GENERATION. That capability is unavailable in this build, so it is
*    a status line carrying Prompt 38's own sentence — not a control that would imply an
*    engine is installed;
*  - a second "text only" switch. Turning automatic output off IS text only, and the row
*    says so in those words; two controls that always move together would be one lie.
*/
function OutputPanel({ category }) {
	const settings = useAppStore((s) => s.settings);
	const updateSettings = useAppStore((s) => s.updateSettings);
	const output = settings.output;
	const groups = (0, import_react.useMemo)(() => outputSettingsGroups(output), [output]);
	const counts = (0, import_react.useMemo)(() => enabledOutputCount(output), [output]);
	const generation = (0, import_react.useMemo)(() => imageGenerationStatus({
		imageProvider: settings.imageProvider,
		imageProviderEndpoint: settings.imageProviderEndpoint
	}), [settings.imageProvider, settings.imageProviderEndpoint]);
	const transientHours = Math.max(1, Math.round(TRANSIENT_ARTIFACT_TTL_MS / 36e5));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "settings-output",
		className: cn("settings-panel scroll-mt-20", category !== "output" && "hidden"),
		"aria-labelledby": "settings-output-heading",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				id: "settings-output-heading",
				className: "text-base font-semibold tracking-[-0.012em]",
				children: "Output"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 max-w-[60ch] text-sm leading-relaxed text-muted",
				children: "What a reply may draw in this conversation. These are display choices: nothing here grants browsing, desktop control, code execution or file access — those are separate permissions on their own pages."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 rounded-md bg-well px-3.5 py-3 shadow-[inset_0_0_0_1px_var(--color-border)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-baseline justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "group-label",
						children: "Right now"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "readout text-meta text-signal",
						children: output.autoSelect ? `${counts.enabled} of ${counts.total} on` : "text only"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1.5 text-meta leading-relaxed text-muted",
					children: output.autoSelect ? "A reply may use any form you have left on. Anything it asks for that is off, unavailable or malformed is shown as one sentence instead of breaking the reply." : "Text only. Your saved per-type choices are kept: turn automatic output back on and they apply again."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
				id: "output-auto-select",
				label: "Automatic output",
				description: "On: a reply may choose among the forms you leave on. Off: every reply is read as text — there is no second switch for this.",
				checked: output.autoSelect,
				onChange: (checked) => updateSettings({ output: {
					...output,
					autoSelect: checked
				} })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
				id: "output-ask-expensive",
				label: "Ask before expensive generation",
				description: `Only for a job that would start an engine, download model weights, leave this machine, or run long enough to make you wait: ${EXPENSIVE_OUTPUT_JOBS.join(", ")}. Charts, diagrams, tables, simulations and 3D models are computed here in milliseconds, so they never ask.`,
				checked: output.askBeforeExpensive,
				onChange: (checked) => updateSettings({ output: {
					...output,
					askBeforeExpensive: checked
				} })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-5 space-y-4",
				children: groups.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-md bg-well px-3.5 py-3 shadow-[inset_0_0_0_1px_var(--color-border)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "group-label",
							children: group.label
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-0.5 text-meta text-faint",
							children: group.detail
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 divide-y divide-border/40",
							children: group.rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
								id: `output-${row.capability.replace(/\./g, "-")}`,
								label: row.label,
								description: row.detail,
								checked: row.enabled,
								disabled: !output.autoSelect,
								onChange: (enabled) => updateSettings({ output: withOutputCapability(output, row.capability, enabled) })
							}, row.capability))
						})
					]
				}, group.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-meta leading-relaxed text-faint",
				children: "Text is always shown: it is the fallback every other type degrades to, so it has no switch."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 rounded-md bg-well px-3.5 py-3 shadow-[inset_0_0_0_1px_var(--color-border)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-baseline justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "group-label",
							children: "Image generation"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "readout text-meta text-warn",
							children: generation.state === "available" ? "available" : "not available"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1.5 text-meta leading-relaxed text-muted",
						children: generation.detail
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-meta leading-relaxed text-faint",
						children: [
							"Engine: ",
							generation.provider,
							". This build has no image-generation control to offer until an engine is installed and a real generation has succeeded; showing an image that already exists is the “Images” switch above, which is a different thing."
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 rounded-md bg-well px-3.5 py-3 shadow-[inset_0_0_0_1px_var(--color-border)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "group-label",
					children: "Files and pictures"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1.5 text-meta leading-relaxed text-muted",
					children: [
						"An artifact starts temporary — removed within ",
						transientHours,
						" hour",
						transientHours === 1 ? "" : "s",
						" unless you save it. Saving is the control: a file you save stays on this machine until you delete it, and a download is only offered after you press the button that creates it."
					]
				})]
			})
		]
	});
}
var TONE = {
	IMPLEMENTED: "text-success bg-success/10",
	"VERIFIED BY TEST": "text-success bg-success/10",
	"USER-SUPPLIED EVIDENCE": "text-accent bg-user",
	"DESIGN PROPOSAL": "text-muted bg-surface-2",
	DISABLED: "text-danger bg-danger/10",
	"MISSING/UNRECOVERED": "text-muted bg-surface-2",
	"REQUIRES DEVICE/LAPTOP VALIDATION": "text-warn bg-warn/10"
};
/**
* V10.32 — the evidence status used to be printed in the ALL-CAPS wire format it
* is stored in, with wide tracking. That is an internal enum shouted at the
* reader: it made every evidence row look like a stamped certificate and made
* the page's real finding (what was verified) compete with its own label style.
* The stored values stay exactly as they are — this is the display layer.
*/
var LABEL = {
	IMPLEMENTED: "Implemented",
	"VERIFIED BY TEST": "Verified by test",
	"USER-SUPPLIED EVIDENCE": "User-supplied evidence",
	"DESIGN PROPOSAL": "Design proposal",
	DISABLED: "Disabled",
	"MISSING/UNRECOVERED": "Missing or unrecovered",
	"REQUIRES DEVICE/LAPTOP VALIDATION": "Requires device validation"
};
function StatusBadge({ status }) {
	const tone = TONE[status] ?? "text-muted bg-surface-2";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex max-w-full items-center rounded-sm px-2 py-0.5 text-meta font-medium", tone),
		children: LABEL[status] ?? status
	});
}
/**
* V7.9.1 — plain-language reading of the last display check the watch actually
* performed. Only real observed state is described: nothing is reported before
* the first poll, and the count comes from the stored signature itself.
*/
function describeProjectorDisplays(sig, stabilitySeconds, active) {
	if (active) return "Projector mode is open right now.";
	if (!sig) return "No display check has run yet — the watch polls every 5 seconds while this is on.";
	const source = sig.startsWith("companion:") ? "the Windows companion" : "this browser";
	const count = projectorCountFromSig(sig);
	if (!Number.isFinite(count) || count < 1) return `Last check came from ${source}.`;
	return count >= 2 ? `Seen via ${source}: ${count} displays. A new second display must hold for ${stabilitySeconds}s before the projector view opens.` : `Seen via ${source}: 1 display — nothing new to switch to yet.`;
}
/** V10.5 — how each projection mode reads to a human. */
var PROJECTION_MODE_LABELS = {
	"pc-only": "PC screen only",
	"projector-only": "Projector only",
	duplicate: "Duplicate (Mirror)",
	extend: "Extend",
	unknown: "Not detected yet"
};
/**
* V7.8 — the late Settings sections (Voice → Advanced), split from
* settings-page.tsx for maintainability. Copy here is deliberately minimal:
* labels and real state only, with safety/honesty lines kept verbatim.
*/
function SettingsLateSections({ category, onAfterClear }) {
	const settings = useAppStore((s) => s.settings);
	const updateSettings = useAppStore((s) => s.updateSettings);
	const setProjectorActive = useAppStore((s) => s.setProjectorActive);
	const requestProjectorDisplayAccess = useAppStore((s) => s.requestProjectorDisplayAccess);
	const projectorDisplaysSig = useAppStore((s) => s.projectorDisplaysSig);
	const projectorTracked = useAppStore((s) => s.projectorActive);
	const projectorViewReady = useAppStore((s) => s.projectorViewReady);
	const projectionMode = useAppStore((s) => s.projectionMode);
	const projectionModeReason = useAppStore((s) => s.projectionModeReason);
	const clearAllData = useAppStore((s) => s.clearAllData);
	const loadPreview = useAppStore((s) => s.loadBrowsingPreview);
	const conversations = useAppStore((s) => s.conversations);
	const navigate = useNavigate();
	const [speech, setSpeech] = (0, import_react.useState)(null);
	const [voices, setVoices] = (0, import_react.useState)([]);
	const [companionPaired, setCompanionPaired] = (0, import_react.useState)(false);
	/** V8.1 — the health failure that decides "offline" vs "token rejected". Kept, never deletes the token. */
	const [companionLastError, setCompanionLastError] = (0, import_react.useState)();
	const [companionState, setCompanionState] = (0, import_react.useState)();
	const [companionMessage, setCompanionMessage] = (0, import_react.useState)();
	const [ttsStatus, setTtsStatus] = (0, import_react.useState)(null);
	const [ttsStatusLoading, setTtsStatusLoading] = (0, import_react.useState)(false);
	const [confirmClear, setConfirmClear] = (0, import_react.useState)(false);
	const companion = (0, import_react.useMemo)(() => new CompanionClient(), []);
	const pairingStatus = companionPairingStatus(companionPaired, companionLastError);
	const refreshTtsStatus = (0, import_react.useCallback)(async () => {
		setTtsStatusLoading(true);
		const status = await fetchLocalTtsStatus();
		setTtsStatus(status);
		setTtsStatusLoading(false);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!settings.localTtsEnabled) return;
		refreshTtsStatus();
	}, [settings.localTtsEnabled, refreshTtsStatus]);
	(0, import_react.useEffect)(() => {
		const saved = readJson(STORAGE_KEYS.companionPaired, false, (value) => typeof value === "boolean");
		if (!saved.ok || !saved.value) return;
		setCompanionPaired(true);
		companion.appPower("status").then(async (power) => {
			if (!power.running || !power.paired) throw new Error("App-owned companion is offline; start it from a desktop task.");
			const state = await companion.health();
			setCompanionState(state);
			setCompanionLastError(void 0);
			syncConsentedTargetsFromCompanion(state);
		}).catch((error) => setCompanionLastError(error));
	}, [companion]);
	(0, import_react.useEffect)(() => {
		setSpeech(detectSpeechSupport());
		if (typeof window === "undefined" || !window.speechSynthesis) return;
		const sync = () => setVoices(listVoices());
		sync();
		window.speechSynthesis.addEventListener("voiceschanged", sync);
		return () => window.speechSynthesis.removeEventListener("voiceschanged", sync);
	}, [settings.textToSpeech]);
	const memoryThreads = (0, import_react.useMemo)(() => conversations.filter((conversation) => Boolean(conversation.contextSummary?.trim())), [conversations]);
	async function pairCompanion() {
		try {
			const power = await companion.appPower("start");
			if (!power.running || !power.paired) throw new Error("The bundled companion did not start and pair.");
			setCompanionPaired(true);
			setCompanionLastError(void 0);
			writeJson(STORAGE_KEYS.companionPaired, true);
			setCompanionMessage("Paired with this app session. The private pairing token stays on the server; automation remains off until you explicitly enable it.");
			const health = await companion.health();
			setCompanionState(health);
			syncConsentedTargetsFromCompanion(health);
		} catch (error) {
			setCompanionMessage(error instanceof Error ? error.message : "Pairing failed.");
		}
	}
	/**
	* V11 — explicit unpair stops the owned process and removes the non-secret
	* browser flag. The server token is discarded with the process.
	*/
	async function unpairCompanion() {
		try {
			await companion.appPower("stop");
		} finally {
			removeKey(STORAGE_KEYS.companionPaired);
			setCompanionPaired(false);
			setCompanionState(void 0);
			setCompanionLastError(void 0);
			setCompanionMessage("Unpaired. The app-owned companion process was stopped.");
		}
	}
	async function refreshCompanion() {
		try {
			const power = await companion.appPower("status");
			if (!power.running || !power.paired) throw new Error("The app-owned companion is offline.");
			const next = await companion.health();
			setCompanionState(next);
			setCompanionLastError(void 0);
			syncConsentedTargetsFromCompanion(next);
		} catch (error) {
			setCompanionLastError(error);
			setCompanionMessage(error instanceof Error ? error.message : "Companion unavailable.");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			id: "settings-voice",
			className: cn("settings-panel scroll-mt-20 rounded-lg bg-surface p-4 shadow-[0_0_0_1px_var(--color-border)]", category !== "voice" && "hidden"),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-base font-semibold tracking-[-0.012em]",
					children: "Voice"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "group-label mt-3",
					children: "Browser speech"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: speech ? speech.detail : "Checking this browser's speech support…"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 rounded-md bg-surface-2 p-3 shadow-[0_0_0_1px_var(--color-border)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-label font-medium text-fg",
							children: "Local Whisper STT"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
							id: "local-stt",
							label: "Use local STT bridge",
							checked: settings.localSttEnabled,
							onChange: (checked) => updateSettings({ localSttEnabled: checked })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 grid gap-2 sm:grid-cols-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-label font-medium text-muted",
								htmlFor: "stt-tier",
								children: ["STT tier", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
									id: "stt-tier",
									className: "mt-1",
									value: settings.sttTier,
									onChange: (e) => updateSettings({ sttTier: e.target.value }),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "low",
											children: "Low — Whisper base"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "auto",
											children: "Auto — conservative RAM choice"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "high",
											children: "High — Whisper small"
										})
									]
								})]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
							id: "wake-session",
							label: "Wake-word session",
							description: "Idle transcripts are discarded.",
							checked: settings.wakeSessionEnabled,
							onChange: (checked) => updateSettings({ wakeSessionEnabled: checked })
						}),
						settings.wakeSessionEnabled ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 grid gap-2 sm:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-label font-medium text-muted",
								htmlFor: "wake-phrase",
								children: ["Wake phrase", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "wake-phrase",
									className: "mt-1",
									value: settings.wakePhrase,
									onChange: (e) => updateSettings({ wakePhrase: e.target.value })
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-label font-medium text-muted",
								htmlFor: "sleep-phrase",
								children: ["Sleep phrase", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "sleep-phrase",
									className: "mt-1",
									value: settings.sleepPhrase,
									onChange: (e) => updateSettings({ sleepPhrase: e.target.value })
								})]
							})]
						}) : null
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
					id: "stt",
					label: "Speech-to-text",
					description: "The composer microphone is requested only when you tap it. The projector wall opens the microphone itself for the wake word.",
					checked: settings.speechToText,
					disabled: !speech?.recognition,
					onChange: (checked) => updateSettings({ speechToText: checked })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
					id: "tts",
					label: "Read-aloud",
					checked: settings.textToSpeech,
					disabled: !speech?.synthesis,
					onChange: (checked) => updateSettings({ textToSpeech: checked })
				}),
				settings.textToSpeech && voices.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "mt-3 block text-xs font-medium text-muted",
					htmlFor: "voice",
					children: "Voice"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					id: "voice",
					className: "mt-1.5",
					value: settings.ttsVoice,
					onChange: (e) => updateSettings({
						ttsVoice: e.target.value,
						ttsProfileId: ""
					}),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "",
						children: "Browser default"
					}), voices.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: v.uri,
						children: v.label
					}, v.uri))]
				})] }) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 border-t border-border pt-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-label font-medium text-fg",
							children: "Voice studio"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs text-muted",
							children: "Presets are shaped by measured pitch and pace — not a neural clone."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VoiceStudioPage, {})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
					className: "group mt-5 border-t border-border pt-4",
					open: true,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("summary", {
							className: "flex cursor-pointer list-none items-center gap-2 [&::-webkit-details-marker]:hidden",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "group-label",
								children: "Voice (local engine)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, {
								className: "ml-auto size-4 shrink-0 text-muted transition-transform group-open:rotate-180",
								"aria-hidden": "true"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
							id: "local-tts",
							label: "Enable local TTS engine",
							description: "Runs a local Python process.",
							checked: settings.localTtsEnabled,
							onChange: (checked) => updateSettings({ localTtsEnabled: checked })
						}),
						settings.localTtsEnabled ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "mt-4 block text-label font-medium text-muted",
								htmlFor: "tts-profile",
								children: "Voice profile"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
								id: "tts-profile",
								className: "mt-1.5",
								value: settings.localTtsProfile,
								onChange: (e) => updateSettings({ localTtsProfile: e.target.value }),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "",
									children: "None — Kokoro everyday voice"
								}), (ttsStatus?.voices ?? []).map((voice) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
									value: voice.name,
									children: [voice.name, voice.complete ? "" : ` (missing ${voice.missing.join(", ")})`]
								}, voice.name))]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
								id: "tts-unload",
								label: "Unload heavy LLM before clone",
								checked: settings.localTtsUnloadBeforeClone,
								onChange: (checked) => updateSettings({ localTtsUnloadBeforeClone: checked })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
								id: "tts-auto-speak",
								label: "Auto-speak last assistant message",
								description: "Completed replies are spoken with the local engine.",
								checked: settings.localTtsAutoSpeak,
								onChange: (checked) => updateSettings({ localTtsAutoSpeak: checked })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-4 flex flex-wrap items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									onClick: () => void refreshTtsStatus(),
									disabled: ttsStatusLoading,
									children: ttsStatusLoading ? "Checking…" : "Check installation"
								}), ttsStatus?.available ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs text-ok",
									children: "Stack found."
								}) : null]
							}),
							ttsStatus && !ttsStatus.available ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-2 flex flex-col gap-1.5",
								children: ttsStatus.hints.map((hint) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
									className: "text-xs leading-relaxed text-warn",
									children: hint
								}, hint))
							}) : null
						] }) : null
					]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			id: "settings-web",
			className: cn("settings-panel scroll-mt-20 rounded-lg bg-surface p-4 shadow-[0_0_0_1px_var(--color-border)]", category !== "access" && "hidden"),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-base font-semibold tracking-[-0.012em]",
					children: "Access mode"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "block text-label font-medium text-muted",
						htmlFor: "access-mode",
						children: "Access mode"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						id: "access-mode",
						className: "mt-1.5",
						value: settings.accessMode ?? (settings.allowWebBrowsing ? "browse" : "off"),
						onChange: (e) => updateSettings({ accessMode: e.target.value }),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "off",
								children: "No browsing — web search not allowed, no web fetch"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "browse",
								children: "Web search allowed — fetch/search public pages for chat only"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "browser",
								children: "Browser assist — Oqe drives its own browser tab through the Oqe Browser Assistant extension (no companion needed); not background browser control"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "desktop",
								children: "Full desktop control — OS automation via the companion (not background OS control; still needs Pair → Enable → consent)"
							})
						]
					})]
				}),
				accessRequirementLine(settings.accessMode ?? (settings.allowWebBrowsing ? "browse" : "off")) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-xs leading-relaxed text-muted",
					role: "status",
					children: accessRequirementLine(settings.accessMode ?? (settings.allowWebBrowsing ? "browse" : "off"))
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "primary",
						onClick: () => {
							loadPreview();
							navigate({ to: "/" });
						},
						children: "Show browsing preview"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-xs leading-relaxed text-muted",
						children: "Sample preview only — not a live fetch."
					})]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			id: "settings-projector",
			className: cn("settings-panel flex scroll-mt-20 flex-col gap-3", category !== "projector" && "hidden"),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-base font-semibold tracking-[-0.012em]",
					children: "Projector"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "A large-type view for a second display."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-md bg-surface-2 p-4 shadow-[inset_0_0_0_1px_var(--color-border)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
							id: "projector-enabled",
							label: "Projector mode — auto-launch on second display",
							description: "Asks the browser once for multi-display access — without that grant auto-start cannot fire. Opening the wall turns on read-aloud, the wake word and full desktop access for the session; Pair → Enable → consent still apply.",
							checked: settings.projectorEnabled,
							onChange: (on) => {
								updateSettings({ projectorEnabled: on });
								if (on) requestProjectorDisplayAccess();
							}
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "mt-3 block text-label font-medium text-muted",
							htmlFor: "projector-text",
							children: "Answers on the wall"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							id: "projector-text",
							className: "mt-1",
							value: settings.projectorTextPolicy,
							onChange: (e) => updateSettings({ projectorTextPolicy: readWallTextPolicy(e.target.value) }),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "when-useful",
									children: "Only when reading helps — summaries, lists, steps, code, links"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "always",
									children: "Always show the answer"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "hidden",
									children: "Never show it — spoken only"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-meta leading-relaxed text-muted",
							children: "Every answer is read aloud either way. This only decides whether it is also printed in large type."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "mt-3 block text-label font-medium text-muted",
							htmlFor: "projector-weather-location",
							children: "Weather location"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							id: "projector-weather-location",
							className: "mt-1",
							value: settings.projectorWeatherLocation,
							onChange: (e) => updateSettings({ projectorWeatherLocation: e.target.value }),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "Not set — the wall shows no weather"
							}), WEATHER_LOCATIONS.map((entry) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: entry.id,
								children: entry.label
							}, entry.id))]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-meta leading-relaxed text-muted",
							children: "The wall shows this station's current reading and the forecast for its own position. Met Éireann measures at fixed stations and offers no lookup by town, so these are the choices — nothing is guessed for a place that is not listed, and an unset location shows as unset rather than borrowing another town's weather."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "mt-3 block text-label font-medium text-muted",
							htmlFor: "projector-weather",
							children: "Weather page (optional)"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "projector-weather",
							type: "url",
							className: "mt-1",
							value: settings.projectorWeatherUrl,
							onChange: (e) => updateSettings({ projectorWeatherUrl: e.target.value.trim() }),
							placeholder: "Weather page URL"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-meta leading-relaxed text-muted",
							children: "Overrides the location above: up to three weather lines from this page are shown instead of the station reading and its forecast. Fetched when the projector opens, then every 15 minutes. Nothing else is read from the site."
						}),
						settings.projectorEnabled ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "mt-2 block text-label font-medium text-muted",
								htmlFor: "projector-stability",
								children: "Stability window — seconds before launch"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
								id: "projector-stability",
								className: "mt-1",
								value: String(settings.projectorStabilitySeconds),
								onChange: (e) => {
									const value = Number(e.target.value);
									updateSettings({ projectorStabilitySeconds: Number.isFinite(value) && value >= 0 ? value : 5 });
								},
								children: [
									0,
									3,
									5,
									10,
									15
								].map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: s,
									children: s === 0 ? "Immediately (0 seconds)" : `${s} seconds`
								}, s))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-meta leading-relaxed text-muted",
								role: "status",
								children: describeProjectorDisplays(projectorDisplaysSig, settings.projectorStabilitySeconds, projectorTracked)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-2 text-meta leading-relaxed text-muted",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "font-medium text-fg",
										children: [
											"Projection mode: ",
											PROJECTION_MODE_LABELS[projectionMode],
											"."
										]
									}),
									" ",
									describeProjectionPlan(projectionMode)
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-meta leading-relaxed text-muted",
								children: projectionModeReason
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "mt-3 block text-label font-medium text-muted",
								htmlFor: "projector-preset",
								children: "Default preset"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
								id: "projector-preset",
								className: "mt-1",
								value: settings.projectorPreset ?? "",
								onChange: (e) => updateSettings({ projectorPreset: e.target.value || null }),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "",
									children: "None — plain fullscreen (no forced voice profile)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "voice-room",
									children: "Voice room — voice-only projector view: read-aloud + speech-to-text with web and desktop access on for the session"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 rounded-md bg-surface-2 p-3 shadow-[inset_0_0_0_1px_var(--color-border)]",
								"aria-label": "Projector mode preview",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-meta font-medium text-muted",
									children: "Projector mode preview"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-2 rounded-md bg-bg p-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-lg leading-relaxed text-fg",
										children: "Oqe: say the wake word (“Oqe”) and the room answers aloud…"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-xs text-muted",
										children: "Wake word on · Read-aloud forced on · Full desktop access for the session · Text only when it helps"
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-meta leading-relaxed text-muted",
								role: "status",
								children: projectorViewReady ? "Projector display: done — the view is open and rendering." : "Projector display: not open yet."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-meta leading-relaxed text-muted",
								children: "Windows set to Duplicate can hide the second display from this browser — switch to Extend, or use Start now."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 flex flex-wrap items-center gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										onClick: () => setProjectorActive(true, "Projector mode enabled from Settings.", false, { placeOnProjector: true }),
										children: "Start now"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										href: "/projector",
										className: "text-xs text-muted underline decoration-dotted underline-offset-2 hover:text-fg",
										children: "Open the projector view"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs text-muted",
										children: "Fullscreen may need one tap."
									})
								]
							})
						] }) : null
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs leading-relaxed text-muted",
					children: "Read-only view. Desktop input still goes through Pair → Enable → per-app consent, with Esc / Ctrl+Alt+K latching STOP."
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			id: "settings-companion",
			className: cn("settings-panel flex scroll-mt-20 flex-col gap-3", category !== "access" && "hidden"),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-base font-semibold tracking-[-0.012em]",
					children: "Computer control"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Loopback-only. Pair, Enable, confirm each target, then run. Esc / Ctrl+Alt+K latches STOP."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-md bg-surface-2 p-4 shadow-[inset_0_0_0_1px_var(--color-border)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "Loopback-only. The app starts its bundled helper, pairs it privately, and keeps automation off until you enable it. Confirm each target; Esc / Ctrl+Alt+K latches STOP."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "flex-1 text-sm text-muted",
								children: "The helper runs locally on this PC. Its session token never enters browser storage."
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								onClick: () => void pairCompanion(),
								disabled: companionPaired,
								children: "Start and pair"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-meta leading-relaxed text-muted",
							children: "The app starts the bundled helper and keeps its pairing token in server memory. Unpair stops the helper and clears the pairing."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex flex-wrap items-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: pairingStatus === "paired" && companionState?.enabled ? "ENABLED" : "DISABLED" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs text-muted",
									children: companionStatusLine(pairingStatus, companionState)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									onClick: () => void refreshCompanion(),
									disabled: !companionPaired,
									children: "Refresh state"
								}),
								companionPaired ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "danger",
									onClick: unpairCompanion,
									children: "Unpair"
								}) : null,
								companionState?.stopped ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									onClick: async () => {
										try {
											await companion.clearStop();
											const next = await companion.health();
											setCompanionState(next);
											syncConsentedTargetsFromCompanion(next);
											setCompanionMessage("STOP cleared. Automation stays off until you Enable.");
										} catch (error) {
											setCompanionMessage(error instanceof Error ? error.message : "Clear STOP failed.");
										}
									},
									children: "Clear STOP"
								}) : companionPaired ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "danger",
									onClick: async () => {
										try {
											await companion.stop();
											const next = await companion.health();
											setCompanionState(next);
											syncConsentedTargetsFromCompanion(next);
											setCompanionMessage("STOP latched. Clear STOP, then Enable.");
										} catch (error) {
											setCompanionMessage(error instanceof Error ? error.message : "STOP failed.");
										}
									},
									children: "STOP"
								}) : null
							]
						}),
						companionPaired ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
							id: "companion-consent",
							label: "Allow desktop automation",
							description: "Explicit consent for this browser session. Disable or STOP revokes consent.",
							checked: Boolean(companionState?.enabled),
							onChange: async (allowed) => {
								try {
									if (allowed) {
										const power = await companion.appPower("enable");
										if (!power.running || !power.paired) throw new Error("The app-owned companion did not enable.");
									} else await companion.appPower("disable");
									const health = await companion.health();
									setCompanionState(health);
									syncConsentedTargetsFromCompanion(health);
								} catch (error) {
									setCompanionMessage(error instanceof Error ? error.message : "Consent change failed.");
								}
							}
						}) : null,
						companionMessage ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-xs text-muted",
							children: companionMessage
						}) : null,
						companionState ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 space-y-1 rounded-md bg-well p-3 text-xs text-muted shadow-[inset_0_0_0_1px_var(--color-border)]",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-medium text-fg",
										children: "Phase:"
									}),
									" ",
									companionState.phase ?? (companionState.enabled ? "enabled" : companionState.paired ? "paired_disabled" : "unpaired")
								] }),
								companionState.next_step ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-medium text-fg",
										children: "Next:"
									}),
									" ",
									companionState.next_step
								] }) : null,
								companionState.ollama_model ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-medium text-fg",
										children: "Vision model:"
									}),
									" ",
									companionState.ollama_model
								] }) : null,
								companionState.loop_status ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-medium text-fg",
										children: "Loop:"
									}),
									" ",
									companionState.loop_status.state,
									companionState.loop_status.step != null && companionState.loop_status.max_steps != null ? ` (${companionState.loop_status.step}/${companionState.loop_status.max_steps})` : "",
									companionState.loop_status.detail ? ` — ${companionState.loop_status.detail}` : ""
								] }) : null,
								companionState.loop_status?.extracted_reply ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-medium text-fg",
										children: "Extracted reply:"
									}),
									" ",
									companionState.loop_status.extracted_reply
								] }) : null,
								companionState.consented_targets && companionState.consented_targets.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium text-fg",
									children: "Consented targets:"
								}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-1 flex flex-wrap gap-1.5",
									children: companionState.consented_targets.map((target) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "inline-flex items-center gap-1 rounded-md bg-surface px-2 py-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: target }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											size: "sm",
											variant: "danger",
											onClick: async () => {
												try {
													await companion.revokeTarget(target);
													const next = await companion.health();
													setCompanionState(next);
													syncConsentedTargetsFromCompanion(next);
													setCompanionMessage(`Revoked ${target}. It must be confirmed again before control.`);
												} catch (error) {
													setCompanionMessage(error instanceof Error ? error.message : "Could not revoke target.");
												}
											},
											children: "Revoke"
										})]
									}, target))
								})] }) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-medium text-fg",
										children: "Screenshots:"
									}),
									" ",
									companionState.screenshots ?? "in-memory-only"
								] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap items-center gap-2 pt-1",
									children: [companionState.consented_targets && companionState.consented_targets.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "sm",
										variant: "danger",
										onClick: async () => {
											try {
												await companion.clearTargets();
												const next = await companion.health();
												setCompanionState(next);
												syncConsentedTargetsFromCompanion(next);
												setCompanionMessage("All target consent revoked.");
											} catch (error) {
												setCompanionMessage(error instanceof Error ? error.message : "Could not clear targets.");
											}
										},
										children: "Revoke all targets"
									}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-meta opacity-80",
										children: "STOP (Esc / Ctrl+Alt+K) latches until Clear STOP. STOP and Disable revoke all targets; use Enable and confirm again."
									})]
								})
							]
						}) : null
					]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			id: "settings-memory",
			className: cn("settings-panel scroll-mt-20 rounded-lg bg-surface p-4 shadow-[0_0_0_1px_var(--color-border)]", category !== "privacy" && "hidden"),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-base font-semibold tracking-[-0.012em]",
					children: "Memory"
				}),
				memoryThreads.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-xs text-muted",
					children: "No saved summaries."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 flex flex-col gap-1.5",
					children: memoryThreads.map((thread) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center justify-between gap-2 rounded-md bg-surface-2 px-3 py-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "min-w-0 truncate text-sm text-fg",
							children: thread.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "shrink-0 font-mono text-meta text-muted",
							children: [
								thread.contextSummary?.length ?? 0,
								" chars",
								thread.compressedAt ? ` · ${new Date(thread.compressedAt).toLocaleDateString()}` : ""
							]
						})]
					}, thread.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-xs text-muted",
					children: "Only a thread's own summary is used in its requests."
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			id: "settings-advanced",
			className: cn("settings-panel scroll-mt-20 rounded-lg bg-surface p-4 shadow-[0_0_0_1px_var(--color-border)]", category !== "privacy" && "hidden"),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-base font-semibold tracking-[-0.012em]",
					children: "Local data & about"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
					id: "process",
					label: "Show model process",
					description: "Only reveals <think> text the provider actually sent.",
					checked: settings.showModelProcess,
					onChange: (checked) => updateSettings({ showModelProcess: checked })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "danger",
					onClick: () => setConfirmClear(true),
					className: "mt-4",
					children: "Clear local data"
				}),
				confirmClear ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 rounded-md bg-surface-2 p-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Removes conversations, connection settings, and preferences. Cannot be undone."
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "danger",
							onClick: () => {
								clearAllData();
								onAfterClear?.();
								setConfirmClear(false);
							},
							children: "Confirm clear"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: () => setConfirmClear(false),
							children: "Cancel"
						})]
					})]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					id: "about-and-limitations",
					className: "mt-4 scroll-mt-16 border-t border-border pt-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
						className: "group",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("summary", {
							className: "flex cursor-pointer list-none items-center gap-2 [&::-webkit-details-marker]:hidden",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-sm font-medium",
								children: "About and limitations"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, {
								className: "ml-auto size-4 shrink-0 text-muted transition-transform group-open:rotate-180",
								"aria-hidden": "true"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AboutPage, {
								embedded: true,
								showTitle: false
							})
						})]
					})
				})
			]
		})
	] });
}
/**
* V7.9.2 — the settings tabs, consolidated from nine to seven.
*
* The old list had three near-empty tabs (Web = one select + one button,
* Memory = one list, Advanced = one toggle + one button) alongside full pages.
* They are now folded into the tab their content actually belongs to, and
* Projector is promoted OUT of Computer control into its own tab so the
* second-display feature is not buried inside pairing settings.
*
* Several panels share one tab on purpose (Prompts + Skills, Web + Computer
* control, Memory + Advanced); each panel keeps its own card and its own
* scroll target id.
*/
var SETTINGS_CATEGORIES = [
	{
		id: "model",
		label: "Connection",
		detail: "Server, key, and model"
	},
	{
		id: "context",
		label: "Context",
		detail: "Window size and when it compacts"
	},
	{
		id: "prompts",
		label: "Prompts & skills",
		detail: "System prompt, playbooks, and teams"
	},
	{
		id: "multi-agent",
		label: "Multi-agent",
		detail: "A lead agent and its sub-agents"
	},
	{
		id: "voice",
		label: "Voice",
		detail: "Speech and read-aloud"
	},
	{
		id: "projector",
		label: "Projector",
		detail: "Second-display view and auto-launch"
	},
	{
		id: "access",
		label: "Access & control",
		detail: "Browsing and desktop control"
	},
	{
		id: "appearance",
		label: "Appearance",
		detail: "Motion, density, and the orb"
	},
	{
		id: "output",
		label: "Output",
		detail: "What replies may draw, and when to ask"
	},
	{
		id: "privacy",
		label: "Privacy & data",
		detail: "Memory and local data"
	}
];
/** The one "this preset is in use" treatment in Settings. */
function presetClass(selected) {
	return selected ? "bg-accent/10 text-accent shadow-[inset_0_0_0_1px_var(--color-accent)] hover:bg-accent/15" : void 0;
}
function SettingsPage() {
	const settings = useAppStore((s) => s.settings);
	const updateSettings = useAppStore((s) => s.updateSettings);
	const setDiscoveredModels = useAppStore((s) => s.setDiscoveredModels);
	const setConnection = useAppStore((s) => s.setConnection);
	const connection = useAppStore((s) => s.connection);
	const models = useAppStore((s) => s.discoveredModels);
	const loadedModelIds = useAppStore((s) => s.loadedModelIds);
	const modelLoading = useAppStore((s) => s.modelLoading);
	const selectModel = useAppStore((s) => s.selectModel);
	const loadModelNow = useAppStore((s) => s.loadModelNow);
	const unloadModelNow = useAppStore((s) => s.unloadModelNow);
	const refreshLoadedModels = useAppStore((s) => s.refreshLoadedModels);
	const userSkills = useAppStore((s) => s.userSkills);
	const skillsState = useAppStore((s) => s.skillsState);
	const multiAgentSkills = useAppStore((s) => s.multiAgentSkills);
	const voiceProfiles = useAppStore((s) => s.voiceProfiles);
	const scheduledPrompts = useAppStore((s) => s.scheduledPrompts);
	const companionHealth = useAppStore((s) => s.companionHealth);
	const toggleSkill = useAppStore((s) => s.toggleSkill);
	const addUserSkill = useAppStore((s) => s.addUserSkill);
	const removeUserSkill = useAppStore((s) => s.removeUserSkill);
	const [keyDraft, setKeyDraft] = (0, import_react.useState)(settings.apiKey);
	const [revealKey, setRevealKey] = (0, import_react.useState)(false);
	const [addressDraft, setAddressDraft] = (0, import_react.useState)(settings.localAddress);
	const [manualModel, setManualModel] = (0, import_react.useState)(settings.model);
	const [testDetail, setTestDetail] = (0, import_react.useState)(null);
	const [loadedModels, setLoadedModels] = (0, import_react.useState)(null);
	const [loadedBusy, setLoadedBusy] = (0, import_react.useState)(false);
	const [loadedError, setLoadedError] = (0, import_react.useState)(null);
	const [editingModelAlias, setEditingModelAlias] = (0, import_react.useState)(null);
	const [modelAliasDraft, setModelAliasDraft] = (0, import_react.useState)("");
	const [skillTrigger, setSkillTrigger] = (0, import_react.useState)("");
	const [skillInstructions, setSkillInstructions] = (0, import_react.useState)("");
	const [skillMultiAgent, setSkillMultiAgent] = (0, import_react.useState)("");
	const [skillThinking, setSkillThinking] = (0, import_react.useState)("");
	const [skillModel, setSkillModel] = (0, import_react.useState)("");
	const [skillMessage, setSkillMessage] = (0, import_react.useState)(null);
	const [editingSkillId, setEditingSkillId] = (0, import_react.useState)(null);
	const [category, setCategory] = (0, import_react.useState)("model");
	const hydrated = useAppStore((s) => s.hydrated);
	const capabilityCache = useAppStore((s) => s.capabilityCache);
	const capabilityRefresh = useAppStore((s) => s.capabilityRefresh);
	const refreshModelCapabilities = useAppStore((s) => s.refreshModelCapabilities);
	(0, import_react.useEffect)(() => {
		if (!hydrated || category !== "model") return;
		refreshModelCapabilities();
	}, [
		hydrated,
		category,
		refreshModelCapabilities
	]);
	const visionPreset = (0, import_react.useMemo)(() => {
		if (models.some((model) => model.id === "qwen3-vl:4b")) return PREFERRED_VISION_MODEL;
		return models.find((model) => isVisionCapable(model.id, capabilityCache, settings.modelTags))?.id;
	}, [
		models,
		capabilityCache,
		settings.modelTags
	]);
	const skillList = (0, import_react.useMemo)(() => allSkills(userSkills), [userSkills]);
	const [companionPaired, setCompanionPaired] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (category !== "prompts") return;
		const saved = readJson(STORAGE_KEYS.companionPaired, false, (value) => typeof value === "boolean");
		setCompanionPaired(Boolean(saved.ok && saved.value));
	}, [category, companionHealth]);
	const capabilitiesPromptPreview = (0, import_react.useMemo)(() => buildAutoCapabilities({
		...autoCapabilitiesContext({
			settings,
			companion: {
				paired: companionPaired || companionHealth?.paired === true,
				enabled: companionHealth?.enabled === true
			},
			voiceProfileCount: voiceProfiles.length
		}),
		model: settings.model.trim(),
		modelTags: modelTagLabels(settings.model, settings.modelTags, capabilityCache),
		skills: [...allSkills(userSkills).map((skill) => ({
			trigger: skill.trigger,
			name: skill.name,
			enabled: Boolean(skillsState[skill.id])
		})), ...multiAgentSkills.map((skill) => ({
			trigger: skill.trigger,
			name: skill.name,
			enabled: skill.enabled
		}))],
		automationCount: scheduledPrompts.length
	}), [
		settings,
		capabilityCache,
		companionPaired,
		companionHealth,
		voiceProfiles.length,
		userSkills,
		skillsState,
		multiAgentSkills,
		scheduledPrompts.length
	]);
	/**
	* V7.9.1 — fill the form from a picked text file. The draft comes from
	* whatever the file actually contains (a /create-skill JSON block, front
	* matter, the first heading, or the file name); the notes say which, and the
	* user still reviews and saves. Nothing is uploaded — File.text() reads it
	* locally.
	*/
	async function importSkillFile(file) {
		const problem = skillFileProblem(file);
		if (problem) {
			setSkillMessage(problem);
			return;
		}
		let contents;
		try {
			contents = await file.text();
		} catch {
			setSkillMessage(`"${file.name}" could not be read as text.`);
			return;
		}
		if (!contents.trim()) {
			setSkillMessage(`"${file.name}" is empty.`);
			return;
		}
		const draft = skillDraftFromFile(file.name, contents);
		setSkillTrigger(draft.trigger);
		setSkillInstructions(draft.instructions);
		setSkillMessage(`Filled from “${file.name}”. ${draft.notes.join(" ")} Review, then Save skill.`);
	}
	/** Prompt 34 — load a saved skill into the form so its text can be changed. */
	function editSkill(id) {
		const skill = userSkills.find((entry) => entry.id === id);
		if (!skill) return;
		setEditingSkillId(skill.id);
		setSkillTrigger(skill.trigger);
		setSkillInstructions(skill.instructions);
		setSkillMultiAgent(skill.settings?.multiAgent ?? "");
		setSkillThinking(skill.settings?.thinking ?? "");
		setSkillModel(skill.settings?.model ?? "");
		setSkillMessage(`Editing ${skill.trigger}. Save skill to replace it.`);
	}
	function cancelSkillEdit() {
		setEditingSkillId(null);
		setSkillTrigger("");
		setSkillInstructions("");
		setSkillMultiAgent("");
		setSkillThinking("");
		setSkillModel("");
		setSkillMessage(null);
	}
	function saveNewSkill() {
		setSkillMessage(null);
		const normalized = normalizeUserSkill({
			trigger: skillTrigger,
			name: skillTrigger,
			instructions: skillInstructions,
			settings: {
				multiAgent: skillMultiAgent,
				thinking: skillThinking,
				model: skillModel
			}
		});
		if (!normalized.ok) {
			setSkillMessage(normalized.message);
			return;
		}
		const skill = normalized.skill;
		const collision = triggerCollision(skill.trigger, {
			userSkills,
			multiAgentSkills
		}, { ignoreUserId: editingSkillId ?? void 0 });
		if (collision) {
			setSkillMessage(collision.message);
			return;
		}
		const previousId = editingSkillId;
		const error = addUserSkill(skill);
		if (error) {
			setSkillMessage(error);
			return;
		}
		if (previousId && previousId !== skill.id) removeUserSkill(previousId);
		setSkillMessage(previousId ? `Updated ${skill.trigger}. It stays ${skillsState[skill.id] === false ? "off" : "on"}.` : `Saved ${skill.trigger}. Toggle it on below; it runs only from this browser with your local model.`);
		setEditingSkillId(null);
		setSkillTrigger("");
		setSkillInstructions("");
		setSkillMultiAgent("");
		setSkillThinking("");
		setSkillModel("");
	}
	const parsed = normalizeApiKey(keyDraft);
	const mismatch = modelMismatch(settings.model, models);
	const sortedModels = (0, import_react.useMemo)(() => {
		const byId = new Map(models.map((model) => [model.id, model]));
		return sortChatModelIds([...byId.keys()]).map((id) => byId.get(id)).filter((model) => Boolean(model));
	}, [models]);
	const skillModelOptions = (0, import_react.useMemo)(() => {
		const ids = sortedModels.map((model) => model.id);
		const current = settings.model.trim();
		if (current && !ids.includes(current)) ids.unshift(current);
		return ids;
	}, [sortedModels, settings.model]);
	(0, import_react.useEffect)(() => {
		if (typeof window === "undefined") return;
		if (window.location.hash === "#about-and-limitations") {
			setCategory("privacy");
			document.getElementById("about-and-limitations")?.scrollIntoView({ block: "start" });
		}
	}, []);
	(0, import_react.useLayoutEffect)(() => {
		if (!hydrated) return;
		setKeyDraft(settings.apiKey);
		setAddressDraft(settings.localAddress);
		setManualModel(settings.model);
	}, [hydrated]);
	async function onTest() {
		const mode = settings.mode;
		const nextKey = keyDraft.trim();
		const nextAddress = addressDraft.trim() || "http://127.0.0.1:11434";
		if (mode === "cloud") updateSettings({ apiKey: nextKey });
		else updateSettings({ localAddress: nextAddress });
		setConnection({ kind: "testing" });
		setTestDetail(null);
		const result = await discoverModels({
			mode,
			localAddress: nextAddress,
			apiKey: nextKey,
			protocol: settings.protocol
		});
		if (!result.ok) {
			setConnection({
				kind: "error",
				message: result.error.message
			});
			setTestDetail(`${result.error.message} ${result.error.recovery}`);
			return;
		}
		const working = result.result.routes.filter((r) => r.ok).map((r) => r.detail).join(" · ");
		const failed = result.result.routes.filter((r) => !r.ok).map((r) => r.detail).join(" · ");
		setDiscoveredModels(result.result.models, working);
		setTestDetail([working, failed].filter(Boolean).join(" | "));
		const ids = result.result.models.map((m) => m.id);
		const preferredId = pickPreferredChatModel(ids) ?? ids[0];
		if (preferredId && !settings.model) {
			const preferred = result.result.models.find((m) => m.id === preferredId);
			updateSettings({
				model: preferredId,
				modelVerified: true,
				lastRoute: preferred?.source ?? result.result.working[0],
				lastRouteDetail: working
			});
			setManualModel(preferredId);
		} else if (settings.model) {
			const match = result.result.models.find((m) => m.id === settings.model);
			updateSettings({
				modelVerified: Boolean(match),
				lastRoute: match?.source ?? result.result.working[0],
				lastRouteDetail: working
			});
		}
	}
	function saveKey() {
		updateSettings({
			apiKey: keyDraft.trim(),
			modelVerified: false
		});
	}
	function saveAddress() {
		updateSettings({
			localAddress: addressDraft.trim() || "http://127.0.0.1:11434",
			modelVerified: false,
			lastRoute: void 0,
			lastRouteDetail: void 0
		});
	}
	function setMode(mode) {
		if (mode === settings.mode) return;
		updateSettings({
			mode,
			modelVerified: false,
			lastRoute: void 0,
			lastRouteDetail: void 0
		});
		setDiscoveredModels([]);
		setTestDetail(null);
		setConnection(isConnectionConfigured({
			...settings,
			mode
		}) ? { kind: "idle" } : { kind: "not_configured" });
	}
	function applyManualModel() {
		const id = manualModel.trim();
		selectModel(id);
	}
	async function refreshLoaded() {
		setLoadedBusy(true);
		setLoadedError(null);
		const result = await listLoadedModels({ localAddress: settings.localAddress });
		setLoadedBusy(false);
		if (!result.ok) {
			setLoadedModels(null);
			setLoadedError(result.error.message);
			return;
		}
		setLoadedModels(result.models);
	}
	async function onUnloadModel(id) {
		setLoadedBusy(true);
		setLoadedError(null);
		await unloadModelNow(id);
		const ps = await listLoadedModels({ localAddress: settings.localAddress });
		setLoadedBusy(false);
		if (!ps.ok) {
			setLoadedError(ps.error.message);
			return;
		}
		setLoadedModels(ps.models);
	}
	function applyProfile(id) {
		if (!models.find((model) => model.id === id)) return;
		selectModel(id);
		setManualModel(id);
	}
	function saveModelAlias(modelId) {
		const canonical = modelId.trim();
		if (!canonical) return;
		const next = modelAliasDraft.trim().slice(0, 48);
		const aliases = { ...settings.modelAliases };
		if (next) aliases[canonical] = next;
		else delete aliases[canonical];
		updateSettings({ modelAliases: aliases });
		setEditingModelAlias(null);
	}
	function cancelModelAliasEdit() {
		setEditingModelAlias(null);
		setModelAliasDraft("");
	}
	const onAfterClear = (0, import_react.useCallback)(() => {
		setKeyDraft("");
		setAddressDraft(DEFAULT_LOCAL_ADDRESS);
		setManualModel("");
		setTestDetail(null);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "settings-page mx-auto flex w-full max-w-5xl flex-col gap-8 px-4 py-7 sm:px-6 lg:px-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-2xl font-semibold tracking-[-0.025em]",
						children: "Settings"
					}), connection.kind === "error" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-danger",
						role: "status",
						children: connection.message || "The connection is not answering."
					}) : !isConnectionConfigured(settings) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-warn",
						role: "status",
						children: "No connection is set up yet. Choose local Ollama or Ollama Cloud below."
					}) : null]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("hr", { className: "lampline mt-5" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					"aria-label": "Settings categories",
					className: "settings-category-grid mt-5",
					children: SETTINGS_CATEGORIES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: cn("settings-category-card flex flex-col gap-1.5", category === item.id && "settings-category-card-active"),
						onClick: () => setCategory(item.id),
						"aria-pressed": category === item.id,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[0.9375rem] font-medium tracking-[-0.012em] text-fg",
							children: item.label
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs leading-snug text-pretty text-muted",
							children: item.detail
						})]
					}, item.id))
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				id: "settings-model",
				className: cn("settings-panel scroll-mt-20 rounded-lg bg-surface p-4 shadow-[0_0_0_1px_var(--color-border)]", category !== "model" && "hidden"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-medium",
						children: "Connection & model"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "One model per request."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 border-t border-border pt-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "group-label",
								children: "Connection"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 flex gap-2",
								role: "radiogroup",
								"aria-label": "Connection mode",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									className: presetClass(settings.mode === "local"),
									"aria-pressed": settings.mode === "local",
									onClick: () => setMode("local"),
									children: "Local"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									className: presetClass(settings.mode === "cloud"),
									"aria-pressed": settings.mode === "cloud",
									onClick: () => setMode("cloud"),
									children: "Ollama Cloud"
								})]
							}),
							settings.mode === "local" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "mt-4 block text-xs font-medium text-muted",
									htmlFor: "local-address",
									children: "Local address"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "local-address",
									className: "mt-1.5 font-mono",
									value: addressDraft,
									placeholder: DEFAULT_LOCAL_ADDRESS,
									autoComplete: "off",
									autoCorrect: "off",
									spellCheck: false,
									onChange: (e) => setAddressDraft(e.target.value),
									onBlur: saveAddress
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-xs text-muted",
									children: "Loopback only: 127.0.0.1 or ::1."
								})
							] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "mt-4 block text-xs font-medium text-muted",
									htmlFor: "api-key",
									children: "API key"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "api-key",
									className: "mt-1.5 font-mono",
									type: revealKey ? "text" : "password",
									value: keyDraft,
									placeholder: "Paste Ollama Cloud API key",
									autoComplete: "off",
									autoCorrect: "off",
									spellCheck: false,
									onChange: (e) => setKeyDraft(e.target.value),
									onBlur: saveKey
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-2 flex flex-wrap items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "sm",
										onClick: () => setRevealKey((v) => !v),
										children: revealKey ? "Hide key" : "Show key"
									}), settings.apiKey.trim() ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-xs text-muted",
										children: ["Saved ", maskApiKey(settings.apiKey)]
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted",
										children: "Not configured"
									})]
								}),
								!parsed.ok && keyDraft.trim() ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-xs text-danger",
									children: parsed.message
								}) : null
							] })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 flex flex-wrap gap-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "primary",
							onClick: () => void onTest(),
							disabled: connection.kind === "testing",
							children: connection.kind === "testing" ? "Testing…" : "Test connection"
						})
					}),
					testDetail ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-xs leading-relaxed text-muted",
						children: testDetail
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "mt-4 block text-xs font-medium text-muted",
						htmlFor: "model",
						children: "Model"
					}),
					models.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						id: "model",
						className: "mt-1.5",
						value: models.some((m) => m.id === settings.model) ? settings.model : "",
						onChange: (e) => {
							const id = e.target.value;
							if (!id) return;
							setManualModel(id);
							selectModel(id);
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: settings.mode === "cloud" ? "Select a model this key can access" : "Select a model"
						}), sortedModels.map((m) => {
							const alias = settings.modelAliases[m.id];
							const label = alias ? `${alias} · ${m.id}` : m.id;
							const where = settings.mode === "cloud" ? m.source === "openai" ? "OpenAI-compatible, remote" : "Ollama Cloud, remote" : "installed locally";
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
								value: m.id,
								children: [
									label,
									" (",
									where,
									")"
								]
							}, `${m.source}-${m.id}`);
						})]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1.5 text-xs text-muted",
						children: "No verified list yet. Test the connection, or enter a model ID manually."
					}),
					settings.mode === "local" && models.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium text-muted",
							children: "Quick profiles"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 flex flex-wrap gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									size: "sm",
									className: presetClass(settings.model === PREFERRED_CHAT_MODEL),
									disabled: !models.some((model) => model.id === PREFERRED_CHAT_MODEL),
									onClick: () => applyProfile(PREFERRED_CHAT_MODEL),
									children: ["Chat: ", PREFERRED_CHAT_MODEL]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									size: "sm",
									className: presetClass(settings.model === PREFERRED_CODER_MODEL),
									disabled: !models.some((model) => model.id === PREFERRED_CODER_MODEL),
									onClick: () => applyProfile(PREFERRED_CODER_MODEL),
									children: ["Code: ", PREFERRED_CODER_MODEL]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									size: "sm",
									className: presetClass(visionPreset !== void 0 && settings.model === visionPreset),
									disabled: !visionPreset,
									onClick: () => {
										if (visionPreset) applyProfile(visionPreset);
									},
									children: ["Vision: ", visionPreset ?? "none installed"]
								})
							]
						})]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "mt-3 block text-xs font-medium text-muted",
						htmlFor: "manual-model",
						children: "Manual model ID"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-1.5 flex flex-col gap-2 sm:flex-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "manual-model",
							value: manualModel,
							spellCheck: false,
							onChange: (e) => setManualModel(e.target.value),
							placeholder: "Enter an ID if listing is unavailable"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: applyManualModel,
							children: "Use ID"
						})]
					}),
					settings.model ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "readout mt-2 text-muted",
						children: settings.modelVerified && !mismatch ? "verified" : "not verified"
					}) }) : null,
					models.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 rounded-md border border-border bg-surface-2/40 p-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-medium text-muted",
									children: "Show in composer picker"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									onClick: () => void refreshModelCapabilities({ force: true }),
									children: "Re-check tags"
								})]
							}),
							capabilityRefresh ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-meta leading-relaxed text-muted",
								children: capabilityRefresh.failures > 0 ? `${capabilityRefresh.refreshed} model${capabilityRefresh.refreshed === 1 ? "" : "s"} checked, ${capabilityRefresh.failures} could not be read${capabilityRefresh.detail ? ` (${capabilityRefresh.detail})` : ""}.` : `Tags checked for ${capabilityRefresh.refreshed + capabilityRefresh.reused} installed model${capabilityRefresh.refreshed + capabilityRefresh.reused === 1 ? "" : "s"} — ${capabilityRefresh.refreshed} refreshed, ${capabilityRefresh.reused} reused.`
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-2 flex flex-col gap-1",
								children: models.map((model) => {
									const visible = settings.showInComposerPicker?.[model.id] !== false;
									const alias = settings.modelAliases[model.id] ?? "";
									const editingAlias = editingModelAlias === model.id;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
										className: "rounded-md bg-surface px-2.5 py-1.5",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between gap-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "min-w-0 flex-1",
												children: [editingAlias ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
													className: "flex min-w-0 items-center gap-2",
													onSubmit: (event) => {
														event.preventDefault();
														saveModelAlias(model.id);
													},
													onKeyDown: (event) => {
														if (event.key === "Escape") cancelModelAliasEdit();
													},
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
														autoFocus: true,
														"aria-label": `Display name for ${model.id}`,
														className: "h-8 min-h-8 font-mono text-xs",
														maxLength: 48,
														placeholder: model.id,
														value: modelAliasDraft,
														onChange: (event) => setModelAliasDraft(event.target.value),
														onBlur: () => saveModelAlias(model.id)
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
														size: "sm",
														type: "submit",
														children: "Save"
													})]
												}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													type: "button",
													className: "block max-w-full truncate text-left font-mono text-xs text-fg hover:text-accent focus-visible:rounded-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent",
													"aria-label": `${alias ? `${alias}, ` : ""}${model.id}. Double-click to change display name.`,
													title: "Double-click to change display name",
													onDoubleClick: () => {
														setEditingModelAlias(model.id);
														setModelAliasDraft(alias);
													},
													children: alias ? `${alias} · ${model.id}` : model.id
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModelTagEditor, {
													modelId: model.id,
													className: "mt-1.5"
												})]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
												id: `picker-visible-${model.id}`,
												compact: true,
												label: visible ? "Visible" : "Hidden",
												checked: visible,
												onChange: (checked) => updateSettings({ showInComposerPicker: {
													...settings.showInComposerPicker ?? {},
													[model.id]: checked
												} })
											})]
										})
									}, model.id);
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-meta text-muted",
								children: "Double-click a model name to change its display name. Clear it to restore the original."
							})
						]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 border-t border-border pt-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "group-label",
								children: "Behavior"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-4 rounded-lg border border-border bg-surface-2/30 p-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "block text-xs font-medium text-muted",
										htmlFor: "thinking-mode",
										children: "Thinking"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										id: "thinking-mode",
										className: "mt-1.5 w-full rounded-md border border-border bg-surface px-3 py-2 text-sm text-fg outline-none focus:border-accent",
										value: settings.thinkingMode,
										onChange: (e) => updateSettings({ thinkingMode: e.target.value }),
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "off",
												children: "Off"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "on",
												children: "On"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "auto",
												children: "Auto"
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1.5 text-xs text-muted",
										children: "Off = faster direct answers · Auto = on for hard tasks · On = think every turn. Local only; Cloud omits think."
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
								id: "auto-switch",
								label: "Auto-route to a suitable model",
								description: "Off by default. When on, a send may use another installed model that fits the work — text as well as images. The run's steps name the model and the reason.",
								checked: settings.autoSwitchModels,
								onChange: (checked) => updateSettings({ autoSwitchModels: checked })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
								id: "memory-management",
								label: "Resource-aware model loading",
								description: "Loads one local model at a time",
								checked: settings.manageModelMemory,
								onChange: (checked) => updateSettings({ manageModelMemory: checked })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
								id: "idle-unload",
								label: "Unload chat model after idle",
								description: "Releases the chat model when idle, never mid-stream",
								checked: settings.idleUnloadEnabled,
								onChange: (checked) => updateSettings({ idleUnloadEnabled: checked })
							}),
							settings.idleUnloadEnabled ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "mt-2 block text-xs font-medium text-muted",
								htmlFor: "idle-unload-minutes",
								children: ["Idle minutes", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "idle-unload-minutes",
									className: "mt-1 max-w-32",
									type: "number",
									min: 1,
									max: 60,
									value: settings.idleUnloadMinutes,
									onChange: (e) => updateSettings({ idleUnloadMinutes: Math.min(60, Math.max(1, Number(e.target.value) || 5)) })
								})]
							}) : null
						]
					}),
					settings.mode === "local" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 border-t border-border pt-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-medium text-muted",
									children: "In memory now"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									onClick: () => {
										refreshLoaded();
										refreshLoadedModels();
									},
									disabled: loadedBusy,
									children: loadedBusy ? "Checking…" : "Check"
								})]
							}),
							loadedError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-xs text-danger",
								children: loadedError
							}) : null,
							loadedModels !== null ? loadedModels.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-xs text-muted",
								children: "Nothing is loaded in memory."
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-2 flex flex-col gap-1.5",
								children: loadedModels.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex items-center justify-between gap-2 rounded-md bg-surface-2 px-2.5 py-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "min-w-0 truncate font-mono text-xs text-fg",
										children: [m.id, m.vramBytes != null ? ` · ${(m.vramBytes / 1073741824).toFixed(1)} GB VRAM` : m.sizeBytes != null ? ` · ${(m.sizeBytes / 1073741824).toFixed(1)} GB` : ""]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "sm",
										onClick: () => void onUnloadModel(m.id),
										disabled: loadedBusy,
										children: "Unload"
									})]
								}, m.id))
							}) : null,
							modelLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-2 text-xs text-accent",
								role: "status",
								children: ["Loading ", modelLoading]
							}) : null,
							settings.mode === "local" && models.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-medium text-muted",
									children: "Load a model on demand"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-2 flex flex-wrap gap-2",
									children: models.filter((m) => !loadedModelIds.some((l) => sameModel(l, m.id))).slice(0, 6).map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										size: "sm",
										disabled: Boolean(modelLoading),
										onClick: () => void loadModelNow(m.id),
										children: ["Load ", m.id]
									}, m.id))
								})]
							}) : null
						]
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProfilePanel, { category }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				id: "settings-prompts",
				className: cn("settings-panel scroll-mt-20 rounded-lg bg-surface p-4 shadow-[0_0_0_1px_var(--color-border)]", category !== "prompts" && "hidden"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-medium",
						children: "Prompts"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "Safety gates stay separate."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mt-4 text-xs font-medium text-muted",
						children: "Your prompts"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1.5 text-meta leading-relaxed text-muted",
						children: "Oqe also adds a short, generated capabilities note for this device, so the model knows what it can reach; that part is automatic and not typed here. It names the selected model, the paired targets and the armed permissions."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1.5 text-meta leading-relaxed text-muted",
						children: "Example of one generated line: “Model: qwen3:8b — vision-capable: no · Companion: not paired — it cannot click or type anything.”"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "mt-4 block text-xs font-medium text-muted",
						htmlFor: "system-prompt",
						children: "System prompt"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						id: "system-prompt",
						className: "mt-1.5 text-sm",
						value: settings.systemPrompt,
						placeholder: "Leave empty for no system prompt",
						onChange: (e) => updateSettings({ systemPrompt: e.target.value })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-wrap items-center justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "block text-xs font-medium text-muted",
							htmlFor: "capabilities-prompt",
							children: "Capabilities prompt"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-md bg-surface-2 px-2 py-0.5 text-meta text-muted shadow-[0_0_0_1px_var(--color-border)]",
							children: "Generated · read-only"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-muted",
						children: "Rebuilt for every request from the settings on this page, so it can never go stale. It is shown read-only, so it is not editable and cannot be typed into a lie."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
						id: "capabilities-prompt",
						"aria-readonly": "true",
						"aria-label": "Generated capabilities prompt",
						className: "mt-1.5 max-h-72 overflow-auto rounded-md bg-surface-2 p-3 font-mono text-meta leading-relaxed whitespace-pre-wrap text-fg shadow-[0_0_0_1px_var(--color-border)]",
						children: capabilitiesPromptPreview
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 flex flex-wrap items-center gap-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							disabled: !settings.systemPrompt.trim(),
							onClick: () => updateSettings({ systemPrompt: "" }),
							children: "Reset to default"
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				id: "settings-skills",
				className: cn("settings-panel scroll-mt-20 rounded-lg bg-surface p-4 shadow-[0_0_0_1px_var(--color-border)]", category !== "prompts" && "hidden"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-medium",
						children: "Skills"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "sr-only",
						children: "Multi-agent skills"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-muted",
						children: [
							"Run one with ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-xs",
								children: "/trigger"
							}),
							". You can call a regular skill from a multi-agent skill, or a multi-agent skill from a regular skill."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1.5 text-meta leading-relaxed text-muted",
						children: "A trigger matches only at the START of a message (or as “use /trigger skill” anywhere in it), and one obvious typo is tolerated. A trigger only one skill can answer: names already taken by a built-in, by another saved skill or by a multi-agent skill are refused when you save. A skill is a playbook — it cannot grant a capability, change your settings, or act on a device; its declared capabilities are requested for that one reply and your settings still decide."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 flex flex-col gap-2",
						children: skillList.map((skill) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-start justify-between gap-3 rounded-md bg-surface-2 px-3 py-2.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "min-w-0",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "block text-sm font-medium text-fg",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "mr-2 font-mono text-xs text-muted",
											children: skill.trigger
										}), skill.name !== skill.trigger ? skill.name : null]
									}),
									skill.description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mt-0.5 block text-xs leading-relaxed text-muted",
										children: skill.description
									}) : null,
									describeSkillSettings(skill.settings) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mt-0.5 block text-meta text-accent/90",
										children: describeSkillSettings(skill.settings)
									}) : null,
									describeSkillCapabilities(skill) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mt-0.5 block text-meta text-muted",
										children: describeSkillCapabilities(skill)
									}) : null
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								id: `skill-${skill.id}`,
								role: "switch",
								"aria-checked": Boolean(skillsState[skill.id]),
								"aria-label": `${skillsState[skill.id] ? "Disable" : "Enable"} ${skill.name}`,
								onClick: () => toggleSkill(skill.id, !skillsState[skill.id]),
								className: "mt-1 shrink-0",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "relative block h-7 w-12 rounded-full bg-surface shadow-[0_0_0_1px_var(--color-border)] data-[on=true]:bg-accent",
									"data-on": skillsState[skill.id] ? "true" : "false",
									"aria-hidden": "true",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "absolute top-0.5 left-0.5 size-6 rounded-full bg-fg transition-transform duration-150 ease-out data-[on=true]:translate-x-5",
										"data-on": skillsState[skill.id] ? "true" : "false"
									})
								})
							})]
						}, skill.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 rounded-md bg-well px-3 py-2 text-xs leading-relaxed text-muted",
						children: [
							"In either skill's instructions, link another skill with",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-fg",
								children: "use /trigger skill"
							}),
							". A regular skill can start a multi-agent skill; its mission and roster run, with the regular skill's instructions carried along."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5 border-t border-border pt-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "group-label",
								children: editingSkillId ? "Edit skill" : "Add skill"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "mt-3 block text-xs font-medium text-muted",
								htmlFor: "skill-trigger",
								children: "Name"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "skill-trigger",
								className: "mt-1.5 font-mono sm:max-w-56",
								value: skillTrigger,
								placeholder: "/review",
								"aria-label": "Skill name — the /trigger that starts a message",
								spellCheck: false,
								onChange: (e) => setSkillTrigger(e.target.value)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1.5 text-meta text-muted",
								children: [
									"Start a message with this name (for example",
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-mono",
										children: "/review"
									}),
									") to run the skill."
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
								id: "skill-instructions",
								className: "mt-3 text-sm",
								value: skillInstructions,
								placeholder: "Instructions the local model follows when this skill triggers…",
								"aria-label": "Skill instructions",
								onChange: (e) => setSkillInstructions(e.target.value)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 grid gap-3 sm:grid-cols-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "block text-xs font-medium text-muted",
										htmlFor: "skill-multi-agent",
										children: ["Multi-agent", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
											id: "skill-multi-agent",
											className: "mt-1.5",
											value: skillMultiAgent,
											onChange: (e) => setSkillMultiAgent(e.target.value),
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "",
													children: "Don't change"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "on",
													children: "On"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "off",
													children: "Off"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "auto",
													children: "Auto"
												})
											]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "block text-xs font-medium text-muted",
										htmlFor: "skill-thinking",
										children: ["Thinking", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
											id: "skill-thinking",
											className: "mt-1.5",
											value: skillThinking,
											onChange: (e) => setSkillThinking(e.target.value),
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "",
													children: "Don't change"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "on",
													children: "On"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "off",
													children: "Off"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "auto",
													children: "Auto"
												})
											]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "block text-xs font-medium text-muted",
										htmlFor: "skill-model",
										children: ["Model", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
											id: "skill-model",
											className: "mt-1.5",
											value: skillModel,
											onChange: (e) => setSkillModel(e.target.value),
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "",
												children: "Don't change"
											}), skillModelOptions.map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: id,
												children: settings.modelAliases[id] ? `${settings.modelAliases[id]} · ${id}` : id
											}, id))]
										})]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-meta leading-relaxed text-muted",
								children: "Don't change keeps the Multi-agent, Thinking and model choices you have selected when the skill runs. A value set here applies to that one reply only — your Settings are never rewritten."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 flex flex-wrap items-center gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										onClick: saveNewSkill,
										children: editingSkillId ? "Save changes" : "Save skill"
									}),
									editingSkillId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										variant: "secondary",
										onClick: cancelSkillEdit,
										children: "Cancel"
									}) : null,
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "inline-flex min-h-10 cursor-pointer items-center justify-center rounded-md bg-surface-2 px-3 text-xs font-medium text-fg shadow-[0_0_0_1px_var(--color-border)] hover:bg-surface",
										children: ["Upload a file", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											id: "skill-file",
											type: "file",
											className: "sr-only",
											accept: SKILL_FILE_ACCEPT,
											"aria-label": "Upload a text or Markdown file to fill the skill form",
											onChange: (event) => {
												const file = event.target.files?.[0];
												event.target.value = "";
												if (file) importSkillFile(file);
											}
										})]
									}),
									skillMessage ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted",
										children: skillMessage
									}) : null
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-2 text-meta leading-relaxed text-muted",
								children: [
									"An upload is read in this browser and only fills the fields above. Instructions are held to ",
									MAX_INSTRUCTION_CHARS,
									" characters."
								]
							}),
							userSkills.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-3 flex flex-col gap-1.5",
								children: userSkills.map((skill) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex items-center justify-between gap-2 rounded-md bg-surface-2 px-2.5 py-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "min-w-0",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "block truncate text-sm text-fg",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "mr-2 font-mono text-xs text-muted",
												children: skill.trigger
											}), skill.name !== skill.trigger ? skill.name : null]
										}), describeSkillSettings(skill.settings) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "mt-0.5 block truncate text-meta text-muted",
											children: describeSkillSettings(skill.settings)
										}) : null]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "flex shrink-0 items-center gap-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											size: "sm",
											variant: "secondary",
											"aria-label": `Edit ${skill.name}`,
											onClick: () => editSkill(skill.id),
											children: "Edit"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											size: "sm",
											variant: "danger",
											"aria-label": `Delete ${skill.name}`,
											onClick: () => {
												if (editingSkillId === skill.id) cancelSkillEdit();
												removeUserSkill(skill.id);
											},
											children: "Delete"
										})]
									})]
								}, skill.id))
							}) : null
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MultiAgentSkillsPanel, {})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContextPanel, { category }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				id: "settings-multi-agent",
				className: cn("settings-panel scroll-mt-20 rounded-lg bg-surface p-4 shadow-[0_0_0_1px_var(--color-border)]", category !== "multi-agent" && "hidden"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-medium",
					children: "Multi-agent"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MultiAgentPanel, {})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppearancePanel, { category }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OutputPanel, { category }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsLateSections, {
				category,
				onAfterClear
			})
		]
	});
}
var SplitComponent = SettingsPage;
//#endregion
export { SplitComponent as component };
