//#region node_modules/.nitro/vite/services/ssr/assets/local-client-Cqz3VYgc.js
async function transcribeAudio(options) {
	const query = new URLSearchParams();
	if (options.tier) query.set("tier", options.tier);
	if (options.wakePhrase) query.set("wakePhrase", options.wakePhrase);
	if (options.sleepPhrase) query.set("sleepPhrase", options.sleepPhrase);
	const response = await fetch(`/api/tts/stt/transcribe?${query.toString()}`, {
		method: "POST",
		headers: { "content-type": options.blob.type || "audio/webm" },
		body: options.blob,
		signal: options.signal
	});
	const data = await response.json().catch(() => ({}));
	if (!response.ok) throw new Error(data.error || `Local STT request failed (HTTP ${response.status}).`);
	return {
		text: data.text || "",
		model: data.model === "small" ? "small" : "base",
		wakeDetected: data.wakeDetected === true
	};
}
function containsPhrase(text, phrase) {
	const needle = phrase.trim();
	if (!needle) return false;
	try {
		return new RegExp(`(?:^|[^\\p{L}\\p{N}_])${escapeRegExp(needle)}(?=$|[^\\p{L}\\p{N}_])`, "iu").test(text);
	} catch {
		return false;
	}
}
function removePhrase(text, phrase) {
	if (!phrase.trim()) return text.trim();
	return text.replace(new RegExp(escapeRegExp(phrase.trim()), "ig"), " ").replace(/\s+/g, " ").trim();
}
function escapeRegExp(value) {
	return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
//#endregion
export { removePhrase as n, transcribeAudio as r, containsPhrase as t };
