import { i as __toESM } from "../_runtime.mjs";
import { H as require_jsx_runtime, V as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Webhook, at as Globe, bt as Clock3, f as Trash2, k as Repeat, tt as Link2 } from "../_libs/lucide-react.mjs";
import { $ as SCHEDULE_UNITS, It as formatRunAt, St as describeProbeMatch, Ut as isJobActive, Yt as jobKind, bt as describeCadence, cn as nextRunAt, d as refreshAutomationSchedule, er as useAppStore, f as removeAutomationThroughServer, h as Button, m as describeRunWire, p as setAutomationEnabledThroughServer, pt as clampScheduleEvery, xt as describeNextRun } from "./router-CiIP6cPA.mjs";
import { t as Toggle } from "./toggle-DgNqV39s.mjs";
import { t as copyText } from "./copy-D7bd_Qke.mjs";
import { n as Select, r as Textarea, t as Input } from "./input-CURER8tx.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/automations-CtCArsfm.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/** The stored check outcome, in words a reader can act on. */
var PROBE_STATUS_LABELS = {
	ok: "checked",
	"no-match": "no match yet",
	changed: "page changed",
	unchanged: "no change",
	error: "page could not be fetched"
};
/**
* V10.21 — one automation, as a card.
*
* The old row put the prompt, the cadence, the next run, the watch target, the
* webhook control and a two-line Toggle all on one flex line. The Toggle's
* description reserved up to 52ch, so on a normal window the prompt column was
* squeezed until the lines collided — "really messy, overlapping text" was the
* reader's report, and it was accurate.
*
* The card is a grid: a kind tile, a content column that can shrink to nothing,
* and a fixed action cluster. Nothing shares a line with anything it can
* overlap. The questions a job has to answer are answered on their own lines:
*
*   what it does        the prompt, two lines, full text in the tooltip
*   how often           the cadence ("Every 15 minutes", "On webhook")
*   when next           a human "in 12 min" AND the exact local timestamp, or
*                       "waiting for an event" for a push job
*   where events land   only for webhook jobs: the endpoint, plus the target
*   what it watches     only for website jobs: the host, the rule, the last check
*
* V10.22 — a webhook job prints its endpoint as text. The URL used to be hidden
* behind an icon, which is the wrong emphasis for the one thing the reader has
* to copy into another tool, so a push job shows `…/trigger/<id>` and a
* "Webhook" copy control beside it.
*/
function JobRow({ item, onToggle, onRemove, delivery, onResolve, onRecoverFailed, now = Date.now(), scheduleState, lastRun }) {
	const [copied, setCopied] = (0, import_react.useState)(null);
	const [recoveryMessage, setRecoveryMessage] = (0, import_react.useState)(null);
	const active = isJobActive(item);
	const kind = jobKind(item);
	const isWebhook = kind === "webhook";
	const KindIcon = kind === "webhook" ? Webhook : kind === "watch" ? Globe : kind === "every" ? Repeat : Clock3;
	const kindLabel = kind === "webhook" ? "Webhook" : kind === "watch" ? "Website watch" : kind === "every" ? "Repeating" : "One-shot";
	const cadence = (0, import_react.useMemo)(() => describeCadence(item), [item]);
	const nextRun = (0, import_react.useMemo)(() => formatRunAt(item.runAt), [item.runAt]);
	const endpoint = (0, import_react.useMemo)(() => `/api/automations/trigger/${item.id}`, [item.id]);
	const host = (0, import_react.useMemo)(() => {
		if (!item.probe) return "";
		try {
			return new URL(item.probe.url).host;
		} catch {
			return item.probe.url;
		}
	}, [item]);
	function copyWebhook() {
		if (!item.webhookToken) return;
		const url = `${typeof window !== "undefined" ? window.location.origin : ""}/api/automations/trigger/${item.id}?token=${encodeURIComponent(item.webhookToken)}`;
		copyText(url).then((result) => {
			setCopied(result.ok ? "Webhook URL copied — it contains the token, so keep it private." : "Copy failed — select the URL from the button's tooltip instead.");
		});
	}
	const webhookUrl = item.webhookToken && typeof window !== "undefined" ? `${window.location.origin}/api/automations/trigger/${item.id}?token=${encodeURIComponent(item.webhookToken)}` : endpoint;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
		className: "group rounded-lg bg-surface shadow-[inset_0_0_0_1px_var(--color-border)] transition-colors hover:bg-surface-2",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-2 p-3 sm:flex-row sm:items-start sm:gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-w-0 flex-1 items-start gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: ["flex size-9 shrink-0 items-center justify-center rounded-md bg-bg shadow-[0_0_0_1px_var(--color-border)]", !active ? "text-muted/70" : kind === "webhook" || kind === "watch" ? "text-signal" : kind === "every" ? "text-fg" : "text-muted"].join(" "),
					title: kindLabel,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KindIcon, {
						className: "size-4",
						"aria-hidden": "true"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "sr-only",
						children: kindLabel
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "line-clamp-2 break-words text-[0.9375rem] leading-relaxed text-fg data-[off=true]:text-muted",
							"data-off": active ? "false" : "true",
							title: item.text,
							children: item.text
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 flex flex-wrap items-baseline gap-x-2 gap-y-0.5 text-meta leading-relaxed text-faint",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono",
								children: cadence
							})
						}),
						scheduleState ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-0.5 text-meta leading-relaxed text-faint",
							children: scheduleState
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-0.5 text-meta leading-relaxed text-faint",
							children: !active ? "Paused — no next run until it is switched back on." : isWebhook ? "Waiting for an event — held on disk until this tab is online." : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								"Next run ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono text-fg/80",
									children: nextRun
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-muted",
									children: [" · ", describeNextRun(item, now)]
								})
							] })
						}),
						lastRun ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-0.5 text-meta leading-relaxed text-faint",
							title: lastRun.detail ?? lastRun.error ?? void 0,
							children: [
								"Last run ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono text-fg/80",
									children: new Date(lastRun.occurrenceAt).toLocaleString()
								}),
								" ",
								"· ",
								describeRunWire(lastRun),
								lastRun.attempts > 1 ? ` · ${lastRun.attempts} attempts` : ""
							]
						}) : null,
						isWebhook ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-0.5 flex flex-wrap items-baseline gap-x-2 break-all text-meta leading-relaxed text-faint",
							title: webhookUrl,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Endpoint ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-fg/80",
								children: endpoint
							})] }), item.probe ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["· watching ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-fg/80",
								children: host
							})] }) : null]
						}) : item.probe ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-0.5 break-words text-meta leading-relaxed text-faint",
							title: item.probe.url,
							children: [
								"Watching ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono text-fg/80",
									children: host
								}),
								" —",
								" ",
								describeProbeMatch(item),
								item.probe.lastStatus ? ` · last check: ${PROBE_STATUS_LABELS[item.probe.lastStatus]}` : " · not checked yet"
							]
						}) : null,
						isWebhook && delivery && delivery.uncertain > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 rounded-md bg-well p-2.5 shadow-[inset_0_0_0_1px_var(--color-border)]",
							role: "status",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-meta leading-relaxed text-fg",
								children: [
									delivery.uncertain === 1 ? "A run could not be confirmed" : `${delivery.uncertain} runs could not be confirmed`,
									" ",
									"— the app stopped before it could say whether the task finished. It will not run again on its own."
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-1.5 flex flex-wrap gap-1.5",
								children: delivery.uncertainEventIds.map((eventId) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "inline-flex gap-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "rounded-md bg-surface-2 px-2 py-1 text-meta text-fg shadow-[0_0_0_1px_var(--color-border)] hover:bg-bg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[color:var(--color-accent)]",
										"aria-label": `Mark ${eventId} as already run`,
										title: "The task did run — record it as delivered and stop asking.",
										onClick: () => onResolve?.(eventId, "done"),
										children: "It ran"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "rounded-md px-2 py-1 text-meta text-muted hover:bg-surface-2 hover:text-fg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[color:var(--color-accent)]",
										"aria-label": `Run ${eventId} again`,
										title: "Run the task again for this event.",
										onClick: () => onResolve?.(eventId, "retry"),
										children: "Run again"
									})]
								}, eventId))
							})]
						}) : null,
						isWebhook && delivery && delivery.failed > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 border-l-2 border-signal pl-3 py-0.5",
							role: "status",
							"aria-label": "Exhausted webhook events",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-meta leading-relaxed text-fg",
									children: [
										delivery.failed === 1 ? "One event exhausted its retries" : `${delivery.failed} events exhausted their retries`,
										".",
										" ",
										"The task was not confirmed delivered after six claims. It is stopped, not waiting to run again.",
										delivery.capacity && delivery.capacity.total >= delivery.capacity.limit ? ` The queue is full (${delivery.capacity.total}/${delivery.capacity.limit}); active accepted events are kept.` : " Choose a deliberate retry or remove the event; it will not restart by itself."
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "mt-1.5 flex flex-col gap-1.5",
									children: delivery.failedEvents.map((event) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "flex flex-wrap items-center gap-x-2 gap-y-1 text-meta text-muted",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-mono text-fg/80",
												title: `Event ${event.id}`,
												children: event.eventId ? `key ${event.eventId}` : `event ${event.id.slice(0, 18)}`
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("time", {
												dateTime: new Date(event.at).toISOString(),
												title: new Date(event.at).toLocaleString(),
												children: new Date(event.at).toLocaleString()
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [event.attempts, " claims"] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												className: "rounded-md bg-surface-2 px-2 py-1 text-meta text-fg shadow-[0_0_0_1px_var(--color-border)] hover:bg-bg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[color:var(--color-accent)]",
												"aria-label": `Retry exhausted event ${event.id}`,
												onClick: async () => {
													setRecoveryMessage(null);
													const ok = await onRecoverFailed?.(event.id, "retry");
													setRecoveryMessage(ok ? "Retry queued with the same event identity." : "Retry was not saved; the event remains exhausted.");
												},
												children: "Retry this event"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												className: "rounded-md px-2 py-1 text-meta text-muted hover:bg-surface-2 hover:text-fg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[color:var(--color-accent)]",
												"aria-label": `Remove exhausted event ${event.id}`,
												onClick: async () => {
													if (!(typeof window !== "undefined" && window.confirm("Remove this exhausted webhook event? It will not run again. Other accepted events will remain."))) return;
													setRecoveryMessage(null);
													const ok = await onRecoverFailed?.(event.id, "remove");
													setRecoveryMessage(ok ? "Event removed." : "Removal was not saved; the event remains.");
												},
												children: "Remove event…"
											})
										]
									}, event.id))
								}),
								recoveryMessage ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-meta text-fg",
									role: "status",
									children: recoveryMessage
								}) : null
							]
						}) : null,
						copied ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-meta leading-relaxed text-faint",
							role: "status",
							children: copied
						}) : null
					]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex shrink-0 items-center gap-1 self-end sm:self-start",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
						id: `automation-enabled-${item.id}`,
						compact: true,
						label: active ? "On" : "Off",
						checked: active,
						onChange: (checked) => onToggle(item.id, checked)
					}),
					item.webhookToken ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "inline-flex h-8 items-center gap-1.5 rounded-md px-2 text-meta text-muted hover:bg-bg hover:text-fg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[color:var(--color-accent)]",
						"aria-label": `Copy webhook URL for ${item.text}`,
						title: "Copy the webhook URL — it contains the token, so keep it private.",
						onClick: copyWebhook,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link2, {
							className: "size-4",
							"aria-hidden": "true"
						}), isWebhook ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Webhook" }) : null]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "inline-flex size-8 items-center justify-center rounded-md text-faint opacity-0 transition-opacity hover:bg-bg hover:text-danger focus-visible:opacity-100 group-hover:opacity-100 group-focus-within:opacity-100 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[color:var(--color-accent)]",
						"aria-label": `Delete automation ${item.text}`,
						title: "Delete this automation",
						onClick: () => onRemove(item.id),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {
							className: "size-4",
							"aria-hidden": "true"
						})
					})
				]
			})]
		})
	});
}
/**
* The form that creates a scheduled local prompt. It is the only creation path
* (the Automations page renders it), and it no longer renders a job list of its
* own: the page's Jobs section is the single list, using the shared JobRow.
*
* V10.3 polish — the form is: task prompt → cadence choice (Every | When) →
* Start task. "Every" is the interval; "When" is the website trigger.
*
* V10.21 — the unit list carries minutes and weeks, and the two fields share a
* grid so the labels and the preview sit on one baseline.
*
* V10.22 — "When" is a WEBHOOK now, not a poller. The reader's point: checking
* a page every so often is a guess, and a short interval only works while the
* tab happens to be open. A When job therefore has no interval and no match
* rule. It owns a trigger URL, whatever watches the page POSTs to it, and the
* event waits in the local queue until this device can run it — including after
* the machine was offline, which is the whole reason for a queue. The target
* URL is optional here because it is only a label on the row; Oqe never fetches
* it.
*/
function SchedulePanel() {
	const add = useAppStore((s) => s.addScheduledPrompt);
	const [text, setText] = (0, import_react.useState)("");
	const [kind, setKind] = (0, import_react.useState)("every");
	const [every, setEvery] = (0, import_react.useState)("1");
	const [unit, setUnit] = (0, import_react.useState)("hours");
	const [url, setUrl] = (0, import_react.useState)("");
	const [message, setMessage] = (0, import_react.useState)(null);
	const everyValue = clampScheduleEvery(Number(every));
	const nextRun = (0, import_react.useMemo)(() => nextRunAt(Date.now(), {
		unit,
		every: everyValue
	}), [unit, everyValue]);
	function submit() {
		const webhook = kind === "when";
		const recurrence = {
			unit,
			every: everyValue
		};
		const target = url.trim();
		const error = add(text, webhook ? Date.now() : nextRunAt(Date.now(), recurrence), webhook ? void 0 : recurrence, {
			...webhook && target ? { probe: {
				url: target,
				mode: "hash"
			} } : {},
			...webhook ? { trigger: "webhook" } : {}
		});
		setMessage(error ?? (webhook ? "Task started — it runs when its webhook receives an event." : "Task started — runs here in this tab."));
		if (!error) setText("");
	}
	const cadence = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-1.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-xs font-medium text-muted",
			children: "When should it run?"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex gap-2",
			role: "radiogroup",
			"aria-label": "Cadence",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				"aria-pressed": kind === "every",
				className: kind === "every" ? "bg-accent/10 text-accent shadow-[inset_0_0_0_1px_var(--color-accent)] hover:bg-accent/15" : void 0,
				onClick: () => setKind("every"),
				children: "Every"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				"aria-pressed": kind === "when",
				className: kind === "when" ? "bg-accent/10 text-accent shadow-[inset_0_0_0_1px_var(--color-accent)] hover:bg-accent/15" : void 0,
				onClick: () => setKind("when"),
				children: "When"
			})]
		})]
	});
	const intervalFields = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-3 sm:grid-cols-[7rem_12rem]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
			className: "text-xs font-medium text-muted",
			htmlFor: "automation-every",
			children: ["Repeat every", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				id: "automation-every",
				type: "number",
				min: 1,
				max: 720,
				className: "mt-1.5",
				value: every,
				onChange: (event) => setEvery(event.target.value.replace(/[^0-9]/g, ""))
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
			className: "text-xs font-medium text-muted",
			htmlFor: "automation-unit",
			children: ["Unit", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
				id: "automation-unit",
				className: "mt-1.5",
				value: unit,
				onChange: (event) => setUnit(event.target.value),
				children: SCHEDULE_UNITS.map((value) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
					value,
					children: value
				}, value))
			})]
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs leading-relaxed text-muted",
				children: "The local Oqe server keeps this schedule. Not OS Task Scheduler."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "text-xs font-medium text-muted",
				htmlFor: "automation-prompt",
				children: ["Task prompt", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					id: "automation-prompt",
					className: "mt-1 min-h-16",
					value: text,
					onChange: (event) => setText(event.target.value),
					placeholder: "What should Oqe do?"
				})]
			}),
			cadence,
			kind === "every" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-2",
				children: [intervalFields, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-meta leading-relaxed text-muted",
					children: [
						"First run ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-fg/80",
							children: formatRunAt(nextRun)
						}),
						",",
						" ",
						describeNextRun({
							runAt: nextRun,
							enabled: true
						})
					]
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "max-w-[58ch] text-xs leading-relaxed text-muted",
					children: "Oqe does not check anything on a schedule. The page, the service or a script POSTs to this job’s webhook URL, and the task runs when that event arrives."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "text-xs font-medium text-muted",
					htmlFor: "automation-url",
					children: [
						"Page or service",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-normal text-muted/80",
							children: "(optional, only names the job)"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "automation-url",
							type: "url",
							className: "mt-1.5",
							value: url,
							onChange: (event) => setUrl(event.target.value),
							placeholder: "https://example.com/weather"
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-3",
				children: [kind === "when" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "max-w-[46ch] text-xs text-muted",
					children: "The endpoint accepts events while Oqe is running; an accepted event is kept on disk and runs as soon as this tab is online. No third-party service, no per-event cost."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { "aria-hidden": "true" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "primary",
					onClick: submit,
					children: "Start task"
				})]
			}),
			message ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "-mt-1 text-xs text-muted",
				role: "status",
				children: message
			}) : null
		]
	});
}
/**
* Prompt 35 — the Automations surface, unchanged in shape and honest about who
* runs the schedule now.
*
* WHAT THE READER SEES DIFFERENTLY:
*
*   - the list is the LOCAL DATABASE's list, not a `localStorage` copy;
*   - each row carries the scheduler's own state line and its last recorded run,
*     so "due", "running" and "expired" are visible instead of implied;
*   - if the schedule cannot be read, the page says so. An empty list used to be
*     indistinguishable from a failed read, which is the one wrong impression
*     this page must never give: it looks like the reader's jobs are gone.
*
* The webhook half is untouched: a "When" job is still an event queue with a
* claim/ack/lease lifecycle (V10.28). This prompt moved the CLOCK into the local
* database; it did not replace the delivery path.
*/
function AutomationsPage() {
	const prompts = useAppStore((s) => s.scheduledPrompts);
	const schedule = useAppStore((s) => s.automationSchedule);
	const delivery = useAppStore((s) => s.webhookDelivery);
	const resolveDelivery = useAppStore((s) => s.resolveWebhookEvent);
	const recoverFailedDelivery = useAppStore((s) => s.recoverFailedWebhookEvent);
	(0, import_react.useEffect)(() => {
		refreshAutomationSchedule();
	}, []);
	const activeCount = prompts.filter(isJobActive).length;
	const ordered = [...prompts].sort((a, b) => a.runAt - b.runAt);
	const stateById = new Map(schedule.jobs.map((job) => [job.id, job]));
	const runById = /* @__PURE__ */ new Map();
	for (const run of schedule.runs) if (!runById.has(run.jobId)) runById.set(run.jobId, run);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex w-full max-w-3xl flex-col gap-6 px-4 py-7 sm:px-6 lg:px-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "border-b border-border pb-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-2xl font-semibold tracking-[-0.02em]",
					children: "Automations"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-xl text-sm text-muted",
					children: prompts.length === 0 ? "Run a prompt every few minutes, hours, days or weeks, or when something happens on a website. The local Oqe server keeps the schedule; it runs free, on this machine." : `${prompts.length} automation${prompts.length === 1 ? "" : "s"}. ${activeCount} on${activeCount < prompts.length ? `, ${prompts.length - activeCount} paused` : ""}.`
				})]
			}),
			schedule.error ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-lg bg-surface p-3 shadow-[0_0_0_1px_var(--color-border)]",
				role: "status",
				"aria-label": "Schedule unavailable",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium text-fg",
						children: "The schedule could not be read"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 max-w-md text-label leading-relaxed text-muted",
						children: schedule.error
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-meta leading-relaxed text-faint",
						children: "Nothing was deleted. The list below is the last state this window saw; check that the local Oqe server is running, then reload."
					})
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "rounded-lg bg-surface p-4 shadow-[0_0_0_1px_var(--color-border)]",
				"aria-label": "New automation",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SchedulePanel, {})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				"aria-labelledby": "automations-jobs-heading",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-baseline justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							id: "automations-jobs-heading",
							className: "text-base font-semibold tracking-[-0.012em]",
							children: "Jobs"
						}), prompts.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-meta text-muted",
							children: "Soonest first. Scheduled by the local server; the model runs while Oqe is open."
						}) : null]
					}),
					schedule.missedCount > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-meta leading-relaxed text-faint",
						children: [
							schedule.missedCount === 1 ? "One occurrence was recorded as missed while Oqe was not running." : `${schedule.missedCount} occurrences were recorded as missed while Oqe was not running.`,
							" ",
							"Missed occurrences are not re-run in a burst; each job continues from its next one."
						]
					}) : null,
					ordered.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-2 flex flex-col gap-2",
						children: ordered.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(JobRow, {
							item,
							scheduleState: stateById.get(item.id)?.state,
							lastRun: runById.get(item.id) ?? stateById.get(item.id)?.lastRun ?? null,
							onToggle: (id, enabled) => {
								setAutomationEnabledThroughServer(id, enabled);
							},
							onRemove: (id) => {
								removeAutomationThroughServer(id);
							},
							delivery: delivery[item.id],
							onResolve: (eventId, decision) => {
								resolveDelivery(item.id, eventId, decision);
							},
							onRecoverFailed: (eventId, action) => recoverFailedDelivery(item.id, eventId, action)
						}, item.id))
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 rounded-lg bg-surface p-4 shadow-[0_0_0_1px_var(--color-border)]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium text-fg",
							children: "No jobs yet"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1.5 max-w-md text-label leading-relaxed text-muted",
							children: "Write what Oqe should do above, then choose when it runs. To react to a website instead, create a job that runs on an event and give that page or service the job’s URL. Events are kept on disk and run as soon as this tab is open."
						})]
					})
				]
			})
		]
	});
}
var SplitComponent = AutomationsPage;
//#endregion
export { SplitComponent as component };
