import { O as CompanionRequestError } from "./router-CiIP6cPA.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/status-CNfpf13v.js
/**
* V8.1 — companion pairing/status contract for the UI (V11 wording).
*
* The bug this fixes (the Settings pairing "disappearing"): the mount effect
* treated ANY failed `health()` as an invalid pairing and DELETED the browser's
* saved pairing state (the legacy `oqe.companionToken.v1` key). A health check
* failing has exactly two honest meanings and neither one is "unpaired":
*
*   1. the companion process is not running (ECONNREFUSED / 502 from the
*      same-origin proxy) — pairing is intact, the helper is offline;
*   2. the companion answered 401 — the token was rejected (the helper's
*      persisted token was deleted or replaced) — the pairing is genuinely
*      dead and re-pairing is required.
*
* V11 model: the credential lives on the server, never in the browser. The
* app's supervisor holds the token in memory and the companion persists its
* own copy in the per-user data directory, so `hasToken` here means "this app
* session is paired", not "the browser stored a token". The browser keeps only
* the non-secret paired marker.
*
* Truth table, encoded once here so Settings, Chat, and tests cannot drift:
*   - A paired app session EXISTS → report paired. Full stop.
*   - Health succeeds → the companion state (paired/enabled/STOP) is live.
*   - Health fails with anything other than 401 → "Paired (companion offline)"
*     and the pairing state is KEPT.
*   - Health fails with 401 → reported as "Paired but rejected". Even here
*     nothing is cleared automatically: re-pairing replaces the app session and
*     the explicit Unpair button clears it. NO failure unpairs by itself.
*/
/** HTTP status carried by a CompanionClient failure (undefined on network error). */
function companionErrorStatus(error) {
	if (error instanceof CompanionRequestError) return error.status;
	if (error instanceof Error) {
		const match = /\((\d{3})\)\s*$/.exec(error.message);
		return match ? Number(match[1]) : void 0;
	}
}
/** The only HTTP failure that means "this pairing is dead" (companion rejected the token). */
function isTokenRejected(error) {
	return companionErrorStatus(error) === 401;
}
function companionPairingStatus(hasToken, lastError) {
	if (!hasToken) return "unpaired";
	if (lastError === void 0) return "paired";
	return isTokenRejected(lastError) ? "token_rejected" : "paired_offline";
}
/**
* V8.5 P0-D (user #11) — the desktop-mode composer placeholder, derived ONLY
* from real gate state. When automation is enabled and at least one target is
* already consented, the composer must NOT say "needs companion consent" —
* that copy is only honest for a target that has not been consented yet.
*/
function desktopComposerPlaceholder(input) {
	const consented = (input.consentedTargets ?? []).filter((t) => t.trim().length > 0);
	if (input.enabled && consented.length > 0) return `Message Oqe — desktop control ready (consent granted: ${consented.join(", ")})`;
	return "Message Oqe — desktop control intended (needs companion consent)";
}
/** One line of honest UI copy per status; shown under the Pair button. */
function companionStatusLine(status, state) {
	switch (status) {
		case "unpaired": return "Not paired";
		case "token_rejected": return "Paired but rejected — the companion no longer knows this token. Pair again or Unpair.";
		case "paired_offline": return "Paired (companion offline)";
		case "paired":
			if (state?.paired && state.enabled) return "Paired and enabled";
			if (state?.paired && state.stopped) return "STOP latched";
			if (state?.paired) return "Paired, disabled";
			return "Companion up, not paired with it";
	}
}
//#endregion
export { companionStatusLine as n, desktopComposerPlaceholder as r, companionPairingStatus as t };
