import { i as __toESM } from "../_runtime.mjs";
import { V as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/use-hold-drag-E5tQGD5V.js
var import_react = /* @__PURE__ */ __toESM(require_react());
/**
* V10.11 — PRESS AND HOLD, THEN MOVE: reordering without a control column.
*
* The reader's request: "the rearranging steps shouldn't be so bulky, just if
* i hold down on it i should be able to move it instead of arrows up and
* down". So the list has no arrows and no handles — a hold anywhere on a row
* picks it up, and the row it is over becomes the drop target. A tap still
* places the caret in the row's input, because nothing happens until the hold
* has lasted `HOLD_MS` AND the pointer has not wandered (a scroll or a text
* selection cancels the arming instead).
*
* WHY THE TIMER LIVES HERE AND NOT IN THE STRIP
* ---------------------------------------------
* The strip's own contract forbids clocks: every number it shows is something
* the run recorded, never something it counted (v72/v73 source contracts). This
* timer measures a gesture, not the run — it never feeds a displayed value — so
* it is kept out of the strip's rendering logic rather than weakening that
* rule.
*
* Pointer capture is taken when the hold arms, so the move and the release
* still arrive at the row even when the pointer leaves it; `elementFromPoint`
* is hit-testing, not event routing, so the drop target is still whichever row
* is under the pointer.
*/
var HOLD_MS = 220;
var MOVE_TOLERANCE_PX = 8;
function rowAt(x, y, attribute) {
	if (typeof document === "undefined") return null;
	const row = document.elementFromPoint(x, y)?.closest(`[${attribute}]`);
	if (!row) return null;
	const raw = row.getAttribute(attribute);
	const index = Number(raw);
	return row.hasAttribute(attribute) && raw !== null && Number.isInteger(index) && index >= 0 ? index : null;
}
function useHoldDrag(options) {
	const { count, onMove, attribute = "data-step-index", ignore } = options;
	const [dragging, setDragging] = (0, import_react.useState)(null);
	const [over, setOverState] = (0, import_react.useState)(null);
	const press = (0, import_react.useRef)(null);
	const overRef = (0, import_react.useRef)(null);
	const moveRef = (0, import_react.useRef)(onMove);
	moveRef.current = onMove;
	const setOver = (0, import_react.useCallback)((index) => {
		overRef.current = index;
		setOverState(index);
	}, []);
	const disarm = (0, import_react.useCallback)(() => {
		const current = press.current;
		if (current?.timer != null) window.clearTimeout(current.timer);
		press.current = null;
		setDragging(null);
		setOver(null);
	}, [setOver]);
	(0, import_react.useEffect)(() => disarm, [disarm]);
	return {
		dragging,
		over,
		rowProps: (0, import_react.useCallback)((index) => ({
			...attribute === "data-voice-index" ? { "data-voice-index": index } : { "data-step-index": index },
			onPointerDown: (event) => {
				if (event.pointerType === "mouse" && event.button !== 0) return;
				if (ignore && event.target instanceof Element && event.target.closest(ignore)) return;
				if (press.current) disarm();
				const element = event.currentTarget;
				const next = {
					index,
					pointerId: event.pointerId,
					x: event.clientX,
					y: event.clientY,
					timer: null,
					held: false,
					element
				};
				next.timer = window.setTimeout(() => {
					if (press.current !== next) return;
					next.held = true;
					try {
						element.setPointerCapture(next.pointerId);
					} catch {}
					if (document.activeElement instanceof HTMLElement) document.activeElement.blur();
					document.getSelection()?.removeAllRanges();
					setDragging(index);
					setOver(index);
				}, HOLD_MS);
				press.current = next;
			},
			onPointerMove: (event) => {
				const current = press.current;
				if (!current || current.index !== index) return;
				if (!current.held) {
					if (Math.abs(event.clientX - current.x) > MOVE_TOLERANCE_PX || Math.abs(event.clientY - current.y) > MOVE_TOLERANCE_PX) disarm();
					return;
				}
				event.preventDefault();
				const target = rowAt(event.clientX, event.clientY, attribute);
				if (target !== null && target !== overRef.current) setOver(target);
			},
			onPointerUp: () => {
				const current = press.current;
				if (!current || current.index !== index) {
					if (current) disarm();
					return;
				}
				const target = overRef.current;
				const held = current.held;
				disarm();
				if (held && target !== null && target !== index && target >= 0 && target < count) moveRef.current(index, target);
			},
			onPointerCancel: () => disarm(),
			onContextMenu: (event) => {
				if (press.current?.held) event.preventDefault();
			}
		}), [
			attribute,
			count,
			disarm,
			ignore,
			setOver
		])
	};
}
//#endregion
export { useHoldDrag as t };
