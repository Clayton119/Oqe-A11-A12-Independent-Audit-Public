import { i as __toESM } from "../_runtime.mjs";
import { H as require_jsx_runtime, V as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { Q as Lock, S as ShieldAlert, p as Terminal, st as FlaskConical } from "../_libs/lucide-react.mjs";
import { h as Button, n as APPROVAL_RULES, r as ROLLBACK_LIMITS, w as cn } from "./router-CiIP6cPA.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/systems-lab-B38zkQ75.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var SYSTEMS_LAB_STAGES = [
	{
		id: "proposal",
		label: "Proposal",
		purpose: "Ask for a change to Oqe's own code and read the exact diff it would make."
	},
	{
		id: "candidate",
		label: "Candidate copy",
		purpose: "Copy the project into a disposable workspace, leaving secrets and user data behind."
	},
	{
		id: "checks",
		label: "Checks",
		purpose: "Run the candidate's type-check, lint, tests and build inside the boundary."
	},
	{
		id: "preview",
		label: "Preview",
		purpose: "Build and launch the candidate in the workspace, then open it here."
	}
];
var SYSTEMS_LAB_CHECKS = [
	{
		script: "typecheck",
		label: "Type-check",
		detail: "tsc --noEmit — no emit, no build output.",
		argv: [
			"run",
			"--silent",
			"typecheck"
		]
	},
	{
		script: "lint",
		label: "Lint",
		detail: "eslint over the tree.",
		argv: [
			"run",
			"--silent",
			"lint"
		]
	},
	{
		script: "test",
		label: "Tests",
		detail: "The repository's own test runner, including the scripts and extension suites.",
		argv: [
			"run",
			"--silent",
			"test"
		]
	},
	{
		script: "build",
		label: "Build",
		detail: "The production build. A preview needs this to have succeeded first.",
		argv: [
			"run",
			"--silent",
			"build"
		]
	}
];
/** The one sentence that keeps a green check from being read as a guarantee. */
var CHECK_RESULT_TRUTH = "PASS means the command exited 0 inside the disposable copy. It is evidence, not proof: a passing suite does not show that a change is correct.";
/**
* Files the Lab refuses to propose changes to, whatever the diff says.
*
* The list is deliberately about BOUNDARIES, not about files that are merely important: the
* safety and consent code, the execution boundary itself, the release and packaging path,
* and the auth gates. A lab that can rewrite its own sandbox, its own STOP handling or a
* release checksum is not a lab — it is a way to change the product without review.
*/
var PROTECTED_PATHS = [
	{
		path: "companion/safety.py",
		reason: "desktop-control safety and STOP handling"
	},
	{
		path: "companion/execute_gate.py",
		reason: "the desktop execute gate"
	},
	{
		path: "companion/pairing.py",
		reason: "companion pairing"
	},
	{
		path: "companion/audit_log.py",
		reason: "the desktop audit trail"
	},
	{
		path: "src/lib/capability-ceiling.ts",
		reason: "the capability ceiling every run obeys"
	},
	{
		path: "src/lib/skill-capability.ts",
		reason: "the skill capability policy"
	},
	{
		path: "src/lib/browser-assistant.ts",
		reason: "browser control, authorizations and consent"
	},
	{
		path: "src/lib/browser-attest.server.ts",
		reason: "target attestation for navigation"
	},
	{
		path: "src/lib/execution/",
		reason: "the isolation boundary this lab depends on"
	},
	{
		path: "src/lib/local-request-security.server.ts",
		reason: "the same-origin gate on local routes"
	},
	{
		path: "src/lib/auth/",
		reason: "the auth gates"
	},
	{
		path: "src/lib/database-schema.server.ts",
		reason: "the database schema and its migrations"
	},
	{
		path: "scripts/release-zip.mjs",
		reason: "release packaging"
	},
	{
		path: "scripts/build-upload-zip.mjs",
		reason: "the archive's packaging allowlist"
	},
	{
		path: "scripts/upload-zip-policy.mjs",
		reason: "what may enter a released archive"
	},
	{
		path: ".github/workflows/ci.yml",
		reason: "the checks that gate a merge"
	},
	{
		path: "package-lock.json",
		reason: "the dependency resolution a change is allowed to assume"
	}
];
/**
* Release artifacts, matched by SHAPE rather than by an exhaustive list.
*
* The packaged builds sit at the root as `Oqe v10.9.zip`, the checksums as
* `RELEASE-V11.0.sha256`, and the installer and the build output appear only when they are
* produced. Enumerating today's names would protect today's files and miss tomorrow's, so the
* rule is the shape: nothing packaged, no checksum, no installer and no release output is ever
* rewritten in place by the Lab.
*/
var PROTECTED_PATTERNS = [
	{
		pattern: /^RELEASE-V[\d.]+\.sha256$/i,
		reason: "a release checksum"
	},
	{
		pattern: /\.zip$/i,
		reason: "a packaged release archive"
	},
	{
		pattern: /^installer\//i,
		reason: "the installer"
	},
	{
		pattern: /^release\//i,
		reason: "the release pipeline's output"
	},
	{
		pattern: /^\.vercel\//i,
		reason: "generated build output"
	},
	{
		pattern: /^dist\//i,
		reason: "generated build output"
	},
	{
		pattern: /\.(exe|msi|msix|appx|dmg|pkg)$/i,
		reason: "a signed distributable"
	}
];
function stripDotSlash(path) {
	let out = path;
	while (out.startsWith("./")) out = out.slice(2);
	return out;
}
/**
* Why this path is protected, or null.
*
* Matching is by exact path OR directory prefix, and case-insensitive because the product
* ships on Windows: `Companion/Safety.py` is the same file as `companion/safety.py` there,
* and a case-sensitive check would let a diff walk straight past the rule.
*/
function protectedPathReason(path, caseInsensitive = true) {
	const raw = stripDotSlash(path.trim());
	if (!raw) return null;
	const normalised = caseInsensitive ? raw.toLowerCase() : raw;
	for (const entry of PROTECTED_PATHS) {
		const protectedPath = caseInsensitive ? entry.path.toLowerCase() : entry.path;
		if (protectedPath.endsWith("/")) {
			if (normalised === protectedPath.slice(0, -1) || normalised.startsWith(protectedPath)) return entry.reason;
			continue;
		}
		if (normalised === protectedPath) return entry.reason;
	}
	for (const entry of PROTECTED_PATTERNS) if (entry.pattern.test(normalised)) return entry.reason;
	return null;
}
var MAX_PATCH_BYTES = 524288;
var MAX_PATCH_LINES = 4e3;
/**
* A patch path, or a refusal.
*
* This is the traversal gate. A proposed diff is untrusted text, and the only shape the Lab
* accepts is a plain relative POSIX path inside the project: no absolute paths, no drive
* letters, no `..` segments, no backslashes (`a\..\..\secrets` on Windows), no NUL bytes and
* no paths that would escape the candidate copy's root once joined.
*/
function patchPath(raw) {
	if (typeof raw !== "string") return {
		ok: false,
		reason: "a file path must be text"
	};
	const trimmed = raw.trim();
	if (!trimmed) return {
		ok: false,
		reason: "a file path is empty"
	};
	if (trimmed.includes("\0")) return {
		ok: false,
		reason: "a file path contains a NUL byte"
	};
	if (/^[a-z]:/i.test(trimmed)) return {
		ok: false,
		reason: `"${trimmed}" is an absolute Windows path`
	};
	if (trimmed.startsWith("/") || trimmed.startsWith("\\")) return {
		ok: false,
		reason: `"${trimmed}" is an absolute path`
	};
	if (trimmed.includes("\\")) return {
		ok: false,
		reason: `"${trimmed}" uses backslashes; a patch must use forward slashes`
	};
	const segments = trimmed.split("/");
	if (segments.some((segment) => segment === "..")) return {
		ok: false,
		reason: `"${trimmed}" climbs out of the project with ".."`
	};
	if (segments.some((segment) => segment === "" || segment === ".")) return {
		ok: false,
		reason: `"${trimmed}" has an empty path segment`
	};
	if (/[<>:"|?*]/.test(trimmed)) return {
		ok: false,
		reason: `"${trimmed}" contains a character a project file cannot have`
	};
	return {
		ok: true,
		path: trimmed,
		status: "modified"
	};
}
function stripPrefix(raw, prefix) {
	const withSlash = `${prefix}/`;
	return raw.startsWith(withSlash) ? raw.slice(withSlash.length) : null;
}
/**
* Read a unified diff into files and hunks — and refuse everything it cannot read.
*
* A parser that guesses is worse than one that refuses: a half-understood patch would let the
* page show a diff that is not the diff. So an unreadable header, a body line outside a hunk,
* a binary marker or a size past the caps is a refusal with a sentence, never a best effort.
*/
function parseCandidatePatch(text) {
	if (typeof text !== "string") return {
		ok: false,
		reason: "a proposal must be text"
	};
	const trimmed = text.trim();
	if (!trimmed) return {
		ok: false,
		reason: "the proposal is empty"
	};
	if (new TextEncoder().encode(trimmed).length > 524288) return {
		ok: false,
		reason: `the proposal is larger than ${Math.round(MAX_PATCH_BYTES / 1024)} KiB, which this lab will not read`
	};
	const lines = trimmed.split(/\r?\n/);
	if (lines.length > 4e3) return {
		ok: false,
		reason: `the proposal has ${lines.length.toLocaleString()} lines; this lab reads at most ${MAX_PATCH_LINES.toLocaleString()}`
	};
	if (lines.some((line) => /^GIT binary patch/.test(line) || /^Binary files .* differ$/.test(line))) return {
		ok: false,
		reason: "the proposal contains a binary change, which this lab cannot show as a diff"
	};
	const files = [];
	let current = null;
	let currentHunk = null;
	let pendingOld = null;
	const commit = () => {
		if (!current) return;
		if (current.hunks.length === 0) throw new Refusal(`"${current.path}" has no hunks, so there is nothing to show`);
		files.push(current);
		current = null;
		currentHunk = null;
	};
	try {
		for (const line of lines) {
			if (line.startsWith("diff --git ")) {
				commit();
				const match = /^diff --git a\/(.+) b\/(.+)$/.exec(line);
				if (!match) throw new Refusal(`the file header "${line.slice(0, 80)}" is not a git diff header`);
				const checked = patchPath(match[2]);
				if (!checked.ok) throw new Refusal(checked.reason);
				current = {
					path: checked.path,
					status: "modified",
					additions: 0,
					deletions: 0,
					hunks: []
				};
				currentHunk = null;
				continue;
			}
			if (line.startsWith("--- ")) {
				const target = line.slice(4).trim();
				if (target === "/dev/null") {
					pendingOld = null;
					continue;
				}
				const stripped = stripPrefix(target, "a");
				if (stripped === null) throw new Refusal(`the removed-file header "${target.slice(0, 80)}" is not prefixed a/`);
				const checked = patchPath(stripped);
				if (!checked.ok) throw new Refusal(checked.reason);
				pendingOld = checked.path;
				continue;
			}
			if (line.startsWith("+++ ")) {
				const target = line.slice(4).trim();
				if (target === "/dev/null") {
					if (!pendingOld) throw new Refusal("a deleted file has no path");
					if (!current) current = {
						path: pendingOld,
						status: "deleted",
						additions: 0,
						deletions: 0,
						hunks: []
					};
					else {
						current.status = "deleted";
						current.path = pendingOld;
					}
					currentHunk = null;
					continue;
				}
				const stripped = stripPrefix(target, "b");
				if (stripped === null) throw new Refusal(`the new-file header "${target.slice(0, 80)}" is not prefixed b/`);
				const checked = patchPath(stripped);
				if (!checked.ok) throw new Refusal(checked.reason);
				if (current && current.path !== checked.path) throw new Refusal(`the file headers name two different paths ("${current.path}" and "${checked.path}")`);
				if (!current) current = {
					path: checked.path,
					status: pendingOld === null ? "added" : "modified",
					additions: 0,
					deletions: 0,
					hunks: []
				};
				currentHunk = null;
				continue;
			}
			if (line.startsWith("@@")) {
				if (!current) throw new Refusal("a hunk appears before any file header");
				const match = /^@@ -\d+(?:,\d+)? \+\d+(?:,\d+)? @@ ?(.*)$/.exec(line);
				if (!match) throw new Refusal(`the hunk header "${line.slice(0, 80)}" is not a valid unified-diff range`);
				currentHunk = {
					header: line.trimEnd(),
					...match[1] ? { context: match[1] } : {},
					lines: []
				};
				current.hunks.push(currentHunk);
				continue;
			}
			if (line.startsWith("index ") || line.startsWith("new file mode ") || line.startsWith("deleted file mode ") || line.startsWith("old mode ") || line.startsWith("new mode ") || line.startsWith("similarity index ") || line.startsWith("rename from ") || line.startsWith("rename to ")) {
				if (line.startsWith("new file mode ") && current) current.status = "added";
				if (line.startsWith("deleted file mode ") && current) current.status = "deleted";
				if ((line.startsWith("rename from ") || line.startsWith("rename to ")) && current) throw new Refusal("the proposal renames a file, which this lab cannot apply");
				continue;
			}
			if (!current || !currentHunk) {
				if (line.trim() === "") continue;
				throw new Refusal("the proposal has text outside any hunk, so it cannot be read as a diff");
			}
			if (line.startsWith("\\")) {
				currentHunk.lines.push({
					kind: "meta",
					text: line
				});
				continue;
			}
			if (line.startsWith("+")) {
				current.additions += 1;
				currentHunk.lines.push({
					kind: "add",
					text: line.slice(1)
				});
				continue;
			}
			if (line.startsWith("-")) {
				current.deletions += 1;
				currentHunk.lines.push({
					kind: "remove",
					text: line.slice(1)
				});
				continue;
			}
			if (line.startsWith(" ")) {
				currentHunk.lines.push({
					kind: "context",
					text: line.slice(1)
				});
				continue;
			}
			if (line === "") {
				currentHunk.lines.push({
					kind: "context",
					text: ""
				});
				continue;
			}
			throw new Refusal(`a hunk line is missing its diff marker: "${line.slice(0, 60)}"`);
		}
		commit();
	} catch (error) {
		if (error instanceof Refusal) return {
			ok: false,
			reason: error.message
		};
		throw error;
	}
	if (files.length === 0) return {
		ok: false,
		reason: "the proposal names no files"
	};
	if (files.length > 24) return {
		ok: false,
		reason: `the proposal changes ${files.length} files; this lab reviews at most 24`
	};
	for (const file of files) if (file.additions === 0 && file.deletions === 0) return {
		ok: false,
		reason: `"${file.path}" changes no lines`
	};
	const additions = files.reduce((total, file) => total + file.additions, 0);
	const deletions = files.reduce((total, file) => total + file.deletions, 0);
	return {
		ok: true,
		files,
		additions,
		deletions,
		summary: `${files.length} file${files.length === 1 ? "" : "s"}, +${additions} −${deletions}`
	};
}
/** Internal refusal carrier — never escapes this module. */
var Refusal = class extends Error {};
/**
* The semantic review a proposal needs before it can even be discussed: protected paths are
* rejected here, by NAME, with the reason. Nothing is dropped silently — a proposal that
* touches the sandbox is refused outright, not filtered down to the harmless half.
*/
function reviewCandidatePatch(text) {
	const parsed = parseCandidatePatch(text);
	if (!parsed.ok) return parsed;
	const blocked = [];
	for (const file of parsed.files) {
		const reason = protectedPathReason(file.path);
		if (reason) blocked.push(`${file.path} — ${reason}`);
	}
	if (blocked.length > 0) return {
		ok: false,
		reason: `the proposal touches files this lab will not change: ${blocked.join("; ")}`
	};
	return parsed;
}
/**
* Is ANY candidate work allowed? Both flags must be true: a probe that found a backend but
* never exercised it is not a verified boundary (Prompt 40's own rule).
*/
function labExecutable(facts) {
	return facts.executionAvailable && facts.isolationProven;
}
/**
* The stage rail.
*
* With the gate closed, all four stages are `blocked` and carry the service's sentence — the
* page then has nothing that can be clicked into running. With the gate open, the first three
* become `ready` and the preview stays blocked until a candidate build has actually succeeded,
* because "open a preview" without a built candidate would be a mockup wearing a status.
*/
function stageViews(facts, progress = {}) {
	const executable = labExecutable(facts);
	const reason = facts.reason.trim() || "No isolated executor is available on this machine.";
	return SYSTEMS_LAB_STAGES.map((stage) => {
		if (!executable) return {
			...stage,
			state: "blocked",
			detail: reason
		};
		switch (stage.id) {
			case "proposal": return {
				...stage,
				state: "ready",
				detail: "Reads a proposed diff and refuses protected paths. Nothing is written to the live tree."
			};
			case "candidate": return progress.candidatePrepared ? {
				...stage,
				state: "passed",
				detail: "The disposable copy exists for this session and is deleted when it ends."
			} : {
				...stage,
				state: "ready",
				detail: "Copies the project without secrets, .env files, .git, user data or the released archive."
			};
			case "checks":
				if (progress.checksRun) return progress.checksPassed ? {
					...stage,
					state: "passed",
					detail: `Every command exited 0 in the candidate copy. ${CHECK_RESULT_TRUTH}`
				} : {
					...stage,
					state: "failed",
					detail: "At least one command did not exit 0. The log stays readable; nothing is applied."
				};
				return {
					...stage,
					state: "ready",
					detail: "Runs the candidate's own scripts, one at a time, inside the boundary."
				};
			case "preview": return progress.buildPassed ? {
				...stage,
				state: "ready",
				detail: "Builds and launches the candidate inside the workspace; the preview is the candidate's own output."
			} : {
				...stage,
				state: "blocked",
				detail: "Preview unavailable / NOT VERIFIED: a preview opens only after this candidate's own build has succeeded. A static mockup is not a preview."
			};
		}
	});
}
/** The one line the page leads with. */
function labHeadline(facts) {
	return labExecutable(facts) ? {
		tone: "ok",
		text: "An isolated executor is available on this machine."
	} : {
		tone: "warn",
		text: "Not available on this machine — nothing below can run."
	};
}
/**
* What the Lab will not do, in one place so the page and the tests agree.
*
* These are not aspirations: each is enforced somewhere else (the candidate copy's exclusion
* list, the protected-path list above, Prompt 40's script allowlist, and the absence of any
* apply/commit/deploy route). Two of them — the safety boundary and STOP — are enforced by the
* fact that this surface has no code path to them at all.
*/
var SYSTEMS_LAB_REFUSALS = [
	"Apply, commit, push, deploy, release, replace the installer or restart the app.",
	"Write to the live source tree, the released archive, the local database, conversations, the queue, the journal or voice profiles.",
	"Change a protected file, including the safety and consent code and this lab's own sandbox.",
	"Grant itself a permission, reuse a desktop pairing, or alter STOP and consent.",
	"Run anything when no isolation boundary is verified."
];
function isHistoryEntry(value) {
	if (typeof value !== "object" || value === null) return false;
	const rec = value;
	return typeof rec.id === "string" && typeof rec.createdAt === "number" && typeof rec.summary === "string" && Array.isArray(rec.checks) && typeof rec.apply === "object" && rec.apply !== null;
}
function isHistoryBody(value) {
	if (typeof value !== "object" || value === null) return false;
	const rec = value;
	return typeof rec.count === "number" && Array.isArray(rec.records) && rec.records.every(isHistoryEntry);
}
/** A stable, locale-independent stamp — the page is server-rendered too. */
function formatWhen(ms) {
	if (!Number.isFinite(ms)) return "unknown time";
	return `${new Date(ms).toISOString().slice(0, 16).replace("T", " ")} UTC`;
}
function isStatusView(value) {
	if (typeof value !== "object" || value === null) return false;
	const rec = value;
	return typeof rec.executionAvailable === "boolean" && typeof rec.isolationProven === "boolean" && typeof rec.reason === "string" && Array.isArray(rec.probes);
}
var STATE_LABEL = {
	available: "available",
	unavailable: "unavailable",
	unsupported: "unsupported",
	unknown: "unknown"
};
var LINE_PREFIX = {
	add: "+",
	remove: "-",
	context: " ",
	meta: "\\"
};
function SystemsLabPage() {
	const [phase, setPhase] = (0, import_react.useState)({ kind: "loading" });
	const [patchText, setPatchText] = (0, import_react.useState)("");
	const [review, setReview] = (0, import_react.useState)(null);
	const read = (0, import_react.useCallback)(async () => {
		setPhase({ kind: "loading" });
		try {
			const response = await fetch("/api/systems-lab/status", {
				headers: { accept: "application/json" },
				credentials: "same-origin"
			});
			if (!response.ok) {
				setPhase({
					kind: "error",
					message: `The executor status answered ${response.status}. Nothing was started.`
				});
				return;
			}
			const body = await response.json();
			if (!isStatusView(body)) {
				setPhase({
					kind: "error",
					message: "The executor status came back in a shape this build does not understand. Nothing was started."
				});
				return;
			}
			setPhase({
				kind: "ready",
				status: body
			});
		} catch {
			setPhase({
				kind: "error",
				message: "The executor status could not be read. Nothing was started; check that the local Oqe server is running, then try again."
			});
		}
	}, []);
	(0, import_react.useEffect)(() => {
		read();
	}, [read]);
	const [history, setHistory] = (0, import_react.useState)({ kind: "loading" });
	const readHistory = (0, import_react.useCallback)(async () => {
		setHistory({ kind: "loading" });
		try {
			const response = await fetch("/api/systems-lab/history", {
				headers: { accept: "application/json" },
				credentials: "same-origin"
			});
			if (!response.ok) {
				setHistory({
					kind: "error",
					message: `The history answered ${response.status}. Nothing was changed.`
				});
				return;
			}
			const body = await response.json();
			if (!isHistoryBody(body)) {
				setHistory({
					kind: "error",
					message: "The history came back in a shape this build does not understand. Nothing was changed."
				});
				return;
			}
			setHistory({
				kind: "ready",
				count: body.count,
				records: body.records
			});
		} catch {
			setHistory({
				kind: "error",
				message: "The history could not be read. Nothing was changed; check that the local Oqe server is running."
			});
		}
	}, []);
	(0, import_react.useEffect)(() => {
		readHistory();
	}, [readHistory]);
	const facts = (0, import_react.useMemo)(() => phase.kind === "ready" ? {
		executionAvailable: phase.status.executionAvailable,
		isolationProven: phase.status.isolationProven,
		reason: phase.status.reason
	} : {
		executionAvailable: false,
		isolationProven: false,
		reason: "The executor status has not been read yet, so nothing may run."
	}, [phase]);
	const executable = labExecutable(facts);
	const headline = labHeadline(facts);
	const stages = (0, import_react.useMemo)(() => stageViews(facts), [facts]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex w-full max-w-3xl flex-col gap-6 px-4 py-7 sm:px-6 lg:px-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "border-b border-border pb-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FlaskConical, {
						className: "size-4 shrink-0 text-muted",
						"aria-hidden": "true"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-2xl font-semibold tracking-[-0.02em]",
						children: "Systems lab"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-xl text-sm text-muted",
					children: "Propose a change to Oqe’s own code, read the exact diff, run that candidate’s checks in a disposable copy, and open it only when the candidate was built and launched for real."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				"aria-labelledby": "lab-status-heading",
				className: cn("rounded-lg bg-surface p-4 shadow-[0_0_0_1px_var(--color-border)]", !executable && "border border-border"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-baseline justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							id: "lab-status-heading",
							className: "text-base font-semibold tracking-[-0.012em]",
							children: "Executor"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: cn("readout text-meta", executable ? "text-[color:var(--color-ok)]" : "text-warn"),
							children: phase.kind === "loading" ? "reading" : executable ? "available" : "unavailable"
						})]
					}),
					phase.kind === "loading" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						role: "status",
						children: "Reading the executor status…"
					}) : null,
					phase.kind === "error" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2",
						role: "status",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "flex items-start gap-2 text-sm text-warn",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, {
								className: "mt-0.5 size-4 shrink-0",
								"aria-hidden": "true"
							}), phase.message]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							size: "sm",
							variant: "secondary",
							className: "mt-2",
							onClick: () => void read(),
							children: "Try again"
						})]
					}) : null,
					phase.kind === "ready" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: cn("text-sm", executable ? "text-fg" : "text-warn"),
								children: headline.text
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1.5 max-w-[62ch] text-label leading-relaxed text-muted",
								children: phase.status.reason
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
								className: "mt-3 grid grid-cols-[auto_minmax(0,1fr)] gap-x-4 gap-y-1 text-meta",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-faint",
										children: "Boundary"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "text-fg",
										children: phase.status.boundary
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-faint",
										children: "Backend"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "text-fg",
										children: phase.status.backend.label
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-faint",
										children: "Platform"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "font-mono text-meta text-fg",
										children: phase.status.platform
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-faint",
										children: "Cleanup"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "text-muted",
										children: phase.status.cleanup
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-3 grid gap-1.5",
								children: phase.status.probes.map((probe) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex flex-wrap items-baseline gap-x-2 text-meta",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "readout min-w-[7.5rem] text-faint",
											children: probe.label
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: cn("readout", probe.state === "available" ? "text-[color:var(--color-ok)]" : "text-warn"),
											children: STATE_LABEL[probe.state] ?? probe.state
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "min-w-0 flex-1 text-muted",
											children: probe.detail
										})
									]
								}, probe.id))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-3",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									size: "sm",
									variant: "ghost",
									onClick: () => void read(),
									children: "Re-read status"
								})
							})
						]
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				"aria-labelledby": "lab-request-heading",
				className: "rounded-lg bg-surface p-4 shadow-[0_0_0_1px_var(--color-border)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						id: "lab-request-heading",
						className: "text-base font-semibold tracking-[-0.012em]",
						children: "The change"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						htmlFor: "lab-request",
						className: "mt-2 block text-sm font-medium",
						children: "What should change?"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: "lab-request",
						type: "text",
						disabled: true,
						"aria-describedby": "lab-request-why",
						placeholder: "Describe a change to Oqe",
						className: "mt-1.5 min-h-10 w-full rounded-md bg-well px-3 text-sm text-fg shadow-[inset_0_0_0_1px_var(--color-border)] outline-none placeholder:text-faint disabled:opacity-60"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 flex flex-wrap items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							size: "sm",
							variant: "secondary",
							disabled: true,
							children: "Propose a change"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							id: "lab-request-why",
							className: "text-meta leading-relaxed text-muted",
							children: executable ? "Ready when the candidate copy is prepared." : "Disabled: a proposal is only useful if its checks and preview can actually run, and no verified boundary exists on this machine."
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 max-w-[62ch] text-meta leading-relaxed text-faint",
						children: "A proposal is read as a diff and never written to the live tree. Nothing on this page applies, commits, pushes, deploys, replaces the installer or restarts the app."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 border-t border-border pt-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-sm font-medium text-fg",
								children: "Read a diff"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 max-w-[62ch] text-meta leading-relaxed text-muted",
								children: "Paste a unified diff to see the changed files and every line, exactly as proposed. Reading it runs nothing and writes nothing; protected paths are refused by name."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								htmlFor: "lab-patch",
								className: "sr-only",
								children: "Unified diff"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								id: "lab-patch",
								value: patchText,
								onChange: (event) => setPatchText(event.target.value),
								spellCheck: false,
								rows: 5,
								placeholder: "diff --git a/src/lib/example.ts b/src/lib/example.ts",
								"aria-describedby": "lab-patch-limits",
								className: "mt-2 w-full rounded-md bg-well p-2.5 font-mono text-meta leading-relaxed text-fg shadow-[inset_0_0_0_1px_var(--color-border)] outline-none placeholder:text-faint focus-visible:shadow-[inset_0_0_0_1px_var(--color-accent)]"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								id: "lab-patch-limits",
								className: "mt-1 text-meta text-faint",
								children: "At most 24 files, 4,000 lines and 512 KiB. A binary change, a rename or a malformed hunk is refused rather than half-shown."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 flex flex-wrap items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									size: "sm",
									variant: "secondary",
									disabled: patchText.trim().length === 0,
									onClick: () => setReview(reviewCandidatePatch(patchText)),
									children: "Review diff"
								}), review ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									size: "sm",
									variant: "ghost",
									onClick: () => setReview(null),
									children: "Clear"
								}) : null]
							}),
							review && !review.ok ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-2 flex items-start gap-2 text-sm text-warn",
								role: "status",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, {
									className: "mt-0.5 size-4 shrink-0",
									"aria-hidden": "true"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "max-w-[62ch] leading-relaxed",
									children: review.reason
								})]
							}) : null,
							review && review.ok ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3",
								role: "group",
								"aria-label": "Proposed diff",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "readout text-meta text-muted",
										children: review.summary
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
										className: "mt-2 flex flex-col gap-3",
										children: review.files.map((file) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex flex-wrap items-baseline gap-x-2",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
													className: "font-mono text-meta text-fg",
													children: file.path
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "readout text-meta text-faint",
													children: file.status
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "readout text-meta text-[color:var(--color-ok)]",
													children: ["+", file.additions]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "readout text-meta text-[color:var(--color-danger)]",
													children: ["−", file.deletions]
												})
											]
										}), file.hunks.map((hunk, hunkIndex) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-1.5 overflow-x-auto rounded-md bg-well",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "readout whitespace-pre px-2.5 pt-1.5 text-meta text-signal",
												children: hunk.header
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
												className: "px-2.5 pb-1.5 text-meta leading-relaxed",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", { children: hunk.lines.map((line, lineIndex) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: cn("block whitespace-pre", line.kind === "add" ? "text-[color:var(--color-ok)]" : line.kind === "remove" ? "text-[color:var(--color-danger)]" : line.kind === "meta" ? "text-faint" : "text-muted"),
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: LINE_PREFIX[line.kind] }), line.text]
												}, lineIndex)) })
											})]
										}, `${file.path}-${hunkIndex}`))] }, file.path))
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 max-w-[62ch] text-meta leading-relaxed text-faint",
										children: "This is the proposal as written. It has not run, has not been applied, and a passing check would not make it correct."
									})
								]
							}) : null
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				"aria-labelledby": "lab-stages-heading",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					id: "lab-stages-heading",
					className: "text-base font-semibold tracking-[-0.012em]",
					children: "How a candidate would run"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-2 flex flex-col gap-2",
					children: stages.map((stage, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "rounded-lg bg-surface px-4 py-3 shadow-[0_0_0_1px_var(--color-border)]",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "readout mt-0.5 w-6 shrink-0 text-faint",
								"aria-hidden": "true",
								children: String(index + 1).padStart(2, "0")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-wrap items-baseline justify-between gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-sm font-medium text-fg",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "sr-only",
												children: [
													"Step ",
													index + 1,
													": "
												]
											}), stage.label]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: cn("readout text-meta", stage.state === "blocked" || stage.state === "not-verified" ? "text-warn" : stage.state === "failed" ? "text-[color:var(--color-danger)]" : stage.state === "passed" ? "text-[color:var(--color-ok)]" : "text-signal"),
											children: stage.state === "blocked" ? "blocked" : stage.state === "not-verified" ? "not verified" : stage.state
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-0.5 text-meta leading-relaxed text-faint",
										children: stage.purpose
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1.5 max-w-[62ch] text-label leading-relaxed text-muted",
										children: stage.detail
									})
								]
							})]
						})
					}, stage.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				"aria-labelledby": "lab-checks-heading",
				className: "rounded-lg bg-surface p-4 shadow-[0_0_0_1px_var(--color-border)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-baseline justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							id: "lab-checks-heading",
							className: "text-base font-semibold tracking-[-0.012em]",
							children: "Checks"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "readout text-meta text-faint",
							children: "candidate profile · network denied"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 max-w-[62ch] text-meta leading-relaxed text-muted",
						children: "Fixed scripts only — never a typed command. Each runs against the disposable copy, one at a time, with a ten-minute ceiling and bounded output."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 flex flex-col gap-1.5",
						children: SYSTEMS_LAB_CHECKS.map((check) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex flex-wrap items-baseline gap-x-2 text-meta",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Terminal, {
									className: "mt-0.5 size-3 shrink-0 text-faint",
									"aria-hidden": "true"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("code", {
									className: "rounded bg-well px-1.5 py-0.5 font-mono text-meta text-fg",
									children: ["npm ", check.argv.join(" ")]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted",
									children: check.label
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-faint",
									children: check.detail
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: cn("readout ml-auto", executable ? "text-signal" : "text-warn"),
									children: executable ? "ready" : "not run"
								})
							]
						}, check.script))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 max-w-[62ch] text-meta leading-relaxed text-faint",
						children: CHECK_RESULT_TRUTH
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				"aria-labelledby": "lab-approvals-heading",
				className: "rounded-lg bg-surface p-4 shadow-[0_0_0_1px_var(--color-border)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-baseline justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							id: "lab-approvals-heading",
							className: "text-base font-semibold tracking-[-0.012em]",
							children: "Approvals and history"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: cn("readout text-meta", executable ? "text-signal" : "text-warn"),
							children: executable ? "available" : "disabled"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-2 flex list-disc flex-col gap-1 pl-5 text-meta leading-relaxed text-muted",
						children: APPROVAL_RULES.map((rule) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: rule }, rule))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex flex-wrap items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								size: "sm",
								variant: "secondary",
								disabled: true,
								"aria-describedby": "lab-apply-why",
								children: "Apply to working copy"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								size: "sm",
								variant: "secondary",
								disabled: true,
								"aria-describedby": "lab-apply-why",
								children: "Roll back"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								id: "lab-apply-why",
								className: cn("max-w-[62ch] text-meta leading-relaxed", executable ? "text-muted" : "text-warn"),
								children: executable ? "Enabled for one approved change-set whose files still match what it wrote." : `Disabled: ${facts.reason}`
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 border-t border-border pt-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-baseline justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "text-sm font-medium text-fg",
									children: "Recorded change-sets"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "readout text-meta text-faint",
									children: history.kind === "ready" ? `${history.count} recorded` : history.kind === "loading" ? "reading" : "unreadable"
								})]
							}),
							history.kind === "loading" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-meta text-muted",
								role: "status",
								children: "Reading the change history…"
							}) : null,
							history.kind === "error" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-1",
								role: "status",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-meta text-warn",
									children: history.message
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									size: "sm",
									variant: "ghost",
									className: "mt-1",
									onClick: () => void readHistory(),
									children: "Try again"
								})]
							}) : null,
							history.kind === "ready" && history.records.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 max-w-[62ch] text-meta leading-relaxed text-muted",
								children: "No change-sets recorded on this machine. Nothing can be applied while no boundary is verified, so this list stays empty until one is — and then every entry here will carry the diff, the checks, the approval and what apply and rollback actually did."
							}) : null,
							history.kind === "ready" && history.records.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-2 flex flex-col gap-2",
								children: history.records.map((entry) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "rounded-md bg-well px-2.5 py-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex flex-wrap items-baseline gap-x-2",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
													className: "font-mono text-meta text-fg",
													children: entry.id
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "readout text-meta text-muted",
													children: entry.summary
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "readout ml-auto text-meta text-faint",
													children: formatWhen(entry.createdAt)
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-0.5 max-w-[62ch] text-meta leading-relaxed text-faint",
											children: entry.intendedEffect
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "mt-1 text-meta text-muted",
											children: [
												entry.approval ? `Approved ${formatWhen(entry.approval.approvedAt)}` : "Not approved",
												" ",
												"· apply ",
												entry.apply.state,
												" · rollback ",
												entry.rollback?.state ?? "none",
												" · preview",
												" ",
												entry.preview
											]
										})
									]
								}, entry.id))
							}) : null
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 max-w-[62ch] text-meta leading-relaxed text-faint",
						children: ROLLBACK_LIMITS
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				"aria-labelledby": "lab-refusals-heading",
				className: "rounded-lg bg-surface p-4 shadow-[0_0_0_1px_var(--color-border)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						id: "lab-refusals-heading",
						className: "flex items-center gap-2 text-base font-semibold tracking-[-0.012em]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, {
							className: "size-3.5 shrink-0 text-muted",
							"aria-hidden": "true"
						}), "What this lab will not do"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-2 flex list-disc flex-col gap-1 pl-5 text-meta leading-relaxed text-muted",
						children: SYSTEMS_LAB_REFUSALS.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: line }, line))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
						className: "mt-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("summary", {
								className: "cursor-pointer text-meta text-fg",
								children: [
									"Protected paths (",
									PROTECTED_PATHS.length,
									") — blocked whatever a diff says"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-2 flex flex-col gap-1",
								children: PROTECTED_PATHS.map((entry) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex flex-wrap items-baseline gap-x-2 text-meta",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
										className: "font-mono text-meta text-fg",
										children: entry.path
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-faint",
										children: entry.reason
									})]
								}, entry.path))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-2 max-w-[62ch] text-meta leading-relaxed text-faint",
								children: [
									"Release artifacts are blocked by shape too (",
									PROTECTED_PATTERNS.length,
									" rules, not a name list): a release checksum, any packaged ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
										className: "font-mono",
										children: ".zip"
									}),
									", the installer directory, the release and build output, and any signed distributable. None of them is ever rewritten in place."
								]
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "max-w-[62ch] text-meta leading-relaxed text-faint",
				children: [SYSTEMS_LAB_STAGES.length, " steps, no shortcuts: a change is a proposal until its candidate’s own checks have run and its own build has succeeded. Passing checks are evidence, not proof, and this page never reports a candidate as release-ready."]
			})
		]
	});
}
var SplitComponent = SystemsLabPage;
//#endregion
export { SplitComponent as component };
