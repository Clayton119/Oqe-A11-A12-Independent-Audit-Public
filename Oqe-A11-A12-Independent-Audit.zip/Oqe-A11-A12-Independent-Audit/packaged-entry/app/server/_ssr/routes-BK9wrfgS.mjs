import { i as __toESM } from "../_runtime.mjs";
import { H as require_jsx_runtime, V as require_react, v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { d as isSafeHttpUrl, f as isSafeMediaSrc, i as compactBrowseSummary, o as extractHttpUrls, u as isSafeHref } from "./safe-fetch.server-CPmpHsTy.mjs";
import { $ as LoaderCircle, A as RefreshCw, Ct as CircleX, Dt as ChevronDown, E as ScrollText, F as Pencil, G as Mic, H as Minus, I as Pause, L as Paperclip, M as Play, Mt as ArrowLeft, O as RotateCcw, Ot as Check, R as PanelRightOpen, St as Circle, T as Search, Tt as CircleCheck, V as Monitor, W as Minimize2, Z as Maximize2, at as Globe, b as ShieldOff, c as Users, ct as FileText, d as TriangleAlert, dt as Download, et as ListChecks, ft as Cpu, g as SquareTerminal, h as Square, it as ImageOff, j as Plus, jt as ArrowRight, kt as Brain, lt as Eye, mt as Compass, n as X, nt as Layers, o as VolumeX, ot as Gauge, pt as Copy, r as Wrench, rt as Image, s as Volume2, u as Undo2, ut as EyeOff, v as Smartphone, w as Send, wt as CircleHelp, x as ShieldCheck, xt as ClipboardCheck, y as SkipForward, z as PanelRightClose } from "../_libs/lucide-react.mjs";
import { A as DEFAULT_OUTPUT_POLICY, B as MAX_MESH_VERTICES, Bn as simulationModel, C as useFocusTrap, Dt as describeUnsupportedBlock, En as readMessageOutput, Et as describeTtsEvent, Fn as sameModel, Gn as startRecognition, Gt as isOutputSessionId, H as MAX_RECALL_CHARS, Ht as isConnectionConfigured, In as sampleSeries, Jt as isVisionModel, Kt as isPlumbingPhase, Ln as searchEvidence, Lt as formatValue, M as EVIDENCE_KIND_LABELS, Mt as estimateContextUsage, N as EVIDENCE_KIND_MEANING, Ot as detectSpeechSupport, Pn as runSimulation, Q as REPETITION_STOPPED_MESSAGE, Rn as settledTaskTitle, Rt as hasCalcErrorIssues, Sn as profileFor, T as BROWSER_ASSIST_PLACEHOLDER, U as MAX_WALKTHROUGH_RESPONSE_CHARS, Un as speak, V as MAX_OUTPUT_IMAGE_BYTES, Vn as sortChatModelIds, Wn as speakLocal, Wt as isOnline, Xt as layoutDiagram, Yn as stopSpeech, Z as PROFILES, Zn as taskStepViews, Zt as layoutOutputRows, _ as readBoolPref, a as MAX_ARTIFACT_BYTES, ar as wrapDiagramLabel, b as OqeCharacter, bn as prepareAttachment, c as isArtifactMediaType, dt as capacityConfidenceLabel, er as useAppStore, g as MESSAGE_PANEL_OPEN_KEY, gt as createId, h as Button, hn as outputPolicyFromSettings, i as ARTIFACT_MEDIA_TYPES, jn as resolveContextCapacityWithLimits, kt as diagramTextOutline, l as isSafeArtifactId, mn as optimizeAtTrigger, ot as applyOutputPolicy, pn as offlineStatusNote, rt as activeRoster, s as describeArtifactBytes, u as safeArtifactName, ut as capabilityLabels, v as writeBoolPref, vt as currentStepLabel, w as cn, x as OqeMark, y as OqeActivityMark, yt as decideRender, z as MAX_MESH_TRIANGLES } from "./router-CiIP6cPA.mjs";
import { t as copyText } from "./copy-D7bd_Qke.mjs";
import { n as Select, t as Input } from "./input-CURER8tx.mjs";
import { r as transcribeAudio } from "./local-client-Cqz3VYgc.mjs";
import { t as routeTranscript } from "./session-XQZkns1t.mjs";
import { r as desktopComposerPlaceholder } from "./status-CNfpf13v.mjs";
import { t as useHoldDrag } from "./use-hold-drag-E5tQGD5V.mjs";
import { t as Markdown } from "../_libs/react-markdown+[...].mjs";
import { t as remarkGfm } from "../_libs/remark-gfm.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BK9wrfgS.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var EXCERPT_LIMIT = 240;
function oneLine(text) {
	return text.replace(/\s+/g, " ").trim();
}
function excerpt(text, limit = EXCERPT_LIMIT) {
	const value = oneLine(text);
	return value.length > limit ? `${value.slice(0, limit).trimEnd()}…` : value;
}
function visibleMessages(conversation) {
	return conversation.messages.filter((message) => message.content.trim() || message.attachments?.length);
}
function messageLabel(message) {
	return message.role === "user" ? "You" : "Oqe";
}
/**
* Build a compact, deterministic brief from visible content. This intentionally
* does not dump the transcript or call a model: every statement is a local
* heuristic and should be checked against the thread.
*/
function buildConversationMarkdown(conversation) {
	const title = conversation.title.trim() || "Oqe conversation";
	const messages = visibleMessages(conversation);
	const userMessages = messages.filter((message) => message.role === "user");
	const assistantMessages = messages.filter((message) => message.role === "assistant");
	const latestUser = userMessages[userMessages.length - 1];
	const latestAssistant = assistantMessages[assistantMessages.length - 1];
	const decisions = assistantMessages.filter((message) => message.content.trim()).slice(-5).map((message) => excerpt(message.content));
	const questions = messages.filter((message) => message.content.includes("?")).slice(-4).map((message) => excerpt(message.content));
	const lastTurns = messages.slice(-4);
	const lines = [
		`# ${title}`,
		"",
		`> Local deterministic brief · generated ${(/* @__PURE__ */ new Date()).toISOString()}`,
		"> Not model-written. Verify against the visible thread.",
		"",
		"## Situation summary",
		"",
		buildSituationSummary(messages, latestUser, latestAssistant),
		"",
		"## Key decisions / outcomes",
		""
	];
	if (decisions.length > 0) for (const decision of decisions) lines.push(`- ${decision}`);
	else lines.push("- No assistant outcome is recorded yet.");
	lines.push("", "## Open questions / next steps", "");
	if (questions.length > 0) for (const question of questions) lines.push(`- ${question}`);
	else if (latestUser) lines.push(`- Review the latest request: ${excerpt(latestUser.content)}`);
	else lines.push("- None identified from the visible content.");
	if (lastTurns.length > 0) {
		lines.push("", `## Last ${lastTurns.length} turns (abbreviated)`, "");
		for (const message of lastTurns) {
			const body = message.content.trim() ? excerpt(message.content) : message.attachments?.length ? "(attachment only)" : "(no visible text)";
			lines.push(`- **${messageLabel(message)}:** ${body}`);
		}
	}
	if (conversation.contextSummary?.trim()) lines.push("", "## Existing context note", "", excerpt(conversation.contextSummary, 400), "", "> This is a local compression note, separate from the visible-thread brief.");
	return `${lines.join("\n").trim()}\n`;
}
function buildSituationSummary(messages, latestUser, latestAssistant) {
	if (messages.length === 0) return "No visible turns are recorded yet.";
	return `This thread contains ${`${messages.length} visible turn${messages.length === 1 ? "" : "s"}`}.${latestUser ? ` The latest request was: “${excerpt(latestUser.content, 180)}”` : ""}${latestAssistant ? ` The latest recorded response was: “${excerpt(latestAssistant.content, 180)}”` : " No assistant outcome is recorded yet."}`;
}
function markdownFileName(conversation) {
	const base = conversation.title.trim().toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
	const stamp = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
	return `${base || "oqe-conversation"}-brief-${stamp}.md`;
}
function composerPrimaryAction(streaming, hasContent) {
	if (!streaming) return "send";
	return hasContent ? "queue" : "stop";
}
/**
* The label and semantics share one source so the button can never say
* "Queue" while behaving like "Stop" (or vice versa).
*/
function composerPrimaryLabel(action) {
	return action === "send" ? "Send" : action === "queue" ? "Queue" : "Stop";
}
/**
* The model's reasoning as a readable chain of steps. Each non-empty line the
* model emitted becomes one numbered step, in its own words. It is a plain
* render with no scroll bookkeeping, so it stays responsive however long the
* reasoning runs.
*/
function ProcessLog({ text, className, preClassName = "text-xs" }) {
	const steps = text.split(/\r?\n/).map((line) => line.trim()).filter((line) => line.length > 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
		className: `${className ?? ""} list-decimal space-y-1 pl-5 ${preClassName} text-muted marker:text-faint`,
		"aria-label": "Model reasoning steps",
		children: steps.map((step, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
			className: "break-words leading-relaxed",
			children: step
		}, index))
	});
}
/** How far the viewport's bottom edge sits from the content's end. */
function distanceFromBottom(metrics) {
	const { scrollTop, scrollHeight, clientHeight } = metrics;
	if (!Number.isFinite(scrollTop) || !Number.isFinite(scrollHeight) || !Number.isFinite(clientHeight)) return Number.POSITIVE_INFINITY;
	return scrollHeight - scrollTop - clientHeight;
}
/**
* The reader's intent after this scroll position: following only while they
* are at the end. Ten pixels up is a deliberate reading position, not a
* rounding error.
*/
function nextFollowing(metrics, tolerance = 8) {
	return distanceFromBottom(metrics) <= Math.max(0, tolerance);
}
/**
* Should a live update move the view to the new end?
*
* Both halves matter: a reader who scrolled up is never moved (their position
* is theirs), and an update that did not change the height does no layout work
* and emits no scroll event.
*/
function shouldMoveView({ following, height, lastHeight }) {
	if (!following) return false;
	if (!Number.isFinite(height) || !Number.isFinite(lastHeight)) return false;
	return height > lastHeight;
}
/**
* Right-hand AGENT GROUP CHAT — what a multi-agent run looks like while it runs.
*
* Existence rule: the panel is there whenever the feature is being used — a
* live run (armed, or turns arriving) or a thread that already holds recorded
* turns. With neither it renders null: not openable, never an empty shell.
*
* Content is the run as a conversation, not a metadata list. Your prompt is the
* message you sent; every turn the main agent and its sub-agents took follows,
* in the order they ran, each carrying its own name, whether it is the main
* agent or a sub-agent, the model that ran it, how long it took, and its text.
* A turn still being generated says so and grows in place. Nothing is invented:
* a turn with no timestamp falls back to its message's createdAt, and there is
* no synthetic agent when no turn ran.
*
* Open state: the desktop dock follows the remembered preference (`open`); the
* chat page re-opens it the moment a new run starts, so a reader who collapsed
* it in an earlier thread still sees this run. On narrow screens the panel is a
* session-local sheet, with the same live strip as the entry point.
*/
function AgentPanel({ messages, open, armed = false, live = false, onOpen, onClose }) {
	const isWide = useIsWideViewport();
	const [sheetOpen, setSheetOpen] = (0, import_react.useState)(false);
	const sheet = !isWide && sheetOpen;
	const sheetRef = (0, import_react.useRef)(null);
	const closeSheet = (0, import_react.useCallback)(() => setSheetOpen(false), []);
	useFocusTrap(sheet, sheetRef, closeSheet);
	(0, import_react.useEffect)(() => {
		if (isWide) setSheetOpen(false);
	}, [isWide]);
	const agentMessages = messages.filter((message) => message.council && message.council.length > 0);
	const passTotal = agentMessages.reduce((total, message) => total + (message.council?.length ?? 0), 0);
	const working = live;
	const present = working || armed || passTotal > 0;
	const docked = isWide && open;
	const handleToggle = (0, import_react.useCallback)(function handleToggle() {
		if (isWide) {
			if (docked) onClose();
			else onOpen();
			return;
		}
		setSheetOpen((current) => !current);
	}, [
		isWide,
		docked,
		onOpen,
		onClose
	]);
	if (!present) return null;
	if (!docked && !sheet) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		className: "flex w-10 shrink-0 flex-col items-center gap-3 border-l border-border bg-surface/35 py-3 max-lg:fixed max-lg:right-3 max-lg:top-20 max-lg:z-30 max-lg:h-10 max-lg:w-10 max-lg:gap-0 max-lg:rounded-full max-lg:border max-lg:border-border max-lg:bg-surface max-lg:p-0 max-lg:shadow-[0_6px_20px_rgb(0_0_0_/_0.5)]",
		"aria-label": "Agent group chat",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			className: "relative inline-flex size-8 items-center justify-center rounded-md text-muted hover:bg-surface-2 hover:text-fg",
			"aria-label": "Open the agent group chat",
			title: "Open the agent group chat",
			onClick: handleToggle,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PanelRightOpen, {
				className: "size-4",
				"aria-hidden": "true"
			}), working ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "absolute right-1 top-1 size-2 animate-pulse rounded-full bg-accent",
				"aria-hidden": "true"
			}) : null]
		}), working ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "flex-1 select-none font-mono text-meta text-accent max-lg:hidden",
			style: { writingMode: "vertical-rl" },
			children: "agents working"
		}) : armed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "flex-1 select-none font-mono text-meta text-accent/80 max-lg:hidden",
			style: { writingMode: "vertical-rl" },
			children: "armed"
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "flex-1 max-lg:hidden",
			"aria-hidden": "true"
		})]
	});
	const distinctModels = Array.from(new Set(agentMessages.flatMap((message) => (message.council ?? []).map((pass) => pass.model))));
	const header = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-start justify-between gap-2 border-b border-border px-3 py-2.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "group-label text-fg",
					children: "Agent group"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-0.5 text-meta text-faint",
					children: [
						passTotal,
						" turn",
						passTotal === 1 ? "" : "s"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 truncate text-meta text-faint",
					title: distinctModels.join(", "),
					children: working ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "inline-flex items-center gap-1.5 text-accent",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "size-1.5 animate-pulse rounded-full bg-accent",
							"aria-hidden": "true"
						}), "working…"]
					}) : armed && passTotal === 0 ? "Armed. No turn yet" : distinctModels.length === 0 ? "no model recorded" : distinctModels.length === 1 ? distinctModels[0] : `${distinctModels.length} models`
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "inline-flex size-8 shrink-0 items-center justify-center rounded-md text-muted hover:bg-surface-2 hover:text-fg",
			"aria-label": "Collapse the agent group chat",
			title: "Collapse",
			onClick: sheet ? closeSheet : onClose,
			children: sheet ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {
				className: "size-4",
				"aria-hidden": "true"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PanelRightClose, {
				className: "size-4",
				"aria-hidden": "true"
			})
		})]
	});
	const list = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AgentGroupChat, {
		messages,
		live: working,
		armed,
		onNavigate: sheet ? closeSheet : void 0
	});
	if (sheet) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "drawer-backdrop fixed inset-0 z-40 bg-bg/70",
		"data-open": "true",
		onClick: closeSheet
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		ref: sheetRef,
		className: "drawer-panel drawer-panel-right fixed inset-y-0 right-0 z-50 flex min-h-0 w-[min(24rem,calc(100%-3rem))] flex-col overflow-hidden bg-surface shadow-[var(--shadow-panel)]",
		"data-open": "true",
		role: "dialog",
		"aria-modal": "true",
		"aria-label": "Agent group chat",
		tabIndex: -1,
		children: [header, list]
	})] });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		className: "hidden min-h-0 w-80 shrink-0 flex-col overflow-hidden border-l border-border bg-surface/35 lg:flex",
		"aria-label": "Agent group chat",
		"data-live": working ? "true" : void 0,
		children: [header, list]
	});
}
/**
* The run as a group chat: your prompt, then every turn in the order it ran.
* Grouping uses the real preceding user message as the prompt — when there is
* none, the group simply starts with the turns.
*/
function AgentGroupChat({ messages, live, armed, onNavigate }) {
	const groups = (0, import_react.useMemo)(() => messages.flatMap((message, index) => {
		if (!message.council || message.council.length === 0) return [];
		let prompt;
		for (let back = index - 1; back >= 0; back -= 1) {
			const prior = messages[back];
			if (prior && prior.role === "user" && prior.content.trim()) {
				prompt = prior.content.trim();
				break;
			}
		}
		return [{
			key: message.id,
			prompt,
			message
		}];
	}), [messages]);
	const scroller = (0, import_react.useRef)(null);
	const following = (0, import_react.useRef)(true);
	const lastHeight = (0, import_react.useRef)(NaN);
	const lastTurns = (groups.length > 0 ? groups[groups.length - 1] : void 0)?.message.council ?? [];
	const tailLength = lastTurns[lastTurns.length - 1]?.message.length ?? 0;
	const turnCount = groups.reduce((total, group) => total + (group.message.council?.length ?? 0), 0);
	(0, import_react.useEffect)(() => {
		const el = scroller.current;
		if (!el) return;
		const height = el.scrollHeight;
		const move = shouldMoveView({
			following: following.current,
			height,
			lastHeight: lastHeight.current
		});
		lastHeight.current = height;
		if (!move) return;
		el.scrollTop = height;
	}, [
		turnCount,
		tailLength,
		groups.length
	]);
	const handlePanelScroll = (0, import_react.useCallback)(() => {
		const el = scroller.current;
		if (!el) return;
		following.current = nextFollowing({
			scrollTop: el.scrollTop,
			scrollHeight: el.scrollHeight,
			clientHeight: el.clientHeight
		});
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
		ref: scroller,
		onScroll: handlePanelScroll,
		className: "flex min-h-0 flex-1 flex-col gap-4 overflow-y-auto p-3",
		children: [
			groups.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
				className: "rounded-lg bg-surface-2/60 px-3 py-2.5 text-meta leading-relaxed text-muted shadow-[0_0_0_1px_var(--color-border)]",
				children: live ? "The run is starting. No agent turn has been recorded yet — this is the honest state until the main agent's first turn begins." : armed ? "Armed. Send your message and the main agent and its sub-agents will appear here, turn by turn, as they work." : "No agent turn was recorded for this thread."
			}) : null,
			groups.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex flex-col gap-2",
				children: [group.prompt ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col items-end",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mb-0.5 mr-1 font-mono text-meta text-faint",
						children: "You"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "max-w-[92%] rounded-lg rounded-br-sm bg-user px-2.5 py-1.5 text-label leading-relaxed text-fg",
						children: group.prompt.length > 200 ? `${group.prompt.slice(0, 200)}…` : group.prompt
					})]
				}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AgentTurns, {
					message: group.message,
					onNavigate
				})]
			}, group.key)),
			live ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex items-center gap-2 px-1 font-mono text-meta text-accent",
				role: "status",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "size-1.5 animate-pulse rounded-full bg-accent",
					"aria-hidden": "true"
				}), "the run is still going"]
			}) : null
		]
	});
}
function AgentTurns({ message, onNavigate }) {
	const passes = message.council ?? [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-2.5",
		children: [passes.map((pass, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AgentTurn, {
			pass,
			index,
			total: passes.length,
			fallbackAt: message.createdAt,
			onNavigate
		}, `${pass.role}-${index}`)), message.process ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
			className: "rounded-md px-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
				className: "cursor-pointer text-meta text-faint",
				children: "Model process (emitted by the model)"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-1",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProcessLog, {
					text: message.process,
					className: "max-h-56 overflow-y-auto",
					preClassName: "text-meta"
				})
			})]
		}) : null]
	});
}
function AgentTurn({ pass, index, total, fallbackAt, onNavigate }) {
	const [expanded, setExpanded] = (0, import_react.useState)(false);
	const isLast = index === total - 1;
	const streaming = pass.streaming === true;
	const clamped = !expanded && !streaming;
	const time = relTime(pass.at ?? fallbackAt);
	const meta = [
		pass.model || "No model",
		pass.durationMs != null ? durationLabel(pass.durationMs) : null,
		time
	].filter((part) => Boolean(part));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "flex flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-1.5 px-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: cn("mark-tile shrink-0", pass.lead ? "text-accent" : "text-muted"),
						"aria-hidden": "true",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OqeMark, { className: "size-3" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "min-w-0 flex-1 truncate text-xs font-medium text-fg",
						children: pass.role
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: cn("shrink-0 rounded px-1.5 py-px text-meta", pass.lead ? "bg-accent/12 text-accent" : "bg-surface text-faint"),
						title: pass.lead ? "Main agent: leads the run, calls sub-agents, and delivers the answer" : "Sub-agent: answered when the main agent asked it",
						children: pass.lead ? "Main" : "Sub"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-0.5 truncate px-1 font-mono text-meta text-faint",
				children: meta.join(" · ")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: cn("mt-1.5 rounded-lg rounded-tl-sm px-2.5 py-2 shadow-[0_0_0_1px_var(--color-border)]", pass.failed ? "bg-surface shadow-[0_0_0_1px_rgb(240_195_79_/_0.34)]" : pass.lead ? "bg-accent/8" : "bg-surface-2/70"),
				children: [
					pass.failed ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mb-1 flex items-center gap-1.5 text-meta font-medium text-warn",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "size-1.5 rounded-full bg-warn",
							"aria-hidden": "true"
						}), "Turn failed"]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: cn(clamped && "max-h-24 overflow-hidden", clamped && "[mask-image:linear-gradient(to_bottom,black_calc(100%-1.5rem),transparent)]"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "whitespace-pre-wrap text-label leading-relaxed text-fg/90",
							children: [pass.message, streaming ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "ml-0.5 inline-block animate-pulse text-accent",
								"aria-hidden": "true",
								children: "▍"
							}) : null]
						})
					}),
					streaming ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 font-mono text-meta text-accent",
						children: "streaming…"
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-1.5 flex items-center gap-2",
						children: [
							!streaming && pass.message.length > 160 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "text-meta text-muted underline hover:text-fg",
								"aria-expanded": expanded,
								onClick: () => {
									setExpanded((current) => !current);
									onNavigate?.();
								},
								children: expanded ? "Show less" : "Show full turn"
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton$2, { text: pass.message }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "ml-auto truncate font-mono text-meta text-faint",
								children: pass.failed ? "failed" : isLast && !streaming ? "last turn" : ""
							})
						]
					})
				]
			})
		]
	});
}
/** V7.6 — elapsed generation time for a turn, e.g. `1.8s` / `420ms`. */
function durationLabel(ms) {
	if (typeof ms !== "number" || !Number.isFinite(ms) || ms < 0) return "—";
	if (ms < 1e3) return `${Math.round(ms)}ms`;
	if (ms < 6e4) return `${(ms / 1e3).toFixed(1)}s`;
	return `${Math.floor(ms / 6e4)}m ${Math.round(ms % 6e4 / 1e3)}s`;
}
function relTime(timestamp) {
	const diff = Date.now() - timestamp;
	if (diff < 6e4) return "just now";
	if (diff < 36e5) return `${Math.floor(diff / 6e4)}m ago`;
	if (diff < 864e5) return `${Math.floor(diff / 36e5)}h ago`;
	return `${Math.floor(diff / 864e5)}d ago`;
}
function useIsWideViewport() {
	const [wide, setWide] = (0, import_react.useState)(() => typeof window === "undefined" ? true : window.matchMedia("(min-width: 1024px)").matches);
	(0, import_react.useEffect)(() => {
		const query = window.matchMedia("(min-width: 1024px)");
		const onChange = (event) => setWide(event.matches);
		query.addEventListener("change", onChange);
		setWide(query.matches);
		return () => query.removeEventListener("change", onChange);
	}, []);
	return wide;
}
/**
* Markdown export viewer used by the composer context popover. Shows the
* generated document with Copy and Download; generation is deterministic
* from the real thread (see src/lib/context-export.ts).
*/
function MarkdownExportViewer({ name, markdown }) {
	const [copied, setCopied] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!copied) return;
		const timer = setTimeout(() => setCopied(false), 1600);
		return () => clearTimeout(timer);
	}, [copied]);
	async function onCopy() {
		const result = await copyText(markdown);
		setCopied(result.ok);
	}
	function onDownload() {
		if (typeof document === "undefined") return;
		const blob = new Blob([markdown], { type: "text/markdown;charset=utf-8" });
		const url = URL.createObjectURL(blob);
		const anchor = document.createElement("a");
		anchor.href = url;
		anchor.download = name;
		document.body.append(anchor);
		anchor.click();
		anchor.remove();
		URL.revokeObjectURL(url);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
			className: "max-h-60 overflow-auto whitespace-pre-wrap rounded-md bg-bg p-3 font-mono text-meta leading-relaxed text-fg shadow-[0_0_0_1px_var(--color-border)]",
			"aria-label": "Generated markdown document",
			children: markdown
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "inline-flex items-center gap-1.5 rounded-md bg-surface-2 px-2.5 py-1.5 text-xs text-fg shadow-[0_0_0_1px_var(--color-border)] hover:bg-user",
					onClick: () => void onCopy(),
					children: [copied ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
						className: "size-3.5 text-ok",
						"aria-hidden": "true"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {
						className: "size-3.5",
						"aria-hidden": "true"
					}), copied ? "Copied" : "Copy markdown"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "inline-flex items-center gap-1.5 rounded-md bg-surface-2 px-2.5 py-1.5 text-xs text-fg shadow-[0_0_0_1px_var(--color-border)] hover:bg-user",
					onClick: onDownload,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {
						className: "size-3.5",
						"aria-hidden": "true"
					}), "Download .md"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "ml-auto truncate font-mono text-meta text-muted/70",
					children: name
				})
			]
		})]
	});
}
function CopyButton$2({ text }) {
	const [copied, setCopied] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!copied) return;
		const timer = setTimeout(() => setCopied(false), 1600);
		return () => clearTimeout(timer);
	}, [copied]);
	async function onCopy() {
		const result = await copyText(text);
		setCopied(result.ok);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		className: "inline-flex size-6 items-center justify-center rounded text-muted hover:bg-surface-2 hover:text-fg",
		"aria-label": copied ? "Copied" : "Copy turn text",
		title: copied ? "Copied" : "Copy",
		onClick: () => void onCopy(),
		children: copied ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
			className: "size-3.5 text-ok",
			"aria-hidden": "true"
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {
			className: "size-3.5",
			"aria-hidden": "true"
		})
	});
}
/**
* The pointer's position, sampled at most once per frame, for the orb's eyes.
*
* V10.8 — the hero orb and the orb that becomes the send button both look at
* the reader, so this lives once. It only re-renders when the pointer actually
* moves (one rAF-throttled listener, and nothing at all while the pointer is
* still), which matters because it feeds a component that renders on every
* frame of the app's busiest screen.
*/
function usePointerGaze(enabled = true) {
	const [gaze, setGaze] = (0, import_react.useState)(null);
	const frame = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		if (!enabled) return;
		const onMove = (event) => {
			if (frame.current !== null) return;
			frame.current = requestAnimationFrame(() => {
				frame.current = null;
				setGaze({
					x: event.clientX,
					y: event.clientY
				});
			});
		};
		window.addEventListener("pointermove", onMove, { passive: true });
		return () => {
			window.removeEventListener("pointermove", onMove);
			if (frame.current !== null) cancelAnimationFrame(frame.current);
			frame.current = null;
		};
	}, [enabled]);
	return enabled ? gaze : null;
}
/**
* The transform that starts the send button at the hero orb's position and size
* and settles at its own. A degenerate rect (zero width, e.g. a hidden element)
* yields no morph rather than a divide-by-zero.
*/
function morphFrom(from, to) {
	const real = (rect) => rect.width > 0 && rect.height > 0;
	if (!real(from) || !real(to)) return {
		dx: 0,
		dy: 0,
		scale: 1
	};
	const fromCx = from.left + from.width / 2;
	const fromCy = from.top + from.height / 2;
	const toCx = to.left + to.width / 2;
	const toCy = to.top + to.height / 2;
	const scale = from.width / to.width;
	if (!Number.isFinite(scale) || scale <= 0) return {
		dx: 0,
		dy: 0,
		scale: 1
	};
	return {
		dx: fromCx - toCx,
		dy: fromCy - toCy,
		scale
	};
}
/**
* The one-shot handoff. `remember` is called by the hero each time it lays out;
* `take` consumes it, so exactly one button can animate from it and a second
* mount (a re-render, a thread switch back) starts still.
*/
function createOrbHandoff(now = () => Date.now()) {
	let pending = null;
	return {
		remember(rect) {
			if (rect.width <= 0 || rect.height <= 0) return;
			pending = {
				rect,
				at: now()
			};
		},
		take() {
			const held = pending;
			pending = null;
			if (!held) return null;
			return now() - held.at > 3e4 ? null : held.rect;
		},
		/** A send that threw: there is no move to make, so drop the reading. */
		clear() {
			pending = null;
		},
		peek() {
			return pending?.rect ?? null;
		}
	};
}
/** The handoff the app uses: one per page, shared by the hero and the button. */
var orbHandoff = createOrbHandoff();
/** A DOMRect is structurally a Rect; this keeps call sites honest about it. */
function rectOf(element) {
	if (!element) return null;
	const box = element.getBoundingClientRect();
	return box.width > 0 && box.height > 0 ? {
		left: box.left,
		top: box.top,
		width: box.width,
		height: box.height
	} : null;
}
/**
* The longest-running keyframe of the arrival (see `.oqe-orb-flier` in
* src/styles.css). The move is over when this one reports done.
*/
var ARRIVAL_ANIMATION = "oqe-orb-fly";
/**
* The send button the character becomes.
*
* V10.8 — the reader asked for the orb to leave the middle of the room once the
* first message is sent, come to rest where the send control is, and BE that
* control: "if you click it it still works as the send button". So this is a
* real `<button type="submit">` inside the composer's own form — it submits the
* same way the labelled button did, it is disabled under exactly the same rule
* (`canSend`), and it carries the same accessible name. Nothing about sending
* changed except what the control looks like.
*
* V10.5 — the arrival was rebuilt around four things the first pass got wrong:
*
*   1. THE ORB CARRIES THE FLIGHT, NOT THE CONTROL. The animation lives on the
*      flier inside this button, so the socket, the focus ring and the hit area
*      are already resting where the orb is going while the orb is still in the
*      middle of the room. Previously the button itself was transformed, which
*      scaled its own socket into a metre-wide dark disc and dragged the focus
*      ring and the tappable area around with it.
*   2. THE HANDOFF MEASURES THE CHARACTER. `--from-scale` used to be the hero
*      container (160–192px) over the control (40px), but it is applied to the
*      32px orb inside that control — so the orb landed on screen 20% smaller
*      than the hero it replaced, a pop at the exact frame the move is supposed
*      to be seamless.
*   3. IT STAYS ALIVE ON THE WAY. Sending clears the input, so the control was
*      disabled for the whole flight, and the disabled treatment is 45% opacity
*      in the `offline` lamp: the character visibly dimmed and greyed out in the
*      air. `arriving` now holds it at full vitality until it has landed.
*   4. IT IS THE RUN'S STATUS LIGHT AFTERWARDS. Once the reply is streaming the
*      orb used to go straight back to the dimmed disconnected look beside a
*      Stop button. A working character says what is happening; `busy` keeps it
*      lit and in the warm `working` lamp for as long as Oqe is answering.
*/
function OrbSendButton({ disabled, busy = false }) {
	const ref = (0, import_react.useRef)(null);
	const [arriving, setArriving] = (0, import_react.useState)(false);
	const gaze = usePointerGaze();
	(0, import_react.useLayoutEffect)(() => {
		const button = ref.current;
		if (!button) return;
		const from = orbHandoff.take();
		const to = rectOf(button.querySelector(".oqe-orb-flier"));
		if (!from || !to) return;
		const { reduceMotion, orbAnimation } = useAppStore.getState().settings;
		if (reduceMotion || !orbAnimation) return;
		if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
		const { dx, dy, scale } = morphFrom(from, to);
		if (Math.abs(dx) < 4 && Math.abs(dy) < 4 && Math.abs(scale - 1) < .08) return;
		button.style.setProperty("--from-x", `${dx.toFixed(1)}px`);
		button.style.setProperty("--from-y", `${dy.toFixed(1)}px`);
		button.style.setProperty("--from-scale", scale.toFixed(3));
		const travel = Math.hypot(dx, dy);
		const arc = Math.min(30, Math.max(5, travel * .12));
		button.style.setProperty("--from-arc", `${arc.toFixed(1)}px`);
		button.style.setProperty("--orb-flight", `${Math.round(Math.min(760, 460 + travel * .22))}ms`);
		button.dataset.arriving = "true";
		setArriving(true);
		let landed = false;
		const land = () => {
			if (landed) return;
			landed = true;
			window.clearTimeout(fallback);
			button.removeEventListener("animationend", onEnd);
			delete button.dataset.arriving;
			setArriving(false);
		};
		const onEnd = (event) => {
			if (event.animationName === ARRIVAL_ANIMATION) land();
		};
		button.addEventListener("animationend", onEnd);
		const fallback = window.setTimeout(land, Math.min(760, 460 + travel * .22) + 60);
	}, []);
	const state = arriving ? "idle" : busy ? "working" : disabled ? "offline" : "idle";
	const dimmed = disabled && !busy && !arriving;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		ref,
		type: "submit",
		disabled,
		"aria-label": "Send message",
		"data-idle": dimmed ? "true" : void 0,
		className: cn("oqe-send-orb", busy && "oqe-send-orb-busy"),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "oqe-orb-flier",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "oqe-orb-scale",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OqeCharacter, {
					className: "block size-8",
					gaze,
					idle: !dimmed,
					state
				})
			})
		})
	});
}
/**
* Prompt 34 — the profile is first-class at the moment it matters: on the
* composer rail, beside Access and Multi-agent, in the same chip + menu shape
* those two already use.
*
* Two deliberate choices:
*   • The chip names the FEATURE and the active profile, so "Profile: Teacher"
*     is readable at a glance — the one thing this control must never do is
*     hide which working style is running.
*   • The menu states, in its own footer, that a profile changes instructions
*     only. It sits next to the access control, so a reader could otherwise
*     read "Product Research" as a permission upgrade.
*/
function ProfileControl() {
	const profile = useAppStore((s) => s.settings.profile);
	const updateSettings = useAppStore((s) => s.updateSettings);
	const [open, setOpen] = (0, import_react.useState)(false);
	const wrapRef = (0, import_react.useRef)(null);
	const active = profileFor(profile);
	(0, import_react.useEffect)(() => {
		if (!open) return;
		function onDocClick(event) {
			if (wrapRef.current && !wrapRef.current.contains(event.target)) setOpen(false);
		}
		function onKey(event) {
			if (event.key === "Escape") setOpen(false);
		}
		document.addEventListener("mousedown", onDocClick);
		document.addEventListener("keydown", onKey);
		return () => {
			document.removeEventListener("mousedown", onDocClick);
			document.removeEventListener("keydown", onKey);
		};
	}, [open]);
	function choose(id) {
		updateSettings({ profile: id });
		setOpen(false);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref: wrapRef,
		className: "relative",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			className: cn("chip", open && "bg-surface-2 text-fg"),
			"aria-haspopup": "menu",
			"aria-expanded": open,
			"aria-label": `Profile: ${active.name}`,
			"aria-describedby": "profile-state",
			title: `Profile: ${active.name} — ${active.short}`,
			"data-on": profile !== "general",
			onClick: () => setOpen((value) => !value),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Compass, {
					className: cn("size-4 shrink-0", profile !== "general" ? "text-accent" : "text-muted"),
					"aria-hidden": "true"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Profile" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					id: "profile-state",
					className: cn("hidden text-meta sm:inline", profile !== "general" ? "text-accent" : "text-muted"),
					children: active.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, {
					className: cn("size-3 shrink-0 transition-transform", open && "rotate-180"),
					"aria-hidden": "true"
				})
			]
		}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "menu",
			"aria-label": "Profile",
			className: "absolute bottom-full left-0 z-40 mb-2 w-72 rounded-lg bg-surface p-1 shadow-[0_0_0_1px_var(--color-border),0_8px_24px_rgba(0,0,0,0.5)]",
			children: [PROFILES.map((option) => {
				const selected = profile === option.id;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					role: "menuitemradio",
					"aria-checked": selected,
					className: cn("w-full rounded-md px-2 py-1.5 text-left hover:bg-surface-2", selected && "bg-surface-2"),
					onClick: () => choose(option.id),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm font-medium text-fg",
							children: option.name
						}), selected ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-sm bg-accent/10 px-1 py-0.5 text-meta text-accent",
							children: "active"
						}) : null]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-0.5 block text-xs leading-snug text-muted",
						children: option.short
					})]
				}, option.id);
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mx-1 mt-1 border-t border-border pt-1.5 text-xs leading-snug text-muted",
				children: "A profile shapes instructions only. It cannot grant browsing, desktop control or an account action — those are set in Access."
			})]
		}) : null]
	});
}
/**
* The three pieces every saved record is read through, shared by the Evidence
* page, the Library page and the composer's recall control so one record is
* never labelled two different ways in two places.
*
* The kind badge carries the whole point of the feature: what a statement IS.
* A note the reader typed, a page a public URL supplied, a model's guess and a
* tool's measurement are drawn in different tones and named in words, because
* telling them apart is the one thing this data cannot get wrong.
*/
var KIND_TONE = {
	note: "text-accent bg-user",
	web: "text-signal bg-surface-2",
	inference: "text-warn bg-warn/10",
	observation: "text-success bg-success/10"
};
function EvidenceKindBadge({ kind, title }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex max-w-full items-center rounded-sm px-2 py-0.5 text-meta font-medium", KIND_TONE[kind]),
		title: title ?? EVIDENCE_KIND_MEANING[kind],
		children: EVIDENCE_KIND_LABELS[kind]
	});
}
/**
* The composer's Recall control — the reader's library, one request at a time.
*
* Recall is EXPLICIT and one-shot. The reader opens this panel, searches their
* saved records, ticks the ones this message should carry, and sends. Nothing
* else ever attaches saved material to a request: there is no automatic recall,
* no "relevant items" the reader did not choose, and no library-wide dump. The
* panel states the two caps it works inside (how many records, roughly how many
* characters), because a limit the reader cannot see is a limit they will
* discover by having something quietly left out.
*
* `RecallStrip` shows the chosen records under the composer and, once the
* message has gone, what the last request actually carried — including the case
* where the window was too full for the recall and nothing was attached.
*/
function RecallControl() {
	const evidence = useAppStore((s) => s.evidence);
	const error = useAppStore((s) => s.evidenceError);
	const pendingRecall = useAppStore((s) => s.pendingRecall);
	const togglePendingRecall = useAppStore((s) => s.togglePendingRecall);
	const setPendingRecall = useAppStore((s) => s.setPendingRecall);
	const [open, setOpen] = (0, import_react.useState)(false);
	const [query, setQuery] = (0, import_react.useState)("");
	const matches = (0, import_react.useMemo)(() => searchEvidence(evidence, { query }, 50), [evidence, query]);
	const chosenCount = pendingRecall.length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "relative flex shrink-0 items-center",
		onBlur: (event) => {
			if (!open) return;
			const next = event.relatedTarget;
			if (next && event.currentTarget.contains(next)) return;
			setOpen(false);
		},
		onKeyDown: (event) => {
			if (event.key === "Escape") setOpen(false);
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: cn("inline-flex size-11 shrink-0 items-center justify-center rounded-lg", chosenCount > 0 ? "bg-surface-2 text-accent" : "text-muted hover:bg-surface-2 hover:text-fg"),
			"aria-expanded": open,
			"aria-haspopup": "dialog",
			"aria-label": chosenCount > 0 ? `Recall from your library — ${chosenCount} chosen for the next message` : "Recall from your library",
			title: "Attach saved knowledge to your next message — only what you tick, once",
			onClick: () => setOpen((value) => !value),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "relative inline-flex",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollText, {
					className: "size-5",
					"aria-hidden": "true"
				}), chosenCount > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "readout absolute -right-2 -top-1.5 rounded-full bg-accent px-1 text-[0.625rem] text-[color:var(--color-on-accent)]",
					children: chosenCount
				}) : null]
			})
		}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "dialog",
			"aria-label": "Recall saved knowledge",
			className: "absolute bottom-full left-0 z-30 mb-2 w-[min(26rem,calc(100vw-2rem))] rounded-lg bg-surface p-3 shadow-[var(--shadow-panel)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium",
						children: "Recall from your library"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-0.5 text-meta leading-relaxed text-muted",
						children: [
							"Chosen records travel with your next message only — up to ",
							5,
							" of them, about ",
							MAX_RECALL_CHARS.toLocaleString(),
							" characters. Each one is labelled with where it came from."
						]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "inline-flex size-7 shrink-0 items-center justify-center rounded-md text-muted hover:bg-surface-2 hover:text-fg",
						"aria-label": "Close recall",
						onClick: () => setOpen(false),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {
							className: "size-4",
							"aria-hidden": "true"
						})
					})]
				}),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 rounded-md bg-danger/10 px-2.5 py-1.5 text-meta text-fg",
					children: ["The local store could not be read: ", error]
				}) : null,
				evidence.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-2.5 rounded-md bg-surface-2 p-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Nothing is saved yet, so there is nothing to recall."
					})
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "relative mt-2.5 block",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
							className: "pointer-events-none absolute left-2.5 top-1/2 size-3.5 -translate-y-1/2 text-muted",
							"aria-hidden": "true"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "search",
							className: "min-h-9 pl-8 text-sm",
							"aria-label": "Search your saved knowledge",
							placeholder: "Search your saved records",
							value: query,
							onChange: (event) => setQuery(event.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "readout mt-1.5 text-meta text-muted",
						role: "status",
						children: matches.length === 0 ? "Nothing matched." : `${matches.length} of ${evidence.length} shown${matches.length >= 50 ? ` (showing the first 50)` : ""}`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-1.5 flex max-h-60 flex-col gap-1 overflow-y-auto",
						children: matches.map((match) => {
							const item = match.item;
							const chosen = pendingRecall.includes(item.id);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: cn("flex cursor-pointer items-start gap-2 rounded-md px-2 py-1.5 hover:bg-surface-2", chosen && "bg-user"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "checkbox",
									className: "mt-0.5",
									checked: chosen,
									onChange: () => togglePendingRecall(item.id)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "min-w-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block truncate text-sm text-fg",
										children: item.title
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "mt-1 flex items-center gap-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EvidenceKindBadge, { kind: item.kind }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "readout truncate text-meta text-muted",
											children: item.origin ?? "no source recorded"
										})]
									})]
								})]
							}) }, item.id);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 flex items-center justify-between gap-2 border-t border-border pt-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "readout text-meta text-muted",
							children: [
								chosenCount,
								" of ",
								5,
								" chosen"
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex items-center gap-1.5",
							children: chosenCount > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "ghost",
								onClick: () => setPendingRecall([]),
								children: "Clear"
							}) : null
						})]
					})
				] })
			]
		}) : null]
	});
}
/** What the reader chose for the next message, and what the last one carried. */
function RecallStrip() {
	const evidence = useAppStore((s) => s.evidence);
	const pendingRecall = useAppStore((s) => s.pendingRecall);
	const togglePendingRecall = useAppStore((s) => s.togglePendingRecall);
	const setPendingRecall = useAppStore((s) => s.setPendingRecall);
	const lastRecall = useAppStore((s) => s.lastRecall);
	const dismissLastRecall = useAppStore((s) => s.dismissLastRecall);
	const chosen = pendingRecall.map((id) => evidence.find((item) => item.id === id)).filter((item) => Boolean(item));
	if (chosen.length === 0 && !lastRecall) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex flex-wrap items-center gap-1.5 px-2 pb-2",
		"aria-label": "Recalled saved knowledge",
		children: chosen.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "readout text-accent",
				children: "Recall"
			}),
			chosen.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "readout inline-flex max-w-56 items-center gap-1 rounded-full bg-surface-2 px-2 py-0.5 text-muted shadow-[0_0_0_1px_var(--color-border)]",
				title: `${EVIDENCE_KIND_LABELS[item.kind]} · ${item.origin ?? "no source recorded"}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "max-w-44 truncate",
					children: item.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "ml-0.5 rounded px-0.5 text-muted hover:text-fg",
					"aria-label": `Remove ${item.title} from this message`,
					onClick: () => togglePendingRecall(item.id),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {
						className: "size-3",
						"aria-hidden": "true"
					})
				})]
			}, item.id)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "readout rounded px-1.5 py-0.5 text-muted hover:bg-surface-2 hover:text-fg",
				onClick: () => setPendingRecall([]),
				children: "Clear"
			})
		] }) : lastRecall ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "readout text-muted",
			children: lastRecall.used ? `Last message used ${lastRecall.description}` : "Last message could not fit the recalled material — nothing was added."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "readout rounded px-1.5 py-0.5 text-muted hover:bg-surface-2 hover:text-fg",
			"aria-label": "Dismiss the recall report",
			onClick: dismissLastRecall,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {
				className: "size-3",
				"aria-hidden": "true"
			})
		})] }) : null
	});
}
/**
* V10.6 — THE THREE THINKING STATES, defined once.
*
* The reader's report: "Thinking shouldn't be defaulted to auto. It should be
* in where I select models I can click to turn thinking on, off, auto, as the
* three options." Thinking was previously a read-only chip on the control
* rail: it announced the mode, could not be changed, and defaulted to auto, so
* a long or hard-looking message silently bought a reasoning trace (and the
* slow generation that comes with it) on a local model. The three states are
* now clickable in the model picker, and the default is off.
*
* V10.31 — the rail copy is gone. The reader asked for ONE place to change it,
* where the model is chosen, and a second chip a few inches away only raised
* the question of which of the two was in charge. Thinking is a property of the
* run the chosen model will perform, so the picker owns it — and it is pinned
* to the picker's bottom edge, because the list above it is the part that grows.
*
* One list, so every option and its meaning is defined exactly once.
*/
var THINKING_OPTIONS = [
	{
		value: "off",
		label: "Off",
		help: "Off = faster direct answers — no reasoning trace is requested."
	},
	{
		value: "on",
		label: "On",
		help: "Ask for a reasoning trace every turn. Slower, and only on models that support it."
	},
	{
		value: "auto",
		label: "Auto",
		help: "A trace only for long, hard-looking or multi-agent turns."
	}
];
function thinkingHelp(mode) {
	return THINKING_OPTIONS.find((option) => option.value === mode)?.help ?? THINKING_OPTIONS[0].help;
}
/**
* V10.6 — the one writer for the thinking state. Deliberately a plain function
* rather than inline update logic at each button: a stored setting written from
* several places is exactly how those places drift apart.
*/
function setThinking(mode) {
	useAppStore.getState().updateSettings({ thinkingMode: mode });
}
function Composer({ nearBottom = true, onSendIntent }) {
	const send = useAppStore((s) => s.sendUserMessage);
	const stop = useAppStore((s) => s.stopStreaming);
	const streamingId = useAppStore((s) => s.streamingId);
	const browsing = useAppStore((s) => s.browsing);
	const settings = useAppStore((s) => s.settings);
	const models = useAppStore((s) => s.discoveredModels);
	const loadedIds = useAppStore((s) => s.loadedModelIds);
	const modelLoading = useAppStore((s) => s.modelLoading);
	const selectModel = useAppStore((s) => s.selectModel);
	const loadModelNow = useAppStore((s) => s.loadModelNow);
	const probeConnection = useAppStore((s) => s.probeConnection);
	const hydrated = useAppStore((s) => s.hydrated);
	const updateSettings = useAppStore((s) => s.updateSettings);
	const activeConversation = useAppStore((s) => s.conversations.find((c) => c.id === s.activeId));
	const companionHealth = useAppStore((s) => s.companionHealth);
	const [pickerOpen, setPickerOpen] = (0, import_react.useState)(false);
	const [value, setValue] = (0, import_react.useState)("");
	const [listening, setListening] = (0, import_react.useState)(false);
	const [voiceSession, setVoiceSession] = (0, import_react.useState)(false);
	const [speechError, setSpeechError] = (0, import_react.useState)(null);
	const [attachments, setAttachments] = (0, import_react.useState)([]);
	const [attachmentError, setAttachmentError] = (0, import_react.useState)(null);
	/** What an archive contributed/skipped — informational, never an error. */
	const [attachmentNotice, setAttachmentNotice] = (0, import_react.useState)(null);
	const sendQueue = useAppStore((s) => s.sendQueue);
	const sendQueueHeld = useAppStore((s) => s.sendQueueHeld);
	const resumeSendQueue = useAppStore((s) => s.resumeSendQueue);
	const enqueueSend = useAppStore((s) => s.enqueueSend);
	const removeQueuedSend = useAppStore((s) => s.removeQueuedSend);
	const clearSendQueue = useAppStore((s) => s.clearSendQueue);
	const retryQueuedSend = useAppStore((s) => s.retryQueuedSend);
	const composerDraft = useAppStore((s) => s.composerDraft);
	const setComposerDraft = useAppStore((s) => s.setComposerDraft);
	const [dragOver, setDragOver] = (0, import_react.useState)(false);
	const [support, setSupport] = (0, import_react.useState)(() => ({
		recognition: false,
		synthesis: false,
		detail: ""
	}));
	const recStop = (0, import_react.useRef)(null);
	const recorderRef = (0, import_react.useRef)(null);
	const recorderStreamRef = (0, import_react.useRef)(null);
	const recorderChunksRef = (0, import_react.useRef)([]);
	const unmountedRef = (0, import_react.useRef)(false);
	const startingCaptureRef = (0, import_react.useRef)(false);
	const closeVoiceSessionAfterTurnRef = (0, import_react.useRef)(false);
	const areaRef = (0, import_react.useRef)(null);
	const pickerRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		setSupport(detectSpeechSupport());
	}, []);
	/**
	* V11.1 — release the microphone stream this composer opened.
	*
	* Navigating away (route change, teardown) used to leave an active local
	* recording running: the MediaRecorder was only ever stopped by the mic
	* button, so the browser's capture indicator stayed on after the composer
	* was gone. The unmount cleanup now stops the recorder, cancels a late
	* `getUserMedia` result, and stops every track synchronously. Stopping the
	* tracks is the privacy boundary; the pending `dataavailable` chunk is
	* discarded because the user never chose to keep that recording.
	*/
	(0, import_react.useEffect)(() => {
		unmountedRef.current = false;
		return () => {
			unmountedRef.current = true;
			recStop.current?.();
			recStop.current = null;
			const recorder = recorderRef.current;
			recorderRef.current = null;
			if (recorder && recorder.state !== "inactive") try {
				recorder.stop();
			} catch {}
			recorderStreamRef.current?.getTracks().forEach((track) => track.stop());
			recorderStreamRef.current = null;
			recorderChunksRef.current = [];
			closeVoiceSessionAfterTurnRef.current = false;
		};
	}, []);
	(0, import_react.useEffect)(() => {
		if (!hydrated) return;
		if (models.length > 0) return;
		if (!isConnectionConfigured(settings)) return;
		probeConnection();
	}, [hydrated]);
	(0, import_react.useEffect)(() => {
		if (!pickerOpen) return;
		const onDocClick = (event) => {
			if (pickerRef.current && !pickerRef.current.contains(event.target)) setPickerOpen(false);
		};
		const onKey = (event) => {
			if (event.key === "Escape") setPickerOpen(false);
		};
		document.addEventListener("mousedown", onDocClick);
		document.addEventListener("keydown", onKey);
		return () => {
			document.removeEventListener("mousedown", onDocClick);
			document.removeEventListener("keydown", onKey);
		};
	}, [pickerOpen]);
	(0, import_react.useEffect)(() => {
		const el = areaRef.current;
		if (!el) return;
		el.style.height = "auto";
		el.style.height = `${Math.min(el.scrollHeight, 200)}px`;
	}, [value]);
	(0, import_react.useEffect)(() => {
		if (composerDraft === null) return;
		setValue(composerDraft);
		setComposerDraft(null);
		const el = areaRef.current;
		if (el) {
			el.focus();
			const end = el.value.length;
			try {
				el.setSelectionRange(end, end);
			} catch {}
		}
	}, [composerDraft, setComposerDraft]);
	const streaming = Boolean(streamingId) || browsing;
	const compact = !streaming && (value.trim().length === 0 || !nearBottom);
	const hasContent = value.trim().length > 0 || attachments.length > 0;
	const hasThread = (activeConversation?.messages.length ?? 0) > 0;
	const primaryAction = composerPrimaryAction(streaming, hasContent);
	const queueReady = primaryAction === "queue";
	const canSend = !streaming && hasContent;
	const configured = isConnectionConfigured(settings) && settings.model.trim().length > 0;
	const hasMedia = extractHttpUrls(value).length > 0;
	const desktopPlaceholder = desktopComposerPlaceholder({
		enabled: companionHealth?.enabled,
		consentedTargets: companionHealth?.consented_targets ?? settings.consentedTargets
	});
	const sortedIds = (0, import_react.useMemo)(() => sortChatModelIds(models.filter((m) => settings.showInComposerPicker?.[m.id] !== false).map((m) => m.id)), [models, settings.showInComposerPicker]);
	const cloudModels = settings.mode === "cloud";
	const sourceById = (0, import_react.useMemo)(() => new Map(models.map((m) => [m.id, m.source])), [models]);
	const currentModel = settings.model.trim();
	const currentLoaded = (0, import_react.useMemo)(() => currentModel.length > 0 && loadedIds.some((loaded) => sameModel(loaded, currentModel)), [loadedIds, currentModel]);
	const capabilityCache = useAppStore((s) => s.capabilityCache);
	const visionBlocked = attachments.some((a) => a.kind === "image") && !isVisionModel(currentModel, settings.modelTags, capabilityCache) && !settings.autoSwitchModels;
	function onSubmit(event) {
		event?.preventDefault();
		const text = value;
		const queuedAttachments = attachments;
		if (!text.trim() && queuedAttachments.length === 0) return;
		if (!streaming) {
			if (!canSend) return;
			onSendIntent?.();
			orbHandoff.remember(rectOf(document.querySelector(".hero-orb")) ?? {
				left: 0,
				top: 0,
				width: 0,
				height: 0
			});
			setValue("");
			setAttachments([]);
			setAttachmentError(null);
			send(text, queuedAttachments).catch((error) => {
				orbHandoff.clear();
				setAttachmentError(error instanceof Error ? error.message : "The attachment could not be sent.");
				setAttachments(queuedAttachments);
			});
			return;
		}
		if (!queueReady) return;
		enqueueSend({
			text,
			attachments: queuedAttachments,
			conversationId: activeConversation?.id ?? useAppStore.getState().activeId ?? null
		});
		setValue("");
		setAttachments([]);
		setAttachmentError(null);
		setAttachmentNotice(null);
	}
	async function addFiles(files) {
		if (files.length === 0) return;
		setAttachmentError(null);
		setAttachmentNotice(null);
		const prepared = [];
		const failures = [];
		for (const file of files) try {
			prepared.push(await prepareAttachment(file, createId("file")));
		} catch (error) {
			failures.push({
				name: file.name,
				message: error instanceof Error ? error.message : "could not be attached."
			});
		}
		if (prepared.length === 0) {
			const first = failures[0]?.message ?? "The files could not be attached.";
			setAttachmentError(failures.length === 1 ? first : `None of these files could be attached: ${failures.map((f) => f.name).join(", ")}. ${first}`);
			return;
		}
		if (failures.length > 0) setAttachmentError(`Could not attach: ${failures.map((f) => f.name).join(", ")}. ${failures[0]?.message ?? ""}`.trim());
		const next = [...attachments, ...prepared];
		setAttachmentNotice(next.map((attachment) => attachment.note).filter((note) => Boolean(note)).join("  ") || null);
		setAttachments(next);
	}
	async function onFilesSelected(event) {
		const files = Array.from(event.target.files ?? []);
		event.target.value = "";
		await addFiles(files);
	}
	function onFilesDropped(event) {
		event.preventDefault();
		setDragOver(false);
		addFiles(Array.from(event.dataTransfer.files));
	}
	function onKeyDown(event) {
		if (event.nativeEvent.isComposing || event.keyCode === 229) return;
		if (event.key === "Enter" && !event.shiftKey) {
			event.preventDefault();
			onSubmit();
		}
	}
	/** Stop every track of the current recording stream (idempotent). */
	function releaseRecordingStream() {
		recorderStreamRef.current?.getTracks().forEach((track) => track.stop());
		recorderStreamRef.current = null;
	}
	async function finishLocalRecording() {
		if (unmountedRef.current) {
			recorderChunksRef.current = [];
			releaseRecordingStream();
			return;
		}
		const closeSessionAfterTurn = closeVoiceSessionAfterTurnRef.current;
		closeVoiceSessionAfterTurnRef.current = false;
		const blob = new Blob(recorderChunksRef.current, { type: recorderChunksRef.current[0]?.type || "audio/webm" });
		recorderChunksRef.current = [];
		recorderRef.current = null;
		releaseRecordingStream();
		if (!blob.size) {
			setListening(false);
			if (closeSessionAfterTurn) setVoiceSession(false);
			return;
		}
		try {
			const result = await transcribeAudio({
				blob,
				tier: settings.sttTier,
				wakePhrase: settings.wakePhrase,
				sleepPhrase: settings.sleepPhrase
			});
			const transcript = result.text.trim();
			if (!transcript) return;
			const decision = routeTranscript({
				transcript: result.wakeDetected ? `${settings.wakePhrase} ${transcript}` : transcript,
				sessionOpen: voiceSession || closeSessionAfterTurn,
				wakeSessionEnabled: settings.wakeSessionEnabled,
				wakePhrase: settings.wakePhrase,
				sleepPhrase: settings.sleepPhrase
			});
			if (decision.kind === "sleep") {
				setVoiceSession(false);
				setSpeechError("Voice session ended.");
				return;
			}
			if (decision.kind === "discard") {
				setSpeechError("Transcript discarded — say the wake phrase or use push-to-talk.");
				return;
			}
			setVoiceSession(closeSessionAfterTurn ? false : decision.sessionOpen);
			const text = decision.text;
			if (!text) return;
			send(text).catch((error) => {
				setSpeechError(error instanceof Error ? error.message : "The transcribed message could not be sent.");
			});
		} catch (error) {
			setSpeechError(error instanceof Error ? error.message : "Local STT failed.");
		} finally {
			setListening(false);
		}
	}
	async function startLocalRecording() {
		if (!navigator.mediaDevices?.getUserMedia || typeof MediaRecorder === "undefined") {
			setSpeechError("This browser cannot capture microphone audio for local STT. You can still type.");
			return;
		}
		if (startingCaptureRef.current) return;
		startingCaptureRef.current = true;
		let stream = null;
		try {
			stream = await navigator.mediaDevices.getUserMedia({ audio: true });
			if (unmountedRef.current) {
				stream.getTracks().forEach((track) => track.stop());
				return;
			}
			const recorder = new MediaRecorder(stream);
			recorderChunksRef.current = [];
			recorderStreamRef.current = stream;
			recorderRef.current = recorder;
			recorder.ondataavailable = (event) => {
				if (event.data.size > 0) recorderChunksRef.current.push(event.data);
			};
			recorder.onstop = () => {
				finishLocalRecording();
			};
			recorder.onerror = () => {
				setSpeechError("Microphone capture stopped unexpectedly.");
				setListening(false);
				const current = recorderRef.current;
				recorderRef.current = null;
				if (current && current.state !== "inactive") try {
					current.stop();
				} catch {}
				recorderChunksRef.current = [];
				releaseRecordingStream();
			};
			recorder.start();
			setListening(true);
			setSpeechError(null);
		} catch (error) {
			stream?.getTracks().forEach((track) => track.stop());
			if (!unmountedRef.current) setSpeechError(error instanceof Error && error.name === "NotAllowedError" ? "Microphone permission was denied. Allow it in the browser to use local STT." : "Microphone could not start.");
		} finally {
			startingCaptureRef.current = false;
		}
	}
	function toggleMic() {
		setSpeechError(null);
		if (settings.localSttEnabled) {
			if (listening) {
				closeVoiceSessionAfterTurnRef.current = true;
				setVoiceSession(false);
				const recorder = recorderRef.current;
				if (recorder && recorder.state !== "inactive") try {
					recorder.stop();
				} catch {}
				releaseRecordingStream();
			} else startLocalRecording();
			return;
		}
		if (listening) {
			recStop.current?.();
			recStop.current = null;
			setListening(false);
			setVoiceSession(false);
			return;
		}
		if (!support.recognition) {
			setSpeechError(support.detail || "Speech recognition is not available in this browser.");
			return;
		}
		const started = startRecognition({
			onInterim: (text) => setValue((prev) => mergeSpeech(prev, text, false)),
			onFinal: (text) => setValue((prev) => mergeSpeech(prev, text, true)),
			onError: (message) => {
				setSpeechError(message);
				setListening(false);
			},
			onEnd: () => setListening(false)
		});
		if ("error" in started) {
			setSpeechError(started.error);
			return;
		}
		recStop.current = started.stop;
		setListening(true);
	}
	function queueNow() {
		if (!queueReady) return;
		const text = value;
		const queuedAttachments = attachments;
		const queuedConversationId = activeConversation?.id ?? useAppStore.getState().activeId ?? null;
		setValue("");
		setAttachments([]);
		setAttachmentError(null);
		enqueueSend({
			text,
			attachments: queuedAttachments,
			conversationId: queuedConversationId
		});
	}
	function removeQueued(id) {
		removeQueuedSend(id);
	}
	function retryQueued(id) {
		retryQueuedSend(id);
	}
	function clearQueued() {
		clearSendQueue();
	}
	const showMic = settings.speechToText || settings.localSttEnabled;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit,
		className: "mx-auto w-full max-w-[44rem] px-4 pb-[max(1rem,env(safe-area-inset-bottom))]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: cn("composer-shell p-3", dragOver && "outline-2 outline-dashed outline-accent", compact && "composer-compact"),
				onDragOver: (event) => {
					event.preventDefault();
					setDragOver(true);
				},
				onDragLeave: () => setDragOver(false),
				onDrop: onFilesDropped,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-2 px-1 pt-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							ref: pickerRef,
							className: "relative min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "inline-flex max-w-full items-center gap-1.5 rounded-md px-1 py-1 text-xs text-muted transition-colors hover:bg-surface-2 hover:text-fg",
								"aria-expanded": pickerOpen,
								"aria-haspopup": "listbox",
								onClick: () => setPickerOpen((open) => !open),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "readout max-w-[16rem] truncate text-faint",
										title: currentModel ? settings.modelAliases[currentModel] ? `${settings.modelAliases[currentModel]} (${currentModel})` : currentModel : void 0,
										children: (() => {
											return (currentModel ? settings.modelAliases[currentModel] : void 0) ?? (currentModel || "Select model");
										})()
									}),
									modelLoading === currentModel && currentModel ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "size-1.5 shrink-0 animate-pulse rounded-full bg-accent",
										"aria-hidden": "true"
									}) : currentLoaded ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "size-1.5 shrink-0 rounded-full bg-ok",
										"aria-hidden": "true"
									}) : null,
									modelLoading === currentModel && currentModel ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "sr-only",
										children: "Model loading"
									}) : currentLoaded ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "sr-only",
										children: "Model loaded in memory"
									}) : null,
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, {
										className: "size-3.5 shrink-0 opacity-60",
										"aria-hidden": "true"
									})
								]
							}), pickerOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "absolute bottom-full left-0 z-40 mb-2 flex max-h-80 w-full min-w-72 flex-col overflow-hidden rounded-lg bg-surface shadow-[0_0_0_1px_var(--color-border),0_8px_24px_rgba(0,0,0,0.5)]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-h-0 flex-1 overflow-y-auto p-1.5 [mask-image:linear-gradient(to_bottom,transparent_0,black_0.5rem)]",
									children: [models.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "px-2.5 py-3 text-xs text-muted",
										children: cloudModels ? "No cloud models listed yet. Test the connection in Settings — Oqe lists only models this key can reach, and never as if they were installed here." : "No installed models listed yet. Test the connection in Settings — Oqe only shows models Ollama actually reports."
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
										className: "flex flex-col gap-0.5",
										role: "listbox",
										"aria-label": cloudModels ? "Cloud models" : "Installed Ollama models",
										children: sortedIds.map((id) => {
											const loaded = loadedIds.some((l) => sameModel(l, id));
											const loading = modelLoading === id;
											const selected = id === currentModel;
											return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
												role: "option",
												"aria-selected": selected,
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
													type: "button",
													className: cn("flex w-full flex-col gap-0.5 rounded-md px-2.5 py-2 text-left hover:bg-surface-2", selected && "bg-surface-2"),
													onClick: () => {
														selectModel(id);
														setPickerOpen(false);
													},
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "flex flex-wrap items-center gap-2 font-mono text-xs text-fg",
														children: [
															settings.modelAliases[id] ? `${settings.modelAliases[id]} · ${id}` : id,
															loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "readout text-signal",
																children: "loading…"
															}) : cloudModels ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "readout text-muted opacity-70",
																children: "cloud"
															}) : loaded ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "readout text-ok",
																children: "in memory"
															}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "readout text-signal opacity-70",
																children: "unloaded"
															}),
															sourceById.get(id) === "openai" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "rounded bg-bg px-1.5 py-0.5 font-sans text-meta text-muted shadow-[0_0_0_1px_var(--color-border)]",
																children: "OpenAI-compatible"
															}) : null
														]
													}), capabilityLabels(id, capabilityCache, settings.modelTags).length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "flex flex-wrap gap-1",
														children: capabilityLabels(id, capabilityCache, settings.modelTags).map((label) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "rounded bg-bg px-1.5 py-0.5 text-meta text-muted shadow-[0_0_0_1px_var(--color-border)]",
															children: label
														}, label))
													}) : null]
												})
											}, id);
										})
									}), currentModel && settings.mode === "local" && !currentLoaded ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-1 border-t border-border pt-1.5",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											className: "w-full rounded-md px-2.5 py-2 text-left text-xs text-accent hover:bg-surface-2 disabled:opacity-50",
											disabled: Boolean(modelLoading),
											onClick: () => {
												loadModelNow(currentModel);
												setPickerOpen(false);
											},
											children: [
												"Load ",
												currentModel,
												" into memory now"
											]
										})
									}) : null]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "shrink-0 border-t border-border bg-surface p-2.5 shadow-[0_-8px_16px_rgba(0,0,0,0.25)]",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs font-medium text-muted",
											id: "thinking-group-label",
											children: "Thinking"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThinkingOptions, {
											className: "mt-1.5",
											labelledBy: "thinking-group-label"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-1 text-meta leading-snug text-muted",
											children: thinkingHelp(settings.thinkingMode)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
											className: "mt-2 flex cursor-pointer select-none items-center justify-between gap-3 border-t border-border pt-2 text-xs text-muted hover:text-fg",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Auto-route to a suitable model" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "checkbox",
												className: "size-3.5 accent-[var(--color-accent)]",
												checked: settings.autoSwitchModels,
												onChange: (e) => updateSettings({ autoSwitchModels: e.target.checked })
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-1 text-meta leading-snug text-muted",
											children: "Off by default. When on, a send may use another installed model that fits the work — text as well as images. The run's steps name the model it used and why."
										})
									]
								})]
							}) : null]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex shrink-0 items-center",
							children: activeConversation ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContextControl, {
								conversation: activeConversation,
								streaming
							}) : null
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MultiAgentArmedBanner, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						htmlFor: "composer",
						className: "sr-only",
						children: "Message"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						id: "composer",
						ref: areaRef,
						rows: 1,
						value,
						onChange: (e) => setValue(e.target.value),
						onKeyDown,
						placeholder: !configured ? settings.mode === "cloud" ? "Paste an Ollama Cloud API key in Settings, or paste a video link" : "Pick a model in Settings, or paste a video link" : (settings.accessMode ?? (settings.allowWebBrowsing ? "browse" : "off")) === "browser" ? BROWSER_ASSIST_PLACEHOLDER : (settings.accessMode ?? (settings.allowWebBrowsing ? "browse" : "off")) === "desktop" ? desktopPlaceholder : "Ask anything",
						className: "block max-h-52 min-h-20 w-full resize-none bg-transparent px-3 py-3 text-[1.0625rem] leading-[1.55] text-fg caret-accent outline-none placeholder:text-faint sm:min-h-12"
					}),
					attachments.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-2 px-2 pb-2",
						"aria-label": "Attachments",
						children: attachments.map((attachment) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "inline-flex max-w-full items-center gap-1.5 rounded-md bg-surface-2 px-2 py-1 text-xs text-muted shadow-[0_0_0_1px_var(--color-border)]",
							title: `${attachment.name} · ${attachment.type} · ${formatBytes$1(attachment.size)}${attachment.note ? ` — ${attachment.note}` : ""}`,
							children: [
								attachment.kind === "image" ? attachment.data ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: `data:${attachment.type};base64,${attachment.data}`,
									alt: "",
									className: "size-8 shrink-0 rounded-sm object-cover shadow-[0_0_0_1px_var(--color-border)]"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Image, {
									className: "size-3.5 shrink-0",
									"aria-hidden": "true"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, {
									className: "size-3.5 shrink-0",
									"aria-hidden": "true"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "max-w-48 truncate",
									children: attachment.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "readout shrink-0 opacity-70",
									children: formatBytes$1(attachment.size)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "inline-flex size-5 items-center justify-center rounded text-muted hover:bg-bg hover:text-fg",
									"aria-label": `Remove ${attachment.name}`,
									onClick: () => {
										const next = attachments.filter((item) => item.id !== attachment.id);
										setAttachments(next);
										if (next.length === 0) setAttachmentNotice(null);
									},
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {
										className: "size-3.5",
										"aria-hidden": "true"
									})
								})
							]
						}, attachment.id))
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RecallStrip, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center justify-end gap-1 px-1 pb-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex min-w-0 flex-wrap items-center gap-1.5 sm:flex-nowrap",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccessModeControl, {}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProfileControl, {}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MultiAgentArm, {})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								"aria-hidden": "true",
								className: "flex-1"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								"aria-hidden": "true",
								className: "hidden h-6 w-px shrink-0 bg-border sm:block"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "inline-flex size-11 shrink-0 cursor-pointer items-center justify-center rounded-lg text-muted hover:bg-surface-2 hover:text-fg",
								"aria-label": "Attach files",
								title: "Attach an image, text, Markdown, CSV, or code file — or a .zip of them",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Paperclip, {
									className: "size-5",
									"aria-hidden": "true"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "file",
									className: "sr-only",
									multiple: true,
									accept: "image/png,image/jpeg,image/webp,.zip,.txt,.md,.csv,.c,.cc,.cpp,.cs,.css,.go,.h,.hpp,.html,.java,.js,.json,.jsx,.mjs,.py,.ps1,.rs,.sh,.sql,.svg,.ts,.tsx,.vue,.xml,.yaml,.yml",
									onChange: (event) => void onFilesSelected(event)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RecallControl, {}),
							showMic ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: cn("inline-flex size-11 shrink-0 items-center justify-center rounded-lg hover:bg-surface-2", listening ? "bg-surface-2 text-accent" : "text-muted hover:text-fg"),
								"aria-label": listening ? "Stop listening" : "Start speech to text",
								"aria-pressed": listening,
								onClick: toggleMic,
								children: listening ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Square, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mic, { className: "size-5" })
							}) : null,
							settings.textToSpeech ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "inline-flex size-11 shrink-0 items-center justify-center rounded-lg text-muted hover:bg-surface-2 hover:text-fg",
								title: "Stop speech",
								"aria-label": "Stop speech",
								onClick: () => stopSpeech(),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, {
									className: "size-5",
									"aria-hidden": "true"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "sr-only",
									children: "Stop speech"
								})]
							}) : null,
							sendQueue.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "mr-1 flex items-center gap-1.5",
								"aria-label": "Send queue",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "readout text-signal",
										children: [
											"Queued (",
											sendQueue.length,
											")"
										]
									}),
									sendQueueHeld ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "readout text-warn",
										title: "Stopped. Nothing queued will be sent until you resume.",
										children: "Held after Stop"
									}) : null,
									sendQueue.map((entry) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: cn("readout inline-flex max-w-44 items-center gap-1 rounded-full bg-surface-2 px-2 py-0.5 text-muted shadow-[0_0_0_1px_var(--color-border)]", entry.failed && "text-warn shadow-[0_0_0_1px_var(--color-warn)]"),
										title: entry.failed ? `Failed to dispatch. Retry or remove. ${entry.text.trim() || "Attachment-only message"}` : entry.text.trim() || "Attachment-only message",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: cn("size-1.5 shrink-0 rounded-full", entry.failed ? "bg-warn" : "bg-accent"),
												"aria-hidden": "true"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "max-w-32 truncate",
												children: entry.text.trim() || "Attachments"
											}),
											entry.failed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												className: "ml-0.5 rounded px-0.5 font-medium text-warn hover:text-fg",
												"aria-label": `Retry failed message: ${entry.text.trim() || "Attachments"}`,
												title: "Re-queue this message; it sends when the current run settles",
												onClick: () => retryQueued(entry.id),
												children: "Retry"
											}) : null,
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												className: "ml-0.5 rounded px-0.5 text-muted hover:text-fg",
												"aria-label": "Remove queued message",
												onClick: () => removeQueued(entry.id),
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {
													className: "size-3",
													"aria-hidden": "true"
												})
											})
										]
									}, entry.id)),
									sendQueueHeld ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "readout rounded px-1.5 py-0.5 font-medium text-accent hover:bg-surface-2 hover:text-accent-hover focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-accent/60",
										"aria-label": "Resume the send queue",
										title: "Send the held messages now — this is a new start, after your Stop",
										onClick: () => resumeSendQueue(),
										children: "Resume"
									}) : null,
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "readout rounded px-1.5 py-0.5 text-muted hover:bg-surface-2 hover:text-fg",
										"aria-label": "Clear queue",
										onClick: clearQueued,
										children: "Clear queue"
									})
								]
							}) : null,
							"          ",
							primaryAction === "stop" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "danger",
								"aria-label": "Stop the current run",
								title: "Abort the current reply / desktop loop now",
								onClick: () => stop(),
								children: composerPrimaryLabel("stop")
							}) : primaryAction === "queue" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "secondary",
								"aria-label": "Queue message for dispatch",
								title: "Queues this message; it sends when the current reply finishes",
								onClick: queueNow,
								children: composerPrimaryLabel("queue")
							}) : hasThread ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "submit",
								variant: "primary",
								disabled: !canSend,
								"aria-label": "Send message",
								children: composerPrimaryLabel("send")
							}),
							hasThread ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrbSendButton, {
								disabled: primaryAction !== "send" || !canSend,
								busy: streaming
							}) : null
						]
					})
				]
			}),
			visionBlocked ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 px-2 text-xs text-warn",
				children: [currentModel || "The selected model", " cannot read images. Automatic switching is off; pick an installed vision model in the picker above before sending."]
			}) : null,
			!configured && hasMedia ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 px-2 text-xs text-muted",
				children: "This link can open on the main screen. A working Ollama connection and a chosen model are still needed for a model reply."
			}) : null,
			speechError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 px-2 text-xs text-danger",
				children: speechError
			}) : null,
			attachmentError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 px-2 text-xs text-danger",
				role: "alert",
				children: attachmentError
			}) : null,
			attachmentNotice ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 px-2 text-xs leading-relaxed text-muted",
				children: attachmentNotice
			}) : null
		]
	});
}
function AccessModeControl() {
	const settings = useAppStore((s) => s.settings);
	const companionHealth = useAppStore((s) => s.companionHealth);
	const updateSettings = useAppStore((s) => s.updateSettings);
	const [open, setOpen] = (0, import_react.useState)(false);
	const wrapRef = (0, import_react.useRef)(null);
	const mode = settings.accessMode ?? (settings.allowWebBrowsing ? "browse" : "off");
	const label = mode === "off" ? "No browsing" : mode === "browse" ? "Browsing allowed" : mode === "browser" ? "Browser assist" : "Full desktop control";
	const icon = mode === "off" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldOff, {
		className: "size-4",
		"aria-hidden": "true"
	}) : mode === "browse" || mode === "browser" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Globe, {
		className: "size-4",
		"aria-hidden": "true"
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Monitor, {
		className: "size-4",
		"aria-hidden": "true"
	});
	(0, import_react.useEffect)(() => {
		if (!open) return;
		function onDocClick(e) {
			if (wrapRef.current && !wrapRef.current.contains(e.target)) setOpen(false);
		}
		function onKey(e) {
			if (e.key === "Escape") setOpen(false);
		}
		document.addEventListener("mousedown", onDocClick);
		document.addEventListener("keydown", onKey);
		return () => {
			document.removeEventListener("mousedown", onDocClick);
			document.removeEventListener("keydown", onKey);
		};
	}, [open]);
	const paired = Boolean(companionHealth?.paired ?? false);
	function select(modeValue) {
		updateSettings({ accessMode: modeValue });
		setOpen(false);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref: wrapRef,
		className: "relative mr-auto",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			className: cn("chip", open && "bg-surface-2 text-fg"),
			"aria-haspopup": "menu",
			"aria-expanded": open,
			"aria-label": `Access mode: ${label}`,
			title: label,
			onClick: () => setOpen((v) => !v),
			children: [
				icon,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "max-w-[7.5rem] truncate",
					children: label
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, {
					className: `size-3 shrink-0 transition-transform ${open ? "rotate-180" : ""}`,
					"aria-hidden": "true"
				})
			]
		}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "menu",
			className: "absolute bottom-full left-0 z-40 mb-2 w-72 rounded-lg bg-surface p-1 shadow-[0_0_0_1px_var(--color-border),0_8px_24px_rgba(0,0,0,0.5)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					role: "menuitemradio",
					"aria-checked": mode === "off",
					className: `flex items-center gap-1.5 rounded-md px-2 py-1 text-left hover:bg-surface-2 ${mode === "off" ? "bg-surface-2" : ""}`,
					onClick: () => select("off"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldOff, {
						className: "size-4 shrink-0 text-muted",
						"aria-hidden": "true"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-sm font-medium text-fg",
						children: "No browsing"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					role: "menuitemradio",
					"aria-checked": mode === "browse",
					className: `flex items-center gap-1.5 rounded-md px-2 py-1 text-left hover:bg-surface-2 ${mode === "browse" ? "bg-surface-2" : ""}`,
					onClick: () => select("browse"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Globe, {
						className: "size-4 shrink-0 text-muted",
						"aria-hidden": "true"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-sm font-medium text-fg",
						children: "Browsing allowed"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					role: "menuitemradio",
					"aria-checked": mode === "browser",
					className: `flex items-center gap-1.5 rounded-md px-2 py-1 text-left hover:bg-surface-2 ${mode === "browser" ? "bg-surface-2" : ""}`,
					onClick: () => select("browser"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Globe, {
						className: "size-4 shrink-0 text-muted",
						"aria-hidden": "true"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-sm font-medium text-fg",
						children: "Browser assist"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					role: "menuitemradio",
					"aria-checked": mode === "desktop",
					className: `flex items-center gap-1.5 rounded-md px-2 py-1 text-left hover:bg-surface-2 ${mode === "desktop" ? "bg-surface-2" : ""}`,
					onClick: () => select("desktop"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Monitor, {
						className: "size-4 shrink-0 text-muted",
						"aria-hidden": "true"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-sm font-medium text-fg",
						children: "Full desktop control"
					})]
				}),
				mode === "desktop" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mx-1 mt-1 border-t border-border pt-1.5 text-xs leading-snug text-muted",
					children: "Desktop control needs Pair → Enable → consent → STOP."
				}) : null,
				mode === "browser" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mx-1 text-xs leading-snug text-muted",
					children: "Browser assist drives Oqe’s own tab through the Oqe Browser Assistant extension — the companion is not involved. Click the extension’s toolbar icon to raise what it may do on a page."
				}) : null,
				mode === "desktop" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mx-1 text-xs leading-snug text-muted",
					children: "Full desktop control is explicit OS automation via the companion — not background OS control."
				}) : null,
				mode === "desktop" && !paired ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mx-1 text-xs font-medium leading-snug text-warn",
					children: "Companion not paired — control unavailable."
				}) : null,
				mode === "browser" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mx-1 text-xs leading-snug text-muted",
					children: "Needs the Oqe Browser Assistant extension installed and enabled — nothing else."
				}) : null
			]
		}) : null]
	});
}
/**
* The three thinking states as a segmented control (used inside the model
* picker). `role="radiogroup"` with real `aria-checked` state, so the current
* mode is announced rather than implied by colour.
*/
function ThinkingOptions({ className, labelledBy }) {
	const mode = useAppStore((s) => s.settings.thinkingMode);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		role: "radiogroup",
		"aria-label": labelledBy ? void 0 : "Thinking",
		"aria-labelledby": labelledBy,
		className: cn("flex gap-0.5 rounded-md bg-well p-0.5 shadow-[inset_0_0_0_1px_var(--color-border)]", className),
		children: THINKING_OPTIONS.map((option) => {
			const selected = mode === option.value;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				role: "radio",
				"aria-checked": selected,
				className: cn("flex-1 rounded-sm px-2 py-1 text-xs font-medium transition-colors", selected ? "bg-surface-2 text-accent shadow-[inset_0_0_0_1px_rgb(255_179_71_/_0.32)]" : "text-muted hover:text-fg"),
				title: option.help,
				onClick: () => setThinking(option.value),
				children: option.label
			}, option.value);
		})
	});
}
/** V10.31 — the three states of the Multi-agent control, in one place. */
var MULTI_AGENT_SEGMENTS = [
	{
		value: "off",
		label: "Off"
	},
	{
		value: "on",
		label: "On"
	},
	{
		value: "auto",
		label: "Auto"
	}
];
/**
* Count-free arm control for the Multi-agent run: the visible label is just
* "Multi-agent" — no agent counts, no pass counts, no promo copy.
*
* V10.31 — it is a three-way choice. OFF answers with one model; ON is the
* one-shot arm this control has always been (the next send runs the engine,
* then it returns to Off); AUTO is a standing choice that decides per message
* from the shape of the task — many items, or several fields to decide plus
* more than one kind of work — and then lets the engine check and repair its
* own result before answering.
*
* V10.38 — ONE chip, not a chip holding three rival buttons. At rest the rail
* now reads like its neighbour: [icon] Multi-agent Off ▾ — the same surface and
* height as the access chip, one word of state, and the three choices in a menu
* where each can be explained. The old nested pill asked a 36px control to hold
* three amber-ringed segments beside a one-word chip, which made the quietest
* part of the composer the busiest. The state is still always visible (the word
* and the chip's lamp), and it is in the accessible description, so nothing
* moved behind the menu that the reader needs at a glance.
*/
function MultiAgentArm() {
	const council = useAppStore((s) => s.settings.council);
	const choice = useAppStore((s) => s.multiAgentChoice);
	const setChoice = useAppStore((s) => s.setMultiAgentChoice);
	const [open, setOpen] = (0, import_react.useState)(false);
	const wrapRef = (0, import_react.useRef)(null);
	const ready = council.mode !== "off" && activeRoster(council.roster).length >= 2;
	const current = MULTI_AGENT_SEGMENTS.find((option) => option.value === choice) ?? MULTI_AGENT_SEGMENTS[0];
	const tip = !ready ? "Multi-agent needs the feature on and at least two roster roles — set them in Settings → Multi-agent." : choice === "on" ? "The next send runs Multi-agent, then this turns off." : choice === "auto" ? "Auto: Oqe starts the agent group when a task has many items, or several fields to decide plus more than one kind of work — then it checks and repairs its own result. Simple requests stay one model." : "One model answers. Choose On for one multi-agent run, or Auto to let Oqe decide per message.";
	(0, import_react.useEffect)(() => {
		if (!open) return;
		function onDocClick(event) {
			if (wrapRef.current && !wrapRef.current.contains(event.target)) setOpen(false);
		}
		function onKey(event) {
			if (event.key === "Escape") setOpen(false);
		}
		document.addEventListener("mousedown", onDocClick);
		document.addEventListener("keydown", onKey);
		return () => {
			document.removeEventListener("mousedown", onDocClick);
			document.removeEventListener("keydown", onKey);
		};
	}, [open]);
	(0, import_react.useEffect)(() => {
		setOpen(false);
	}, [choice]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref: wrapRef,
		className: "relative",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			className: cn("chip", open && "bg-surface-2 text-fg"),
			"aria-haspopup": "menu",
			"aria-expanded": open,
			"aria-label": "Multi-agent",
			"aria-describedby": "multi-agent-state",
			title: tip,
			"data-on": choice !== "off",
			onClick: () => setOpen((value) => !value),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, {
					className: cn("size-4 shrink-0", choice !== "off" ? "text-accent" : "text-muted"),
					"aria-hidden": "true"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Multi-agent" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					id: "multi-agent-state",
					className: cn("hidden text-meta sm:inline", choice !== "off" ? "text-accent" : "text-muted"),
					children: current.label
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, {
					className: cn("size-3 shrink-0 transition-transform", open && "rotate-180"),
					"aria-hidden": "true"
				})
			]
		}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "menu",
			"aria-label": "Multi-agent",
			className: "absolute bottom-full left-0 z-40 mb-2 w-64 rounded-lg bg-surface p-1 shadow-[0_0_0_1px_var(--color-border),0_8px_24px_rgba(0,0,0,0.5)]",
			children: [MULTI_AGENT_SEGMENTS.map((option) => {
				const selected = choice === option.value;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					role: "menuitemradio",
					"aria-checked": selected,
					disabled: !ready,
					className: cn("flex w-full items-center rounded-md px-2 py-1 text-left text-sm font-medium text-fg hover:bg-surface-2 disabled:cursor-not-allowed disabled:opacity-40", selected && "bg-surface-2"),
					onClick: () => setChoice(option.value),
					children: option.label
				}, option.value);
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mx-1 mt-1 border-t border-border pt-1.5 text-xs leading-snug text-muted",
				children: tip
			})]
		}) : null]
	});
}
/**
* IMP-19 (change sugg v3 / issue #40) — the arm is impossible to miss at
* compose time. Reads only the REAL arm flag and gates (activity honesty — no
* fabricated progress): when the next send is armed, say so — and say WHY it
* will not run multi-agent when the mode is off or the roster has fewer than
* two roles. Disappears the moment the send consumes the arm.
*/
function MultiAgentArmedBanner() {
	const council = useAppStore((s) => s.settings.council);
	if (!useAppStore((s) => s.multiAgentNextSend)) return null;
	const problem = !(activeRoster(council.roster).length >= 2) ? "The roster has fewer than two roles, so it will not run. Add roles in Settings." : council.mode === "off" ? "Multi-agent is off, so it will not run. Turn it on in Settings." : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		role: "status",
		className: "mx-2 mt-1 rounded-md border border-accent/40 bg-accent/10 px-3 py-1.5 text-xs text-fg",
		children: problem ? `Multi-agent is armed for your next send. ${problem}` : "Multi-agent is armed for your next send. The agent group chat opens on the right while it runs."
	});
}
/**
* Composer context control: shows an honest context-usage estimate for the
* active thread and exposes two local actions — collapse (compress older
* turns into the existing local context summary) and receive markdown (a
* portable export of the real thread with Copy + Download). Both reuse the
* V5.1 compression path and a deterministic local document builder; nothing
* here invents token counts (they are labelled estimates) or deletes the
* visible thread.
*/
function ContextControl({ conversation, streaming }) {
	const compress = useAppStore((s) => s.compressConversation);
	const contextModel = useAppStore((s) => s.settings.model);
	const contextLimits = useAppStore((s) => s.settings.contextLimits);
	const optimizeAt = useAppStore((s) => s.settings.contextOptimizeAt);
	const archive = conversation.contextArchive ?? [];
	const [open, setOpen] = (0, import_react.useState)(false);
	const [showArchive, setShowArchive] = (0, import_react.useState)(false);
	const [exported, setExported] = (0, import_react.useState)(null);
	const [confirmCompress, setConfirmCompress] = (0, import_react.useState)(false);
	const wrapRef = (0, import_react.useRef)(null);
	const capacity = resolveContextCapacityWithLimits(contextModel, contextLimits);
	const usage = estimateContextUsage(conversation, capacity);
	const estimate = usage.estimated;
	const optimizeTrigger = optimizeAtTrigger(capacity.tokens, optimizeAt);
	const crowded = usage.percent >= optimizeTrigger.effectiveWindowPercent;
	const canCompress = conversation.messages.length >= 4;
	(0, import_react.useEffect)(() => {
		if (!open) return;
		function onDocClick(event) {
			if (wrapRef.current && !wrapRef.current.contains(event.target)) setOpen(false);
		}
		function onKey(event) {
			if (event.key === "Escape") setOpen(false);
		}
		document.addEventListener("mousedown", onDocClick);
		document.addEventListener("keydown", onKey);
		return () => {
			document.removeEventListener("mousedown", onDocClick);
			document.removeEventListener("keydown", onKey);
		};
	}, [open]);
	(0, import_react.useEffect)(() => {
		if (!open) setConfirmCompress(false);
	}, [open]);
	function onCompress() {
		if (!canCompress || streaming) return;
		setConfirmCompress(true);
	}
	function commitCompress() {
		if (!canCompress || streaming) return;
		compress(conversation.id);
		setExported(null);
		setConfirmCompress(false);
	}
	function onExport() {
		setExported({
			name: markdownFileName(conversation),
			markdown: buildConversationMarkdown(conversation)
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref: wrapRef,
		className: "relative",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			className: cn("readout inline-flex min-h-12 items-center gap-1.5 rounded-lg px-2 text-muted hover:bg-surface-2 hover:text-fg", crowded && "text-warn"),
			"aria-expanded": open,
			"aria-haspopup": "dialog",
			title: estimate ? "Context use — counted by the model runtime through your last turn, estimated after it" : "Context use — counted by the model runtime",
			onClick: () => setOpen((value) => !value),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gauge, {
				className: "size-4 shrink-0 text-faint",
				"aria-hidden": "true"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "readout whitespace-nowrap text-muted",
				children: [
					estimate ? "~" : "",
					usage.percent,
					"% context"
				]
			})]
		}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "dialog",
			"aria-label": "Context controls",
			className: "absolute right-0 top-full z-40 mt-2 w-[min(21rem,calc(100vw-2rem))] rounded-lg bg-surface p-3 shadow-[0_0_0_1px_var(--color-border),0_8px_24px_rgba(0,0,0,0.5)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "group-label",
					children: "Context"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1.5 text-xs leading-relaxed text-muted",
					children: [
						estimate ? "Usage estimate" : "Measured usage",
						": ",
						usage.usedTokens.toLocaleString(),
						" of",
						" ",
						capacity.tokens.toLocaleString(),
						" tokens (",
						usage.percent,
						"%). Window:",
						" ",
						capacityConfidenceLabel(capacity),
						"."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-meta leading-relaxed text-muted",
					children: usage.exact ? `Counted by the model runtime: your last prompt was ${usage.measuredPromptTokens?.toLocaleString() ?? 0} tokens${usage.measuredOutputTokens !== void 0 ? `, its reply ${usage.measuredOutputTokens.toLocaleString()}` : ""}.` : usage.anchorIndex >= 0 ? `Counted by the model runtime through your last reply, plus an estimate for ${usage.estimatedMessages} message${usage.estimatedMessages === 1 ? "" : "s"} added since (about ${usage.charsPerToken.toFixed(1)} characters per token, learned from this thread).` : `No turn in this thread has been counted by the model runtime yet — a first estimate from the text (about ${usage.charsPerToken.toFixed(1)} characters per token).`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-meta leading-relaxed text-muted",
					children: "The send preflight measures the full request — prompts, fetched pages and your new message — not just this thread. A small thread can still sit near a small model's send ceiling; a refusal names both numbers."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-meta leading-relaxed text-muted",
					children: [
						capacity.source === "measured" ? capacity.confidence === "verified" ? `Measured on this device by the stress test, and verified against the installed model.` : `Measured by a stress test, but not verified against the model installed now.` : capacity.source === "category" ? `No stress test for this model — using its parameter-class ceiling.` : capacity.source === "configured" ? `Configured capacity for this model.` : `No measurement yet — planning against a conservative default.`,
						" ",
						optimizeTrigger.capped ? `Optimization starts at ${optimizeTrigger.effectiveWindowPercent}% — the most this window can send (${optimizeAt}% configured).` : `Optimization starts at ${optimizeAt}%.`
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-2 h-0.5 w-full overflow-hidden rounded-full bg-bg",
					"aria-hidden": "true",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: cn("h-full", crowded ? "bg-accent" : "bg-signal"),
						style: { width: `${Math.max(usage.percent, 2)}%` }
					})
				}),
				archive.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 border-t border-border pt-2.5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "flex w-full items-center justify-between gap-2 text-left text-xs text-fg",
							"aria-expanded": showArchive,
							onClick: () => setShowArchive((value) => !value),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
								"Kept for later (",
								archive.length,
								")"
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, {
								className: cn("size-3.5 shrink-0 text-muted transition-transform", showArchive && "rotate-180"),
								"aria-hidden": "true"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-meta leading-relaxed text-muted",
							children: "Notes for material optimization took out of the request, so the detail is still findable. These notes are not sent to the model."
						}),
						showArchive ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-1.5 flex max-h-48 flex-col gap-1.5 overflow-y-auto",
							children: archive.map((note, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "rounded-md bg-surface-2 px-2 py-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "readout text-meta uppercase text-muted",
									children: [
										note.role,
										" · ",
										note.reason,
										" · ",
										note.chars.toLocaleString(),
										" chars"
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-0.5 text-meta leading-snug text-fg/80",
									children: note.excerpt
								})]
							}, `${note.at}-${index}`))
						}) : null
					]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex flex-col gap-1.5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "inline-flex items-center gap-2 rounded-md bg-surface-2 px-2.5 py-2 text-left text-xs text-fg shadow-[0_0_0_1px_var(--color-border)] hover:bg-user disabled:opacity-50",
							disabled: !canCompress || streaming,
							title: canCompress ? "Summarize older turns into the local context summary" : "A compression needs at least 4 messages",
							onClick: onCompress,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minimize2, {
								className: "size-3.5 shrink-0 text-accent",
								"aria-hidden": "true"
							}), "Collapse older context"]
						}),
						confirmCompress ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-md bg-surface-2 p-2.5 shadow-[0_0_0_1px_var(--color-border)]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-meta leading-relaxed text-fg/90",
								children: "Compress older turns into a local context summary? Recent turns stay visible, and future replies use the summary instead of the older text. The visible thread is not deleted."
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 flex gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "rounded-md bg-surface px-2.5 py-1.5 text-xs text-fg shadow-[0_0_0_1px_var(--color-border)] hover:bg-user",
									onClick: commitCompress,
									children: "Compress"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "rounded-md bg-surface px-2.5 py-1.5 text-xs text-muted shadow-[0_0_0_1px_var(--color-border)] hover:bg-user hover:text-fg",
									onClick: () => setConfirmCompress(false),
									children: "Cancel"
								})]
							})]
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "inline-flex items-center gap-2 rounded-md bg-surface-2 px-2.5 py-2 text-left text-xs text-fg shadow-[0_0_0_1px_var(--color-border)] hover:bg-user",
							onClick: onExport,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layers, {
								className: "size-3.5 shrink-0 text-accent",
								"aria-hidden": "true"
							}), "Receive markdown"]
						})
					]
				}),
				exported ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-2.5 border-t border-border pt-2.5",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MarkdownExportViewer, {
						name: exported.name,
						markdown: exported.markdown
					})
				}) : null,
				streaming ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-meta text-muted/80",
					children: "Collapse is unavailable while Oqe is generating."
				}) : null
			]
		}) : null]
	});
}
function formatBytes$1(size) {
	if (size < 1024) return `${size} B`;
	if (size < 1048576) return `${Math.round(size / 1024)} KB`;
	return `${(size / 1048576).toFixed(1)} MB`;
}
function mergeSpeech(prev, incoming, isFinal) {
	const base = prev.replace(/[^\S\n]+$/g, "");
	if (!incoming.trim()) return prev;
	if (!isFinal) {
		const withoutInterim = base.replace(/\u200b.*$/s, "");
		return `${withoutInterim}${withoutInterim && !withoutInterim.endsWith(" ") ? " " : ""}\u200b${incoming}`;
	}
	const withoutInterim = base.replace(/\u200b.*$/s, "");
	return `${withoutInterim}${withoutInterim && !withoutInterim.endsWith(" ") ? " " : ""}${incoming}`;
}
/**
* New-chat empty state.
*
* V10.6 — the room is the character and nothing else. The previous version
* carried a headline, a promise sentence, four suggested questions and a line
* explaining what a suggestion does; the reader asked for all of it gone, and
* they were right: none of it was information. It was the interface describing
* itself, which is exactly what made the app read like a template.
*
* What is left is the one lit object, centred, alive — eyes on the pointer —
* and, underneath, the composer. The pinned status line just above the composer
* already reports the real state (local or cloud, the model, whether anything is
* resident), so repeating it here would only be a second copy of the same facts.
*
* V10.8 — when the first message is sent, this whole block unmounts and the
* character is seen to MOVE into the send control instead of blinking out of
* existence here and appearing there. The measurement that makes that possible
* is taken by the composer at the moment of the send, while this block is still
* on screen (see src/lib/orb-morph.ts).
*
* The single exception is a genuine failure: when the local setup cannot answer
* a message at all, that is not explanation, it is the reason nothing will
* happen — so it is stated once, in the interface's voice, with the one action
* that fixes it.
*
* V10.5 — two things were wrong with that exception, and both are fixed here:
*
*   1. THE FIX WAS A BUTTON. "Settings" was a `<button>` calling `navigate`, so
*      a reader could not middle-click it, could not open it in a new tab, and
*      got no link affordances from the browser. It navigates, so it is a
*      `<Link>`.
*   2. IT SAID NOTHING ABOUT THE OUTCOME. "Settings" names a place; "Open
*      settings" names what happens when you use it.
*
* The reason is also announced now: it is set with `role="status"`, so a reader
* using a screen reader learns that the setup is what is blocking them instead
* of only finding the orb sitting there.
*/
function EmptyState() {
	const settings = useAppStore((s) => s.settings);
	const connection = useAppStore((s) => s.connection);
	const needsConnection = !isConnectionConfigured(settings);
	const ollamaUnavailable = settings.mode === "local" && connection.kind === "error";
	const noModel = !settings.model.trim();
	const gaze = usePointerGaze();
	const blocked = ollamaUnavailable ? {
		text: "Ollama is not reachable",
		tone: "text-danger"
	} : noModel ? {
		text: "No model selected",
		tone: "text-warn"
	} : needsConnection ? {
		text: "No connection set up yet",
		tone: "text-warn"
	} : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full min-h-[58vh] w-full flex-col items-center justify-center px-4 pb-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "hero-orb",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OqeCharacter, {
				className: "size-40 sm:size-48",
				gaze,
				state: ollamaUnavailable ? "error" : noModel ? "offline" : "idle"
			})
		}), blocked ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-12 flex items-center gap-3 text-sm",
			role: "status",
			"aria-live": "polite",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: blocked.tone,
				children: blocked.text
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/settings",
				className: "rounded-sm text-muted underline underline-offset-4 transition-colors hover:text-fg focus-visible:text-fg",
				children: "Open settings"
			})]
		}) : null]
	});
}
var components = {
	a({ href, children }) {
		if (!isSafeHref(href)) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children });
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
			href,
			target: "_blank",
			rel: "noopener noreferrer",
			children
		});
	},
	img() {
		return null;
	},
	h1({ children }) {
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children });
	},
	table({ children }) {
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "overflow-x-auto",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("table", { children })
		});
	}
};
/**
* V7.9.2 — markdown rendering, kept cheap while a reply streams.
*
* Parsing a message with remark-gfm is the most expensive thing in a chat
* render, and it used to run for EVERY message on EVERY token — which is what
* made the thread stutter badly the moment you scrolled during a response.
* Two guards fix that without changing what is shown:
*
*  - `memo` on the same `text` never re-parses at all, so a settled message
*    costs nothing and only the message that is actually streaming is parsed.
*  - `useDeferredValue` makes the parse a non-urgent render. Scrolling, typing,
*    and the rest of the UI stay responsive; the markdown catches up a beat
*    later. It is the same text, just rendered at lower priority — the final
*    output is identical.
*/
var MarkdownView = (0, import_react.memo)(function MarkdownView({ text }) {
	const deferredText = (0, import_react.useDeferredValue)(text);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "md",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Markdown, {
			remarkPlugins: [remarkGfm],
			components,
			children: deferredText
		})
	});
});
/** 1, 2, 2.5, 5, 10 × 10^k — the steps a reader recognises on an axis. */
function niceStep(raw) {
	const magnitude = Math.abs(raw);
	if (!Number.isFinite(magnitude) || magnitude === 0) return 1;
	const base = Math.pow(10, Math.floor(Math.log10(magnitude)));
	const normalised = magnitude / base;
	return (normalised <= 1 ? 1 : normalised <= 2 ? 2 : normalised <= 2.5 ? 2.5 : normalised <= 5 ? 5 : 10) * base;
}
/**
* The y-range for a chart, or null when the reply supplied no numeric value at all
* (all points missing) — the caller then shows the "no values" state rather than an
* empty axis with invented numbers.
*/
function chartDomain(points, kind) {
	const values = points.map((point) => point.value).filter((value) => value !== null);
	if (values.length === 0) return null;
	const dataMin = Math.min(...values);
	const dataMax = Math.max(...values);
	if (kind === "bar") {
		const min = Math.min(0, dataMin);
		const max = Math.max(0, dataMax);
		return min === max ? {
			min: 0,
			max: 1
		} : {
			min,
			max
		};
	}
	if (dataMin === dataMax) {
		const pad = Math.abs(dataMin) > 0 ? Math.abs(dataMin) * .1 : 1;
		return {
			min: dataMin - pad,
			max: dataMax + pad
		};
	}
	const pad = (dataMax - dataMin) * .08;
	return {
		min: dataMin - pad,
		max: dataMax + pad
	};
}
/** Axis ticks covering the domain, including zero when zero is in range. */
function chartTicks(domain, count = 4) {
	const span = domain.max - domain.min;
	if (!Number.isFinite(span) || span <= 0) return [domain.min];
	const step = niceStep(span / Math.max(1, count));
	const start = Math.ceil(domain.min / step) * step;
	const ticks = [];
	for (let value = start; value <= domain.max + step * .001; value += step) {
		ticks.push(Math.abs(value) < step / 1e6 ? 0 : Number(value.toFixed(10)));
		if (ticks.length > 12) break;
	}
	if (ticks.length === 0) ticks.push(domain.min);
	return ticks;
}
function chartSeries(points) {
	const runs = [];
	const gaps = [];
	let current = [];
	points.forEach((point, index) => {
		if (point.value === null) {
			gaps.push(index);
			if (current.length > 0) runs.push(current);
			current = [];
			return;
		}
		current.push(index);
	});
	if (current.length > 0) runs.push(current);
	return {
		runs,
		gaps
	};
}
/** Group thousands deterministically (no locale, so a test can assert the string). */
function groupThousands(text) {
	const [whole, fraction] = text.split(".");
	const grouped = whole.replace(/\B(?=(\d{3})+(?!\d))/g, " ");
	return fraction ? `${grouped}.${fraction}` : grouped;
}
function formatChartValue(value, unit) {
	const rounded = Math.abs(value) >= 100 ? Math.round(value) : Math.round(value * 100) / 100;
	const text = groupThousands(String(rounded));
	return unit ? `${text} ${unit}` : text;
}
/**
* What the numbers actually are, phrased so a reader can tell the reply's data
* from this build's arithmetic.
*/
function chartFacts(points, unit) {
	const values = points.map((point) => point.value).filter((value) => value !== null);
	const missing = points.length - values.length;
	const min = values.length > 0 ? Math.min(...values) : null;
	const max = values.length > 0 ? Math.max(...values) : null;
	const parts = [];
	if (values.length === 0) parts.push("No values were supplied, so there is nothing to draw.");
	else parts.push(`${values.length} of ${points.length} points supplied a value (range ${formatChartValue(min, unit)} to ${formatChartValue(max, unit)} — computed here).`);
	if (missing > 0) parts.push(`${missing} point${missing === 1 ? " has" : "s have"} no value and are drawn as a gap, not as zero.`);
	return {
		supplied: values.length,
		missing,
		min,
		max,
		text: parts.join(" ")
	};
}
/**
* Prompt 39 — the chart renderer.
*
* A real chart now: an axis with ticks, a unit where the reply supplied one, a
* zero line for bars, and a gap wherever a value was not supplied. The previous
* bar list could not show a negative value honestly, had no axis and had no
* concept of a missing point — every number became a bar, so "no data" and "zero"
* looked identical.
*
* THREE THINGS IT REFUSES TO DO:
*  - draw a missing value as zero (the point becomes a gap, and the caption says
*    how many points had no value);
*  - bridge a gap in a line (each run of consecutive values is its own polyline);
*  - claim its own arithmetic came from the reply (the caption says the range and
*    the scale are computed here).
*
* ACCESSIBILITY. The SVG carries a title and a description; underneath it, the
* same numbers exist as a real table (behind "Show the numbers"), which is also
* the answer for anyone who cannot use the axis. Nothing here is hover-only.
*/
var VIEW_WIDTH = 360;
var VIEW_HEIGHT = 188;
var PLOT = {
	left: 46,
	right: 352,
	top: 14,
	bottom: 142
};
function xFor(index, count) {
	if (count <= 1) return (PLOT.left + PLOT.right) / 2;
	const span = PLOT.right - PLOT.left;
	return PLOT.left + span * index / (count - 1);
}
function barWidth(count) {
	const span = PLOT.right - PLOT.left;
	return Math.max(4, Math.min(26, span / Math.max(1, count) * .62));
}
function OutputChart({ block }) {
	const titleId = (0, import_react.useId)();
	const descId = (0, import_react.useId)();
	const facts = (0, import_react.useMemo)(() => chartFacts(block.points, block.unit), [block]);
	const domain = (0, import_react.useMemo)(() => chartDomain(block.points, block.kind), [block]);
	const ticks = (0, import_react.useMemo)(() => domain ? chartTicks(domain, 4) : [], [domain]);
	const series = (0, import_react.useMemo)(() => chartSeries(block.points), [block]);
	if (block.points.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "my-3 rounded-md bg-well px-3 py-2",
		role: "status",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-meta text-muted",
			children: "This chart has no data, so nothing is drawn."
		})
	});
	if (block.points.length > 24) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "my-3 rounded-md bg-well px-3 py-2",
		role: "status",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-meta text-muted",
			children: [
				"This chart has ",
				block.points.length,
				" points; at most ",
				24,
				" can be drawn here."
			]
		})
	});
	const valueToY = (value) => {
		if (!domain) return PLOT.bottom;
		const span = domain.max - domain.min || 1;
		return PLOT.bottom - (value - domain.min) / span * (PLOT.bottom - PLOT.top);
	};
	const baseline = domain && domain.min <= 0 && domain.max >= 0 ? valueToY(0) : null;
	const labelStride = Math.max(1, Math.ceil(block.points.length / 7));
	const pointsTable = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
		className: "w-full border-collapse text-meta",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("caption", {
				className: "sr-only",
				children: [block.caption ? `${block.caption}. ` : "", "Chart values as supplied by the reply."]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
				scope: "col",
				className: "px-2 py-1 text-left font-medium text-muted",
				children: "Label"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("th", {
				scope: "col",
				className: "px-2 py-1 text-right font-medium text-muted",
				children: ["Value", block.unit ? ` (${block.unit})` : ""]
			})] }) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: block.points.map((point, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
				className: "border-t border-border/60",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
					scope: "row",
					className: "px-2 py-1 text-left font-normal text-fg",
					children: point.label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: "px-2 py-1 text-right font-mono text-fg",
					children: point.value === null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						"aria-hidden": "true",
						children: "—"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "sr-only",
						children: "no value supplied"
					})] }) : formatChartValue(point.value, block.unit)
				})]
			}, `${point.label}-${index}`)) })
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
		className: "my-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-md bg-surface px-3 py-2.5 shadow-[0_0_0_1px_var(--color-border)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "readout text-faint",
					children: [block.kind === "bar" ? "Bar chart" : "Line chart", block.unit ? ` · ${block.unit}` : ""]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
					viewBox: `0 0 ${VIEW_WIDTH} ${VIEW_HEIGHT}`,
					className: "mt-1 block h-auto w-full",
					role: "img",
					"aria-labelledby": titleId,
					"aria-describedby": descId,
					preserveAspectRatio: "xMidYMid meet",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("title", {
							id: titleId,
							children: block.caption ?? "Chart"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("desc", {
							id: descId,
							children: [
								facts.text,
								" Values: ",
								block.points.map((point) => `${point.label} ${point.value === null ? "no value" : point.value}`).join("; "),
								"."
							]
						}),
						ticks.map((tick) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
							x1: PLOT.left,
							x2: PLOT.right,
							y1: valueToY(tick),
							y2: valueToY(tick),
							stroke: "var(--color-border)",
							strokeOpacity: .5,
							strokeWidth: 1
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
							x: PLOT.left - 6,
							y: valueToY(tick),
							textAnchor: "end",
							dominantBaseline: "middle",
							fontSize: 9,
							fill: "var(--color-muted)",
							children: formatChartValue(tick)
						})] }, tick)),
						baseline !== null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
							x1: PLOT.left,
							x2: PLOT.right,
							y1: baseline,
							y2: baseline,
							stroke: "var(--color-border)",
							strokeWidth: 1.25
						}) : null,
						block.kind === "bar" ? block.points.map((point, index) => {
							const x = xFor(index, block.points.length);
							const width = barWidth(block.points.length);
							if (point.value === null) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("g", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
								cx: x,
								cy: baseline ?? PLOT.bottom,
								r: 3,
								fill: "none",
								stroke: "var(--color-muted)",
								strokeDasharray: "2 2",
								strokeWidth: 1,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("title", { children: `${point.label}: no value supplied` })
							}) }, `${point.label}-${index}`);
							const y = valueToY(point.value);
							const zero = baseline ?? PLOT.bottom;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
								x: x - width / 2,
								y: Math.min(y, zero),
								width,
								height: Math.max(1, Math.abs(zero - y)),
								rx: 2,
								fill: "var(--color-accent)",
								fillOpacity: .72,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("title", { children: `${point.label}: ${formatChartValue(point.value, block.unit)}` })
							}, `${point.label}-${index}`);
						}) : series.runs.map((run, runIndex) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [run.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polyline", {
							fill: "none",
							stroke: "var(--color-accent)",
							strokeWidth: 2,
							strokeLinejoin: "round",
							points: run.map((index) => `${xFor(index, block.points.length)},${valueToY(block.points[index].value)}`).join(" ")
						}) : null, run.map((index) => {
							const point = block.points[index];
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
								cx: xFor(index, block.points.length),
								cy: valueToY(point.value),
								r: run.length === 1 ? 3 : 2.5,
								fill: "var(--color-accent)",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("title", { children: `${point.label}: ${formatChartValue(point.value, block.unit)}` })
							}, `${point.label}-${index}`);
						})] }, `run-${runIndex}`)),
						block.points.map((point, index) => index % labelStride === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("text", {
							x: xFor(index, block.points.length),
							y: PLOT.bottom + 14,
							textAnchor: "middle",
							fontSize: 9,
							fill: "var(--color-muted)",
							children: [point.label.length > 12 ? `${point.label.slice(0, 11)}…` : point.label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("title", { children: point.label })]
						}, `label-${index}`) : null)
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
					className: "mt-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
						className: "cursor-pointer text-meta text-faint",
						children: "Show the numbers"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-1 overflow-x-auto",
						children: pointsTable
					})]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figcaption", {
			className: "mt-1 text-meta leading-relaxed text-faint",
			children: [block.caption ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "block",
				children: block.caption
			}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "block",
				children: [facts.text, " The axis scale is computed by Oqe from those supplied values."]
			})]
		})]
	});
}
/**
* Prompt 43 — the browser's side of the artifact store, for READER-INITIATED saves.
*
* WHY THIS EXISTS. Prompt 36 built the store and the route, but nothing in the app
* ever created an artifact — so the download half of the output system was
* unreachable, and "Download" could only ever answer "this file is no longer here".
* A code block, a diff, a log or a structured document can now be saved as a file,
* which is the deliberate user action the policy requires: the reader presses the
* button, the bytes came from the reply they are looking at, and the id is minted
* here rather than supplied by a model.
*
* WHAT IT CANNOT DO.
*
*  - No path, no URL and no filename of the reader's choosing: the name is derived
*    here (`suggestArtifactName`), checked again by the route and the store, and the
*    bytes on disk are named by the opaque id.
*  - No silent overwrite. The stored file is always `<id>.<ext>`; the name the
*    reader sees is metadata. If their browser already has a file with that name the
*    browser renames it, and this module says so rather than promising otherwise.
*  - No permanent storage by accident: a create is `transient` (24 h, swept), and
*    only the explicit "keep on this machine" action promotes it.
*  - No localStorage, no conversation row, no credential. The request carries the
*    bytes and nothing else, and every failure is returned as a sentence.
*
* DOM-free on purpose (fetch is injected) so the request and its validation are
* testable without a browser. The `<a download>` click that starts a download lives
* in the component, because a click is a UI concern.
*/
/** The one route artifacts are read and written through. */
var ARTIFACT_ROUTE = "/api/storage/artifacts";
/** The header every local write already requires. */
var ARTIFACT_WRITE_HEADER = "x-oqe-storage";
/** Where the bytes live, by opaque id. Nothing else is ever part of this URL. */
function artifactDownloadUrl(id) {
	return `${ARTIFACT_ROUTE}?id=${encodeURIComponent(id)}`;
}
function randomToken(bytes = 16) {
	const buffer = new Uint8Array(bytes);
	const webCrypto = globalThis.crypto;
	if (webCrypto && typeof webCrypto.getRandomValues === "function") webCrypto.getRandomValues(buffer);
	else for (let index = 0; index < buffer.length; index += 1) buffer[index] = Math.floor(Math.random() * 256);
	return Array.from(buffer, (byte) => byte.toString(16).padStart(2, "0")).join("");
}
/** A fresh opaque id in the one shape the store accepts. */
function newArtifactId() {
	return `art_${randomToken()}`;
}
/**
* UTF-8 text → base64, in chunks.
*
* `String.fromCharCode(...bytes)` on a 20 kB block is fine, but spreading a
* multi-megabyte array overflows the argument list, so the bytes are folded in
* chunks. The result is the plain base64 the route expects — never a data URL.
*/
function utf8ToBase64(text) {
	const bytes = new TextEncoder().encode(text);
	const chunk = 32768;
	let binary = "";
	for (let index = 0; index < bytes.length; index += chunk) binary += String.fromCharCode(...bytes.subarray(index, index + chunk));
	return btoa(binary);
}
/**
* Prompt 45 — bytes, not text.
*
* A mesh export is binary (STL is a header and 50-byte records, 3MF is a ZIP), so it needs
* its own encoder. `utf8ToBase64` would corrupt it by round-tripping through a JS string.
* Chunked for the same reason as above: spreading 3 MB of bytes into `fromCharCode`
* overflows the argument list.
*/
function bytesToBase64(bytes) {
	const chunk = 32768;
	let binary = "";
	for (let index = 0; index < bytes.length; index += chunk) binary += String.fromCharCode(...bytes.subarray(index, index + chunk));
	return btoa(binary);
}
var LANGUAGE_EXTENSIONS = {
	javascript: "js",
	typescript: "ts",
	python: "py",
	bash: "sh",
	json: "json",
	yaml: "yaml",
	html: "html",
	css: "css",
	sql: "sql",
	markdown: "md",
	md: "md",
	csv: "csv",
	txt: "txt",
	text: "txt",
	plain: "txt"
};
/**
* The extension a saved file gets. An unknown language is `txt` — the file is
* still the reader's text, it just does not claim to be a language this build does
* not know.
*/
function extensionFor(kind, language, format) {
	if (kind === "data") return format === "json" ? "json" : format === "yaml" ? "yaml" : "txt";
	if (kind === "source") return LANGUAGE_EXTENSIONS[(language ?? "").trim().toLowerCase()] ?? "txt";
	if (kind === "diff") return "diff";
	if (kind === "logs") return "log";
	if (kind === "markdown") return "md";
	if (kind === "csv") return "csv";
	return "txt";
}
/**
* The media type a saved text artifact is stored as.
*
* All four are on the store's allowlist. A diff, a log and source code are
* `text/plain` deliberately: they are text, and claiming `application/x-sh` for a
* shell snippet would invite the browser or the OS to treat it as a program.
*/
function mediaTypeFor(kind, format) {
	if (kind === "data" && format === "json") return "application/json";
	if (kind === "markdown") return "text/markdown";
	if (kind === "csv") return "text/csv";
	return "text/plain";
}
/**
* The name the reader sees and their browser receives.
*
* Always `oqe-<kind>[.<ext>]`: no separators, no leading dot, no control
* characters, no dependence on anything the model wrote. The store re-validates it,
* and the route refuses it if it is not a plain name — this function is the
* suggestion, not the authority.
*/
function suggestArtifactName(kind, language, format) {
	const extension = extensionFor(kind, language, format);
	const candidate = `${kind === "source" ? "oqe-snippet" : `oqe-${kind}`}.${extension}`;
	return safeArtifactName(candidate) ?? `oqe-${kind}.txt`;
}
function isWireArtifact(value) {
	if (typeof value !== "object" || value === null) return false;
	const rec = value;
	return isSafeArtifactId(rec.id) && typeof rec.name === "string" && typeof rec.mediaType === "string" && isArtifactMediaType(rec.mediaType) && typeof rec.bytes === "number" && Number.isFinite(rec.bytes) && rec.bytes > 0;
}
async function postJson(body, fetchImpl) {
	let response;
	try {
		response = await fetchImpl(ARTIFACT_ROUTE, {
			method: "POST",
			headers: {
				"content-type": "application/json",
				[ARTIFACT_WRITE_HEADER]: "1"
			},
			body: JSON.stringify(body)
		});
	} catch (error) {
		return {
			ok: false,
			reason: `The artifact store could not be reached (${error instanceof Error ? error.message : String(error)}).`
		};
	}
	let payload;
	try {
		payload = await response.json();
	} catch {
		return {
			ok: false,
			reason: `The artifact store answered ${response.status} without a readable body.`
		};
	}
	const record = typeof payload === "object" && payload !== null ? payload : {};
	if (!response.ok || record.ok !== true) return {
		ok: false,
		reason: typeof record.error === "string" && record.error ? record.error : `The artifact store answered ${response.status}.`
	};
	if (!isWireArtifact(record.artifact)) return {
		ok: false,
		reason: "The artifact store answered with a record this build cannot use."
	};
	return {
		ok: true,
		artifact: record.artifact
	};
}
/**
* Store the text of a technical block as a temporary artifact.
*
* The size check runs BEFORE the bytes are encoded, so an 8 MB snippet is refused
* in constant time instead of being base64'd and then refused by the route.
*/
async function createTextArtifact(input) {
	const fetchImpl = input.fetchImpl ?? globalThis.fetch;
	if (!fetchImpl) return {
		ok: false,
		reason: "This page cannot reach the artifact store."
	};
	const text = input.text;
	if (!text.trim()) return {
		ok: false,
		reason: "There is nothing in this block to save."
	};
	const mediaType = mediaTypeFor(input.kind, input.format);
	if (!ARTIFACT_MEDIA_TYPES.includes(mediaType)) return {
		ok: false,
		reason: "That kind of file is not one this build stores."
	};
	const name = input.name ?? suggestArtifactName(input.kind, input.language, input.format);
	if (!safeArtifactName(name)) return {
		ok: false,
		reason: "That file name is not a plain name this build can save."
	};
	const byteLength = new TextEncoder().encode(text).length;
	if (byteLength > 8388608) return {
		ok: false,
		reason: `This block is ${byteLength} bytes; this build saves at most ${MAX_ARTIFACT_BYTES}.`
	};
	return postJson({
		mode: "create",
		id: newArtifactId(),
		name,
		mediaType,
		data: utf8ToBase64(text),
		...input.origin ? { origin: input.origin.slice(0, 200) } : {}
	}, fetchImpl);
}
/**
* Store generated BYTES as a temporary artifact.
*
* The same rules as `createTextArtifact`: a generated name, a media type from the store's
* allowlist, the local storage header, a size check before encoding — and it is still the
* reader's click that starts it. Used by the 3D viewer's export buttons; nothing else in
* this build produces binary output.
*/
async function createBinaryArtifact(input) {
	const fetchImpl = input.fetchImpl ?? globalThis.fetch;
	if (!fetchImpl) return {
		ok: false,
		reason: "This page cannot reach the artifact store."
	};
	if (input.bytes.length === 0) return {
		ok: false,
		reason: "There are no bytes to save."
	};
	if (input.bytes.length > 8388608) return {
		ok: false,
		reason: `This export is ${input.bytes.length.toLocaleString()} bytes; this build saves at most ${MAX_ARTIFACT_BYTES.toLocaleString()}.`
	};
	const mediaType = input.kind === "stl" ? "model/stl" : "model/3mf";
	if (!isArtifactMediaType(mediaType)) return {
		ok: false,
		reason: "That kind of file is not one this build stores."
	};
	const name = safeArtifactName(input.name ?? `oqe-model.${input.kind}`);
	if (!name) return {
		ok: false,
		reason: "That file name is not a plain name this build can save."
	};
	return postJson({
		mode: "create",
		id: newArtifactId(),
		name,
		mediaType,
		data: bytesToBase64(input.bytes),
		...input.origin ? { origin: input.origin.slice(0, 200) } : {}
	}, fetchImpl);
}
/**
* Promote a stored artifact from temporary to saved.
*
* It is a state change on this machine's copy — the expiry is dropped — and it is
* the only way a generated file outlives its cleanup window. Nothing moves on disk,
* and no new copy is written to the reader's Downloads folder.
*/
async function keepArtifactOnMachine(id, fetchImpl = globalThis.fetch) {
	if (!isSafeArtifactId(id)) return {
		ok: false,
		reason: "That is not an artifact id this build issues."
	};
	if (!fetchImpl) return {
		ok: false,
		reason: "This page cannot reach the artifact store."
	};
	return postJson({
		mode: "save",
		id
	}, fetchImpl);
}
var listCache = null;
/**
* Is this artifact still on this machine?
*
* A download that silently does nothing is the worst outcome for a `file` block, so
* the view asks first. The only read that answers "what exists" is the bounded
* metadata listing (the id read returns BYTES, which would mean pulling up to 8 MB
* just to find out), so the listing is reused for a few seconds across blocks in the
* same reply instead of being fetched once per file.
*
* "Missing" and "could not check" are kept apart: an expired file earns no download,
* while an unreachable store still leaves the reader the anchor, because the check
* failing is not proof the file is gone.
*/
async function lookupArtifact(id, options = {}) {
	if (!isSafeArtifactId(id)) return {
		ok: false,
		code: "missing",
		reason: "That is not an artifact id this build issues."
	};
	const fetchImpl = options.fetchImpl ?? globalThis.fetch;
	if (!fetchImpl) return {
		ok: false,
		code: "unreachable",
		reason: "This page cannot reach the artifact store."
	};
	const now = options.now ?? Date.now();
	if (!listCache || now - listCache.at >= 5e3) {
		let response;
		try {
			response = await fetchImpl(ARTIFACT_ROUTE, { method: "GET" });
		} catch {
			return {
				ok: false,
				code: "unreachable",
				reason: "The artifact store could not be reached."
			};
		}
		if (!response.ok) return {
			ok: false,
			code: "unreachable",
			reason: `The artifact store answered ${response.status}.`
		};
		let payload;
		try {
			payload = await response.json();
		} catch {
			return {
				ok: false,
				code: "unreachable",
				reason: "The artifact store sent no readable listing."
			};
		}
		const record = typeof payload === "object" && payload !== null ? payload : {};
		listCache = {
			at: now,
			artifacts: Array.isArray(record.artifacts) ? record.artifacts.filter(isWireArtifact) : []
		};
	}
	const found = listCache.artifacts.find((entry) => entry.id === id);
	if (!found) return {
		ok: false,
		code: "missing",
		reason: "This file is no longer on this machine."
	};
	return {
		ok: true,
		artifact: found
	};
}
/**
* What a download actually is, in the words the UI shows.
*
* The distinction matters: Oqe stores a copy under its own data directory, and the
* browser separately copies it wherever the reader's download settings say. Saying
* "saved to your computer" would be true and useless; saying "saved to Documents"
* would be a lie, because Oqe never learns that path.
*/
function describeDownload() {
	return "Your browser saves a copy to its download folder and decides the name if one already exists. Oqe does not write to that folder.";
}
function describeStoredCopy(state) {
	return state === "saved" ? "Kept on this machine until you delete it." : "Temporary — this build removes it after its cleanup window unless you keep it.";
}
var MAX_HIGHLIGHT_LINES = 1200;
/** The label shown in the view header, so a reader knows what was understood. */
var LANGUAGE_LABELS = {
	json: "JSON",
	javascript: "JavaScript",
	typescript: "TypeScript",
	python: "Python",
	bash: "Shell",
	plain: "Text"
};
/**
* Map whatever the reply wrote to a language this build highlights.
*
* Aliases are matched exactly (after trimming and lowercasing) rather than by
* substring, so `notjson` is text and `JSON` is JSON. An unknown language is not
* an error: it is `plain`.
*/
function normalizeLanguage(value) {
	const raw = (value ?? "").trim().toLowerCase();
	if (!raw) return "plain";
	switch (raw) {
		case "json":
		case "jsonc":
		case "json5": return "json";
		case "js":
		case "jsx":
		case "mjs":
		case "cjs":
		case "javascript":
		case "node": return "javascript";
		case "ts":
		case "tsx":
		case "mts":
		case "cts":
		case "typescript": return "typescript";
		case "py":
		case "py3":
		case "python":
		case "python3": return "python";
		case "sh":
		case "bash":
		case "shell":
		case "zsh":
		case "console":
		case "terminal": return "bash";
		default: return "plain";
	}
}
var JS_KEYWORDS = /* @__PURE__ */ new Set([
	"abstract",
	"as",
	"async",
	"await",
	"break",
	"case",
	"catch",
	"class",
	"const",
	"continue",
	"declare",
	"default",
	"delete",
	"do",
	"else",
	"enum",
	"export",
	"extends",
	"finally",
	"for",
	"from",
	"function",
	"get",
	"if",
	"implements",
	"import",
	"in",
	"instanceof",
	"interface",
	"keyof",
	"let",
	"namespace",
	"new",
	"of",
	"private",
	"protected",
	"public",
	"readonly",
	"return",
	"satisfies",
	"set",
	"static",
	"super",
	"switch",
	"this",
	"throw",
	"try",
	"type",
	"typeof",
	"var",
	"void",
	"while",
	"with",
	"yield"
]);
var SPECS = {
	json: {
		lineComment: [],
		strings: ["\""],
		keywords: /* @__PURE__ */ new Set(),
		literals: /* @__PURE__ */ new Set([
			"true",
			"false",
			"null"
		]),
		jsonStyle: true
	},
	javascript: {
		lineComment: ["//"],
		blockComment: {
			open: "/*",
			close: "*/"
		},
		strings: [
			"'",
			"\"",
			"`"
		],
		keywords: JS_KEYWORDS,
		literals: /* @__PURE__ */ new Set([
			"true",
			"false",
			"null",
			"undefined",
			"NaN",
			"Infinity"
		])
	},
	typescript: {
		lineComment: ["//"],
		blockComment: {
			open: "/*",
			close: "*/"
		},
		strings: [
			"'",
			"\"",
			"`"
		],
		keywords: JS_KEYWORDS,
		literals: /* @__PURE__ */ new Set([
			"true",
			"false",
			"null",
			"undefined",
			"NaN",
			"Infinity"
		])
	},
	python: {
		lineComment: ["#"],
		strings: ["'", "\""],
		keywords: /* @__PURE__ */ new Set([
			"and",
			"as",
			"assert",
			"async",
			"await",
			"break",
			"class",
			"continue",
			"def",
			"del",
			"elif",
			"else",
			"except",
			"finally",
			"for",
			"from",
			"global",
			"if",
			"import",
			"in",
			"is",
			"lambda",
			"match",
			"nonlocal",
			"not",
			"or",
			"pass",
			"raise",
			"return",
			"try",
			"while",
			"with",
			"yield"
		]),
		literals: /* @__PURE__ */ new Set([
			"True",
			"False",
			"None"
		])
	},
	bash: {
		lineComment: ["#"],
		strings: ["'", "\""],
		keywords: /* @__PURE__ */ new Set([
			"alias",
			"case",
			"cd",
			"do",
			"done",
			"echo",
			"elif",
			"else",
			"esac",
			"exit",
			"export",
			"fi",
			"for",
			"function",
			"if",
			"in",
			"local",
			"read",
			"return",
			"set",
			"source",
			"then",
			"unset",
			"until",
			"while"
		]),
		literals: /* @__PURE__ */ new Set(["true", "false"]),
		hashNeedsBoundary: true
	}
};
var IDENT_START = /[A-Za-z_$]/;
var IDENT_PART = /[A-Za-z0-9_$]/;
var DIGIT = /[0-9]/;
var NUMBER_PART = /[0-9a-fA-FxXoObB._n]/;
function isCommentStart(line, index, spec) {
	for (const prefix of spec.lineComment) {
		if (!line.startsWith(prefix, index)) continue;
		if (prefix === "#" && spec.hashNeedsBoundary) {
			const previous = index === 0 ? "" : line[index - 1];
			if (previous && !/\s/.test(previous)) continue;
		}
		return prefix;
	}
	return null;
}
function readString(line, start, quote) {
	let index = start + 1;
	while (index < line.length) {
		const char = line[index];
		if (char === "\\") {
			index += 2;
			continue;
		}
		if (char === quote) {
			index += 1;
			return {
				text: line.slice(start, index),
				end: index
			};
		}
		index += 1;
	}
	return {
		text: line.slice(start),
		end: line.length
	};
}
function readNumber(line, start) {
	let index = start;
	while (index < line.length && NUMBER_PART.test(line[index])) index += 1;
	if (index < line.length && (line[index] === "+" || line[index] === "-")) {
		const previous = line[index - 1];
		if (previous === "e" || previous === "E") {
			index += 1;
			while (index < line.length && DIGIT.test(line[index])) index += 1;
		}
	}
	return index;
}
function tokenizeLine(line, spec, state) {
	const out = [];
	let plain = "";
	let index = 0;
	const flush = () => {
		if (plain) {
			out.push({
				text: plain,
				kind: "plain"
			});
			plain = "";
		}
	};
	const push = (text, kind) => {
		flush();
		out.push({
			text,
			kind
		});
	};
	while (index < line.length) {
		if (state.blockComment) {
			const close = spec.blockComment?.close ?? "*/";
			const end = line.indexOf(close, index);
			if (end < 0) {
				push(line.slice(index), "comment");
				return out;
			}
			push(line.slice(index, end + close.length), "comment");
			index = end + close.length;
			state.blockComment = false;
			continue;
		}
		if (spec.blockComment && line.startsWith(spec.blockComment.open, index)) {
			const end = line.indexOf(spec.blockComment.close, index + spec.blockComment.open.length);
			if (end < 0) {
				push(line.slice(index), "comment");
				state.blockComment = true;
				return out;
			}
			const stop = end + spec.blockComment.close.length;
			push(line.slice(index, stop), "comment");
			index = stop;
			continue;
		}
		if (isCommentStart(line, index, spec)) {
			push(line.slice(index), "comment");
			return out;
		}
		const char = line[index];
		if (spec.strings.includes(char)) {
			const string = readString(line, index, char);
			let kind = "string";
			if (spec.jsonStyle) {
				let look = string.end;
				while (look < line.length && /\s/.test(line[look])) look += 1;
				if (line[look] === ":") kind = "property";
			}
			push(string.text, kind);
			index = string.end;
			continue;
		}
		if (DIGIT.test(char)) {
			const end = readNumber(line, index);
			push(line.slice(index, end), "number");
			index = end;
			continue;
		}
		if (IDENT_START.test(char)) {
			let end = index + 1;
			while (end < line.length && IDENT_PART.test(line[end])) end += 1;
			const word = line.slice(index, end);
			const kind = spec.keywords.has(word) ? "keyword" : spec.literals.has(word) ? "literal" : "plain";
			if (kind === "plain") plain += word;
			else push(word, kind);
			index = end;
			continue;
		}
		if ("{}()[],:;.".includes(char)) {
			push(char, "punct");
			index += 1;
			continue;
		}
		plain += char;
		index += 1;
	}
	flush();
	return out;
}
/**
* Tokenise a code block.
*
* The line endings are normalised (`\r\n` → `\n`) but nothing else is changed:
* indentation, trailing spaces and blank lines are content in a code block, and a
* highlighter that tidied them would be editing the reply.
*/
function highlight(code, language) {
	const normalized = code.replace(/\r\n/g, "\n").replace(/\r/g, "\n");
	const lines = normalized.split("\n").slice(0, MAX_HIGHLIGHT_LINES);
	const resolved = normalizeLanguage(language);
	if (resolved === "plain" || normalized.length > 24e3) return lines.map((line) => line ? [{
		text: line,
		kind: "plain"
	}] : []);
	const spec = SPECS[resolved];
	const state = { blockComment: false };
	return lines.map((line) => {
		if (!line) return [];
		return tokenizeLine(line, spec, state);
	});
}
/** True when this build actually coloured the text, for the view's own label. */
function isHighlighted(language, code) {
	return normalizeLanguage(language) !== "plain" && code.length <= 24e3;
}
function diffStats(lines) {
	let added = 0;
	let removed = 0;
	let context = 0;
	for (const line of lines) if (line.kind === "add") added += 1;
	else if (line.kind === "remove") removed += 1;
	else context += 1;
	return {
		added,
		removed,
		context
	};
}
/**
* The sentence above a diff.
*
* It always says the change is PROPOSED, because a diff drawn in a reply is a
* description: nothing in this build writes a patch to a file, and a reader who
* sees `+` lines must not conclude that they are now in their code.
*/
function describeDiff(lines) {
	const { added, removed } = diffStats(lines);
	return `${`${added} line${added === 1 ? "" : "s"} added`}, ${`${removed} line${removed === 1 ? "" : "s"} removed`}. Proposed — not applied to any file.`;
}
function logCounts(lines) {
	const counts = {
		debug: 0,
		info: 0,
		warn: 0,
		error: 0,
		unlabelled: 0
	};
	for (const line of lines) if (line.level) counts[line.level] += 1;
	else counts.unlabelled += 1;
	return counts;
}
/** Which severities actually appear, in the order they should be shown. */
function presentLevels(counts) {
	return [
		"error",
		"warn",
		"info",
		"debug"
	].filter((level) => counts[level] > 0);
}
function describeLogs(lines, truncated = false) {
	const counts = logCounts(lines);
	const total = lines.length;
	const parts = [`${total} line${total === 1 ? "" : "s"}`];
	for (const level of presentLevels(counts)) parts.push(`${counts[level]} ${level}`);
	if (counts.unlabelled > 0) parts.push(`${counts.unlabelled} unlabelled`);
	return `${parts.join(" · ")}${truncated ? " · the reply says it omitted lines" : ""}`;
}
function take(budget, depth) {
	if (depth > 20) {
		budget.truncated = true;
		return false;
	}
	if (budget.nodes >= 2e3) {
		budget.truncated = true;
		return false;
	}
	budget.nodes += 1;
	return true;
}
function stringNode(value) {
	if (value.length <= 400) return {
		kind: "string",
		value
	};
	return {
		kind: "string",
		value: value.slice(0, 400),
		truncated: true
	};
}
/** JSON value → drawer node. Depth and node count are enforced here, not by the caller. */
function jsonNode(value, depth, budget) {
	if (!take(budget, depth)) return { kind: "omitted" };
	if (value === null) return { kind: "null" };
	if (typeof value === "string") return stringNode(value);
	if (typeof value === "number") return Number.isFinite(value) ? {
		kind: "number",
		value
	} : { kind: "null" };
	if (typeof value === "boolean") return {
		kind: "boolean",
		value
	};
	if (Array.isArray(value)) {
		const items = [];
		for (const item of value) {
			if (budget.nodes >= 2e3) {
				budget.truncated = true;
				items.push({ kind: "omitted" });
				break;
			}
			items.push(jsonNode(item, depth + 1, budget));
		}
		return {
			kind: "array",
			items,
			...budget.truncated ? { truncated: true } : {}
		};
	}
	if (typeof value === "object") {
		const entries = [];
		for (const [key, item] of Object.entries(value)) {
			if (budget.nodes >= 2e3) {
				budget.truncated = true;
				entries.push({
					key,
					value: { kind: "omitted" }
				});
				break;
			}
			const safeKey = key.length <= 400 ? key : key.slice(0, 400);
			entries.push({
				key: safeKey,
				value: jsonNode(item, depth + 1, budget)
			});
		}
		return {
			kind: "object",
			entries,
			...budget.truncated ? { truncated: true } : {}
		};
	}
	return { kind: "null" };
}
var REFUSED_STARTS = [
	["---", "document markers (---) are not supported by this view"],
	["...", "document markers (...) are not supported by this view"],
	["%", "directives (%) are not supported by this view"],
	["?", "complex keys (?) are not supported by this view"]
];
function refuse(reason) {
	return {
		ok: false,
		reason
	};
}
/** Remove a trailing ` # comment` that is not inside a quoted string. */
function stripComment(value) {
	let quote = "";
	for (let index = 0; index < value.length; index += 1) {
		const char = value[index];
		if (quote) {
			if (char === "\\" && quote === "\"") {
				index += 1;
				continue;
			}
			if (char === quote) quote = "";
			continue;
		}
		if (char === "\"" || char === "'") {
			quote = char;
			continue;
		}
		if (char === "#" && index > 0 && /\s/.test(value[index - 1])) return value.slice(0, index);
	}
	return value;
}
/** The index of the `:` that separates a key from its value, or -1. */
function keyColon(content) {
	let quote = "";
	for (let index = 0; index < content.length; index += 1) {
		const char = content[index];
		if (quote) {
			if (char === "\\" && quote === "\"") {
				index += 1;
				continue;
			}
			if (char === quote) quote = "";
			continue;
		}
		if (char === "\"" || char === "'") {
			quote = char;
			continue;
		}
		if (char === "#" && index > 0 && /\s/.test(content[index - 1])) return -1;
		if (char === ":") {
			const next = content[index + 1];
			if (next === void 0 || next === " ") return index;
		}
	}
	return -1;
}
function scalarNode(raw, line) {
	const value = stripComment(raw).trim();
	if (!value) return {
		ok: true,
		node: { kind: "null" }
	};
	if (value.startsWith("|") || value.startsWith(">")) return refuse(`line ${line}: block scalars (| and >) are not supported by this view`);
	if (value.startsWith("&")) return refuse(`line ${line}: anchors (&) are not supported by this view`);
	if (value.startsWith("*")) return refuse(`line ${line}: aliases (*) are not supported by this view`);
	if (value.startsWith("!")) return refuse(`line ${line}: tags (!) are not supported by this view`);
	if (value.startsWith("[") || value.startsWith("{")) return refuse(`line ${line}: flow collections ([…] and {…}) are not supported by this view`);
	if (value.startsWith("\"")) {
		if (value.length < 2 || !value.endsWith("\"")) return refuse(`line ${line}: an unterminated double-quoted string is not supported`);
		return {
			ok: true,
			node: stringNode(value.slice(1, -1).replace(/\\(["\\/nrt])/g, (_match, code) => {
				if (code === "n") return "\n";
				if (code === "t") return "	";
				if (code === "r") return "\r";
				return code;
			}))
		};
	}
	if (value.startsWith("'")) {
		if (value.length < 2 || !value.endsWith("'")) return refuse(`line ${line}: an unterminated single-quoted string is not supported`);
		return {
			ok: true,
			node: stringNode(value.slice(1, -1).replace(/''/g, "'"))
		};
	}
	if (value === "~" || value === "null" || value === "Null" || value === "NULL") return {
		ok: true,
		node: { kind: "null" }
	};
	if (value === "true" || value === "True" || value === "TRUE") return {
		ok: true,
		node: {
			kind: "boolean",
			value: true
		}
	};
	if (value === "false" || value === "False" || value === "FALSE") return {
		ok: true,
		node: {
			kind: "boolean",
			value: false
		}
	};
	if (/^[+-]?\d+$/.test(value) || /^[+-]?(\d+\.\d*|\.\d+|\d+)([eE][+-]?\d+)?$/.test(value)) {
		const parsed = Number(value);
		if (Number.isFinite(parsed)) return {
			ok: true,
			node: {
				kind: "number",
				value: parsed
			}
		};
	}
	return {
		ok: true,
		node: stringNode(value)
	};
}
function preparseYaml(source) {
	const lines = [];
	const rawLines = source.replace(/\r\n?/g, "\n").split("\n");
	for (let index = 0; index < rawLines.length; index += 1) {
		let raw = rawLines[index];
		if (index === 0) raw = raw.replace(/^\uFEFF/, "");
		if (!raw.trim()) continue;
		const lead = raw.match(/^[ \t]*/)?.[0] ?? "";
		if (lead.includes("	")) return refuse(`line ${index + 1}: tabs are not supported in indentation`);
		const content = raw.slice(lead.length).replace(/\s+$/, "");
		if (!content || content.startsWith("#")) continue;
		for (const [marker, reason] of REFUSED_STARTS) if (content.startsWith(marker)) return refuse(`line ${index + 1}: ${reason}`);
		lines.push({
			indent: lead.length,
			content,
			number: index + 1
		});
	}
	if (lines.length === 0) return refuse("the document is empty");
	return {
		ok: true,
		lines
	};
}
function parseYamlNode(lines, index, indent, depth, budget) {
	if (!take(budget, depth)) return {
		ok: true,
		node: { kind: "omitted" },
		next: lines.length
	};
	const first = lines[index];
	if (!first) return {
		ok: true,
		node: { kind: "null" },
		next: index
	};
	if (first.content === "-" || first.content.startsWith("- ")) return parseYamlSequence(lines, index, indent, depth, budget);
	if (keyColon(first.content) >= 0) return parseYamlMapping(lines, index, indent, depth, budget);
	const scalar = scalarNode(first.content, first.number);
	if (!scalar.ok) return scalar;
	return {
		ok: true,
		node: scalar.node,
		next: index + 1
	};
}
function parseYamlSequence(lines, index, indent, depth, budget) {
	const items = [];
	let cursor = index;
	while (cursor < lines.length) {
		const line = lines[cursor];
		if (line.indent !== indent) break;
		if (!(line.content === "-" || line.content.startsWith("- "))) break;
		if (budget.nodes >= 2e3) {
			budget.truncated = true;
			items.push({ kind: "omitted" });
			break;
		}
		const rest = line.content.slice(1).trim();
		if (!rest) {
			const next = lines[cursor + 1];
			if (!next || next.indent <= indent) {
				items.push({ kind: "null" });
				cursor += 1;
				continue;
			}
			const child = parseYamlNode(lines, cursor + 1, next.indent, depth + 1, budget);
			if (!child.ok) return child;
			items.push(child.node);
			cursor = child.next;
			continue;
		}
		if (keyColon(rest) >= 0) return refuse(`line ${line.number}: a sequence item that starts a mapping on the same line is not supported by this view`);
		if (rest === "-" || rest.startsWith("- ")) return refuse(`line ${line.number}: nested inline sequences are not supported by this view`);
		const scalar = scalarNode(rest, line.number);
		if (!scalar.ok) return scalar;
		items.push(scalar.node);
		cursor += 1;
	}
	return {
		ok: true,
		node: {
			kind: "array",
			items,
			...budget.truncated ? { truncated: true } : {}
		},
		next: cursor
	};
}
function parseYamlMapping(lines, index, indent, depth, budget) {
	const entries = [];
	const seen = /* @__PURE__ */ new Set();
	let cursor = index;
	while (cursor < lines.length) {
		const line = lines[cursor];
		if (line.indent !== indent) break;
		if (line.content === "-" || line.content.startsWith("- ")) break;
		const colon = keyColon(line.content);
		if (colon < 0) return refuse(`line ${line.number}: expected "key: value"`);
		const key = line.content.slice(0, colon).trim();
		if (!key) return refuse(`line ${line.number}: a key cannot be empty`);
		if (seen.has(key)) return refuse(`line ${line.number}: the key "${key}" appears twice`);
		seen.add(key);
		if (budget.nodes >= 2e3) {
			budget.truncated = true;
			entries.push({
				key,
				value: { kind: "omitted" }
			});
			break;
		}
		const rest = line.content.slice(colon + 1).trim();
		if (rest) {
			const scalar = scalarNode(rest, line.number);
			if (!scalar.ok) return scalar;
			entries.push({
				key,
				value: scalar.node
			});
			cursor += 1;
			continue;
		}
		const next = lines[cursor + 1];
		if (!next || next.indent <= indent) {
			entries.push({
				key,
				value: { kind: "null" }
			});
			cursor += 1;
			continue;
		}
		const child = parseYamlNode(lines, cursor + 1, next.indent, depth + 1, budget);
		if (!child.ok) return child;
		entries.push({
			key,
			value: child.node
		});
		cursor = child.next;
	}
	return {
		ok: true,
		node: {
			kind: "object",
			entries,
			...budget.truncated ? { truncated: true } : {}
		},
		next: cursor
	};
}
/** YAML in the subset this build understands, or the reason it did not. */
function parseYaml(source) {
	const prepared = preparseYaml(source);
	if (!prepared.ok) return {
		ok: false,
		format: "yaml",
		reason: prepared.reason
	};
	const budget = {
		nodes: 0,
		truncated: false
	};
	const parsed = parseYamlNode(prepared.lines, 0, prepared.lines[0].indent, 0, budget);
	if (!parsed.ok) return {
		ok: false,
		format: "yaml",
		reason: parsed.reason
	};
	if (parsed.next < prepared.lines.length) return {
		ok: false,
		format: "yaml",
		reason: `line ${prepared.lines[parsed.next].number}: unexpected indentation`
	};
	return {
		ok: true,
		format: "yaml",
		node: parsed.node,
		truncated: budget.truncated
	};
}
/** JSON via `JSON.parse`, walked with the same bounds. */
function parseJson(source) {
	let value;
	try {
		value = JSON.parse(source);
	} catch (error) {
		return {
			ok: false,
			format: "json",
			reason: `This is not valid JSON: ${error instanceof Error ? error.message : String(error)}`
		};
	}
	const budget = {
		nodes: 0,
		truncated: false
	};
	return {
		ok: true,
		format: "json",
		node: jsonNode(value, 0, budget),
		truncated: budget.truncated
	};
}
function parseStructured(format, source) {
	return format === "json" ? parseJson(source) : parseYaml(source);
}
/** A short description of a node's shape, for the view's header. */
function describeNode(node) {
	switch (node.kind) {
		case "object": return `${node.entries.length} key${node.entries.length === 1 ? "" : "s"}`;
		case "array": return `${node.items.length} item${node.items.length === 1 ? "" : "s"}`;
		case "string": return "a string";
		case "number": return "a number";
		case "boolean": return "a boolean";
		case "null": return "null";
		case "omitted": return "not shown";
	}
}
/**
* Prompt 43 — the CODE, DIFF and LOG views.
*
* DISPLAY ONLY. Every character below comes from the reply and is rendered as text
* inside a `<span>`; there is no HTML, no `eval`, no iframe and no syntax tree that
* gets executed. Highlighting is a token list (see `syntax-highlight.ts`), so the
* worst a hostile snippet can do is look like source code.
*
* TWO CONTROLS, EACH NAMED FOR WHAT IT DOES. "Copy" puts the exact text on the
* clipboard. "Save as a file" asks the artifact store to keep a copy and then asks
* the BROWSER to download it — and the sentence under it says which of those two
* things happened, because "saved to your computer" would be a half-truth.
*
* A DIFF IS A PROPOSAL. It is drawn with `+`/`−` markers, counted, and labelled
* "proposed — not applied"; there is no apply control and no patch is written
* anywhere. A reader who wants the change copies it into their own editor.
*/
var TOKEN_CLASS = {
	plain: "text-fg",
	comment: "text-faint italic",
	keyword: "text-[color:var(--color-accent)]",
	string: "text-[color:var(--color-ok)]",
	number: "text-[color:var(--color-warn)]",
	literal: "text-signal font-medium",
	property: "text-fg font-medium",
	punct: "text-muted"
};
function Tokens({ tokens }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: tokens.map((token, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: TOKEN_CLASS[token.kind],
		children: token.text
	}, index)) });
}
/** Ask the browser to download an artifact. A click is the only side effect. */
function startBrowserDownload$1(url, name) {
	const anchor = document.createElement("a");
	anchor.href = url;
	anchor.download = name;
	anchor.rel = "noopener";
	document.body.appendChild(anchor);
	anchor.click();
	anchor.remove();
}
function CopyButton$1({ text, label }) {
	const [copied, setCopied] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		className: "rounded px-1.5 py-0.5 text-meta text-muted hover:bg-bg hover:text-fg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[color:var(--color-accent)]",
		onClick: () => {
			navigator.clipboard?.writeText(text).then(() => setCopied(true), () => setCopied(false));
		},
		"aria-label": label,
		children: copied ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "inline-flex items-center gap-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
				className: "size-3",
				"aria-hidden": "true"
			}), " Copied"]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "inline-flex items-center gap-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {
				className: "size-3",
				"aria-hidden": "true"
			}), " Copy"]
		})
	});
}
/**
* "Save as a file", with the store's answer shown either way.
*
* The three states are distinct on purpose: saving, saved (with the real file name
* and whether the copy is temporary), and failed (with the store's own reason —
* never a generic "something went wrong").
*/
function SaveControl({ text, kind, language, format }) {
	const [phase, setPhase] = (0, import_react.useState)("idle");
	const [artifact, setArtifact] = (0, import_react.useState)(null);
	const [reason, setReason] = (0, import_react.useState)("");
	async function save() {
		if (phase === "saving") return;
		setPhase("saving");
		const result = await createTextArtifact({
			text,
			kind,
			language,
			format,
			origin: "saved from a reply"
		});
		if (!result.ok) {
			setReason(result.reason);
			setPhase("failed");
			return;
		}
		setArtifact(result.artifact);
		setPhase("saved");
		startBrowserDownload$1(artifactDownloadUrl(result.artifact.id), result.artifact.name);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-1.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			type: "button",
			variant: "ghost",
			size: "sm",
			onClick: () => void save(),
			disabled: phase === "saving",
			className: "px-1.5 text-muted hover:text-fg",
			children: [phase === "saving" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
				className: "size-3.5 animate-spin",
				"aria-hidden": "true"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {
				className: "size-3.5",
				"aria-hidden": "true"
			}), phase === "saving" ? "Saving…" : "Save as a file"]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "status",
			"aria-live": "polite",
			className: "text-meta",
			children: [phase === "saved" && artifact ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-muted",
					children: [
						"Asked your browser to download ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-fg",
							children: artifact.name
						}),
						"."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-faint",
					children: describeDownload()
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-faint",
					children: describeStoredCopy(artifact.state === "saved" ? "saved" : "transient")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: artifactDownloadUrl(artifact.id),
					download: artifact.name,
					className: "mt-0.5 inline-block text-meta text-muted underline decoration-border underline-offset-2 hover:text-fg",
					children: "Download again if your browser blocked it"
				})
			] }) : null, phase === "failed" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "flex items-start gap-1.5 text-warn",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "mt-0.5 size-3 shrink-0",
					"aria-hidden": "true"
				}), reason]
			}) : null]
		})]
	});
}
/** The frame every technical view shares: a title row, an action row, a body. */
function TechnicalFrame({ label, title, meta, actions, children, footer, caption }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
		className: "my-3 overflow-hidden rounded-md bg-surface shadow-[0_0_0_1px_var(--color-border)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-2 border-b border-border/60 px-3 py-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex min-w-0 items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "readout shrink-0 text-faint",
						children: label
					}), title ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "min-w-0 truncate text-meta text-fg",
						title,
						children: title
					}) : null]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex items-center gap-1.5",
					children: actions
				})]
			}),
			meta ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "px-3 py-1 text-meta text-faint",
				children: meta
			}) : null,
			children,
			footer ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "border-t border-border/60 px-3 py-1.5 text-meta text-faint",
				children: footer
			}) : null,
			caption ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", {
				className: "border-t border-border/60 px-3 py-1.5 text-meta text-faint",
				children: caption
			}) : null
		]
	});
}
function OutputCode({ block }) {
	const lines = (0, import_react.useMemo)(() => highlight(block.code, block.language), [block.code, block.language]);
	const language = normalizeLanguage(block.language);
	const start = block.startLine ?? 1;
	const coloured = isHighlighted(block.language, block.code) && language !== "plain";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TechnicalFrame, {
		label: block.language?.trim() || "code",
		meta: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			LANGUAGE_LABELS[language],
			" · ",
			lines.length,
			" line",
			lines.length === 1 ? "" : "s",
			start > 1 ? ` · from line ${start}` : "",
			language !== "plain" && !coloured ? " · too long to colour, shown as plain text" : ""
		] }),
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton$1, {
			text: block.code,
			label: "Copy this code"
		}),
		caption: block.caption,
		footer: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SaveControl, {
			text: block.code,
			kind: "source",
			language: block.language
		}),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
			className: "max-h-96 overflow-auto px-0 py-2 text-xs leading-relaxed",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", { children: lines.map((tokens, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "flex",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					"aria-hidden": "true",
					className: "w-10 shrink-0 select-none pr-3 text-right text-faint",
					children: start + index
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "min-w-0 whitespace-pre",
					children: tokens.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tokens, { tokens }) : " "
				})]
			}, index)) })
		})
	});
}
var DIFF_MARK = {
	add: "+",
	remove: "-",
	context: " "
};
var DIFF_CLASS = {
	add: "text-[color:var(--color-ok)]",
	remove: "text-[color:var(--color-danger)]",
	context: "text-muted"
};
function OutputDiff({ block }) {
	const stats = diffStats(block.lines);
	const asText = (0, import_react.useMemo)(() => block.lines.map((line) => `${DIFF_MARK[line.kind]}${line.text}`).join("\n"), [block.lines]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TechnicalFrame, {
		label: "diff",
		title: block.title,
		meta: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "text-[color:var(--color-ok)]",
				children: ["+", stats.added]
			}),
			" ",
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "text-[color:var(--color-danger)]",
				children: ["−", stats.removed]
			}),
			" · ",
			stats.context,
			" unchanged"
		] }),
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton$1, {
			text: asText,
			label: "Copy this diff"
		}),
		caption: block.caption,
		footer: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: describeDiff(block.lines) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SaveControl, {
			text: asText,
			kind: "diff"
		})] }),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
			className: "max-h-96 overflow-auto px-0 py-2 text-xs leading-relaxed",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", { children: block.lines.map((line, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "flex",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					"aria-hidden": "true",
					className: `w-6 shrink-0 select-none text-center ${DIFF_CLASS[line.kind]}`,
					children: DIFF_MARK[line.kind]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: `min-w-0 whitespace-pre ${DIFF_CLASS[line.kind]}`,
					children: line.text || " "
				})]
			}, index)) })
		})
	});
}
var LEVEL_CLASS = {
	error: "text-[color:var(--color-danger)]",
	warn: "text-[color:var(--color-warn)]",
	info: "text-muted",
	debug: "text-faint"
};
function OutputLogs({ block }) {
	const counts = logCounts(block.lines);
	const levels = presentLevels(counts);
	const asText = (0, import_react.useMemo)(() => block.lines.map((line) => line.level ? `[${line.level}] ${line.text}` : line.text).join("\n"), [block.lines]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TechnicalFrame, {
		label: "log",
		title: block.title,
		meta: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [levels.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mr-2 inline-flex gap-1.5",
			children: levels.map((level) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: LEVEL_CLASS[level],
				children: [
					counts[level],
					" ",
					level
				]
			}, level))
		}) : null, counts.unlabelled > 0 ? `${counts.unlabelled} unlabelled` : null] }),
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton$1, {
			text: asText,
			label: "Copy these log lines"
		}),
		caption: block.caption,
		footer: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [describeLogs(block.lines, block.truncated === true), ". Lines are shown as the reply wrote them; no level was inferred."] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SaveControl, {
			text: asText,
			kind: "logs"
		})] }),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
			className: "max-h-80 overflow-auto px-3 py-2 text-xs leading-relaxed",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", { children: block.lines.map((line, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: `w-12 shrink-0 select-none text-right text-meta uppercase ${line.level ? LEVEL_CLASS[line.level] : "text-faint"}`,
					children: line.level ?? "—"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "min-w-0 whitespace-pre-wrap break-words text-fg",
					children: line.text
				})]
			}, index)) })
		}), block.truncated ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-1.5 px-3 py-1 text-meta text-warn",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, {
				className: "size-3 shrink-0",
				"aria-hidden": "true"
			}), "The reply says it left lines out of this log."]
		}) : null]
	});
}
/**
* Prompt 42 — the ANSWERS to an interactive block, decided as data.
*
* WHY THIS IS A SEPARATE, PURE MODULE. The interesting rules of a form are not
* React rules: which controls start empty, what counts as a valid answer, what
* text is sent when the reader submits, and which control a confirmation may focus
* first. Those are decisions that must be testable without a browser and identical
* everywhere, so they live here and the component is only the drawing of them.
*
* WHAT SUBMITTING CAN DO: exactly one thing. It produces a STRING — the reader's
* answers, in a fixed shape this module owns — and the component hands that string
* to the conversation's existing send path (`onSend`), the same path the composer
* uses. There is no request, no URL, no handler, no permission and no side effect in
* this module. A form cannot delete, purchase, publish, message or run anything, and
* neither can a confirmation: answering one states a decision, and the action it
* describes still has to pass through the ordinary approval path.
*
* WHY THE TEXT LOOKS THE WAY IT DOES. `submissionText` always begins with a fixed
* heading ("Form answers — …"). That is not decoration: `sendUserMessage` treats a
* message beginning with `/` as a command (`/browse`, `/say`, `/models=…`), so a
* field the reader fills in with `/say hello` must not become a command. The fixed
* prefix makes that impossible for every field, and the tests assert it.
*/
/** The heading every submission starts with. Fixed, never model-supplied. */
var FORM_SUBMISSION_HEADING = "Form answers";
/** How an unanswered optional field is written, so it is not silently omitted. */
var FORM_BLANK = "(left blank)";
var FORM_NONE_SELECTED = "(none selected)";
function maySubmit(phase) {
	return phase === "idle";
}
function mayDecide(phase) {
	return phase === "idle";
}
function isMulti(field) {
	return field.kind === "multi";
}
function optionValues(field) {
	return new Set((field.options ?? []).map((option) => option.value));
}
/**
* A form starts with NOTHING answered.
*
* Not one control is pre-selected, even when an option reads "Recommended": the
* block has no `value` field to smuggle a default through, and this function does
* not invent one. A `required` field therefore starts invalid, which is the honest
* state — the reader has not answered yet.
*/
function initialFormValues(block) {
	const values = {};
	for (const field of block.fields) values[field.id] = isMulti(field) ? [] : "";
	return values;
}
function textOf(values, field) {
	const raw = values[field.id];
	return typeof raw === "string" ? raw : "";
}
function listOf(values, field) {
	const raw = values[field.id];
	return Array.isArray(raw) ? raw : [];
}
/**
* Set a text/number answer, clamped to the field's own limit.
*
* The clamp lives in the input path as well as the validator because a reader
* should not be able to type past the limit and only find out on submit; the
* validator still checks, because the two must not be able to disagree.
*/
function setFormText(values, field, raw) {
	const max = field.maxLength ?? 400;
	return {
		...values,
		[field.id]: raw.slice(0, max)
	};
}
/**
* Choose one option, or toggle one box.
*
* A single choice cannot be un-chosen by clicking it again (that is how a radio
* group behaves in every other part of this app), and a value that is not one of
* the field's options is ignored rather than stored — so nothing outside the
* validated option list can ever end up in an answer.
*/
function chooseFormOption(values, field, value) {
	if (!optionValues(field).has(value)) return values;
	if (isMulti(field)) {
		const current = listOf(values, field);
		if (current.includes(value)) return {
			...values,
			[field.id]: current.filter((entry) => entry !== value)
		};
		const cap = field.maxSelections;
		if (cap !== void 0 && current.length >= cap) return values;
		return {
			...values,
			[field.id]: [...current, value]
		};
	}
	return {
		...values,
		[field.id]: value
	};
}
/** Which options are currently ticked — used to disable the rest at the cap. */
function selectedValues(values, field) {
	return listOf(values, field);
}
/**
* Why this field's answer is not acceptable, or `null` when it is.
*
* Messages name the limit that was hit ("Enter 1 or more GB", "Choose at most 2"),
* because "invalid value" tells a reader nothing about how to fix it.
*/
function validateFormField(field, values) {
	switch (field.kind) {
		case "text": {
			const value = textOf(values, field);
			if (!value.trim()) return field.required ? "Enter an answer." : null;
			const max = field.maxLength ?? 400;
			if (value.length > max) return `Keep this to ${max} characters.`;
			return null;
		}
		case "number": {
			const value = textOf(values, field).trim();
			if (!value) return field.required ? "Enter a number." : null;
			const parsed = Number(value);
			if (!Number.isFinite(parsed)) return "Enter a number, not text.";
			if (field.min !== void 0 && field.max !== void 0) {
				if (parsed < field.min || parsed > field.max) return `Enter a number from ${field.min} to ${field.max}.`;
				return null;
			}
			if (field.min !== void 0 && parsed < field.min) return `Enter ${field.min} or more.`;
			if (field.max !== void 0 && parsed > field.max) return `Enter ${field.max} or less.`;
			return null;
		}
		case "choice":
		case "select": {
			const value = textOf(values, field);
			if (!value) return field.required ? "Choose an option." : null;
			if (!optionValues(field).has(value)) return "Choose one of the listed options.";
			return null;
		}
		case "multi": {
			const chosen = listOf(values, field);
			if (chosen.length === 0) return field.required ? "Choose at least one option." : null;
			const allowed = optionValues(field);
			if (chosen.some((value) => !allowed.has(value))) return "Choose only the listed options.";
			const cap = field.maxSelections;
			if (cap !== void 0 && chosen.length > cap) return `Choose at most ${cap}.`;
			return null;
		}
	}
}
/** Every refused field, in the form's own order. Empty means safe to submit. */
function validateForm(block, values) {
	const problems = [];
	for (const field of block.fields) {
		const message = validateFormField(field, values);
		if (message) problems.push({
			fieldId: field.id,
			label: field.label,
			message
		});
	}
	return problems;
}
function optionLabel(field, value) {
	return (field.options ?? []).find((option) => option.value === value);
}
/** A multi-line answer keeps its line breaks; continuation lines are indented. */
function asLines(value) {
	const [first, ...rest] = value.split(/\r?\n/);
	if (rest.length === 0) return first ?? "";
	return [first ?? "", ...rest.map((line) => `  ${line}`)].join("\n");
}
/**
* One answer as the reader (and the reply) will read it.
*
* A choice is written as its LABEL; when the reply gave the option a different
* meaning (`value`), that meaning is kept in parentheses, because dropping it would
* lose information the reply deliberately asked for.
*/
function formatAnswer(field, value) {
	if (field.kind === "multi") {
		const chosen = Array.isArray(value) ? value : [];
		if (chosen.length === 0) return FORM_NONE_SELECTED;
		return chosen.map((entry) => {
			const option = optionLabel(field, entry);
			if (!option) return entry;
			return option.value === option.label ? option.label : `${option.label} (${option.value})`;
		}).join(", ");
	}
	const raw = typeof value === "string" ? value : "";
	if (field.kind === "choice" || field.kind === "select") {
		if (!raw) return FORM_BLANK;
		const option = optionLabel(field, raw);
		if (!option) return FORM_BLANK;
		return option.value === option.label ? option.label : `${option.label} (${option.value})`;
	}
	const trimmed = raw.trim();
	if (!trimmed) return FORM_BLANK;
	return trimmed;
}
/**
* The message a submitted form sends.
*
* Shape, fixed here so a test can pin it:
*
*     Form answers — Delivery preferences
*     - Size: Medium
*     - Colours: Blue, Green
*     - Notes: (left blank)
*
* The first line is this module's own constant, so the message can never begin
* with `/` and be read as a slash command — whatever the reader typed.
*/
function submissionText(block, values) {
	const lines = [`${FORM_SUBMISSION_HEADING} — ${block.title}`];
	for (const field of block.fields) lines.push(`- ${field.label}: ${asLines(formatAnswer(field, values[field.id]))}`);
	return lines.join("\n");
}
/**
* The message a confirmation sends.
*
* It states the reader's decision and repeats the action it was about, so the
* conversation holds the exact thing that was decided rather than "yes".
*/
function confirmSubmissionText(block, decision) {
	return `${decision === "confirm" ? "Confirmed" : "Declined"}: ${block.action}`;
}
/**
* A confirmation's controls, in the order they appear in the DOM.
*
* Cancel is FIRST on purpose: the focus trap focuses the first focusable control,
* so a reader who simply presses Enter dismisses the dialog instead of approving a
* consequential action they have not read.
*/
function confirmControls(block) {
	return {
		cancel: block.cancelLabel ?? "Cancel",
		confirm: block.confirmLabel ?? "Confirm"
	};
}
/**
* Prompt 42 — the FORM and CONFIRMATION renderers.
*
* WHAT THESE CAN DO: draw validated controls, check the reader's answers against
* the field's own rules, and hand ONE string to `onSend` — the same send path the
* composer uses. Nothing else. No fetch, no URL, no handler, no navigation, no
* clipboard, no desktop call: the model's block cannot name an action, and this
* file has none to name.
*
* WHERE THE ANSWERS LIVE: React state in this component. Nothing is written to
* localStorage, to the conversation tables or to any file. The submitted message is
* the durable record; after a reload the form is unanswered again, and the honest
* account of what was sent is the user message underneath it.
*
* THE FALLBACK IS NOT A BROKEN FORM. With no `onSend` (a read-only view) the block
* is drawn as its questions and options in text, with one sentence saying it cannot
* be answered here — never inputs whose submit does nothing.
*/
function OutputForm({ block, onSend }) {
	const baseId = (0, import_react.useId)();
	const formRef = (0, import_react.useRef)(null);
	const [values, setValues] = (0, import_react.useState)(() => initialFormValues(block));
	const [problems, setProblems] = (0, import_react.useState)([]);
	const [phase, setPhase] = (0, import_react.useState)("idle");
	const [sentText, setSentText] = (0, import_react.useState)(null);
	const headingId = `${baseId}-heading`;
	const problemFor = (fieldId) => problems.find((problem) => problem.fieldId === fieldId)?.message;
	/** Typing or ticking clears that field's complaint, so an error never outlives it. */
	const clearProblem = (fieldId) => setProblems((current) => current.filter((problem) => problem.fieldId !== fieldId));
	if (!onSend) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "my-3 rounded-md bg-surface px-3 py-2.5 shadow-[0_0_0_1px_var(--color-border)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium text-fg",
				children: block.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-0.5 text-meta leading-relaxed text-muted",
				children: "This form cannot be answered here — there is no way to send an answer from this view."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-2 space-y-1.5",
				children: block.fields.map((field) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "text-meta text-fg",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: field.label }),
						field.required ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-faint",
							children: " (required)"
						}) : null,
						field.options?.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-0.5 block text-muted",
							children: field.options.map((option) => option.label).join(" · ")
						}) : null
					]
				}, field.id))
			}),
			block.caption ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-meta text-faint",
				children: block.caption
			}) : null
		]
	});
	const send = onSend;
	function submit(event) {
		event.preventDefault();
		if (!maySubmit(phase)) return;
		const found = validateForm(block, values);
		setProblems(found);
		if (found.length > 0) {
			const first = found[0];
			if (first) formRef.current?.querySelector(`[name="${first.fieldId}"]`)?.focus();
			return;
		}
		const text = submissionText(block, values);
		setSentText(text);
		setPhase("sent");
		send(text);
	}
	function cancel() {
		if (phase !== "idle") return;
		setProblems([]);
		setValues(initialFormValues(block));
		setPhase("cancelled");
	}
	function restart() {
		setProblems([]);
		setValues(initialFormValues(block));
		setSentText(null);
		setPhase("idle");
	}
	const locked = phase !== "idle";
	function describedBy(field, helpId, errorId) {
		const ids = [field.help ? helpId : null, problemFor(field.id) ? errorId : null].filter(Boolean);
		return ids.length > 0 ? ids.join(" ") : void 0;
	}
	function label(field) {
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [field.label, field.required ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "text-faint",
			"aria-hidden": "true",
			children: [" ", "*"]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: " (required)"
		})] }) : null] });
	}
	function notes(field, helpId, errorId) {
		const problem = problemFor(field.id);
		if (!field.help && !problem) return null;
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [field.help ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			id: helpId,
			className: "mt-1 text-meta leading-relaxed text-muted",
			children: field.help
		}) : null, problem ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			id: errorId,
			className: "mt-0.5 text-meta text-warn",
			children: problem
		}) : null] });
	}
	function renderField(field) {
		const fieldId = `${baseId}-${field.id}`;
		const helpId = `${fieldId}-help`;
		const errorId = `${fieldId}-error`;
		const problem = problemFor(field.id);
		const problemId = describedBy(field, helpId, errorId);
		if (field.kind === "choice" || field.kind === "multi") {
			const multi = field.kind === "multi";
			const chosen = selectedValues(values, field);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
				className: "m-0 min-w-0 border-0 p-0",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
						className: "text-meta font-medium text-fg",
						children: label(field)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-1 space-y-1",
						children: (field.options ?? []).map((option) => {
							const checked = multi ? chosen.includes(option.value) : values[field.id] === option.value;
							const atCap = multi && field.maxSelections !== void 0 && chosen.length >= field.maxSelections && !checked;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex cursor-pointer items-start gap-2 text-meta text-fg",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: multi ? "checkbox" : "radio",
									id: `${fieldId}-${option.value}`,
									name: field.id,
									value: option.value,
									checked,
									disabled: locked || atCap,
									"aria-invalid": problem ? true : void 0,
									"aria-describedby": problemId,
									onChange: () => {
										clearProblem(field.id);
										setValues((current) => chooseFormOption(current, field, option.value));
									},
									className: "mt-0.5 size-3.5 shrink-0 accent-[color:var(--color-accent)]"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: atCap ? "text-faint" : void 0,
									children: option.label
								})]
							}, option.value);
						})
					}),
					field.maxSelections !== void 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-meta text-faint",
						children: [
							"Choose up to ",
							field.maxSelections,
							"."
						]
					}) : null,
					notes(field, helpId, errorId)
				]
			});
		}
		if (field.kind === "select") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					htmlFor: fieldId,
					className: "text-meta font-medium text-fg",
					children: label(field)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					id: fieldId,
					name: field.id,
					disabled: locked,
					"aria-invalid": problem ? true : void 0,
					"aria-describedby": problemId,
					value: typeof values[field.id] === "string" ? values[field.id] : "",
					onChange: (event) => {
						const next = event.target.value;
						clearProblem(field.id);
						setValues((current) => chooseFormOption(current, field, next));
					},
					className: "mt-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "",
						children: "Choose…"
					}), (field.options ?? []).map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: option.value,
						children: option.label
					}, option.value))]
				}),
				notes(field, helpId, errorId)
			]
		});
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					htmlFor: fieldId,
					className: "text-meta font-medium text-fg",
					children: label(field)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-1 flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: fieldId,
						name: field.id,
						disabled: locked,
						"aria-invalid": problem ? true : void 0,
						"aria-describedby": problemId,
						type: field.kind === "number" ? "number" : "text",
						inputMode: field.kind === "number" ? "decimal" : void 0,
						min: field.min,
						max: field.max,
						step: field.step,
						maxLength: field.kind === "text" ? field.maxLength : void 0,
						placeholder: field.placeholder,
						value: typeof values[field.id] === "string" ? values[field.id] : "",
						onChange: (event) => {
							const next = event.target.value;
							clearProblem(field.id);
							setValues((current) => setFormText(current, field, next));
						}
					}), field.unit ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-meta text-muted",
						children: field.unit
					}) : null]
				}),
				notes(field, helpId, errorId)
			]
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		ref: formRef,
		className: "my-3 rounded-md bg-surface px-3 py-2.5 shadow-[0_0_0_1px_var(--color-border)]",
		onSubmit: submit,
		"aria-labelledby": headingId,
		noValidate: true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				id: headingId,
				className: "text-sm font-medium text-fg",
				children: block.title
			}),
			block.description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-0.5 text-meta leading-relaxed text-muted",
				children: block.description
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2.5 space-y-3",
				children: block.fields.map((field) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: renderField(field) }, field.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				role: "status",
				"aria-live": "polite",
				className: "mt-2 text-meta",
				children: problems.length === 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-warn",
					children: [
						problems[0]?.label,
						": ",
						problems[0]?.message
					]
				}) : problems.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-warn",
					children: [problems.length, " fields need attention before this can be sent."]
				}) : phase === "sent" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "flex items-center gap-1.5 text-muted",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
						className: "size-3.5",
						"aria-hidden": "true"
					}), "Sent as one message. This block will not send again."]
				}) : phase === "cancelled" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-muted",
					children: "Cancelled — nothing was sent."
				}) : null
			}),
			sentText ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
				className: "mt-2 max-h-40 overflow-auto whitespace-pre-wrap break-words rounded-sm bg-well px-2 py-1.5 text-meta text-muted",
				children: sentText
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-2.5 flex flex-wrap items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					variant: "primary",
					size: "sm",
					disabled: !maySubmit(phase),
					children: phase === "sent" ? "Sent" : block.submitLabel ?? "Send answers"
				}), phase === "cancelled" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					type: "button",
					variant: "secondary",
					size: "sm",
					onClick: restart,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {
						className: "size-3.5",
						"aria-hidden": "true"
					}), "Start again"]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "ghost",
					size: "sm",
					onClick: cancel,
					disabled: phase !== "idle",
					children: block.cancelLabel ?? "Cancel"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1.5 text-meta text-faint",
				children: "Sending puts your answers in the conversation as a message. It does not perform any other action."
			}),
			block.caption ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-meta text-faint",
				children: block.caption
			}) : null
		]
	});
}
/**
* A confirmation for a consequential action.
*
* TWO STEPS ON PURPOSE. The card in the reply is a summary with one control —
* "Review" — because an affirmative button inline in a transcript is one stray
* click away from approving something. The decision is taken in a modal dialog that
* repeats the exact action, and the dialog's focus trap lands on Cancel (see
* `confirmInitialFocus`), so the reader has to move to approve.
*
* DISMISSAL IS NOT A DECISION. Escape or a click outside closes the dialog and
* changes nothing; the card can be opened again. Only the two explicit controls
* send anything, and what they send is the reader's decision as text.
*/
function OutputConfirm({ block, onSend }) {
	const baseId = (0, import_react.useId)();
	const panelRef = (0, import_react.useRef)(null);
	const [open, setOpen] = (0, import_react.useState)(false);
	const [decision, setDecision] = (0, import_react.useState)(null);
	const [sentText, setSentText] = (0, import_react.useState)(null);
	const close = (0, import_react.useCallback)(() => setOpen(false), []);
	useFocusTrap(open, panelRef, close);
	const controls = confirmControls(block);
	const phase = decision ? "sent" : "idle";
	function decide(kind) {
		if (!mayDecide(phase) || !onSend) return;
		const text = confirmSubmissionText(block, kind);
		setSentText(text);
		setDecision(kind);
		setOpen(false);
		onSend(text);
	}
	const titleId = `${baseId}-title`;
	const actionId = `${baseId}-action`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "my-3 rounded-md bg-surface px-3 py-2.5 shadow-[0_0_0_1px_var(--color-border)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start gap-2",
				children: [block.destructive ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "mt-0.5 size-4 shrink-0 text-warn",
					"aria-hidden": "true"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleHelp, {
					className: "mt-0.5 size-4 shrink-0 text-muted",
					"aria-hidden": "true"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium text-fg",
						children: block.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-0.5 text-meta leading-relaxed text-fg",
						children: block.action
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-2 flex flex-wrap items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: decision ? "secondary" : "primary",
					size: "sm",
					onClick: () => setOpen(true),
					disabled: decision !== null || !onSend,
					children: "Review"
				}), decision === null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-meta text-faint",
					children: onSend ? "Nothing has been decided yet." : "This page cannot send a decision."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-meta text-muted",
					children: decision === "confirm" ? "You confirmed this." : "You declined this."
				})]
			}),
			sentText ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
				className: "mt-2 max-h-32 overflow-auto whitespace-pre-wrap break-words rounded-sm bg-well px-2 py-1.5 text-meta text-muted",
				children: sentText
			}) : null,
			block.caption ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-meta text-faint",
				children: block.caption
			}) : null,
			open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "fixed inset-0 z-50 flex items-end justify-center bg-black/50 p-3 sm:items-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute inset-0",
					"aria-hidden": "true",
					onClick: close
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					ref: panelRef,
					role: "dialog",
					"aria-modal": "true",
					"aria-labelledby": titleId,
					"aria-describedby": actionId,
					tabIndex: -1,
					className: "relative w-full max-w-md rounded-lg bg-bg p-4 shadow-[0_0_0_1px_var(--color-border)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							id: titleId,
							className: "text-sm font-medium text-fg",
							children: block.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							id: actionId,
							className: "mt-1.5 text-sm leading-relaxed text-fg",
							children: block.action
						}),
						block.detail ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1.5 text-meta leading-relaxed text-muted",
							children: block.detail
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-meta leading-relaxed text-faint",
							children: "Answering sends your decision to the conversation. It does not perform the action itself — that still needs its own approval."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex flex-col gap-2 sm:flex-row sm:justify-end",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "ghost",
								onClick: close,
								children: controls.cancel
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: block.destructive ? "danger" : "primary",
								onClick: () => decide("confirm"),
								children: controls.confirm
							})]
						})
					]
				})]
			}) : null
		]
	});
}
/**
* Prompt 39 — the diagram renderer (flow charts and decision trees).
*
* WHAT IS DRAWN. A node/edge list laid out by `diagram-layout.ts` and drawn as
* plain SVG shapes. There is no diagram language here: nothing the model wrote is
* parsed as markup, and no text becomes HTML. A node's label is a `<text>` child,
* so even an angle bracket is just a character.
*
* FIT, ZOOM, PAN. At rest the drawing is scaled to the column, which is the useful
* default for a phone. The zoom buttons change the pixel size inside a scrollable
* frame, so a dense diagram can be panned by touch, by the scrollbar, or by the
* arrow keys while the frame has focus — the frame is a labelled, focusable group
* with a spoken hint, not a magic scroll area.
*
* THE TEXT ALTERNATIVE IS NOT DECORATION. Under the drawing, "Read this diagram as
* text" lists every step and the branches leaving it. That is how a screen reader
* user, a keyboard-only user or anyone on a very narrow screen gets the same
* information — and when the layout refuses (too many stages, too wide), that list
* IS the block.
*
* SHAPES MEAN SOMETHING, AND ONLY WHAT THEY LOOK LIKE: pill = start/end, cut-corner
* box = decision, rounded box = process. The legend under the frame says so, so a
* reader is never asked to infer it.
*/
var ZOOM_STEPS = [
	.5,
	.75,
	1,
	1.25,
	1.5,
	2,
	3
];
function nextZoom(current, direction) {
	const index = ZOOM_STEPS.findIndex((step) => step >= current);
	const from = index < 0 ? ZOOM_STEPS.length - 1 : index;
	return ZOOM_STEPS[Math.min(ZOOM_STEPS.length - 1, Math.max(0, from + direction))];
}
function decisionPoints(node) {
	const cut = Math.min(14, node.height / 3);
	const { x, y, width, height } = node;
	return [
		`${x + cut},${y}`,
		`${x + width - cut},${y}`,
		`${x + width},${y + cut}`,
		`${x + width},${y + height - cut}`,
		`${x + width - cut},${y + height}`,
		`${x + cut},${y + height}`,
		`${x},${y + height - cut}`,
		`${x},${y + cut}`
	].join(" ");
}
function NodeShape({ node }) {
	const stroke = node.shape === "decision" ? "var(--color-accent)" : "var(--color-border)";
	const fill = node.shape === "start" || node.shape === "end" ? "var(--color-bg)" : "var(--color-surface-2)";
	if (node.shape === "decision") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
		points: decisionPoints(node),
		fill,
		stroke,
		strokeWidth: 1.25
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
		x: node.x,
		y: node.y,
		width: node.width,
		height: node.height,
		rx: node.shape === "start" || node.shape === "end" ? node.height / 2 : 6,
		fill,
		stroke,
		strokeWidth: 1.25
	});
}
function NodeText({ node }) {
	const lineHeight = 12;
	const cx = node.x + node.width / 2;
	const blockHeight = node.lines.length * lineHeight + (node.detail ? 11 : 0);
	const firstY = node.y + node.height / 2 - blockHeight / 2 + lineHeight / 2;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [node.lines.map((line, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
		x: cx,
		y: firstY + index * lineHeight,
		textAnchor: "middle",
		dominantBaseline: "middle",
		fontSize: 11,
		fill: "var(--color-fg)",
		children: line
	}, `${node.id}-line-${index}`)), node.detail ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
		x: cx,
		y: firstY + node.lines.length * lineHeight,
		textAnchor: "middle",
		dominantBaseline: "middle",
		fontSize: 9,
		fill: "var(--color-muted)",
		children: node.detail.length > 28 ? `${node.detail.slice(0, 27)}…` : node.detail
	}) : null] });
}
function OutputDiagram({ block }) {
	const titleId = (0, import_react.useId)();
	const descId = (0, import_react.useId)();
	const hintId = (0, import_react.useId)();
	const markerId = (0, import_react.useId)();
	const frameRef = (0, import_react.useRef)(null);
	const [zoom, setZoom] = (0, import_react.useState)(1);
	const layout = (0, import_react.useMemo)(() => layoutDiagram(block), [block]);
	const outline = (0, import_react.useMemo)(() => diagramTextOutline(block), [block]);
	const outlineList = /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
		className: "mt-1 list-decimal space-y-0.5 pl-5 text-meta leading-relaxed text-muted",
		children: outline.map((line, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: line }, index))
	});
	if (!layout.ok) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "my-3 rounded-md bg-surface px-3 py-2 shadow-[0_0_0_1px_var(--color-border)]",
		role: "status",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-meta text-fg",
				children: "This diagram cannot be drawn here."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-0.5 text-meta leading-relaxed text-muted",
				children: layout.reason
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
				className: "mt-1",
				open: true,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
					className: "cursor-pointer text-meta text-faint",
					children: "Read this diagram as text"
				}), outlineList]
			})
		]
	});
	function onKeyDown(event) {
		const frame = frameRef.current;
		const pan = 48;
		switch (event.key) {
			case "ArrowDown":
				frame?.scrollBy({ top: pan });
				break;
			case "ArrowUp":
				frame?.scrollBy({ top: -48 });
				break;
			case "ArrowLeft":
				frame?.scrollBy({ left: -48 });
				break;
			case "ArrowRight":
				frame?.scrollBy({ left: pan });
				break;
			case "+":
			case "=":
				setZoom((current) => nextZoom(current, 1));
				break;
			case "-":
			case "_":
				setZoom((current) => nextZoom(current, -1));
				break;
			case "0":
				setZoom(1);
				break;
			default: return;
		}
		event.preventDefault();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
		className: "my-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-md bg-surface px-3 py-2.5 shadow-[0_0_0_1px_var(--color-border)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "readout text-faint",
						children: [
							block.kind === "decision" ? "Decision tree" : "Flow chart",
							" · ",
							block.nodes.length,
							" ",
							"step",
							block.nodes.length === 1 ? "" : "s",
							layout.backEdges > 0 ? ` · ${layout.backEdges} loop` : ""
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-1",
						role: "group",
						"aria-label": "Diagram zoom",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "inline-flex size-7 items-center justify-center rounded text-muted hover:bg-surface-2 hover:text-fg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[color:var(--color-accent)] disabled:opacity-40",
								onClick: () => setZoom((current) => nextZoom(current, -1)),
								disabled: zoom <= ZOOM_STEPS[0],
								"aria-label": "Zoom out",
								title: "Zoom out",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, {
									className: "size-3.5",
									"aria-hidden": "true"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "min-w-10 text-center font-mono text-meta text-muted",
								"aria-live": "polite",
								children: [Math.round(zoom * 100), "%"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "inline-flex size-7 items-center justify-center rounded text-muted hover:bg-surface-2 hover:text-fg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[color:var(--color-accent)] disabled:opacity-40",
								onClick: () => setZoom((current) => nextZoom(current, 1)),
								disabled: zoom >= ZOOM_STEPS[ZOOM_STEPS.length - 1],
								"aria-label": "Zoom in",
								title: "Zoom in",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
									className: "size-3.5",
									"aria-hidden": "true"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "inline-flex size-7 items-center justify-center rounded text-muted hover:bg-surface-2 hover:text-fg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[color:var(--color-accent)] disabled:opacity-40",
								onClick: () => setZoom(1),
								disabled: zoom === 1,
								"aria-label": "Fit the diagram to the column",
								title: "Fit to view",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {
									className: "size-3.5",
									"aria-hidden": "true"
								})
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					ref: frameRef,
					tabIndex: 0,
					role: "group",
					"aria-label": `${block.kind === "decision" ? "Decision tree" : "Flow chart"}, scrollable`,
					"aria-describedby": hintId,
					onKeyDown,
					className: "mt-1 overflow-auto rounded-sm bg-bg/40 p-2 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[color:var(--color-accent)]",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
						viewBox: `0 0 ${layout.width} ${layout.height}`,
						role: "img",
						"aria-labelledby": titleId,
						"aria-describedby": descId,
						preserveAspectRatio: "xMidYMid meet",
						className: "block",
						style: zoom === 1 ? {
							width: "100%",
							height: "auto"
						} : {
							width: layout.width * zoom,
							height: layout.height * zoom
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("title", {
								id: titleId,
								children: block.caption ?? (block.kind === "decision" ? "Decision tree" : "Flow chart")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("desc", {
								id: descId,
								children: outline.join(" ")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("marker", {
								id: markerId,
								viewBox: "0 0 8 8",
								refX: 7,
								refY: 4,
								markerWidth: 7,
								markerHeight: 7,
								orient: "auto-start-reverse",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
									d: "M 0 0 L 8 4 L 0 8 z",
									fill: "var(--color-border)"
								})
							}) }),
							layout.edges.map((edge, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
								d: edge.path,
								fill: "none",
								stroke: "var(--color-border)",
								strokeWidth: 1.25,
								strokeDasharray: edge.back ? "4 3" : void 0,
								markerEnd: `url(#${markerId})`
							}), edge.label ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
								x: edge.labelX,
								y: edge.labelY - 4,
								textAnchor: "middle",
								fontSize: 8.5,
								fill: "var(--color-muted)",
								stroke: "var(--color-surface)",
								strokeWidth: 3,
								paintOrder: "stroke",
								children: wrapDiagramLabel(edge.label, 16, 1).lines[0]
							}) : null] }, `${edge.from}-${edge.to}-${index}`)),
							layout.nodes.map((node) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NodeShape, { node }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NodeText, { node })] }, node.id))
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					id: hintId,
					className: "sr-only",
					children: "Use the arrow keys to pan the diagram, plus and minus to zoom, and zero to fit it to the column."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-meta text-faint",
					children: "Pill: start or end. Cut-corner box: a decision. Rounded box: a step. A dashed connection loops back."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
					className: "mt-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
						className: "cursor-pointer text-meta text-faint",
						children: "Read this diagram as text"
					}), outlineList]
				})
			]
		}), block.caption ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", {
			className: "mt-1 text-meta text-faint",
			children: block.caption
		}) : null]
	});
}
/**
* Prompt 43 — a stored file, and the reader's two choices about it.
*
* THE RECORD BEATS THE BLOCK. The name, type and size in a `file` block are what the
* reply SAID; the artifact store is what is actually on this machine. So the view
* asks the store (one bounded, cached list read) and shows the record's own cleanup
* sentence. If the file is gone — expired, deleted, never stored — it says so and
* offers no download that would silently fail.
*
* "DOWNLOAD" IS A BROWSER ACTION. It is an anchor with `download`, nothing more: Oqe
* does not open a save dialog, does not learn where the file went, and does not claim
* it wrote anything. The sentence under the row says exactly that.
*
* "KEEP ON THIS MACHINE" IS THE ONLY WAY A GENERATED FILE OUTLIVES ITS CLEANUP
* WINDOW: a state change on this machine's copy, which drops the expiry. It writes no
* second copy and nothing leaves the machine.
*/
function OutputFile({ block }) {
	const [lookup, setLookup] = (0, import_react.useState)({ kind: "checking" });
	const [keep, setKeep] = (0, import_react.useState)({ phase: "idle" });
	(0, import_react.useEffect)(() => {
		let live = true;
		setLookup({ kind: "checking" });
		lookupArtifact(block.artifact).then((result) => {
			if (!live) return;
			if (result.ok) setLookup({
				kind: "present",
				artifact: result.artifact
			});
			else if (result.code === "missing") setLookup({
				kind: "missing",
				reason: result.reason
			});
			else setLookup({
				kind: "unreachable",
				reason: result.reason
			});
		});
		return () => {
			live = false;
		};
	}, [block.artifact]);
	async function keepOnMachine() {
		if (keep.phase === "keeping" || keep.phase === "kept") return;
		setKeep({ phase: "keeping" });
		const result = await keepArtifactOnMachine(block.artifact);
		if (!result.ok) {
			setKeep({
				phase: "failed",
				reason: result.reason
			});
			return;
		}
		setLookup({
			kind: "present",
			artifact: result.artifact
		});
		setKeep({ phase: "kept" });
	}
	const available = lookup.kind === "present" || lookup.kind === "unreachable";
	const stateLabel = lookup.kind === "present" ? lookup.artifact.state : block.transient ? "transient" : void 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
		className: "my-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-md bg-surface px-3 py-2 shadow-[0_0_0_1px_var(--color-border)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, {
							className: "size-4 shrink-0 text-muted",
							"aria-hidden": "true"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate text-sm text-fg",
								title: block.name,
								children: block.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-meta text-faint",
								children: [
									block.mediaType,
									" · ",
									describeArtifactBytes(block.bytes),
									lookup.kind === "present" ? ` · ${lookup.artifact.name}` : ""
								]
							})]
						}),
						available ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: artifactDownloadUrl(block.artifact),
							download: block.name,
							className: "inline-flex items-center gap-1.5 rounded-md bg-surface-2 px-2 py-1 text-meta text-fg shadow-[0_0_0_1px_var(--color-border)] hover:bg-bg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[color:var(--color-accent)]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {
								className: "size-3.5",
								"aria-hidden": "true"
							}), "Download"]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-md bg-surface-2 px-2 py-1 text-meta text-faint",
							"aria-disabled": "true",
							children: "Download"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					role: "status",
					"aria-live": "polite",
					className: "mt-1.5 text-meta",
					children: [
						lookup.kind === "checking" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "flex items-center gap-1.5 text-faint",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
								className: "size-3 animate-spin",
								"aria-hidden": "true"
							}), "Checking this file on this machine…"]
						}) : null,
						lookup.kind === "missing" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "flex items-start gap-1.5 text-warn",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
								className: "mt-0.5 size-3 shrink-0",
								"aria-hidden": "true"
							}), lookup.reason]
						}) : null,
						lookup.kind === "unreachable" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-muted",
							children: [lookup.reason, " The download is still offered — it may work even though this check did not."]
						}) : null,
						lookup.kind === "present" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-muted",
							children: describeStoredCopy(stateLabel === "saved" ? "saved" : "transient")
						}) : null
					]
				}),
				available && stateLabel !== "saved" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-1.5 flex flex-wrap items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "button",
							variant: "secondary",
							size: "sm",
							onClick: () => void keepOnMachine(),
							disabled: keep.phase === "keeping" || keep.phase === "kept",
							children: [keep.phase === "keeping" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
								className: "size-3.5 animate-spin",
								"aria-hidden": "true"
							}) : null, keep.phase === "kept" ? "Kept" : "Keep on this machine"]
						}),
						keep.phase === "kept" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-meta text-muted",
							children: "It stays until you delete it."
						}) : null,
						keep.phase === "failed" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-meta text-warn",
							children: keep.reason
						}) : null
					]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1.5 text-meta text-faint",
					children: describeDownload()
				})
			]
		}), block.caption ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", {
			className: "mt-1 text-meta text-faint",
			children: block.caption
		}) : null]
	});
}
function ViewerDialog({ open, title, onClose, children }) {
	const panelRef = (0, import_react.useRef)(null);
	const close = (0, import_react.useCallback)(() => onClose(), [onClose]);
	useFocusTrap(open, panelRef, close);
	if (!open) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-50 flex flex-col bg-bg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "absolute inset-0",
			onClick: close,
			"aria-hidden": "true"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			ref: panelRef,
			role: "dialog",
			"aria-modal": "true",
			"aria-labelledby": "viewer-title",
			tabIndex: -1,
			className: "viewer-panel relative flex h-full flex-col",
			"data-open": "true",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2 px-2 pt-[env(safe-area-inset-top)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					id: "viewer-title",
					className: "min-w-0 flex-1 truncate px-3 text-sm font-medium",
					children: title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "inline-flex size-12 items-center justify-center rounded-lg text-fg hover:bg-surface-2",
					onClick: close,
					"aria-label": "Close",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-6" })
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "min-h-0 flex-1 overflow-y-auto px-5 py-4 pb-[max(1.5rem,env(safe-area-inset-bottom))]",
				children
			})]
		})]
	});
}
/**
* Prompt 37 — TEMPORARY MEDIA: the bytes a reply shows without keeping them.
*
* WHAT THIS IS FOR. A screenshot, an uploaded picture, an image a research step
* retrieved — the things that appear in a reply and then stop mattering. They must
* not be written to the conversation, to localStorage, or to long-lived artifact
* storage, because "the thread remembers a picture you glanced at" is a promise
* nobody asked for and a disk that fills up quietly. So the bytes live in MEMORY,
* behind an object URL, for as long as something on screen is looking at them —
* and then they are gone.
*
* THE RULES, in the order they are enforced:
*
*  1. ONE SOURCE OF TRUTH. `registerTransientImage` is the only way bytes get in.
*     It checks the media type against a fixed list (PNG/JPEG/WebP/GIF — never
*     anything the browser might treat as a document), the size, the alt text,
*     and — the part that matters for truthfulness — WHERE the image came from.
*     A screenshot, a retrieved image or a generated one is only accepted when the
*     operation that produced it reports SUCCESS and the caller says display was
*     authorized. An operation that failed cannot leave a picture behind.
*
*  2. THE HANDLE IS OPAQUE. Callers get `img_…` and nothing else: no path, no
*     data URL, no blob kept by the caller. The renderer can only resolve a handle;
*     a handle nobody registered is a placeholder, never a fetch.
*
*  3. THE WINDOW IS BOUNDED. Every image carries an expiry (a rolling TTL) and the
*     store refuses to grow past a count and a total-size cap. Expiry is enforced
*     on ACCESS (every resolve/register sweeps first) and by one timer, so an
*     idle tab does not hold bytes forever.
*
*  4. CLEANUP IS ON EVERY PATH. Unmount releases a reference; the LAST reference
*     revokes the object URL. Cancellation, failure and a component teardown all
*     release. `pagehide` releases everything the page was holding, because a
*     closed tab should not depend on a React cleanup having run. Expiry releases
*     whatever is left.
*
*  5. RE-READING IS HONEST. A revived image after its window is `expired`; a handle
*     this page never minted is `unknown`. Both are sentences in the UI, and
*     neither is retried behind the reader's back.
*
* Client-safe (no node imports). The object-URL implementation is injected so the
* state machine can be tested exactly, without a DOM.
*/
function defaultAdapter() {
	if (typeof URL !== "undefined" && typeof URL.createObjectURL === "function" && typeof URL.revokeObjectURL === "function") return {
		create: (bytes) => URL.createObjectURL(bytes),
		revoke: (url) => URL.revokeObjectURL(url)
	};
	let counter = 0;
	return {
		create: () => `blob:oqe/${counter += 1}`,
		revoke: () => {}
	};
}
var adapter = defaultAdapter();
var entries = /* @__PURE__ */ new Map();
/**
* Handles whose window PASSED — no bytes, just the fact.
*
* Without this, an expired image and a handle that never existed would both read as
* "unknown", and the honest sentence ("this was temporary and its window ended") is
* exactly what the reader needs when they scroll back. A tombstone holds nothing but
* the id, so this does not keep a picture alive to make old history look unchanged.
* It is bounded, because the list is a courtesy, not a record.
*/
var expiredHandles = /* @__PURE__ */ new Set();
var MAX_EXPIRED_TOMBSTONES = 128;
function rememberExpired(handle) {
	expiredHandles.add(handle);
	while (expiredHandles.size > MAX_EXPIRED_TOMBSTONES) {
		const oldest = expiredHandles.values().next().value;
		if (typeof oldest !== "string") break;
		expiredHandles.delete(oldest);
	}
}
function drop(entry) {
	if (entry.url) try {
		adapter.revoke(entry.url);
	} catch {}
	entries.delete(entry.handle);
}
/**
* Remove every entry whose window has passed. Called on every access and by the
* timer below, so a tab that is never touched still lets go.
*/
function sweepExpiredTransientImages(now = Date.now()) {
	let removed = 0;
	for (const entry of [...entries.values()]) if (now >= entry.expiresAt) {
		drop(entry);
		rememberExpired(entry.handle);
		removed += 1;
	}
	return removed;
}
function urlFor(entry) {
	if (!entry.url) entry.url = adapter.create(entry.bytes);
	return entry.url;
}
/** What a renderer may draw for this handle right now. */
function resolveTransientImage(handle, now = Date.now()) {
	sweepExpiredTransientImages(now);
	if (!isOutputSessionId(handle)) return {
		state: "unknown",
		handle
	};
	const entry = entries.get(handle);
	if (!entry) return expiredHandles.has(handle) ? {
		state: "expired",
		handle
	} : {
		state: "unknown",
		handle
	};
	return {
		state: "ready",
		handle: entry.handle,
		url: urlFor(entry),
		mediaType: entry.mediaType,
		alt: entry.alt,
		bytes: entry.byteLength,
		origin: entry.origin,
		expiresAt: entry.expiresAt
	};
}
/**
* Hold a reference for as long as a component is mounted. Returns the number of
* references after this call (0 when the handle is not there), so a caller can tell
* "kept" from "already gone".
*/
function retainTransientImage(handle, now = Date.now()) {
	sweepExpiredTransientImages(now);
	const entry = entries.get(handle);
	if (!entry) return 0;
	entry.refs += 1;
	return entry.refs;
}
/**
* Let go of a reference. The object URL is revoked when the LAST consumer releases
* it — which is what makes two blocks showing the same picture safe, and what makes
* an unmount actually free the bytes' URL.
*/
function releaseTransientImage(handle) {
	const entry = entries.get(handle);
	if (!entry) return 0;
	entry.refs = Math.max(0, entry.refs - 1);
	if (entry.refs === 0 && entry.url) {
		try {
			adapter.revoke(entry.url);
		} catch {}
		entry.url = null;
	}
	return entry.refs;
}
/**
* Drop an image only if nothing on screen is still using it.
*
* This is the failure path: the bytes could not be decoded, so they are useless to
* everyone — but if a second block is showing the same picture, its reference is a
* claim that the failure may be local to the first img. Its release decides.
*/
function revokeTransientImageIfUnused(handle) {
	const entry = entries.get(handle);
	if (!entry || entry.refs > 0) return false;
	drop(entry);
	return true;
}
/**
* The handle a block points at, or null when it is artifact-backed (or names
* nothing). A convenience for the renderer, which must not care about the shape.
*/
function sessionHandleOf(block) {
	return typeof block.session === "string" && isOutputSessionId(block.session) ? block.session : null;
}
/**
* Prompt 37 — WHAT AN IMAGE BLOCK SHOULD SAY, decided without a browser.
*
* The component that draws an image has three jobs that are easy to blur: get a
* URL, say what happened when there is no URL, and describe the picture accessibly.
* The first is a fetch, the second is a sentence, and the third is a rule — so all
* the deciding happens here, in a pure function the tests can drive, and the
* component only renders the result.
*
* The states are deliberately distinct, because \"no picture\" is not one situation:
*
*  - `ready`     — a URL to draw.
*  - `expired`   — the window passed (temporary bytes, in memory or on disk).
*  - `unknown`   — a handle this page never minted: the reply mentions a picture
*                  that was never here, or the page was reloaded. Never retried.
*  - `oversized` — the declared size is above what this build will load. Refused
*                  BEFORE loading, so a huge file cannot stall the thread.
*  - `blocked`   — artifacts may not be loaded in the current policy (an
*                  exports-only or offline mode).
*
* None of these is an error dialog: each one is a plate in the reply that explains
* itself in the interface's voice. A failed *load* (bytes that were promised but did
* not arrive) is the sixth state, and it is chosen by the component's `onError`.
*/
/** The local route an artifact's bytes come from. Never a model-supplied URL. */
function artifactImageUrl(artifactId) {
	return `/api/storage/artifacts?id=${encodeURIComponent(artifactId)}`;
}
/**
* Resolve one block to what can be drawn right now.
*
* `allowFetch` is the policy's `allowArtifactFetch`: when it is false an artifact
* may not be requested at all, and the block says so instead of showing a broken
* frame. Session images are unaffected — they are already in memory and involve no
* request.
*/
function resolveImageView(block, options = {}) {
	const allowFetch = options.allowFetch !== false;
	const alt = block.alt;
	if (typeof block.bytes === "number" && block.bytes > 8388608) return {
		state: "oversized",
		alt,
		title: "This image is too large to show here",
		detail: `${formatImageBytes(block.bytes)} is above the ${formatImageBytes(MAX_OUTPUT_IMAGE_BYTES)} this build displays inline.`
	};
	const handle = sessionHandleOf(block);
	if (handle) {
		const resolved = resolveTransientImage(handle, options.now);
		if (resolved.state === "ready") return {
			state: "ready",
			url: resolved.url,
			alt: resolved.alt || alt,
			source: "session",
			transient: true,
			bytes: resolved.bytes
		};
		if (resolved.state === "expired") return {
			state: "expired",
			alt,
			title: "This image expired",
			detail: "It was a temporary image held in this session, and its window has passed. The rest of the reply is unaffected."
		};
		return {
			state: "unknown",
			alt,
			title: "This image is no longer available",
			detail: "It was a temporary image from this session, so it is not kept with the conversation. Reloading the page or starting a new one clears it."
		};
	}
	if (block.artifact) {
		if (!allowFetch) return {
			state: "blocked",
			alt,
			title: "Images from files are turned off here",
			detail: "The reply included a picture, but this build will not load stored files in this view."
		};
		return {
			state: "ready",
			url: artifactImageUrl(block.artifact),
			alt,
			source: "artifact",
			transient: block.transient === true,
			...typeof block.bytes === "number" ? { bytes: block.bytes } : {}
		};
	}
	return {
		state: "unknown",
		alt,
		title: "This image has no source",
		detail: "The reply referenced a picture without naming where it is."
	};
}
/**
* The sentence for bytes that were promised but did not arrive.
*
* The temporary/permanent distinction is the useful part: \"it expired\" tells the
* reader the picture existed and is gone by design, while \"it is not on this
* machine\" tells them something is actually missing.
*/
function describeImageLoadFailure(block) {
	if (sessionHandleOf(block) || block.transient === true) return {
		title: "This image could not be shown",
		detail: "It was temporary, and its cleanup window has passed or its bytes are gone. Nothing was kept."
	};
	return {
		title: "This image could not be loaded",
		detail: "The file is no longer on this machine, or it could not be read."
	};
}
/**
* Whether an \"Open larger\" affordance is worth offering.
*
* A thumbnail-sized picture gains nothing from a full-screen copy, and the control
* would be a dead end; a picture that is already larger than the column is exactly
* what the affordance is for.
*/
function canEnlarge(naturalWidth, naturalHeight) {
	if (!Number.isFinite(naturalWidth) || !Number.isFinite(naturalHeight)) return false;
	return naturalWidth >= 640 || naturalHeight >= 480;
}
/** A byte count in the reader's terms. */
function formatImageBytes(bytes) {
	if (!Number.isFinite(bytes) || bytes <= 0) return "0 B";
	if (bytes < 1024) return `${Math.round(bytes)} B`;
	if (bytes < 1048576) return `${(bytes / 1024).toFixed(bytes < 10240 ? 1 : 0)} KB`;
	return `${(bytes / 1048576).toFixed(1)} MB`;
}
/**
* The provenance line under a picture, when there is one worth saying.
*
* It reports only what is known: a session image is temporary, an artifact may be
* saved or temporary, and a saved artifact has no expiry to mention. The renderer
* never claims an image was generated or retrieved — that is the operation's story,
* and the block does not carry it.
*/
function describeImageProvenance(view) {
	if (view.state !== "ready") return null;
	if (view.source === "session") return "Temporary — not kept with this conversation.";
	if (view.transient) return "Temporary — removed when its cleanup window ends.";
	return null;
}
function OutputImage({ block, allowFetch = true, layout = "full" }) {
	const handle = sessionHandleOf(block);
	const [view, setView] = (0, import_react.useState)(() => resolveImageView(block, { allowFetch }));
	const [phase, setPhase] = (0, import_react.useState)("loading");
	const [natural, setNatural] = (0, import_react.useState)(null);
	const [enlarged, setEnlarged] = (0, import_react.useState)(false);
	const sourceKey = `${handle ?? block.artifact ?? "none"}:${block.bytes ?? "?"}:${allowFetch ? "on" : "off"}`;
	(0, import_react.useEffect)(() => {
		setEnlarged(false);
		setPhase("loading");
		setNatural(null);
		setView(resolveImageView(block, { allowFetch }));
		if (!handle) return;
		retainTransientImage(handle);
		return () => {
			releaseTransientImage(handle);
		};
	}, [
		sourceKey,
		handle,
		allowFetch
	]);
	const provenance = (0, import_react.useMemo)(() => describeImageProvenance(view), [view]);
	const failure = (0, import_react.useMemo)(() => describeImageLoadFailure(block), [block]);
	const framing = layout === "aside" ? "mt-0 mb-3" : "my-3";
	if (view.state !== "ready") {
		const isOversized = view.state === "oversized";
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
			className: framing,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start gap-2.5 rounded-md bg-surface px-3 py-2.5 shadow-[0_0_0_1px_var(--color-border)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImageOff, {
					className: "mt-0.5 size-4 shrink-0 text-muted",
					"aria-hidden": "true"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-fg",
							children: view.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-meta leading-relaxed text-muted",
							children: view.detail
						}),
						isOversized ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-meta leading-relaxed text-faint",
							children: ["Picture: ", view.alt]
						}),
						view.state === "oversized" && block.artifact ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: `/api/storage/artifacts?id=${encodeURIComponent(block.artifact)}`,
							className: "mt-2 inline-block text-meta text-fg underline decoration-border-strong underline-offset-2 hover:decoration-fg",
							children: "Download the full file instead"
						}) : null
					]
				})]
			}), block.caption ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", {
				className: "mt-1 text-meta text-faint",
				children: block.caption
			}) : null]
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("figure", {
		className: framing,
		children: phase === "failed" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-start gap-2.5 rounded-md bg-surface px-3 py-2.5 shadow-[0_0_0_1px_var(--color-border)]",
			role: "status",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImageOff, {
				className: "mt-0.5 size-4 shrink-0 text-muted",
				"aria-hidden": "true"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-fg",
						children: failure.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-meta leading-relaxed text-muted",
						children: failure.detail
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-meta leading-relaxed text-faint",
						children: ["Picture: ", view.alt]
					})
				]
			})]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative overflow-hidden rounded-md bg-well shadow-[0_0_0_1px_var(--color-border)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: view.url,
					alt: view.alt,
					decoding: "async",
					loading: "lazy",
					className: cn("mx-auto block max-h-[26rem] w-auto max-w-full object-contain", phase === "loaded" ? "" : "invisible h-0 w-0"),
					onLoad: (event) => {
						setNatural({
							width: event.currentTarget.naturalWidth,
							height: event.currentTarget.naturalHeight
						});
						setPhase("loaded");
					},
					onError: () => {
						setPhase("failed");
						if (handle) {
							releaseTransientImage(handle);
							revokeTransientImageIfUnused(handle);
						}
					}
				}),
				phase !== "loaded" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex min-h-32 items-center justify-center gap-2 px-3 py-6",
					role: "status",
					"aria-live": "polite",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
						className: "size-3.5 shrink-0 animate-spin text-muted motion-reduce:animate-none",
						"aria-hidden": "true"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-meta text-muted",
						children: "Loading image"
					})]
				}) : null,
				phase === "loaded" && canEnlarge(natural?.width ?? 0, natural?.height ?? 0) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "absolute right-2 top-2 rounded-md bg-bg/85 px-2 py-1 text-meta text-fg shadow-[0_0_0_1px_var(--color-border-strong)] backdrop-blur hover:bg-surface-2 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[color:var(--color-accent)]",
					onClick: () => setEnlarged(true),
					children: "Open larger"
				}) : null
			]
		}), block.caption || provenance ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figcaption", {
			className: "mt-1 flex flex-wrap items-baseline gap-x-2 text-meta text-faint",
			children: [block.caption ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: block.caption }) : null, provenance ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: provenance }) : null]
		}) : null] })
	}), enlarged ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ViewerDialog, {
		open: enlarged,
		title: block.caption ?? view.alt,
		onClose: () => setEnlarged(false),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: view.url,
			alt: view.alt,
			className: "mx-auto block max-h-[80vh] w-auto max-w-full rounded-md object-contain"
		}), provenance ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 text-center text-meta text-faint",
			children: provenance
		}) : null]
	}) : null] });
}
var MAX_EXPORT_BYTES = MAX_ARTIFACT_BYTES;
var MESH_EXPORT_FORMATS = [{
	id: "stl",
	label: "STL (binary)",
	extension: "stl",
	mediaType: "model/stl",
	note: "Triangle soup in millimetres. No units or names are stored in the file."
}, {
	id: "3mf",
	label: "3MF",
	extension: "3mf",
	mediaType: "model/3mf",
	note: "A package with the unit (millimetre) and one named object per body."
}];
function exportFormat(id) {
	const found = MESH_EXPORT_FORMATS.find((entry) => entry.id === id);
	if (!found) throw new Error(`export format "${id}" is not supported`);
	return found;
}
var textEncoder = new TextEncoder();
/**
* A binary STL.
*
* The stored normal is written per triangle from the winding, which is what slicers use as
* a hint and what some of them trust when the winding is wrong. It is not an independent
* check: `inspectMesh` is what decides whether the winding is consistent.
*/
function toBinaryStl(mesh, title) {
	const triangles = mesh.indices.length / 3;
	const bytes = new Uint8Array(84 + triangles * 50);
	const view = new DataView(bytes.buffer);
	const header = `Oqe binary STL - ${title}`.replace(/[^\x20-\x7e]/g, " ").slice(0, 80);
	bytes.set(textEncoder.encode(header), 0);
	view.setUint32(80, triangles, true);
	let offset = 84;
	for (let index = 0; index < mesh.indices.length; index += 3) {
		const ia = mesh.indices[index] * 3;
		const ib = mesh.indices[index + 1] * 3;
		const ic = mesh.indices[index + 2] * 3;
		const ax = mesh.positions[ia];
		const ay = mesh.positions[ia + 1];
		const az = mesh.positions[ia + 2];
		const bx = mesh.positions[ib];
		const by = mesh.positions[ib + 1];
		const bz = mesh.positions[ib + 2];
		const cx = mesh.positions[ic];
		const cy = mesh.positions[ic + 1];
		const cz = mesh.positions[ic + 2];
		const e1x = bx - ax;
		const e1y = by - ay;
		const e1z = bz - az;
		const e2x = cx - ax;
		const e2y = cy - ay;
		const e2z = cz - az;
		let nx = e1y * e2z - e1z * e2y;
		let ny = e1z * e2x - e1x * e2z;
		let nz = e1x * e2y - e1y * e2x;
		const length = Math.sqrt(nx * nx + ny * ny + nz * nz) || 1;
		nx /= length;
		ny /= length;
		nz /= length;
		for (const value of [
			nx,
			ny,
			nz,
			ax,
			ay,
			az,
			bx,
			by,
			bz,
			cx,
			cy,
			cz
		]) {
			view.setFloat32(offset, value, true);
			offset += 4;
		}
		view.setUint16(offset, 0, true);
		offset += 2;
	}
	return bytes;
}
var CRC_TABLE = (() => {
	const table = /* @__PURE__ */ new Uint32Array(256);
	for (let index = 0; index < 256; index += 1) {
		let value = index;
		for (let bit = 0; bit < 8; bit += 1) value = value & 1 ? 3988292384 ^ value >>> 1 : value >>> 1;
		table[index] = value >>> 0;
	}
	return table;
})();
function crc32(bytes) {
	let crc = 4294967295;
	for (const byte of bytes) crc = CRC_TABLE[(crc ^ byte) & 255] ^ crc >>> 8;
	return (crc ^ 4294967295) >>> 0;
}
/**
* A minimal ZIP writer: stored entries, fixed 1980-01-01 timestamp, no comments, no ZIP64.
*
* Deliberately boring — the archive only ever holds three small XML documents this module
* wrote itself, and a stored entry is the one shape every reader (including this
* repository's own `readZip`) handles without a decompressor.
*/
function writeStoredZip(entries) {
	const encoder = textEncoder;
	const locals = [];
	const centrals = [];
	let offset = 0;
	for (const entry of entries) {
		const name = encoder.encode(entry.path);
		const crc = crc32(entry.data);
		const local = new Uint8Array(30 + name.length + entry.data.length);
		const localView = new DataView(local.buffer);
		localView.setUint32(0, 67324752, true);
		localView.setUint16(4, 20, true);
		localView.setUint16(6, 0, true);
		localView.setUint16(8, 0, true);
		localView.setUint16(10, 0, true);
		localView.setUint16(12, 33, true);
		localView.setUint32(14, crc, true);
		localView.setUint32(18, entry.data.length, true);
		localView.setUint32(22, entry.data.length, true);
		localView.setUint16(26, name.length, true);
		localView.setUint16(28, 0, true);
		local.set(name, 30);
		local.set(entry.data, 30 + name.length);
		locals.push(local);
		const central = new Uint8Array(46 + name.length);
		const centralView = new DataView(central.buffer);
		centralView.setUint32(0, 33639248, true);
		centralView.setUint16(4, 20, true);
		centralView.setUint16(6, 20, true);
		centralView.setUint16(8, 0, true);
		centralView.setUint16(10, 0, true);
		centralView.setUint16(12, 0, true);
		centralView.setUint16(14, 33, true);
		centralView.setUint32(16, crc, true);
		centralView.setUint32(20, entry.data.length, true);
		centralView.setUint32(24, entry.data.length, true);
		centralView.setUint16(28, name.length, true);
		centralView.setUint16(30, 0, true);
		centralView.setUint16(32, 0, true);
		centralView.setUint16(34, 0, true);
		centralView.setUint16(36, 0, true);
		centralView.setUint32(38, 0, true);
		centralView.setUint32(42, offset, true);
		central.set(name, 46);
		centrals.push(central);
		offset += local.length;
	}
	const centralSize = centrals.reduce((total, entry) => total + entry.length, 0);
	const end = /* @__PURE__ */ new Uint8Array(22);
	const endView = new DataView(end.buffer);
	endView.setUint32(0, 101010256, true);
	endView.setUint16(4, 0, true);
	endView.setUint16(6, 0, true);
	endView.setUint16(8, entries.length, true);
	endView.setUint16(10, entries.length, true);
	endView.setUint32(12, centralSize, true);
	endView.setUint32(16, offset, true);
	endView.setUint16(20, 0, true);
	const total = offset + centralSize + end.length;
	const zip = new Uint8Array(total);
	let cursor = 0;
	for (const chunk of [
		...locals,
		...centrals,
		end
	]) {
		zip.set(chunk, cursor);
		cursor += chunk.length;
	}
	return zip;
}
function escapeXml(value) {
	return value.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;");
}
/** Six decimals is micrometre precision; trailing zeros are trimmed. */
function numberText(value) {
	const rounded = Math.round(value * 1e6) / 1e6;
	return Number.isInteger(rounded) ? String(rounded) : rounded.toFixed(6).replace(/0+$/, "");
}
var CONTENT_TYPES_XML = `<?xml version="1.0" encoding="UTF-8"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
 <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
 <Default Extension="model" ContentType="application/vnd.ms-package.3dmanufacturing-3dmodel+xml"/>
</Types>
`;
var RELS_XML = `<?xml version="1.0" encoding="UTF-8"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
 <Relationship Target="/3D/3dmodel.model" Id="rel0" Type="http://schemas.microsoft.com/3dmanufacturing/2013/01/3dmodel"/>
</Relationships>
`;
/**
* The 3MF model document.
*
* One `<object>` per BODY, each with its own mesh, and — when there is more than one body —
* an assembly object that references them. That is the shape the core specification
* describes, and it keeps the body names (which STL cannot carry) intact.
*/
function to3mfModelXml(mesh, title) {
	const lines = [];
	lines.push("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
	lines.push("<model unit=\"millimeter\" xml:lang=\"en-US\" xmlns=\"http://schemas.microsoft.com/3dmanufacturing/core/2015/02\">");
	lines.push(" <metadata name=\"Application\">Oqe</metadata>");
	lines.push(` <metadata name="Title">${escapeXml(title)}</metadata>`);
	lines.push(" <resources>");
	mesh.bodies.forEach((body, index) => {
		const vertexStart = body.firstVertex;
		const vertexEnd = body.firstVertex + body.vertexCount;
		const triangleStart = body.firstTriangle;
		const triangleEnd = body.firstTriangle + body.triangleCount;
		lines.push(`  <object id="${index + 1}" type="model" name="${escapeXml(body.id)}">`);
		lines.push("   <mesh>");
		lines.push("    <vertices>");
		for (let vertex = vertexStart; vertex < vertexEnd; vertex += 1) {
			const base = vertex * 3;
			lines.push(`     <vertex x="${numberText(mesh.positions[base])}" y="${numberText(mesh.positions[base + 1])}" z="${numberText(mesh.positions[base + 2])}"/>`);
		}
		lines.push("    </vertices>");
		lines.push("    <triangles>");
		for (let triangle = triangleStart; triangle < triangleEnd; triangle += 1) {
			const base = triangle * 3;
			const a = mesh.indices[base] - vertexStart;
			const b = mesh.indices[base + 1] - vertexStart;
			const c = mesh.indices[base + 2] - vertexStart;
			lines.push(`     <triangle v1="${a}" v2="${b}" v3="${c}"/>`);
		}
		lines.push("    </triangles>");
		lines.push("   </mesh>");
		lines.push("  </object>");
	});
	if (mesh.bodies.length > 1) {
		const assemblyId = mesh.bodies.length + 1;
		lines.push(`  <object id="${assemblyId}" type="model" name="assembly">`);
		lines.push("   <components>");
		mesh.bodies.forEach((_, index) => {
			lines.push(`    <component objectid="${index + 1}"/>`);
		});
		lines.push("   </components>");
		lines.push("  </object>");
		lines.push(" </resources>");
		lines.push(` <build><item objectid="${assemblyId}"/></build>`);
	} else {
		lines.push(" </resources>");
		lines.push(" <build><item objectid=\"1\"/></build>");
	}
	lines.push("</model>");
	return `${lines.join("\n")}\n`;
}
/** The whole 3MF package: three stored entries, in the order readers expect. */
function to3mf(mesh, title) {
	return writeStoredZip([
		{
			path: "[Content_Types].xml",
			data: textEncoder.encode(CONTENT_TYPES_XML)
		},
		{
			path: "_rels/.rels",
			data: textEncoder.encode(RELS_XML)
		},
		{
			path: "3D/3dmodel.model",
			data: textEncoder.encode(to3mfModelXml(mesh, title))
		}
	]);
}
/**
* Export a mesh, with a generated name and the store's own media type.
*
* The name is `oqe-model.<ext>`: generated here, re-validated by `safeArtifactName`, and
* never derived from the reply. The size check runs before the bytes are handed on, so a
* model the store would refuse is refused here with a sentence instead of a 413.
*/
function exportMesh(mesh, format, title) {
	if (mesh.indices.length === 0) return {
		ok: false,
		reason: "there is no geometry in this model to export"
	};
	const info = exportFormat(format);
	const bytes = format === "stl" ? toBinaryStl(mesh, title) : to3mf(mesh, title);
	if (bytes.length > MAX_EXPORT_BYTES) return {
		ok: false,
		reason: `this export would be ${bytes.length.toLocaleString()} bytes; the artifact store accepts ${MAX_EXPORT_BYTES.toLocaleString()}`
	};
	const name = safeArtifactName(`oqe-model.${info.extension}`);
	if (!name) return {
		ok: false,
		reason: "this build could not generate a safe file name"
	};
	return {
		ok: true,
		bytes,
		name,
		mediaType: info.mediaType,
		format: info
	};
}
function push(draft, x, y, z) {
	const index = draft.positions.length / 3;
	draft.positions.push(x, y, z);
	return index;
}
function tri(draft, a, b, c) {
	draft.indices.push(a, b, c);
}
/** A box centred on its own origin. `width` is X, `depth` is Y, `height` is Z. */
function box(shape) {
	const hx = shape.width / 2;
	const hy = shape.depth / 2;
	const hz = shape.height / 2;
	const draft = {
		positions: [],
		indices: []
	};
	const v = [
		push(draft, -hx, -hy, -hz),
		push(draft, hx, -hy, -hz),
		push(draft, hx, hy, -hz),
		push(draft, -hx, hy, -hz),
		push(draft, -hx, -hy, hz),
		push(draft, hx, -hy, hz),
		push(draft, hx, hy, hz),
		push(draft, -hx, hy, hz)
	];
	tri(draft, v[0], v[3], v[2]);
	tri(draft, v[0], v[2], v[1]);
	tri(draft, v[4], v[5], v[6]);
	tri(draft, v[4], v[6], v[7]);
	tri(draft, v[0], v[1], v[5]);
	tri(draft, v[0], v[5], v[4]);
	tri(draft, v[3], v[7], v[6]);
	tri(draft, v[3], v[6], v[2]);
	tri(draft, v[0], v[4], v[7]);
	tri(draft, v[0], v[7], v[3]);
	tri(draft, v[1], v[2], v[6]);
	tri(draft, v[1], v[6], v[5]);
	return draft;
}
/**
* A wedge: a right-triangular prism. The right angle is at -X/-Z, the slope rises toward
* +X, and the prism is extruded along Y (depth). It is the shape a reply reaches for when
* it means "a ramp" or "a gusset".
*/
function wedge(shape) {
	const hx = shape.width / 2;
	const hy = shape.depth / 2;
	const hz = shape.height / 2;
	const draft = {
		positions: [],
		indices: []
	};
	const b0 = push(draft, -hx, -hy, -hz);
	const b1 = push(draft, hx, -hy, -hz);
	const b2 = push(draft, -hx, -hy, hz);
	const f0 = push(draft, -hx, hy, -hz);
	const f1 = push(draft, hx, hy, -hz);
	const f2 = push(draft, -hx, hy, hz);
	tri(draft, b0, b1, b2);
	tri(draft, f0, f2, f1);
	tri(draft, b0, f1, b1);
	tri(draft, b0, f0, f1);
	tri(draft, b0, b2, f2);
	tri(draft, b0, f2, f0);
	tri(draft, b1, f1, f2);
	tri(draft, b1, f2, b2);
	return draft;
}
function ring(draft, radius, z, facets) {
	const points = [];
	for (let index = 0; index < facets; index += 1) {
		const angle = index / facets * Math.PI * 2;
		points.push(push(draft, Math.cos(angle) * radius, Math.sin(angle) * radius, z));
	}
	return points;
}
/** A cylinder about the Z axis, centred on its own origin. */
function cylinder(shape) {
	const draft = {
		positions: [],
		indices: []
	};
	const facets = shape.sides;
	const bottom = ring(draft, shape.radius, -shape.height / 2, facets);
	const top = ring(draft, shape.radius, shape.height / 2, facets);
	const bottomCentre = push(draft, 0, 0, -shape.height / 2);
	const topCentre = push(draft, 0, 0, shape.height / 2);
	for (let index = 0; index < facets; index += 1) {
		const next = (index + 1) % facets;
		tri(draft, bottom[index], bottom[next], top[next]);
		tri(draft, bottom[index], top[next], top[index]);
		tri(draft, bottomCentre, bottom[next], bottom[index]);
		tri(draft, topCentre, top[index], top[next]);
	}
	return draft;
}
/** A hollow cylinder (a washer) about the Z axis; the inner wall is wound inward. */
function tube(shape) {
	const draft = {
		positions: [],
		indices: []
	};
	const facets = shape.sides;
	const outerBottom = ring(draft, shape.outerRadius, -shape.height / 2, facets);
	const outerTop = ring(draft, shape.outerRadius, shape.height / 2, facets);
	const innerBottom = ring(draft, shape.innerRadius, -shape.height / 2, facets);
	const innerTop = ring(draft, shape.innerRadius, shape.height / 2, facets);
	for (let index = 0; index < facets; index += 1) {
		const next = (index + 1) % facets;
		tri(draft, outerBottom[index], outerBottom[next], outerTop[next]);
		tri(draft, outerBottom[index], outerTop[next], outerTop[index]);
		tri(draft, innerBottom[index], innerTop[index], innerTop[next]);
		tri(draft, innerBottom[index], innerTop[next], innerBottom[next]);
		tri(draft, outerTop[index], outerTop[next], innerTop[next]);
		tri(draft, outerTop[index], innerTop[next], innerTop[index]);
		tri(draft, outerBottom[index], innerBottom[index], innerBottom[next]);
		tri(draft, outerBottom[index], innerBottom[next], outerBottom[next]);
	}
	return draft;
}
function shapeDraft(shape) {
	switch (shape.kind) {
		case "box": return box(shape);
		case "wedge": return wedge(shape);
		case "cylinder": return cylinder(shape);
		case "tube": return tube(shape);
	}
}
var DEG$1 = Math.PI / 180;
/**
* Rotate about X, then Y, then Z (extrinsic), then translate.
*
* Written out rather than pulled from a matrix library because it is nine multiplications
* and this module must stay dependency-free and deterministic.
*/
function transformPoint(x, y, z, rotate, at) {
	const [rx, ry, rz] = [
		rotate[0] * DEG$1,
		rotate[1] * DEG$1,
		rotate[2] * DEG$1
	];
	let cy = Math.cos(rx);
	let sy = Math.sin(rx);
	const y1 = y * cy - z * sy;
	const z1 = y * sy + z * cy;
	cy = Math.cos(ry);
	sy = Math.sin(ry);
	const x1 = x * cy + z1 * sy;
	const z2 = -x * sy + z1 * cy;
	cy = Math.cos(rz);
	sy = Math.sin(rz);
	const x2 = x1 * cy - y1 * sy;
	const y2 = x1 * sy + y1 * cy;
	return [
		x2 + at[0],
		y2 + at[1],
		z2 + at[2]
	];
}
/**
* Build the mesh for a validated recipe.
*
* The limits are checked again here (a recipe could reach this function from a caller that
* skipped `parseGeometryRecipe`), and the build is refused rather than truncated: half a
* model is not a model.
*/
function buildMesh(recipe) {
	const positions = [];
	const indices = [];
	const bodies = [];
	for (const part of recipe.parts) {
		const draft = shapeDraft(part.shape);
		const firstVertex = positions.length / 3;
		const at = part.at ?? [
			0,
			0,
			0
		];
		const rotate = part.rotate ?? [
			0,
			0,
			0
		];
		for (let index = 0; index < draft.positions.length; index += 3) {
			const [x, y, z] = transformPoint(draft.positions[index], draft.positions[index + 1], draft.positions[index + 2], rotate, at);
			if (!Number.isFinite(x) || !Number.isFinite(y) || !Number.isFinite(z)) return {
				ok: false,
				reason: `part "${part.id}" produced a non-finite vertex`
			};
			positions.push(x, y, z);
		}
		const firstTriangle = indices.length / 3;
		for (const offset of draft.indices) indices.push(offset + firstVertex);
		if (positions.length / 3 > 6e3) return {
			ok: false,
			reason: `this model exceeds ${MAX_MESH_VERTICES.toLocaleString()} vertices`
		};
		if (indices.length / 3 > 12e3) return {
			ok: false,
			reason: `this model exceeds ${MAX_MESH_TRIANGLES.toLocaleString()} triangles`
		};
		bodies.push({
			id: part.id,
			shape: part.shape.kind,
			firstTriangle,
			triangleCount: indices.length / 3 - firstTriangle,
			firstVertex,
			vertexCount: positions.length / 3 - firstVertex
		});
	}
	return {
		ok: true,
		mesh: {
			positions,
			indices,
			bodies
		}
	};
}
function key(a, b) {
	return a < b ? `${a}:${b}` : `${b}:${a}`;
}
/**
* Inspect a built mesh.
*
* The three real checks are: every edge is used twice (closed), no edge is used more than
* twice (manifold), and the signed volume is positive (the normals point out). The rest is
* counting and bounds. `notChecked` is deliberately part of the type: it travels with the
* report so the UI cannot present a mesh as more verified than it is.
*/
function inspectMesh(mesh) {
	const vertices = mesh.positions.length / 3;
	const triangles = mesh.indices.length / 3;
	const edges = /* @__PURE__ */ new Map();
	itri: for (let index = 0; index < mesh.indices.length; index += 3) {
		const a = mesh.indices[index];
		const b = mesh.indices[index + 1];
		const c = mesh.indices[index + 2];
		if (a >= vertices || b >= vertices || c >= vertices) continue itri;
		for (const pair of [
			[a, b],
			[b, c],
			[c, a]
		]) {
			const edge = key(pair[0], pair[1]);
			edges.set(edge, (edges.get(edge) ?? 0) + 1);
		}
	}
	let openEdges = 0;
	let nonManifoldEdges = 0;
	for (const count of edges.values()) if (count === 1) openEdges += 1;
	else if (count > 2) nonManifoldEdges += 1;
	let volume = 0;
	for (let index = 0; index < mesh.indices.length; index += 3) {
		const a = mesh.indices[index] * 3;
		const b = mesh.indices[index + 1] * 3;
		const c = mesh.indices[index + 2] * 3;
		const ax = mesh.positions[a];
		const ay = mesh.positions[a + 1];
		const az = mesh.positions[a + 2];
		const bx = mesh.positions[b];
		const by = mesh.positions[b + 1];
		const bz = mesh.positions[b + 2];
		const cx = mesh.positions[c];
		const cy = mesh.positions[c + 1];
		const cz = mesh.positions[c + 2];
		volume += (ax * (by * cz - bz * cy) - ay * (bx * cz - bz * cx) + az * (bx * cy - by * cx)) / 6;
	}
	const min = [
		Infinity,
		Infinity,
		Infinity
	];
	const max = [
		-Infinity,
		-Infinity,
		-Infinity
	];
	for (let index = 0; index < mesh.positions.length; index += 3) for (let axis = 0; axis < 3; axis += 1) {
		const value = mesh.positions[index + axis];
		if (value < min[axis]) min[axis] = value;
		if (value > max[axis]) max[axis] = value;
	}
	if (vertices === 0) {
		min.fill(0);
		max.fill(0);
	}
	return {
		triangles,
		vertices,
		bodies: mesh.bodies.length,
		min,
		max,
		size: [
			max[0] - min[0],
			max[1] - min[1],
			max[2] - min[2]
		],
		volumeMm3: volume,
		watertight: openEdges === 0 && nonManifoldEdges === 0 && triangles > 0,
		openEdges,
		nonManifoldEdges,
		windingConsistent: volume > 0,
		notChecked: [
			"self-intersection between bodies",
			"wall thickness",
			"overhangs or print supports",
			"a slicer import or print test"
		]
	};
}
/** Radius of the bounding sphere about the box centre — what the camera frames. */
function boundingRadius(report) {
	const [x, y, z] = report.size;
	const radius = Math.sqrt(x * x + y * y + z * z) / 2;
	return radius > 0 ? radius : 1;
}
/** The centre of the bounding box: what the camera orbits. */
function boundingCentre(report) {
	return [
		(report.min[0] + report.max[0]) / 2,
		(report.min[1] + report.max[1]) / 2,
		(report.min[2] + report.max[2]) / 2
	];
}
/**
* Prompt 45 — the VIEWER's maths, kept out of the component so it can be tested.
*
* A perspective camera orbiting a Z-up model: yaw around Z, then tilt, then translate by
* the pan and project. There is no 3D library here — the projection is fifteen lines of
* arithmetic and the shading is one dot product, which is enough to look at a bracket and
* far cheaper than shipping a renderer for one block type.
*
* WHAT THE RENDERER IS. Flat-shaded triangles sorted back to front and filled as polygons:
* a painter's algorithm. It is honest about its limits — a concave model can show a
* triangle through another one, and there is no depth buffer. The viewer says "flat
* shading, painter's order" rather than pretending to be a CAD viewport, and the dimension
* panel is the authoritative readout.
*
* Everything here is pure: angles in degrees, distances in model radii, screen coordinates
* in CSS pixels. No canvas, no DOM.
*/
var DEFAULT_VIEW = {
	yaw: -35,
	pitch: 22,
	distance: 4.6,
	panX: 0,
	panY: 0
};
var MIN_DISTANCE = 1.8;
var MAX_PAN = 4e3;
var DEG = Math.PI / 180;
function clamp(value, min, max) {
	if (!Number.isFinite(value)) return min;
	return Math.min(max, Math.max(min, value));
}
/** Fold an angle into [0, 360) so a long drag does not lose precision. */
function wrapDegrees(value) {
	if (!Number.isFinite(value)) return 0;
	const wrapped = value % 360;
	return wrapped < 0 ? wrapped + 360 : wrapped;
}
function clampView(view) {
	return {
		yaw: wrapDegrees(view.yaw),
		pitch: clamp(view.pitch, -85, 85),
		distance: clamp(view.distance, MIN_DISTANCE, 16),
		panX: clamp(view.panX, -4e3, MAX_PAN),
		panY: clamp(view.panY, -4e3, MAX_PAN)
	};
}
function orbit(view, deltaYaw, deltaPitch) {
	return clampView({
		...view,
		yaw: view.yaw + deltaYaw,
		pitch: view.pitch + deltaPitch
	});
}
/** `factor` > 1 moves the camera away (smaller model), < 1 moves it closer. */
function zoomBy(view, factor) {
	return clampView({
		...view,
		distance: view.distance * factor
	});
}
function panBy(view, dx, dy) {
	return clampView({
		...view,
		panX: view.panX + dx,
		panY: view.panY + dy
	});
}
function resetView() {
	return { ...DEFAULT_VIEW };
}
function cameraFor(mesh, report, view, width, height) {
	return {
		view: clampView(view),
		centre: boundingCentre(report),
		radius: boundingRadius(report),
		width: Math.max(1, width),
		height: Math.max(1, height)
	};
}
/**
* World → screen.
*
* Z is up, the camera looks along +Y from −Y, and screen Y grows downward, so a higher
* point on the model is a smaller screen y. `depth` is returned so the caller can sort and
* so a point behind the camera can be rejected instead of projected through it.
*/
function projectPoint(camera, x, y, z) {
	const { view, centre, radius, width, height } = camera;
	const px = x - centre[0];
	const py = y - centre[1];
	const pz = z - centre[2];
	const yaw = view.yaw * DEG;
	const cosYaw = Math.cos(yaw);
	const sinYaw = Math.sin(yaw);
	const x1 = px * cosYaw + py * sinYaw;
	const y1 = -px * sinYaw + py * cosYaw;
	const pitch = view.pitch * DEG;
	const cosPitch = Math.cos(pitch);
	const sinPitch = Math.sin(pitch);
	const z2 = y1 * sinPitch + pz * cosPitch;
	const depth = view.distance * radius + y1 * cosPitch - pz * sinPitch;
	const scale = 1 / Math.tan(42 * DEG / 2) * (height / 2);
	if (depth <= radius * .05) return {
		x: width / 2 + view.panX,
		y: height / 2 + view.panY,
		depth
	};
	return {
		x: width / 2 + view.panX + x1 * scale / depth,
		y: height / 2 + view.panY - z2 * scale / depth,
		depth
	};
}
var LIGHT = (() => {
	const [x, y, z] = [
		-.45,
		-.72,
		.53
	];
	const length = Math.sqrt(x * x + y * y + z * z);
	return [
		x / length,
		y / length,
		z / length
	];
})();
/**
* Every triangle, projected and sorted FAR to NEAR, with a flat shade.
*
* Sorting is by mean depth. Triangle count is already bounded by the recipe
* (60,000), and the caller draws what it is given, so this is a single pass.
*/
function projectMesh(mesh, report, view, width, height) {
	const camera = cameraFor(mesh, report, view, width, height);
	const triangles = [];
	const yaw = camera.view.yaw * DEG;
	const pitch = camera.view.pitch * DEG;
	const cosYaw = Math.cos(yaw);
	const sinYaw = Math.sin(yaw);
	const cosPitch = Math.cos(pitch);
	const sinPitch = Math.sin(pitch);
	const bodyOf = (triangleIndex) => {
		for (const [index, body] of mesh.bodies.entries()) if (triangleIndex >= body.firstTriangle && triangleIndex < body.firstTriangle + body.triangleCount) return index;
		return 0;
	};
	for (let index = 0; index < mesh.indices.length; index += 3) {
		const ia = mesh.indices[index] * 3;
		const ib = mesh.indices[index + 1] * 3;
		const ic = mesh.indices[index + 2] * 3;
		const ax = mesh.positions[ia];
		const ay = mesh.positions[ia + 1];
		const az = mesh.positions[ia + 2];
		const bx = mesh.positions[ib];
		const by = mesh.positions[ib + 1];
		const bz = mesh.positions[ib + 2];
		const cx = mesh.positions[ic];
		const cy = mesh.positions[ic + 1];
		const cz = mesh.positions[ic + 2];
		const a = projectPoint(camera, ax, ay, az);
		const b = projectPoint(camera, bx, by, bz);
		const c = projectPoint(camera, cx, cy, cz);
		const depth = (a.depth + b.depth + c.depth) / 3;
		if (depth <= camera.radius * .05) continue;
		const e1 = [
			bx - ax,
			by - ay,
			bz - az
		];
		const e2 = [
			cx - ax,
			cy - ay,
			cz - az
		];
		const nx0 = e1[1] * e2[2] - e1[2] * e2[1];
		const ny0 = e1[2] * e2[0] - e1[0] * e2[2];
		const nz0 = e1[0] * e2[1] - e1[1] * e2[0];
		const nx = nx0 * cosYaw + ny0 * sinYaw;
		const ny1 = -nx0 * sinYaw + ny0 * cosYaw;
		const ny = ny1 * cosPitch - nz0 * sinPitch;
		const nz = ny1 * sinPitch + nz0 * cosPitch;
		const length = Math.sqrt(nx * nx + ny * ny + nz * nz) || 1;
		const lambert = Math.max(0, (nx * LIGHT[0] + ny * LIGHT[1] + nz * LIGHT[2]) / length);
		triangles.push({
			points: [
				a,
				b,
				c
			],
			depth,
			shade: .18 + .82 * lambert,
			body: bodyOf(index / 3)
		});
	}
	triangles.sort((left, right) => right.depth - left.depth);
	return triangles;
}
/** The size string shown beside the viewer, in millimetres. */
function describeSize(report) {
	const round = (value) => (Math.round(value * 10) / 10).toFixed(1);
	return `${round(report.size[0])} × ${round(report.size[1])} × ${round(report.size[2])} mm`;
}
/**
* Prompt 45 — the 3D VIEWER.
*
* WHAT IS ACTUALLY DRAWN. Triangles. The recipe is meshed in this page (`buildMesh`), the
* same triangle list is inspected (`inspectMesh`), projected through a perspective camera
* (`projectMesh`) and filled on a 2D canvas — flat-shaded, sorted back to front. There is
* no image, no pre-rendered picture and no fake "drag to rotate" card: turn the model and
* the geometry turns, because the geometry is here.
*
* ORBIT, ZOOM, PAN, RESET. Drag orbits, wheel zooms, shift-drag (or a right-drag) pans,
* double-click or the Reset button restores the opening view. Arrow keys orbit, shift +
* arrows pan, `+`/`-` zoom and `0` resets, so the viewer is usable without a pointer.
*
* WHAT THE PANEL WILL NOT SAY. It never calls the model print-ready. It reports the checks
* that ran — edge counts (watertight per body), winding via signed volume, body count,
* triangle count, bounding size in millimetres — and it lists the checks that did NOT run
* (self-intersection, wall thickness, overhangs, a slicer import). A model that renders is
* a model that renders; that is all.
*
* EXPORT IS THE READER'S CLICK. STL and 3MF are generated here, saved through the artifact
* store, and handed to the browser as a download. The sentence under the button says the
* browser saves the copy and Oqe never writes to that folder, and nothing here claims the
* file was printed, sliced or opened elsewhere.
*/
function startBrowserDownload(url, name) {
	const anchor = document.createElement("a");
	anchor.href = url;
	anchor.download = name;
	anchor.rel = "noopener";
	document.body.appendChild(anchor);
	anchor.click();
	anchor.remove();
}
function draw(canvas, mesh, report, view) {
	const context = canvas.getContext("2d");
	if (!context || !mesh.ok || !report) return;
	const ratio = Math.min(2, globalThis.devicePixelRatio || 1);
	const width = canvas.clientWidth;
	const height = canvas.clientHeight;
	if (width === 0 || height === 0) return;
	if (canvas.width !== Math.round(width * ratio) || canvas.height !== Math.round(height * ratio)) {
		canvas.width = Math.round(width * ratio);
		canvas.height = Math.round(height * ratio);
	}
	context.setTransform(ratio, 0, 0, ratio, 0, 0);
	context.clearRect(0, 0, width, height);
	const triangles = projectMesh(mesh.mesh, report, view, width, height);
	const outlines = triangles.length < 8e3;
	for (const triangle of triangles) {
		const [a, b, c] = triangle.points;
		context.beginPath();
		context.moveTo(a.x, a.y);
		context.lineTo(b.x, b.y);
		context.lineTo(c.x, c.y);
		context.closePath();
		const tone = Math.round(120 + 115 * triangle.shade);
		context.fillStyle = `rgb(${tone}, ${tone - 8}, ${tone - 22})`;
		context.fill();
		if (outlines) {
			context.strokeStyle = "rgba(10, 10, 11, 0.35)";
			context.lineWidth = .6;
			context.stroke();
		}
	}
	const originX = 26;
	const originY = height - 26;
	const axis = 18;
	const yaw = view.yaw * Math.PI / 180;
	const pitch = view.pitch * Math.PI / 180;
	const axes = [
		[
			"X",
			1,
			0,
			0
		],
		[
			"Y",
			0,
			1,
			0
		],
		[
			"Z",
			0,
			0,
			1
		]
	];
	context.font = "9px ui-monospace, monospace";
	context.lineWidth = 1;
	for (const [label, x, y, z] of axes) {
		const x1 = x * Math.cos(yaw) + y * Math.sin(yaw);
		const screenZ = (-x * Math.sin(yaw) + y * Math.cos(yaw)) * Math.sin(pitch) + z * Math.cos(pitch);
		context.strokeStyle = "rgba(243, 238, 227, 0.28)";
		context.beginPath();
		context.moveTo(originX, originY);
		context.lineTo(originX + x1 * axis, originY - screenZ * axis);
		context.stroke();
		context.fillStyle = "rgba(243, 238, 227, 0.45)";
		context.fillText(label, originX + x1 * axis * 1.25 - 2, originY - screenZ * axis * 1.25 + 3);
	}
}
function OutputMesh({ block }) {
	const built = (0, import_react.useMemo)(() => buildMesh(block.recipe), [block.recipe]);
	const report = (0, import_react.useMemo)(() => built.ok ? inspectMesh(built.mesh) : null, [built]);
	const [view, setView] = (0, import_react.useState)(() => resetView());
	const canvasRef = (0, import_react.useRef)(null);
	const drag = (0, import_react.useRef)(null);
	const [phase, setPhase] = (0, import_react.useState)("idle");
	const [artifact, setArtifact] = (0, import_react.useState)(null);
	const [format, setFormat] = (0, import_react.useState)(null);
	const [reason, setReason] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		const canvas = canvasRef.current;
		if (!canvas) return;
		draw(canvas, built, report, view);
	}, [
		built,
		report,
		view
	]);
	(0, import_react.useEffect)(() => {
		const canvas = canvasRef.current;
		if (!canvas || typeof ResizeObserver === "undefined") return;
		const observer = new ResizeObserver(() => draw(canvas, built, report, view));
		observer.observe(canvas);
		return () => observer.disconnect();
	}, [
		built,
		report,
		view
	]);
	const onWheel = (0, import_react.useCallback)((event) => {
		event.preventDefault();
		setView((current) => zoomBy(current, event.deltaY > 0 ? 1.08 : .92));
	}, []);
	(0, import_react.useEffect)(() => {
		const canvas = canvasRef.current;
		if (!canvas) return;
		canvas.addEventListener("wheel", onWheel, { passive: false });
		return () => canvas.removeEventListener("wheel", onWheel);
	}, [onWheel]);
	async function save(as) {
		if (phase === "saving") return;
		if (!built.ok) {
			setReason(built.reason);
			setPhase("failed");
			return;
		}
		setPhase("saving");
		setFormat(as);
		const exported = exportMesh(built.mesh, as, block.title);
		if (!exported.ok) {
			setReason(exported.reason);
			setPhase("failed");
			return;
		}
		const stored = await createBinaryArtifact({
			bytes: exported.bytes,
			kind: as,
			name: exported.name,
			origin: "3D model exported from a reply"
		});
		if (!stored.ok) {
			setReason(stored.reason);
			setPhase("failed");
			return;
		}
		setArtifact(stored.artifact);
		setPhase("saved");
		startBrowserDownload(artifactDownloadUrl(stored.artifact.id), stored.artifact.name);
	}
	if (!built.ok) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "my-3 flex items-start gap-2 rounded-md bg-well px-3 py-2",
		role: "status",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
			className: "mt-0.5 size-4 shrink-0 text-warn",
			"aria-hidden": "true"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-fg",
			children: "This 3D model could not be built."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-meta leading-relaxed text-muted",
			children: built.reason
		})] })]
	});
	const size = report ? describeSize(report) : "";
	const printable = report?.watertight === true && report?.windingConsistent === true;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
		className: "my-3 overflow-hidden rounded-md bg-surface shadow-[0_0_0_1px_var(--color-border)]",
		"aria-label": `3D model: ${block.title}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-2 border-b border-border/60 px-3 py-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex min-w-0 items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "readout shrink-0 text-faint",
						children: "3D model"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "min-w-0 truncate text-meta text-fg",
						title: block.title,
						children: block.title
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-meta text-faint",
					children: size
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative bg-[radial-gradient(circle_at_50%_35%,rgb(33_33_37),rgb(10_10_11))]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
						ref: canvasRef,
						tabIndex: 0,
						className: "block h-[20rem] w-full cursor-grab touch-none select-none focus-visible:outline-2 focus-visible:-outline-offset-2 focus-visible:outline-[color:var(--color-accent)] active:cursor-grabbing",
						"aria-label": `Interactive view of ${block.title}. ${size}. Drag to orbit, wheel to zoom, shift-drag to pan. Arrow keys orbit, shift and arrows pan, plus and minus zoom, zero resets.`,
						onPointerDown: (event) => {
							event.target.setPointerCapture?.(event.pointerId);
							drag.current = {
								pointerId: event.pointerId,
								mode: event.shiftKey || event.button === 2 ? "pan" : "orbit",
								x: event.clientX,
								y: event.clientY
							};
						},
						onPointerMove: (event) => {
							const current = drag.current;
							if (!current || current.pointerId !== event.pointerId) return;
							const dx = event.clientX - current.x;
							const dy = event.clientY - current.y;
							current.x = event.clientX;
							current.y = event.clientY;
							setView((state) => current.mode === "pan" ? panBy(state, dx, dy) : orbit(state, dx * .4, -dy * .4));
						},
						onPointerUp: (event) => {
							drag.current = null;
							event.target.releasePointerCapture?.(event.pointerId);
						},
						onPointerCancel: () => {
							drag.current = null;
						},
						onContextMenu: (event) => event.preventDefault(),
						onDoubleClick: () => setView(resetView()),
						onKeyDown: (event) => {
							const step = event.shiftKey ? 12 : 4;
							if (event.key === "ArrowLeft" || event.key === "ArrowRight") {
								event.preventDefault();
								const delta = event.key === "ArrowLeft" ? -step : step;
								setView((state) => event.shiftKey ? panBy(state, delta, 0) : orbit(state, delta, 0));
							} else if (event.key === "ArrowUp" || event.key === "ArrowDown") {
								event.preventDefault();
								const delta = event.key === "ArrowUp" ? step : -step;
								setView((state) => event.shiftKey ? panBy(state, 0, -delta) : orbit(state, 0, delta));
							} else if (event.key === "+" || event.key === "=") {
								event.preventDefault();
								setView((state) => zoomBy(state, .9));
							} else if (event.key === "-") {
								event.preventDefault();
								setView((state) => zoomBy(state, 1.1));
							} else if (event.key === "0") {
								event.preventDefault();
								setView(resetView());
							}
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "pointer-events-none absolute bottom-1.5 right-2 text-meta text-faint",
						children: "Z is up · mm"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "absolute right-2 top-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "button",
							size: "sm",
							variant: "ghost",
							className: "px-1.5 text-meta text-muted hover:text-fg",
							onClick: () => setView(resetView()),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {
								className: "size-3",
								"aria-hidden": "true"
							}), "Reset view"]
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 border-t border-border/40 px-3 py-2 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-1 text-meta font-medium uppercase tracking-wide text-faint",
					children: "Checks run"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "space-y-0.5 text-meta leading-relaxed text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
							report.triangles.toLocaleString(),
							" triangles · ",
							report.vertices.toLocaleString(),
							" ",
							"vertices · ",
							report.bodies,
							" closed ",
							report.bodies === 1 ? "body" : "bodies"
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
							"Watertight per body:",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: report.watertight ? "text-[color:var(--color-ok)]" : "text-[color:var(--color-danger)]",
								children: report.watertight ? "yes — every edge shared by two triangles" : `no — ${report.openEdges} open, ${report.nonManifoldEdges} non-manifold`
							})
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
							"Winding:",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: report.windingConsistent ? "text-[color:var(--color-ok)]" : "text-[color:var(--color-danger)]",
								children: report.windingConsistent ? `outward (signed volume ${Math.round(report.volumeMm3).toLocaleString()} mm³)` : "inconsistent (signed volume is not positive)"
							})
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
							"Size: ",
							size,
							" (millimetres)"
						] })
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-1 text-meta font-medium uppercase tracking-wide text-faint",
						children: "Not checked"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "list-disc pl-4 text-meta leading-relaxed text-faint",
						children: report.notChecked.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: item }, item))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-meta leading-relaxed text-faint",
						children: printable ? "The mesh is closed and wound outward. That is not a print-readiness claim: nothing here was sliced or printed." : "This mesh is not closed, so it is not a solid. Do not treat it as printable."
					})
				] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "border-t border-border/40 px-3 py-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-1 text-meta font-medium uppercase tracking-wide text-faint",
					children: "Parts"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "flex flex-wrap gap-x-3 gap-y-1 text-meta text-muted",
					children: built.mesh.bodies.map((body) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-fg",
							children: body.id
						}),
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-faint",
							children: [
								body.shape,
								" · ",
								body.triangleCount,
								" tris"
							]
						})
					] }, body.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "border-t border-border/60 px-3 py-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-1.5",
					children: [MESH_EXPORT_FORMATS.map((entry) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "button",
						size: "sm",
						variant: entry.id === "stl" ? "secondary" : "ghost",
						disabled: phase === "saving",
						onClick: () => void save(entry.id),
						title: entry.note,
						children: [
							phase === "saving" && format === entry.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
								className: "size-3.5 animate-spin",
								"aria-hidden": "true"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {
								className: "size-3.5",
								"aria-hidden": "true"
							}),
							"Export ",
							entry.label
						]
					}, entry.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-meta text-faint",
						children: "Z-up, millimetres"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					role: "status",
					"aria-live": "polite",
					className: "mt-1 text-meta leading-relaxed",
					children: [
						phase === "saved" && artifact ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-muted",
								children: [
									"Asked your browser to download",
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-fg",
										children: artifact.name
									}),
									" (",
									artifact.mediaType,
									")."
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-faint",
								children: describeDownload()
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-faint",
								children: describeStoredCopy(artifact.state === "saved" ? "saved" : "transient")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: artifactDownloadUrl(artifact.id),
								download: artifact.name,
								className: "inline-block text-meta text-muted underline decoration-border underline-offset-2 hover:text-fg",
								children: "Download again if your browser blocked it"
							})
						] }) : null,
						phase === "failed" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "flex items-start gap-1.5 text-warn",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
								className: "mt-0.5 size-3 shrink-0",
								"aria-hidden": "true"
							}), reason]
						}) : null,
						phase === "idle" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-faint",
							children: "Two formats are generated here, each tested by reading it back: binary STL and 3MF. A 3MF carries the unit and the body names; STL carries neither."
						}) : null
					]
				})]
			}),
			block.caption ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", {
				className: "border-t border-border/60 px-3 py-1.5 text-meta text-faint",
				children: block.caption
			}) : null
		]
	});
}
/**
* Prompt 44 — a UI PROTOTYPE, drawn from validated primitives.
*
* WHAT RUNS HERE: this build's own React components, over a tree the parser already
* reduced to eight primitives. What does NOT run: anything the reply wrote that could
* be code. There is no `dangerouslySetInnerHTML`, no HTML string, no `style` attribute
* from the model, no `href`, no `src`, no iframe and no URL — the parser drops every key
* it does not name, and the renderer only knows the primitives below. That is why this
* needs no sandbox: there is no generated code to sandbox. A reply that wants a real
* HTML/CSS/JS page is refused at the schema ("unsupported element"), and the sentence it
* gets is honest rather than a broken frame.
*
* INTERACTION IS LOCAL, AND SAID SO. Tabs switch, fields accept typing, buttons report
* that they were pressed into one sentence in this panel. Nothing is submitted, fetched,
* stored or announced to the rest of the app: the only state is this component's. The
* status line spells that out the first time, and the footer says the preview is not a
* deployed page, because a convincing mock-up is exactly the thing a reader might
* mistake for one.
*
* THE DESIGN DIRECTION IS OQE'S, not a generic dashboard: charcoal plates, hairline
* borders, amber only where the real interface spends it. A prototype is a sketch of
* THIS product's language unless the reply's `purpose` says it is something else — and
* even then the frame stays Oqe's, so the preview never pretends to be a live page in
* another brand.
*/
var GAP_CLASS = {
	none: "gap-0",
	tight: "gap-1.5",
	normal: "gap-3",
	wide: "gap-5"
};
var TEXT_CLASS = {
	title: "text-[1.0625rem] font-semibold leading-snug text-fg",
	body: "text-sm leading-relaxed text-fg",
	caption: "text-meta leading-relaxed text-muted",
	meta: "text-meta text-faint"
};
var BADGE_CLASS = {
	neutral: "bg-surface-2 text-muted",
	accent: "bg-accent/12 text-[color:var(--color-accent)]",
	ok: "bg-ok/12 text-[color:var(--color-ok)]",
	warn: "bg-warn/12 text-[color:var(--color-warn)]",
	danger: "bg-danger/12 text-[color:var(--color-danger)]"
};
var BUTTON_VARIANT = {
	primary: "primary",
	secondary: "secondary",
	ghost: "ghost",
	danger: "danger"
};
/** A field keeps its own value. It is never read by anything but its own box. */
function PrototypeField({ node, disabled }) {
	const id = (0, import_react.useId)();
	const helpId = `${id}-help`;
	const [value, setValue] = (0, import_react.useState)(node.value ?? "");
	const [checked, setChecked] = (0, import_react.useState)(false);
	const off = disabled || node.disabled === true;
	const common = {
		id,
		disabled: off,
		"aria-describedby": node.help ? helpId : void 0,
		className: "min-h-9 w-full rounded-sm bg-well px-2.5 text-sm text-fg shadow-[inset_0_0_0_1px_var(--color-border)] placeholder:text-faint focus-visible:shadow-[inset_0_0_0_1px_var(--color-accent)] focus-visible:outline-none disabled:opacity-50"
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-w-0",
		children: [node.control === "checkbox" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				id,
				type: "checkbox",
				checked,
				disabled: off,
				onChange: (event) => setChecked(event.target.checked),
				"aria-describedby": node.help ? helpId : void 0,
				className: "size-3.5 rounded-sm accent-[color:var(--color-accent)] disabled:opacity-50"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
				htmlFor: id,
				className: "text-sm text-fg",
				children: node.label
			})]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
			htmlFor: id,
			className: "mb-1 block text-meta text-muted",
			children: node.label
		}), node.control === "textarea" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
			...common,
			rows: 3,
			value,
			placeholder: node.placeholder,
			onChange: (event) => setValue(event.target.value)
		}) : node.control === "select" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
			...common,
			value,
			onChange: (event) => setValue(event.target.value),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
				value: "",
				children: node.placeholder ?? "Choose…"
			}), (node.options ?? []).map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
				value: option,
				children: option
			}, option))]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			...common,
			type: "text",
			value,
			placeholder: node.placeholder,
			onChange: (event) => setValue(event.target.value)
		})] }), node.help ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			id: helpId,
			className: "mt-1 text-meta leading-relaxed text-faint",
			children: node.help
		}) : null]
	});
}
/** Tabs hold no state outside themselves; switching one changes nothing else. */
function PrototypeTabs({ node, onActivate, disabled, depth }) {
	const [active, setActive] = (0, import_react.useState)(0);
	const current = node.tabs[Math.min(active, node.tabs.length - 1)];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-w-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-2 flex flex-wrap gap-1 rounded-sm bg-well p-0.5 shadow-[inset_0_0_0_1px_var(--color-border)]",
			role: "group",
			"aria-label": "Preview tabs",
			children: node.tabs.map((tab, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				"aria-pressed": index === active,
				disabled,
				onClick: () => {
					setActive(index);
					onActivate(`Switched to the “${tab.label}” view. This preview changes nothing.`);
				},
				className: `rounded-sm px-2 py-0.5 text-meta transition-colors duration-150 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[color:var(--color-accent)] disabled:opacity-45 ${index === active ? "bg-surface-2 text-fg" : "text-muted hover:text-fg"}`,
				children: tab.label
			}, `${tab.label}-${index}`))
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "min-w-0",
			children: current.children.map((child, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrototypeNodeView, {
				node: child,
				onActivate,
				disabled,
				depth: depth + 1
			}, index))
		})]
	});
}
function PrototypeNodeView({ node, onActivate, disabled, depth }) {
	switch (node.kind) {
		case "stack": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: `flex min-w-0 ${node.direction === "row" ? "flex-row flex-wrap items-center" : "flex-col"} ${GAP_CLASS[node.gap ?? "normal"]}`,
			children: node.children.map((child, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrototypeNodeView, {
				node: child,
				onActivate,
				disabled,
				depth: depth + 1
			}, index))
		});
		case "panel": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "min-w-0 rounded-md bg-surface-2/60 p-3 shadow-[0_0_0_1px_var(--color-border)]",
			children: [node.title ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
				className: "mb-2 text-meta font-medium uppercase tracking-wide text-faint",
				children: node.title
			}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex min-w-0 flex-col gap-2.5",
				children: node.children.map((child, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrototypeNodeView, {
					node: child,
					onActivate,
					disabled,
					depth: depth + 1
				}, index))
			})]
		});
		case "tabs": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrototypeTabs, {
			node,
			onActivate,
			disabled,
			depth
		});
		case "text": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: TEXT_CLASS[node.tone ?? "body"],
			children: node.text
		});
		case "badge": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: `inline-flex items-center rounded-full px-2 py-0.5 text-meta ${BADGE_CLASS[node.tone ?? "neutral"]}`,
			children: node.label
		});
		case "divider": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("hr", { className: "my-1 border-0 border-t border-border" });
		case "button": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			type: "button",
			size: "sm",
			variant: BUTTON_VARIANT[node.variant ?? "secondary"],
			disabled: disabled || node.disabled === true,
			onClick: () => onActivate(node.note ?? `“${node.label}” was pressed in the preview. Nothing happened.`),
			children: node.label
		});
		case "field": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "w-full min-w-[12rem]",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrototypeField, {
				node,
				disabled
			})
		});
	}
}
var VIEWPORT_CLASS = {
	auto: "",
	phone: "mx-auto w-full max-w-[22rem]",
	desktop: "w-full"
};
function OutputPrototype({ block }) {
	const titleId = (0, import_react.useId)();
	const [note, setNote] = (0, import_react.useState)("");
	const [resetKey, setResetKey] = (0, import_react.useState)(0);
	const [frozen, setFrozen] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
		className: "my-3 overflow-hidden rounded-md bg-surface shadow-[0_0_0_1px_var(--color-border)]",
		"aria-labelledby": titleId,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-2 border-b border-border/60 px-3 py-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex min-w-0 items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "readout shrink-0 text-faint",
						children: "prototype"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						id: titleId,
						className: "min-w-0 truncate text-meta text-fg",
						title: block.title,
						children: block.title
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-1.5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-meta text-faint",
							children: block.viewport === "phone" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "inline-flex items-center gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Smartphone, {
									className: "size-3",
									"aria-hidden": "true"
								}), " narrow"]
							}) : block.viewport === "desktop" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "inline-flex items-center gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Monitor, {
									className: "size-3",
									"aria-hidden": "true"
								}), " wide"]
							}) : null
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "button",
							size: "sm",
							variant: "ghost",
							className: "px-1.5 text-meta text-muted hover:text-fg",
							onClick: () => {
								setResetKey((key) => key + 1);
								setNote("Preview reset to its starting state.");
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {
								className: "size-3",
								"aria-hidden": "true"
							}), "Reset"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							size: "sm",
							variant: "ghost",
							"aria-pressed": frozen,
							className: "px-1.5 text-meta text-muted hover:text-fg",
							onClick: () => {
								setFrozen((value) => !value);
								setNote(frozen ? "Preview is interactive again." : "Preview frozen — its controls no longer respond.");
							},
							children: frozen ? "Unfreeze" : "Freeze"
						})
					]
				})]
			}),
			block.purpose ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "border-b border-border/40 px-3 py-1.5 text-meta leading-relaxed text-muted",
				children: block.purpose
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "px-3 py-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: `${VIEWPORT_CLASS[block.viewport ?? "auto"]}`,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: `rounded-md bg-bg p-3 shadow-[inset_0_0_0_1px_var(--color-border)] ${block.viewport === "phone" ? "min-h-[26rem]" : ""}`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex min-w-0 flex-col gap-2.5",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrototypeNodeView, {
								node: block.root,
								onActivate: setNote,
								disabled: frozen,
								depth: 0
							})
						}, resetKey)
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "border-t border-border/60 px-3 py-1.5",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-meta leading-relaxed text-faint",
					role: "status",
					"aria-live": "polite",
					children: note || "A preview of an interface, drawn from validated blocks — not a deployed page, and its controls only change what is on this card."
				})
			}),
			block.caption ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", {
				className: "border-t border-border/60 px-3 py-1.5 text-meta text-faint",
				children: block.caption
			}) : null
		]
	});
}
/**
* Prompt 44 — a SIMULATION, computed by this build's own arithmetic.
*
* WHAT THIS IS. The reply names one of four registered models and supplies starting
* numbers. `simulation.ts` computes the series — deterministically, with no clock and no
* randomness — and this panel lets the reader play it forward, step it, reset it and
* move its parameters. Nothing here executes reply-supplied code, which is why it works
* at all on this machine: the Prompt 40 isolation boundary is unavailable here, and
* drawing a chart of a savings balance never needed it.
*
* BOUNDED AT EVERY LEVEL. The period count is capped by the schema (2–600) and clamped
* again by `runSimulation`; a parameter can only move between the bounds the MODEL
* declares, so a reply cannot widen one; the strip draws at most 120 bars however long
* the run, and the playback timer is cleared on unmount, on pause, on reset and on the
* last period. There is no unbounded loop and no accumulating history.
*
* HONEST LABELS. The card says simulation, the numbers panel separates supplied inputs
* from computed results, and the assumptions are listed twice over: what the MODEL
* assumes (written here, in the source) and what the REPLY assumed (its own words, shown
* apart). The footer says it is not real-world data or a forecast.
*/
/** The bar strip. Decorative: every number in it is also in the panel below. */
function SeriesStrip({ series, cursor, ticks, model }) {
	const sampled = sampleSeries(series);
	const min = Math.min(...series);
	const span = Math.max(...series) - min || 1;
	const revealed = Math.max(1, Math.round(cursor / ticks * sampled.length));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-3 py-2",
		"aria-hidden": "true",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex h-24 items-end gap-[2px]",
			children: sampled.map((value, index) => {
				const height = Math.max(2, (value - min) / span * 100);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: `min-w-0 flex-1 rounded-t-[1px] transition-[opacity,background-color] duration-150 ${index < revealed ? "bg-[color:var(--color-accent)]" : "bg-surface-3/70"}`,
					style: { height: `${height}%` }
				}, index);
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-1 flex justify-between text-meta text-faint",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "period 1" }),
				series.length > 120 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
					"every ",
					(series.length / 120).toFixed(1),
					"th period drawn"
				] }) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
					"period ",
					ticks,
					" · ",
					model.seriesLabel
				] })
			]
		})]
	});
}
function OutputSimulation({ block }) {
	const model = (0, import_react.useMemo)(() => simulationModel(block.model), [block.model]);
	const baseId = (0, import_react.useId)();
	const startingValues = (0, import_react.useMemo)(() => {
		const values = {};
		for (const spec of model.parameters) values[spec.id] = spec.value;
		for (const supplied of block.values) values[supplied.id] = supplied.value;
		return values;
	}, [model, block.values]);
	const [values, setValues] = (0, import_react.useState)(startingValues);
	const [cursor, setCursor] = (0, import_react.useState)(1);
	const [playing, setPlaying] = (0, import_react.useState)(false);
	const run = (0, import_react.useMemo)(() => runSimulation({
		model: block.model,
		values,
		ticks: block.ticks
	}), [
		block.model,
		values,
		block.ticks
	]);
	(0, import_react.useEffect)(() => {
		if (!playing) return;
		if (cursor >= run.ticks) {
			setPlaying(false);
			return;
		}
		const timer = setTimeout(() => setCursor((value) => Math.min(run.ticks, value + 1)), model.tickMs);
		return () => clearTimeout(timer);
	}, [
		playing,
		cursor,
		run.ticks,
		model.tickMs
	]);
	const atEnd = cursor >= run.ticks;
	const current = run.series[Math.min(cursor, run.ticks) - 1] ?? run.summary.first;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
		className: "my-3 overflow-hidden rounded-md bg-surface shadow-[0_0_0_1px_var(--color-border)]",
		"aria-label": `Simulation: ${block.title}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-2 border-b border-border/60 px-3 py-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex min-w-0 items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "readout shrink-0 text-faint",
						children: "simulation"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "min-w-0 truncate text-meta text-fg",
						title: block.title,
						children: block.title
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "rounded-full bg-surface-2 px-2 py-0.5 text-meta text-muted",
					children: "arithmetic, not observation"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-1.5 border-b border-border/40 px-3 py-1.5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						size: "sm",
						variant: "primary",
						onClick: () => {
							if (playing) {
								setPlaying(false);
								return;
							}
							if (atEnd) setCursor(1);
							setPlaying(true);
						},
						"aria-label": playing ? "Pause the simulation" : "Play the simulation",
						children: playing ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, {
							className: "size-3.5",
							"aria-hidden": "true"
						}), " Pause"] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {
							className: "size-3.5",
							"aria-hidden": "true"
						}), " Play"] })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "button",
						size: "sm",
						variant: "secondary",
						disabled: atEnd,
						onClick: () => {
							setPlaying(false);
							setCursor((value) => Math.min(run.ticks, value + 1));
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkipForward, {
							className: "size-3.5",
							"aria-hidden": "true"
						}), " Step"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "button",
						size: "sm",
						variant: "ghost",
						onClick: () => {
							setPlaying(false);
							setCursor(1);
							setValues(startingValues);
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {
							className: "size-3.5",
							"aria-hidden": "true"
						}), " Reset"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "ml-auto text-meta text-muted",
						role: "status",
						"aria-live": "polite",
						children: [
							"period ",
							cursor,
							" of ",
							run.ticks
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-baseline gap-x-4 gap-y-1 px-3 pt-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-lg font-semibold text-fg",
					children: [formatValue(current, run.unit), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "ml-1 text-meta font-normal text-faint",
						children: model.seriesLabel
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-meta text-muted",
					children: [
						"start ",
						formatValue(run.summary.first, run.unit),
						" · end",
						" ",
						formatValue(run.summary.last, run.unit),
						" · change",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: run.summary.change < 0 ? "text-[color:var(--color-danger)]" : "text-[color:var(--color-ok)]",
							children: [run.summary.change > 0 ? "+" : "", formatValue(run.summary.change, run.unit)]
						}),
						" ",
						"over ",
						run.ticks,
						" periods"
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SeriesStrip, {
				series: run.series,
				cursor,
				ticks: run.ticks,
				model
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "border-t border-border/40 px-3 py-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-2 text-meta font-medium uppercase tracking-wide text-faint",
					children: "Parameters you supplied"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-col gap-2",
					children: model.parameters.map((spec) => {
						const value = run.values[spec.id] ?? spec.value;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-baseline justify-between gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										htmlFor: `${baseId}-${spec.id}`,
										className: "text-meta text-muted",
										children: spec.label
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-meta text-fg",
										children: formatValue(value, spec.unit ?? run.unit)
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									id: `${baseId}-${spec.id}`,
									type: "range",
									min: spec.min,
									max: spec.max,
									step: spec.step,
									value,
									onChange: (event) => {
										const next = Number(event.target.value);
										setValues((previous) => ({
											...previous,
											[spec.id]: Number.isFinite(next) ? next : spec.value
										}));
									},
									className: "mt-1 h-1 w-full cursor-pointer appearance-none rounded-full bg-surface-3 accent-[color:var(--color-accent)] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[color:var(--color-accent)]"
								}),
								spec.help ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-0.5 text-meta text-faint",
									children: spec.help
								}) : null
							]
						}, spec.id);
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "border-t border-border/40 px-3 py-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-1 text-meta font-medium uppercase tracking-wide text-faint",
						children: "What the model assumes"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "list-disc pl-4 text-meta leading-relaxed text-muted",
						children: run.assumptions.map((assumption) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: assumption }, assumption))
					}),
					block.assumptions && block.assumptions.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 mb-1 text-meta font-medium uppercase tracking-wide text-faint",
						children: "Stated by the reply — not checked"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "list-disc pl-4 text-meta leading-relaxed text-muted",
						children: block.assumptions.map((assumption) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: assumption }, assumption))
					})] }) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start gap-1.5 border-t border-border/60 px-3 py-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "mt-0.5 size-3 shrink-0 text-faint",
					"aria-hidden": "true"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-meta leading-relaxed text-faint",
					children: [
						"A simulation of “",
						model.label,
						"”, not a forecast or measurement. ",
						model.description
					]
				})]
			}),
			block.caption ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", {
				className: "border-t border-border/60 px-3 py-1.5 text-meta text-faint",
				children: block.caption
			}) : null
		]
	});
}
/**
* Prompt 43 — the STRUCTURED DATA view (JSON and a documented YAML subset).
*
* WHAT IT PARSES WITH. `JSON.parse` for JSON — a data parser, not an evaluator. YAML
* has no library here, so `parseYaml` accepts the subset this build documents and
* REFUSES anchors, tags, block scalars, flow collections, tabs in indentation and
* duplicate keys by name. A refusal is shown as readable text with the reason and the
* raw source, which is the honest rendering for a document this build did not
* understand.
*
* NOTHING HERE RUNS. The tree is built from plain objects and arrays and rendered as
* nested lists of text; there is no template, no `eval`, no HTML string and no
* property access driven by the model.
*
* RAW IS ALWAYS AVAILABLE, and it is what is shown when parsing fails. A tree view is
* a convenience; the source is the truth, so a reader can always see exactly what the
* reply sent.
*/
var VALUE_CLASS = {
	object: "text-faint",
	array: "text-faint",
	string: "text-[color:var(--color-ok)]",
	number: "text-[color:var(--color-warn)]",
	boolean: "text-signal",
	null: "text-faint italic",
	omitted: "text-faint italic"
};
function leafText(node) {
	switch (node.kind) {
		case "string": return `"${node.value}"${node.truncated ? "…" : ""}`;
		case "number": return String(node.value);
		case "boolean": return node.value ? "true" : "false";
		case "null": return "null";
		case "omitted": return "… (not shown)";
		default: return "";
	}
}
function DataValue({ node }) {
	if (node.kind === "object" || node.kind === "array") {
		const entries = node.kind === "object" ? node.entries.map((entry) => ({
			key: entry.key,
			value: entry.value
		})) : node.items.map((value, index) => ({
			key: String(index),
			value
		}));
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "text-faint",
				children: [
					node.kind === "object" ? "{" : "[",
					" ",
					entries.length,
					node.truncated ? " shown" : "",
					" ",
					node.kind === "object" ? "}" : "]"
				]
			}), entries.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "ml-1 border-l border-border/60 pl-3",
				children: entries.map((entry, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "min-w-0",
					children: [node.kind === "object" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-fg",
						children: entry.key
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-muted",
						children: ": "
					})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-faint",
						children: [entry.key, ": "]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataValue, { node: entry.value })]
				}, `${entry.key}-${index}`))
			}) : null]
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: `whitespace-pre-wrap break-words ${VALUE_CLASS[node.kind]}`,
		children: leafText(node)
	});
}
function OutputStructured({ block }) {
	const parsed = (0, import_react.useMemo)(() => parseStructured(block.format, block.source), [block.format, block.source]);
	const [view, setView] = (0, import_react.useState)(parsed.ok ? "tree" : "raw");
	const [phase, setPhase] = (0, import_react.useState)("idle");
	const [artifact, setArtifact] = (0, import_react.useState)(null);
	const [reason, setReason] = (0, import_react.useState)("");
	const [copied, setCopied] = (0, import_react.useState)(false);
	async function save() {
		if (phase === "saving") return;
		setPhase("saving");
		const result = await createTextArtifact({
			text: block.source,
			kind: "data",
			format: block.format,
			origin: "structured data from a reply"
		});
		if (!result.ok) {
			setReason(result.reason);
			setPhase("failed");
			return;
		}
		setArtifact(result.artifact);
		setPhase("saved");
		const anchor = document.createElement("a");
		anchor.href = artifactDownloadUrl(result.artifact.id);
		anchor.download = result.artifact.name;
		anchor.rel = "noopener";
		document.body.appendChild(anchor);
		anchor.click();
		anchor.remove();
	}
	const label = block.format === "json" ? "JSON" : "YAML";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
		className: "my-3 overflow-hidden rounded-md bg-surface shadow-[0_0_0_1px_var(--color-border)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-2 border-b border-border/60 px-3 py-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex min-w-0 items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "readout shrink-0 text-faint",
						children: label
					}), block.title ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "min-w-0 truncate text-meta text-fg",
						title: block.title,
						children: block.title
					}) : null]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex rounded-sm bg-well p-0.5 shadow-[inset_0_0_0_1px_var(--color-border)]",
						role: "group",
						"aria-label": "View",
						children: ["tree", "raw"].map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-pressed": view === option,
							onClick: () => setView(option),
							disabled: option === "tree" && !parsed.ok,
							className: `rounded-sm px-1.5 py-0.5 text-meta capitalize focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[color:var(--color-accent)] disabled:opacity-40 ${view === option ? "bg-surface-2 text-fg" : "text-muted hover:text-fg"}`,
							children: option
						}, option))
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "rounded px-1.5 py-0.5 text-meta text-muted hover:bg-bg hover:text-fg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[color:var(--color-accent)]",
						onClick: () => {
							navigator.clipboard?.writeText(block.source).then(() => setCopied(true), () => setCopied(false));
						},
						"aria-label": `Copy this ${label}`,
						children: copied ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "inline-flex items-center gap-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
								className: "size-3",
								"aria-hidden": "true"
							}), " Copied"]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "inline-flex items-center gap-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {
								className: "size-3",
								"aria-hidden": "true"
							}), " Copy"]
						})
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "px-3 py-1 text-meta text-faint",
				children: parsed.ok ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [describeNode(parsed.node), parsed.truncated ? " · larger than this view draws, so it is truncated" : ""] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-warn",
					children: [
						"Not parsed as ",
						label,
						" — shown as text."
					]
				})
			}),
			!parsed.ok ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-3 mb-1 flex items-start gap-1.5 rounded-sm bg-well px-2 py-1.5",
				role: "status",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "mt-0.5 size-3 shrink-0 text-warn",
					"aria-hidden": "true"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-meta leading-relaxed text-muted",
					children: parsed.reason
				})]
			}) : null,
			parsed.ok && view === "tree" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "max-h-96 overflow-auto px-3 py-2 font-mono text-xs leading-relaxed",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataValue, { node: parsed.node })
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
				className: "max-h-96 overflow-auto px-3 py-2 text-xs leading-relaxed",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
					className: "whitespace-pre text-fg",
					children: block.source
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "border-t border-border/60 px-3 py-1.5 text-meta text-faint",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "button",
						variant: "ghost",
						size: "sm",
						onClick: () => void save(),
						disabled: phase === "saving",
						className: "px-1.5 text-muted hover:text-fg",
						children: [phase === "saving" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
							className: "size-3.5 animate-spin",
							"aria-hidden": "true"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {
							className: "size-3.5",
							"aria-hidden": "true"
						}), phase === "saving" ? "Saving…" : `Save as a .${block.format === "json" ? "json" : "yaml"} file`]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						role: "status",
						"aria-live": "polite",
						children: [phase === "saved" && artifact ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-muted",
								children: [
									"Asked your browser to download ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-fg",
										children: artifact.name
									}),
									"."
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: describeDownload() }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: describeStoredCopy(artifact.state === "saved" ? "saved" : "transient") })
						] }) : null, phase === "failed" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-warn",
							children: reason
						}) : null]
					}),
					block.caption ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1",
						children: block.caption
					}) : null
				]
			})
		]
	});
}
/**
* Prompt 41 — the WALKTHROUGH SESSION, as a value.
*
* The lesson's behaviour is here rather than inside the component because "what
* does Next do on the last step", "does Back wrap", "what survives a reset" are
* decisions with right answers, and a decision buried in an `onClick` can only be
* tested by driving a browser. This module is pure: no React, no storage, no clock.
*
* THREE RULES IT KEEPS
*
*  1. THE SESSION IS MEMORY-ONLY. There is no `localStorage`, no database, no
*     export path here: a lesson the reader did not ask to keep is gone when the
*     message unmounts. `resetSession()` is total — every answer, hint and reveal.
*  2. REVEALS ARE THE READER'S ACTIONS. `revealHint` and `revealAnswer` are two
*     separate functions over two separate steps, and nothing reveals an answer as
*     a side effect of arriving at a step (including the last one).
*  3. NOTHING IS GRADED. `results` reports what the reader DID (answered, opened a
*     hint, compared an answer) and never whether it was right. There is no
*     notion of a score here, because a client-side comparison is not an
*     assessment and must not be presented as one.
*/
var EMPTY_WALKTHROUGH_SESSION = Object.freeze({
	index: 0,
	hints: [],
	answers: [],
	responses: {},
	finished: false
});
function clampIndex(index, count) {
	if (!Number.isFinite(index) || count <= 0) return 0;
	return Math.min(Math.max(0, Math.trunc(index)), count - 1);
}
function has(list, step) {
	return list.includes(step);
}
function withValue(list, step) {
	return has(list, step) ? [...list] : [...list, step].sort((a, b) => a - b);
}
function startSession() {
	return EMPTY_WALKTHROUGH_SESSION;
}
/** Next stops at the last step; it never wraps to the beginning. */
function goNext(session, count) {
	if (count <= 0) return session;
	const next = clampIndex(session.index + 1, count);
	if (next === session.index) return session;
	return {
		...session,
		index: next
	};
}
/** Back stops at the first step; it never wraps to the end. */
function goBack(session, count) {
	if (count <= 0) return session;
	const next = clampIndex(session.index - 1, count);
	if (next === session.index) return session;
	return {
		...session,
		index: next
	};
}
/** Jump to a step (the results panel's "review this step" control). */
function goToStep(session, index, count) {
	return {
		...session,
		index: clampIndex(index, count),
		finished: false
	};
}
function revealHint(session, step) {
	return {
		...session,
		hints: withValue(session.hints, step)
	};
}
function revealAnswer(session, step) {
	return {
		...session,
		answers: withValue(session.answers, step)
	};
}
/**
* Store a typed response.
*
* Capped at the schema's limit and stored as typed (newlines preserved) — a lesson
* about code or prose needs its line breaks. An empty response removes the entry,
* so "not answered" and "answered with nothing" are not two states.
*/
function setResponse(session, step, text) {
	const capped = text.slice(0, MAX_WALKTHROUGH_RESPONSE_CHARS);
	const responses = { ...session.responses };
	if (capped.trim().length === 0) delete responses[step];
	else responses[step] = capped;
	return {
		...session,
		responses
	};
}
/** Everything goes: index, hints, answers, responses, the finished flag. */
function resetSession() {
	return EMPTY_WALKTHROUGH_SESSION;
}
function finishSession(session, count) {
	if (count <= 0) return session;
	return {
		...session,
		finished: true
	};
}
function reopenSession(session, count) {
	return {
		...session,
		finished: false,
		index: clampIndex(session.index, count)
	};
}
function isFirstStep(session) {
	return session.index <= 0;
}
function isLastStep(session, count) {
	return count > 0 && session.index >= count - 1;
}
/** `current` is one-based for display; `percent` is the fraction of steps reached. */
function progress(session, count) {
	const total = Math.max(0, count);
	if (total === 0) return {
		current: 0,
		total: 0,
		percent: 0
	};
	const index = clampIndex(session.index, total);
	return {
		current: index + 1,
		total,
		percent: Math.round((index + 1) / total * 100)
	};
}
function stepState(session, step) {
	const response = session.responses[step] ?? "";
	return {
		hintShown: has(session.hints, step),
		answerShown: has(session.answers, step),
		response,
		answered: response.trim().length > 0
	};
}
/**
* The results panel's data: what happened, step by step. Never a verdict.
*
* `asked` means the step had a prompt, so "answered: false" on it says something;
* on a reading step the two are simply not applicable and the UI says so.
*/
function results(session, block) {
	return block.steps.map((step, index) => {
		const state = stepState(session, index);
		return {
			step: index,
			position: index + 1,
			title: step.title,
			asked: Boolean(step.prompt),
			answered: state.answered,
			hintUsed: state.hintShown,
			answerCompared: state.answerShown,
			response: state.response
		};
	});
}
function resultCounts(session, block) {
	const rows = results(session, block);
	return {
		total: rows.length,
		asked: rows.filter((row) => row.asked).length,
		answered: rows.filter((row) => row.asked && row.answered).length,
		hintUsed: rows.filter((row) => row.hintUsed).length,
		answerCompared: rows.filter((row) => row.answerCompared).length
	};
}
/**
* A copyable transcript of the reader's OWN work.
*
* Deliberately excludes the reference answers: copying them out would hand over the
* thing the reader may still want to attempt, and the transcript is meant to be
* their notes, not an answer key.
*/
function summaryText(session, block) {
	const lines = [`${block.title}`];
	if (block.intro) lines.push("", block.intro);
	for (const row of results(session, block)) {
		lines.push("", `${row.position}. ${row.title}`);
		if (row.asked) lines.push(row.answered ? `Your answer: ${row.response}` : "Your answer: (not written)");
		if (row.hintUsed) lines.push("Hint: opened");
		if (row.answerCompared) lines.push("Reference answer: compared");
	}
	return lines.join("\n");
}
var DEFAULT_EXECUTION = {
	available: false,
	reason: "No isolated executor is installed on this machine, so this example was not run. Turning it on is a separate decision in Settings."
};
var RUN_LABELS = {
	completed: "Ran to completion",
	failed: "Ran and failed",
	"timed-out": "Stopped at the time limit",
	cancelled: "Stopped by you",
	error: "Could not run",
	refused: "Did not run"
};
function OutputWalkthrough({ block, policy = DEFAULT_OUTPUT_POLICY, execution = DEFAULT_EXECUTION }) {
	const count = block.steps.length;
	const [session, setSession] = (0, import_react.useState)(() => startSession());
	const [confirmReset, setConfirmReset] = (0, import_react.useState)(false);
	const [copied, setCopied] = (0, import_react.useState)("idle");
	const [runs, setRuns] = (0, import_react.useState)({});
	const [running, setRunning] = (0, import_react.useState)(null);
	const progressInfo = (0, import_react.useMemo)(() => progress(session, count), [session, count]);
	const rows = (0, import_react.useMemo)(() => results(session, block), [session, block]);
	const counts = (0, import_react.useMemo)(() => resultCounts(session, block), [session, block]);
	const baseId = (0, import_react.useId)();
	const stepTitleId = `${baseId}-step-title`;
	const liveId = `${baseId}-live`;
	const regionRef = (0, import_react.useRef)(null);
	const navigated = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		if (navigated.current) regionRef.current?.focus();
	}, [session.index, session.finished]);
	function navigate(next) {
		navigated.current = true;
		setConfirmReset(false);
		setSession(next);
	}
	if (count === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "my-3 rounded-md bg-surface px-3 py-2 text-meta text-muted shadow-[0_0_0_1px_var(--color-border)]",
		role: "status",
		children: "This walkthrough has no steps."
	});
	const step = block.steps[Math.min(session.index, count - 1)];
	const state = stepState(session, session.index);
	const diagramDecision = decideRender("diagram", policy);
	const imageDecision = decideRender("image", policy);
	const allowArtifactFetch = policy.allowArtifactFetch !== false;
	const last = isLastStep(session, count);
	async function runCode() {
		if (!execution.available || !execution.run || !step.code) return;
		setRunning(session.index);
		try {
			const result = await execution.run(step.code, session.index);
			setRuns((current) => ({
				...current,
				[session.index]: result
			}));
		} catch {
			setRuns((current) => ({
				...current,
				[session.index]: {
					status: "error",
					command: "",
					exitCode: null,
					output: "",
					truncated: false,
					note: "The run could not be started, so nothing was executed."
				}
			}));
		} finally {
			setRunning(null);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
		className: "my-3 overflow-hidden rounded-md bg-surface shadow-[0_0_0_1px_var(--color-border)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "border-b border-border/60 px-3 py-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-baseline justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "readout text-faint",
							children: [
								"Walkthrough · ",
								count,
								" step",
								count === 1 ? "" : "s"
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono text-meta text-muted",
							"aria-hidden": "true",
							children: session.finished ? "Results" : `${progressInfo.current}/${progressInfo.total}`
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mt-0.5 text-sm font-medium text-fg",
						children: block.title
					}),
					block.intro ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-1 text-meta leading-relaxed text-muted",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MarkdownView, { text: block.intro })
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2 h-0.5 w-full overflow-hidden rounded bg-surface-2",
						role: "progressbar",
						"aria-label": "Lesson progress",
						"aria-valuemin": 0,
						"aria-valuemax": count,
						"aria-valuenow": session.finished ? count : progressInfo.current,
						"aria-valuetext": session.finished ? "Finished" : `Step ${progressInfo.current} of ${progressInfo.total}`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-full rounded bg-[color:var(--color-accent)] transition-[width] duration-200 motion-reduce:transition-none",
							style: { width: `${session.finished ? 100 : progressInfo.percent}%` }
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				id: liveId,
				className: "sr-only",
				role: "status",
				"aria-live": "polite",
				children: session.finished ? `Results for ${block.title}, ${count} steps` : `Step ${progressInfo.current} of ${progressInfo.total}: ${step.title}`
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "px-3 py-2.5",
				children: session.finished ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					ref: regionRef,
					tabIndex: -1,
					role: "region",
					"aria-label": `Results for ${block.title}`,
					className: "focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[color:var(--color-accent)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-fg",
							children: "You reached the end of this walkthrough."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-0.5 text-meta leading-relaxed text-muted",
							children: [
								counts.asked > 0 ? `${counts.answered} of ${counts.asked} question${counts.asked === 1 ? "" : "s"} written${counts.hintUsed > 0 ? `, ${counts.hintUsed} hint${counts.hintUsed === 1 ? "" : "s"} opened` : ""}${counts.answerCompared > 0 ? `, ${counts.answerCompared} reference answer${counts.answerCompared === 1 ? "" : "s"} compared` : ""}.` : "This walkthrough asked nothing to write; the steps are all above.",
								" ",
								"Nothing here is graded."
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
							className: "mt-2 space-y-1",
							children: rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex flex-wrap items-center gap-x-2 gap-y-1 rounded bg-bg/40 px-2 py-1.5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "min-w-0 flex-1 text-meta text-fg",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "font-mono text-faint",
												children: [row.position, "."]
											}),
											" ",
											row.title
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-meta text-muted",
										children: [row.asked ? row.answered ? "answered" : "not written" : "reading step", row.hintUsed ? " · hint opened" : ""]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										className: "rounded px-1.5 py-0.5 text-meta text-muted hover:bg-surface-2 hover:text-fg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[color:var(--color-accent)]",
										onClick: () => navigate(goToStep(session, row.step, count)),
										children: ["Review", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "sr-only",
											children: [" step ", row.position]
										})]
									})
								]
							}, row.step))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 flex flex-wrap items-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									className: "inline-flex items-center gap-1.5 rounded-md bg-surface-2 px-2 py-1 text-meta text-fg shadow-[0_0_0_1px_var(--color-border)] hover:bg-bg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[color:var(--color-accent)]",
									onClick: () => {
										navigator.clipboard?.writeText(summaryText(session, block)).then(() => setCopied("copied"), () => setCopied("failed"));
									},
									children: [copied === "copied" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
										className: "size-3.5",
										"aria-hidden": "true"
									}) : null, copied === "copied" ? "Copied your notes" : "Copy your notes"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "rounded-md px-2 py-1 text-meta text-muted hover:bg-surface-2 hover:text-fg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[color:var(--color-accent)]",
									onClick: () => navigate(reopenSession(session, count)),
									children: "Back to the last step"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									className: "ml-auto inline-flex items-center gap-1.5 rounded-md px-2 py-1 text-meta text-muted hover:bg-surface-2 hover:text-fg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[color:var(--color-accent)]",
									onClick: () => {
										setConfirmReset(false);
										setRuns({});
										setCopied("idle");
										setSession(resetSession());
									},
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {
										className: "size-3.5",
										"aria-hidden": "true"
									}), "Start over"]
								})
							]
						}),
						copied === "failed" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-meta text-muted",
							role: "status",
							children: "This browser did not let the page copy to the clipboard. Select the text above instead."
						}) : null
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					ref: regionRef,
					tabIndex: -1,
					role: "region",
					"aria-labelledby": stepTitleId,
					"aria-describedby": liveId,
					"data-step": session.index,
					className: "focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[color:var(--color-accent)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "readout text-faint",
							children: [
								"Step ",
								progressInfo.current,
								" of ",
								progressInfo.total
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
							id: stepTitleId,
							className: "mt-0.5 text-sm font-medium text-fg",
							children: step.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-1 text-sm leading-relaxed text-muted",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MarkdownView, { text: step.body })
						}),
						step.diagram ? diagramDecision.ok ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OutputDiagram, { block: step.diagram }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "my-2 rounded bg-well px-2 py-1 text-meta text-muted",
							role: "status",
							children: [
								"This step includes a diagram, which ",
								diagramDecision.reason,
								"."
							]
						}) : null,
						step.image ? imageDecision.ok ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OutputImage, {
							block: step.image,
							allowFetch: allowArtifactFetch
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "my-2 rounded bg-well px-2 py-1 text-meta text-muted",
							role: "status",
							children: [
								"This step includes an image, which ",
								imageDecision.reason,
								"."
							]
						}) : null,
						step.code ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
							className: "my-2 overflow-hidden rounded-md bg-bg/40 shadow-[0_0_0_1px_var(--color-border)]",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap items-center justify-between gap-2 border-b border-border/60 px-2.5 py-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "readout text-faint",
										children: ["Example · ", step.code.language]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										disabled: !execution.available || !execution.run || running === session.index,
										"aria-describedby": `${baseId}-run-status`,
										onClick: () => {
											runCode();
										},
										className: "inline-flex items-center gap-1.5 rounded bg-surface-2 px-2 py-1 text-meta text-fg shadow-[0_0_0_1px_var(--color-border)] hover:bg-bg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[color:var(--color-accent)] disabled:cursor-not-allowed disabled:opacity-50",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SquareTerminal, {
											className: "size-3.5",
											"aria-hidden": "true"
										}), running === session.index ? "Running…" : "Run"]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
									className: "max-h-72 overflow-auto px-2.5 py-2 text-xs leading-relaxed",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", { children: step.code.source })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									id: `${baseId}-run-status`,
									className: "border-t border-border/60 px-2.5 py-1.5 text-meta leading-relaxed text-muted",
									children: execution.available ? (() => {
										const view = runs[session.index];
										if (!execution.run) return "This host reports an executor but has no runner wired, so nothing can be run here.";
										if (!view) return running === session.index ? "Running in the isolated executor…" : "Not run yet. Choose Run to execute this example.";
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "space-y-1",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
													className: "text-fg",
													children: [
														RUN_LABELS[view.status],
														view.exitCode !== null ? ` · exit code ${view.exitCode}` : "",
														view.truncated ? " · output truncated" : ""
													]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-faint",
													children: "Command: "
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
													className: "break-all font-mono text-[11px]",
													children: view.command
												})] }),
												view.output ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
													className: "max-h-48 overflow-auto whitespace-pre-wrap rounded bg-bg/60 p-2 font-mono text-[11px] text-fg",
													children: view.output
												}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "No output." }),
												view.note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-faint",
													children: view.note
												}) : null
											]
										});
									})() : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-fg",
											children: "Not executed."
										}),
										" ",
										execution.reason
									] })
								}),
								step.code.expected ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "border-t border-border/60 px-2.5 py-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "readout text-faint",
										children: "Expected output — not observed"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
										className: "mt-0.5 max-h-40 overflow-auto whitespace-pre-wrap font-mono text-[11px] text-muted",
										children: step.code.expected
									})]
								}) : null
							]
						}) : null,
						step.prompt ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									htmlFor: `${baseId}-response`,
									className: "block text-meta text-fg",
									children: step.prompt
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
									id: `${baseId}-response`,
									value: state.response,
									maxLength: MAX_WALKTHROUGH_RESPONSE_CHARS,
									onChange: (event) => setSession(setResponse(session, session.index, event.target.value)),
									rows: 3,
									"aria-describedby": `${baseId}-response-hint`,
									placeholder: step.responseLabel ?? "Your answer",
									className: "mt-1 w-full resize-y rounded-md bg-bg px-2 py-1.5 text-sm text-fg shadow-[0_0_0_1px_var(--color-border)] placeholder:text-faint focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[color:var(--color-accent)]"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									id: `${baseId}-response-hint`,
									className: "mt-0.5 text-meta text-faint",
									children: [
										state.response.length,
										"/",
										MAX_WALKTHROUGH_RESPONSE_CHARS,
										" characters · kept in this message only, never saved"
									]
								})
							]
						}) : null,
						step.hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								"aria-expanded": state.hintShown,
								onClick: () => setSession(state.hintShown ? session : revealHint(session, session.index)),
								className: "inline-flex items-center gap-1.5 rounded-md px-2 py-1 text-meta text-muted hover:bg-surface-2 hover:text-fg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[color:var(--color-accent)]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleHelp, {
									className: "size-3.5",
									"aria-hidden": "true"
								}), state.hintShown ? "Hide hint" : "Show hint"]
							}), state.hintShown ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 rounded bg-well px-2 py-1.5 text-meta leading-relaxed text-muted",
								children: step.hint
							}) : null]
						}) : null,
						step.answer ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								"aria-expanded": state.answerShown,
								onClick: () => setSession(state.answerShown ? {
									...session,
									answers: session.answers.filter((entry) => entry !== session.index)
								} : revealAnswer(session, session.index)),
								className: "inline-flex items-center gap-1.5 rounded-md px-2 py-1 text-meta text-muted hover:bg-surface-2 hover:text-fg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[color:var(--color-accent)]",
								children: [state.answerShown ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, {
									className: "size-3.5",
									"aria-hidden": "true"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, {
									className: "size-3.5",
									"aria-hidden": "true"
								}), state.answerShown ? "Hide reference answer" : "Compare with a reference answer"]
							}), state.answerShown ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-1 rounded bg-well px-2 py-1.5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "readout text-faint",
										children: "Reference answer"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-0.5 text-meta leading-relaxed text-muted",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MarkdownView, { text: step.answer })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-meta text-faint",
										children: "A reference, not a verdict — nothing compared it with what you wrote."
									})
								]
							}) : null]
						}) : null
					]
				})
			}),
			session.finished ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-2 border-t border-border/60 px-3 py-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							disabled: isFirstStep(session),
							onClick: () => navigate(goBack(session, count)),
							className: "inline-flex items-center gap-1.5 rounded-md px-2 py-1 text-meta text-muted hover:bg-surface-2 hover:text-fg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[color:var(--color-accent)] disabled:cursor-not-allowed disabled:opacity-40",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, {
								className: "size-3.5",
								"aria-hidden": "true"
							}), "Back"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-meta text-faint",
							"aria-hidden": "true",
							children: [
								progressInfo.current,
								" of ",
								progressInfo.total
							]
						}),
						confirmReset ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "inline-flex items-center gap-1.5 rounded px-2 py-1 text-meta text-muted hover:bg-surface-2 hover:text-fg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[color:var(--color-accent)]",
							onClick: () => setConfirmReset(true),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {
								className: "size-3.5",
								"aria-hidden": "true"
							}), "Start over"]
						})
					]
				}), confirmReset ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2",
					role: "alert",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-meta text-fg",
							children: "Start over? This clears your answers and reveals."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "rounded bg-surface-2 px-2 py-1 text-meta text-fg shadow-[0_0_0_1px_var(--color-border)] hover:bg-bg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[color:var(--color-accent)]",
							onClick: () => {
								setRuns({});
								setCopied("idle");
								navigate(resetSession());
							},
							children: "Yes, start over"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "rounded px-2 py-1 text-meta text-muted hover:bg-surface-2 hover:text-fg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[color:var(--color-accent)]",
							onClick: () => setConfirmReset(false),
							children: "Keep going"
						})
					]
				}) : last ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "inline-flex items-center gap-1.5 rounded-md bg-surface-2 px-2 py-1 text-meta text-fg shadow-[0_0_0_1px_var(--color-border)] hover:bg-bg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[color:var(--color-accent)]",
					onClick: () => navigate(finishSession(session, count)),
					children: [
						"Finish",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "sr-only",
							children: " the walkthrough"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
							className: "size-3.5",
							"aria-hidden": "true"
						})
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "inline-flex items-center gap-1.5 rounded-md bg-surface-2 px-2 py-1 text-meta text-fg shadow-[0_0_0_1px_var(--color-border)] hover:bg-bg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[color:var(--color-accent)]",
					onClick: () => navigate(goNext(session, count)),
					children: ["Next", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {
						className: "size-3.5",
						"aria-hidden": "true"
					})]
				})]
			}),
			block.caption ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", {
				className: "border-t border-border/60 px-3 py-1.5 text-meta text-faint",
				children: block.caption
			}) : null
		]
	});
}
var BlockBoundary = class extends import_react.Component {
	state = { failed: false };
	static getDerivedStateFromError() {
		return { failed: true };
	}
	componentDidCatch(error, info) {
		console.error(`Oqe output block "${this.props.label}" failed to render`, error, info);
	}
	render() {
		if (this.state.failed) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "my-3 rounded-md bg-surface px-3 py-2 shadow-[0_0_0_1px_var(--color-border)]",
			role: "status",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-fg",
				children: [
					"This ",
					this.props.label,
					" could not be displayed."
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-meta leading-relaxed text-faint",
				children: this.props.fallback
			})]
		});
		return this.props.children;
	}
};
function TextBlockView({ block }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MarkdownView, { text: block.text });
}
/** A cell that looks numeric is aligned and monospaced; nothing else is guessed. */
function isNumericCell(cell) {
	return /^[-+]?[\d][\d\s.,]*%?$/.test(cell.trim());
}
/**
* Prompt 39 — the table as a real, accessible table.
*
* What changed from Prompt 36: a caption that belongs to the table (not a loose
* paragraph), an explicit empty state, a spoken "no value supplied" for a blank
* cell instead of a bare em dash that could be read as zero, numeric alignment so a
* column of figures can be scanned, and a labelled scroll region so a wide table on
* a narrow screen is reachable by keyboard and announced as scrollable.
*/
function TableBlockView({ block }) {
	const empty = block.rows.length === 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figure", {
		className: "my-3",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			tabIndex: 0,
			role: "group",
			"aria-label": "Table, scrollable horizontally",
			className: "overflow-x-auto rounded-md shadow-[0_0_0_1px_var(--color-border)] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[color:var(--color-accent)]",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full border-collapse text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("caption", {
						className: "px-3 py-1.5 text-left text-meta text-faint",
						children: [block.caption ?? "Table", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "sr-only",
							children: [
								" ",
								block.rows.length,
								" row",
								block.rows.length === 1 ? "" : "s",
								", ",
								block.columns.length,
								" ",
								"column",
								block.columns.length === 1 ? "" : "s",
								"."
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: block.columns.map((column, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						scope: "col",
						className: "bg-surface px-3 py-1.5 text-left text-meta font-medium text-muted",
						children: column
					}, `${column}-${index}`)) }) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: empty ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
						className: "border-t border-border/60",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							colSpan: block.columns.length,
							className: "px-3 py-2 text-meta text-muted",
							children: "This table has no rows — the reply supplied the columns and no data."
						})
					}) : block.rows.map((row, rowIndex) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
						className: "border-t border-border/60",
						children: row.map((cell, cellIndex) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: `px-3 py-1.5 align-top text-fg ${isNumericCell(cell) ? "text-right font-mono" : ""}`,
							children: cell ? cell : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								"aria-hidden": "true",
								children: "—"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "sr-only",
								children: "no value supplied"
							})] })
						}, cellIndex))
					}, rowIndex)) })
				]
			})
		})
	});
}
function MetricsBlockView({ block }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
		className: "my-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
			className: "grid grid-cols-2 gap-2 sm:grid-cols-3",
			children: block.items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-md bg-surface px-3 py-2 shadow-[0_0_0_1px_var(--color-border)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-meta text-faint",
						children: item.label
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "mt-0.5 font-mono text-sm text-fg",
						children: item.value
					}),
					item.detail ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-0.5 text-meta text-muted",
						children: item.detail
					}) : null
				]
			}, item.label))
		}), block.caption ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", {
			className: "mt-1 text-meta text-faint",
			children: block.caption
		}) : null]
	});
}
function ChoicesBlockView({ block, onSend }) {
	if (!onSend) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "my-3 rounded-md bg-surface px-3 py-2 shadow-[0_0_0_1px_var(--color-border)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-fg",
			children: block.prompt
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-1 list-disc pl-5 text-sm text-muted",
			children: block.options.map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: option.label }, option.label))
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "my-3 rounded-md bg-surface px-3 py-2.5 shadow-[0_0_0_1px_var(--color-border)]",
		role: "group",
		"aria-label": block.prompt,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-fg",
			children: block.prompt
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-2 flex flex-wrap gap-2",
			children: block.options.map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "rounded-md bg-surface-2 px-2.5 py-1 text-meta text-fg shadow-[0_0_0_1px_var(--color-border)] hover:bg-bg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[color:var(--color-accent)]",
				onClick: () => onSend(option.send),
				children: option.label
			}, option.label))
		})]
	});
}
function UnsupportedBlockView({ block }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "my-3 rounded-md bg-well px-3 py-2",
		role: "status",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-start gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
				className: "mt-0.5 size-4 shrink-0 text-muted",
				"aria-hidden": "true"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-meta leading-relaxed text-muted",
				children: describeUnsupportedBlock(block)
			})]
		}), block.fallbackText && block.fallbackText.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-2 border-t border-border/40 pt-2 pl-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-meta text-faint",
				children: "The reply described it like this:"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "mt-1 list-decimal space-y-0.5 pl-4 text-meta leading-relaxed text-muted",
				children: block.fallbackText.map((line, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: line }, `${index}-${line.slice(0, 16)}`))
			})]
		}) : null]
	});
}
function renderBlock(block, options) {
	switch (block.type) {
		case "text": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextBlockView, { block });
		case "code": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OutputCode, { block });
		case "table": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBlockView, { block });
		case "metrics": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricsBlockView, { block });
		case "chart": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OutputChart, { block });
		case "diagram": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OutputDiagram, { block });
		case "image": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OutputImage, {
			block,
			allowFetch: options.allowArtifactFetch
		});
		case "file": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OutputFile, { block });
		case "diff": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OutputDiff, { block });
		case "structured": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OutputStructured, { block });
		case "logs": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OutputLogs, { block });
		case "prototype": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OutputPrototype, { block });
		case "simulation": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OutputSimulation, { block });
		case "mesh": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OutputMesh, { block });
		case "choices": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChoicesBlockView, {
			block,
			onSend: options.onSend
		});
		case "form": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OutputForm, {
			block,
			onSend: options.onSend
		});
		case "confirm": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OutputConfirm, {
			block,
			onSend: options.onSend
		});
		case "walkthrough": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OutputWalkthrough, {
			block,
			policy: options.policy
		});
		case "unsupported": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UnsupportedBlockView, { block });
	}
}
/**
* One reply's blocks, in the order the model wrote them.
*
* `onSend` is the ONE way an interactive block reaches the reader's own send path
* — the same path the composer uses. There is no second channel: `choices` sends
* the chosen text, a `form` sends the answers as one message, and a `confirm` sends
* the reader's decision. The component never calls a store or a network of its own,
* and passing nothing turns each of them into readable text, which is the honest
* rendering when no host offers to send anything.
*
* ROWS, not blocks (Prompt 37). A picture that asked to sit beside its sentence
* shares a row with it: two columns on a wide screen, stacked in reading order on a
* narrow one. The decision is `layoutOutputRows` — a pure function, so the layout
* rule is tested instead of being implied by CSS.
*/
function OutputBlocks({ blocks, policy = DEFAULT_OUTPUT_POLICY, onSend }) {
	const visible = (0, import_react.useMemo)(() => applyOutputPolicy(blocks, policy), [blocks, policy]);
	const rows = (0, import_react.useMemo)(() => layoutOutputRows(visible), [visible]);
	const allowArtifactFetch = policy.allowArtifactFetch !== false;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "oqe-output",
		children: rows.map((row, index) => {
			if (row.kind === "aside") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BlockBoundary, {
				label: "text and image",
				fallback: "The rest of this reply is unaffected.",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "my-3 grid gap-3 lg:grid-cols-[minmax(0,1fr)_minmax(0,0.9fr)] lg:items-start",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "min-w-0",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MarkdownView, { text: row.text.text })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "min-w-0",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OutputImage, {
							block: row.image,
							allowFetch: allowArtifactFetch,
							layout: "aside"
						})
					})]
				})
			}, `aside-${index}`);
			const block = row.block;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BlockBoundary, {
				label: block.type === "unsupported" ? "output block" : block.type,
				fallback: block.type === "unsupported" ? describeUnsupportedBlock(block) : "The rest of this reply is unaffected.",
				children: renderBlock(block, {
					allowArtifactFetch,
					onSend,
					policy
				})
			}, `${block.type}-${index}`);
		})
	});
}
function BrowseStage({ info, acting = false }) {
	const [open, setOpen] = (0, import_react.useState)(null);
	if (info.status === "fetching") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		role: "status",
		className: "mt-3 flex items-center gap-2 rounded-lg bg-surface px-4 py-3 text-sm text-muted shadow-[0_0_0_1px_var(--color-border)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OqeActivityMark, { active: acting }), "Fetching pages and media from the web…"]
	});
	if (info.sources.length === 0) return info.detail ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mt-2 text-sm text-muted",
		children: info.detail
	}) : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-3 flex w-full flex-col gap-3",
		role: info.preview ? "group" : void 0,
		"aria-label": info.preview ? "Browsing preview" : void 0,
		children: [info.sources.map((source) => {
			const host = hostOf(source.url);
			const title = source.title && source.title !== source.url ? source.title : host;
			const summary = compactBrowseSummary(source);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("article", {
				className: "rounded-lg bg-surface shadow-[0_0_0_1px_var(--color-border)]",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start gap-3 px-4 py-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteLogo, {
							host,
							url: source.url
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate text-sm leading-snug text-fg",
									title: source.title,
									children: title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "truncate font-mono text-meta text-muted",
									children: [host, source.error ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-danger",
										children: [" · ", source.error]
									}) : null]
								}),
								summary ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 line-clamp-2 text-pretty text-label leading-relaxed text-muted",
									children: summary
								}) : null
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "inline-flex size-10 shrink-0 items-center justify-center rounded-lg text-muted hover:bg-surface-2 hover:text-fg focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-accent/60",
							"aria-label": `Open ${source.title} full screen`,
							title: "Open the full page text",
							onClick: () => setOpen(source),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Maximize2, {
								className: "size-4",
								"aria-hidden": "true"
							})
						})
					]
				})
			}, source.url);
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ViewerDialog, {
			open: Boolean(open),
			title: open?.title ?? "",
			onClose: () => setOpen(null),
			children: [
				open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MediaBody, {
					source: open,
					large: true
				}) : null,
				open?.kind === "page" && open.excerpt ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 whitespace-pre-wrap text-sm leading-relaxed text-pretty",
					children: open.excerpt
				}) : null,
				open && isSafeHttpUrl(open.url) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: open.url,
						target: "_blank",
						rel: "noopener noreferrer",
						className: "text-sm text-accent hover:text-accent-hover",
						children: "Open original"
					})
				}) : null
			]
		})]
	});
}
/** The bare domain a source came from (www. dropped), or the raw value if it does not parse. */
function hostOf(url) {
	try {
		return new URL(url).hostname.replace(/^www\./, "");
	} catch {
		return url;
	}
}
/**
* The site's own logo, read from its origin (`/favicon.ico`). Nothing is sent
* to a third party. If the site has no icon, or it fails to load, a neutral
* globe is shown instead of a broken image.
*/
function SiteLogo({ host, url }) {
	const [failed, setFailed] = (0, import_react.useState)(false);
	const logo = (0, import_react.useMemo)(() => {
		try {
			const parsed = new URL(url);
			return parsed.protocol === "https:" || parsed.protocol === "http:" ? `${parsed.origin}/favicon.ico` : null;
		} catch {
			return null;
		}
	}, [url]);
	if (!logo || failed || !isSafeHttpUrl(logo)) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Globe, {
		className: "size-5 shrink-0 text-muted",
		"aria-hidden": "true"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src: logo,
		alt: "",
		width: 20,
		height: 20,
		loading: "lazy",
		referrerPolicy: "no-referrer",
		className: "size-5 shrink-0 rounded-sm",
		"data-host": host,
		onError: () => setFailed(true)
	});
}
function MediaBody({ source, large = false }) {
	const frame = "aspect-video w-full bg-surface-2";
	if (source.kind === "video" && source.embedUrl && isSafeEmbedUrl(source.embedUrl)) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
		src: source.embedUrl,
		title: source.title,
		className: frame,
		allow: "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture",
		allowFullScreen: true
	});
	if (source.kind === "video" && isSafeMediaSrc(source.url)) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
		className: frame,
		src: source.url,
		controls: true,
		playsInline: true,
		preload: "metadata"
	});
	const image = source.imageUrl || (source.kind === "image" ? source.url : void 0);
	if (image && isSafeMediaSrc(image)) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src: image,
		alt: source.title,
		className: large ? "mx-auto max-h-[70vh] w-auto" : "max-h-72 w-full object-contain bg-surface-2"
	});
	return null;
}
function isSafeEmbedUrl(url) {
	try {
		const parsed = new URL(url);
		return parsed.protocol === "https:" && (parsed.hostname === "www.youtube-nocookie.com" || parsed.hostname === "player.vimeo.com");
	} catch {
		return false;
	}
}
/**
* V10.2 (additional bug 2, §4D) — AUTHORITATIVE STEP ACCOUNTING.
*
* The task card used to print `2/8 steps · 4 failed` from a raw phase count
* that mixed two different kinds of records:
*
*   - WORK STEPS — planned operations (browse, verify, generate, checkpoint
*     rounds, multi-agent passes), and
*   - EVENT RECORDS — one-off bookkeeping lines ("Checkpoint 3 not saved",
*     "Skill capability") that are NOT steps of the plan.
*
* and it counted every `state: "error"` phase as a distinct failed step, so
* RETRY ATTEMPTS of the same step silently inflated the failed-step count.
*
* This module defines the authoritative vocabulary over the task's own state:
*
*   planned   — steps the run set out to do (distinct step labels).
*   started   — steps that actually began (left "pending").
*   completed — steps that finished successfully ("done").
*   failed    — DISTINCT steps whose final state is failure. Retries of the
*               same step NEVER inflate this.
*   retryAttempts — extra attempts beyond the first for any step.
*   cancelled — steps stopped by STOP/cancellation ("stopped").
*   blocked   — steps that could not start/finish for an external reason and
*               whose outcome is unverified (explicitly marked).
*
* The summary is derived ONLY from task state — no timers, no invention — and
* `completionIsHonest` refuses to present a run as complete while required
* work remains failed, cancelled, or unverified.
*/
/**
* Labels that are bookkeeping EVENTS, not plan steps. They stay visible in the
* phase list but never count as planned/failed steps.
*/
var EVENT_PATTERNS = [
	/^checkpoint \d+/i,
	/^skill capability/i,
	/^saved\b/i
];
/**
* V10.10 — AND NEITHER DOES THE TRANSPORT. The card summed the same rows the
* step strip had been drawing, so a finished run reported "8 steps" for a run
* that took three: the connection and model readouts, the queued load, the
* wait and the generic generating row were all counted as work. The rule for
* "is this row a step" lives in ONE place — `isPlumbingPhase` in activity.ts,
* which the strip reads too — so the count and the list can never disagree
* again.
*/
function isEventPhase(phase) {
	return EVENT_PATTERNS.some((re) => re.test(phase.label.trim())) || isPlumbingPhase(phase);
}
/**
* Derive the authoritative accounting from a task's phases.
*
* Distinctness rule: one step = one label. A label that went error → current
* again (a retry) is ONE step with a retry attempt, not two steps and not a
* failed step unless its FINAL state is failure.
*/
function accountSteps(task) {
	const phases = (task?.phases ?? []).filter((p) => !isEventPhase(p));
	const byLabel = /* @__PURE__ */ new Map();
	for (const phase of phases) {
		const list = byLabel.get(phase.label) ?? [];
		list.push(phase);
		byLabel.set(phase.label, list);
	}
	const accounting = {
		planned: byLabel.size,
		started: 0,
		completed: 0,
		failed: 0,
		retryAttempts: 0,
		cancelled: 0,
		blocked: 0
	};
	for (const [, occurrences] of byLabel) {
		const first = occurrences[0];
		const last = occurrences[occurrences.length - 1];
		if (first.state !== "pending") accounting.started += 1;
		const explicit = Math.max(0, (last.attempts ?? 1) - 1);
		accounting.retryAttempts += explicit > 0 ? explicit : Math.max(0, occurrences.length - 1);
		switch (last.state) {
			case "done":
				accounting.completed += 1;
				break;
			case "error":
				accounting.failed += 1;
				break;
			case "stopped":
				accounting.cancelled += 1;
				break;
			case "current":
			case "pending": accounting.blocked += 1;
		}
	}
	return accounting;
}
/**
* V10.11 — count the steps the UI actually shows.
*
* The card printed a count from the run's raw records while listing the step
* view, so a model-authored plan of four steps over five pipeline records read
* "5 steps" above a list of four. This derives the accounting from the very
* views being drawn, carrying each step's real retry count across from the
* record (so the "attempts, not failures" line keeps working).
*/
function accountViews(task, views) {
	const attemptsForLabel = (label) => {
		const rows = (task?.phases ?? []).filter((row) => row.label === label);
		if (rows.length === 0) return void 0;
		return Math.max(...rows.map((row) => row.attempts ?? 1));
	};
	return accountSteps({ phases: views.map((view) => {
		const attempts = attemptsForLabel(view.label);
		return {
			label: view.label,
			state: view.state,
			...attempts !== void 0 ? { attempts } : {}
		};
	}) });
}
/**
* One honest line for the task card. Attempts and failed steps are shown as
* DIFFERENT numbers — "2/8 steps · 4 retry attempts · 1 step failed" — so a
* retried step can never masquerade as four failures.
*/
function stepSummaryLine(accounting) {
	const { planned, completed, failed, retryAttempts, cancelled, blocked } = accounting;
	const parts = [`${completed}/${planned} step${planned === 1 ? "" : "s"}`];
	if (failed > 0) parts.push(`${failed} step${failed === 1 ? "" : "s"} failed`);
	if (retryAttempts > 0) parts.push(`${retryAttempts} retr${retryAttempts === 1 ? "y" : "ies"} (attempts, not failures)`);
	if (cancelled > 0) parts.push(`${cancelled} cancelled`);
	if (blocked > 0) parts.push(`${blocked} unverified`);
	return parts.join(" · ");
}
function MessageList({ conversationId, messages }) {
	const contextSummary = useAppStore((s) => s.conversations.find((conversation) => conversation.id === conversationId)?.contextSummary);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "message-column mx-auto flex flex-col gap-6 px-4 py-7 sm:px-6 sm:py-9",
		children: [contextSummary ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "well readout flex items-start gap-2 rounded-md px-3 py-2 leading-relaxed text-signal/85",
			role: "status",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layers, {
				className: "mt-0.5 size-3 shrink-0 opacity-70",
				"aria-hidden": "true"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Older turns are represented by a local context summary. The visible thread below remains available." })]
		}) : null, messages.map((message) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageRow, {
			conversationId,
			message
		}, message.id))]
	});
}
/**
* V7.9.2 — one row per message, memoized on the message object.
*
* `patchMessage` returns every OTHER message untouched, so while a reply
* streams only the streaming row re-renders. Before this the whole list was
* rebuilt on every token and every row's markdown was re-parsed from scratch,
* which is what made a long thread stutter the moment you scrolled during a
* response.
*
* The store actions and the two settings flags read here are stable for the
* life of a stream, so a shallow compare on `message` is exactly right.
*/
var MessageRow = (0, import_react.memo)(function MessageRow({ conversationId, message }) {
	const showProcess = useAppStore((s) => s.settings.showModelProcess);
	const isLocalMode = useAppStore((s) => s.settings.mode === "local");
	const orbCursor = useAppStore((s) => s.settings.orbCursor);
	const confirmCompanionTarget = useAppStore((s) => s.confirmCompanionTarget);
	const declineCompanionTarget = useAppStore((s) => s.declineCompanionTarget);
	const continueCouncil = useAppStore((s) => s.continueCouncil);
	const output = (0, import_react.useMemo)(() => message.role === "assistant" ? readMessageOutput(message.content) : {
		kind: "none",
		text: message.content
	}, [message.content, message.role]);
	const outputSettings = useAppStore((s) => s.settings.output);
	const outputPolicy = (0, import_react.useMemo)(() => outputPolicyFromSettings(outputSettings), [outputSettings]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("article", {
		id: `msg-${message.id}`,
		tabIndex: -1,
		className: cn("max-w-full scroll-mt-4 outline-none", message.role === "user" && !message.browse ? "w-full" : "w-full"),
		children: message.role === "user" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: cn("user-turn px-4 py-3.5 text-[0.9375rem] leading-[1.65] text-fg", message.browse ? "w-full" : ""),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "whitespace-pre-wrap text-pretty",
					children: message.content
				})
			}),
			message.attachments?.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2 flex flex-wrap gap-1.5",
				"aria-label": "Attached files",
				children: message.attachments.map((attachment) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "inline-flex max-w-full items-center gap-1.5 rounded-md bg-surface-2 px-2 py-1 text-xs text-muted",
					title: `${attachment.name} · ${attachment.type}${attachment.size ? ` · ${formatBytes(attachment.size)}` : ""}`,
					children: [
						attachment.kind === "image" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Image, {
							className: "size-3.5 shrink-0",
							"aria-hidden": "true"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, {
							className: "size-3.5 shrink-0",
							"aria-hidden": "true"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "max-w-56 truncate",
							children: attachment.name
						}),
						attachment.size > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "shrink-0 text-meta opacity-70",
							children: formatBytes(attachment.size)
						}) : null
					]
				}, attachment.id))
			}) : null,
			message.browse ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BrowseStage, {
				info: message.browse,
				acting: orbCursor && message.browse.status === "fetching"
			}) : null
		] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "assistant-message px-1 sm:px-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-2.5 flex items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[0.8125rem] font-medium text-fg",
							children: "Oqe"
						}),
						message.model ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "readout min-w-0 truncate text-faint",
							title: message.model,
							children: message.model
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, { text: message.content })
					]
				}),
				showProcess && message.process ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
					className: "plate mb-3 rounded-md px-3 py-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
						className: "cursor-pointer text-xs text-muted",
						children: "Model process"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProcessLog, {
							text: message.process,
							className: "max-h-72 overflow-y-auto"
						})
					})]
				}) : null,
				message.task ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TaskBlock, { task: message.task }) : null,
				message.council?.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CouncilBlock, {
					entries: message.council,
					createdAt: message.createdAt
				}) : null,
				message.councilPause ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3 flex items-center gap-2 rounded-md border border-accent/40 bg-surface px-3 py-2",
					role: "status",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "flex-1 text-xs text-muted",
						children: message.councilPause.prompt
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "primary",
						onClick: continueCouncil,
						children: "Continue"
					})]
				}) : null,
				output.kind === "ready" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [output.text ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MarkdownView, { text: output.text }) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OutputBlocks, {
					blocks: output.envelope.blocks,
					policy: outputPolicy,
					onSend: (text) => {
						useAppStore.getState().sendUserMessage(text);
					}
				})] }) : message.content.trim() ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MarkdownView, { text: output.text || message.content }) : message.status === "streaming" && !message.task ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "flex items-center gap-2 text-sm text-muted",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "oqe-glow size-1.5 rounded-full bg-accent",
						"aria-hidden": "true"
					}), "Generating response…"]
				}) : message.status === "stopped" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Stopped before any visible text arrived."
				}) : null,
				message.companionGate?.status === "pending" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 rounded-md bg-surface px-3 py-3 shadow-[0_0_0_1px_var(--color-border)]",
					role: "group",
					"aria-label": "Desktop control confirmation",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OqeActivityMark, {
								active: orbCursor,
								label: message.task?.lastAction ?? null
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm text-fg",
								children: ["Oqe wants to control ", message.companionGate.target]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs text-muted",
							children: "Pairing and Enable are not enough for a new target. Allow only if that app is in front on this PC."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex flex-wrap gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "primary",
								size: "sm",
								onClick: () => confirmCompanionTarget(conversationId, message.id),
								children: "Allow"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								size: "sm",
								onClick: () => declineCompanionTarget(conversationId, message.id),
								children: "Deny"
							})]
						})
					]
				}) : null,
				hasCalcErrorIssues(message.calcVerify) ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 text-xs text-warn",
					role: "status",
					children: [
						"Check the numbers — ",
						message.calcVerify.issues.filter((i) => i.severity === "error").length === 1 ? "one calculation looks wrong" : "some calculations look wrong",
						message.calcVerify.issues[0] ? `: ${message.calcVerify.issues[0].expression}` : "."
					]
				}) : null,
				message.status === "stopped" && message.content.trim() ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-xs text-muted",
					children: "Stopped. Partial answer kept."
				}) : null,
				message.content.trim() ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LocalSpeakControls, { text: message.content }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BrowserSpeakControls, { text: message.content })] }) : null,
				message.status === "generation_stopped" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 text-xs text-warn",
					children: [REPETITION_STOPPED_MESSAGE, " Partial answer kept."]
				}) : null,
				message.status === "incomplete" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 text-xs text-muted",
					children: ["The stream ended before the model finished. Partial answer kept.", isLocalMode ? " In local mode this can be an Ollama or model limit (num_predict / context) — not a Wi-Fi cancel." : ""]
				}) : null,
				message.status === "interrupted" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 text-xs text-muted",
					children: ["The stream disconnected. Partial answer kept.", isLocalMode ? " Local streams don’t abort on Wi-Fi drops; check that Ollama is still running." : ""]
				}) : null,
				message.error && message.status !== "generation_stopped" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex gap-2.5 rounded-md bg-surface px-3 py-2.5 shadow-[0_0_0_1px_rgb(242_101_90_/_0.32)]",
					role: "alert",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
						className: "mt-0.5 size-3.5 shrink-0 text-danger",
						"aria-hidden": "true"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm leading-relaxed text-fg/90",
						children: message.error
					})]
				}) : null
			]
		})
	});
});
/**
* Speak / Stop for the local TTS engine. Rendered only when Settings → Voice
* enables the local engine. Every status line comes from a real server event
* (spawned engine, progress line, audio bytes, error) — there is no fake
* "speaking" state and no timers.
*/
function LocalSpeakControls({ text }) {
	const localTtsEnabled = useAppStore((s) => s.settings.localTtsEnabled);
	const profile = useAppStore((s) => s.settings.localTtsProfile);
	const unloadBeforeClone = useAppStore((s) => s.settings.localTtsUnloadBeforeClone);
	const localAddress = useAppStore((s) => s.settings.localAddress);
	const mode = useAppStore((s) => s.settings.mode);
	const [phase, setPhase] = (0, import_react.useState)("idle");
	const [label, setLabel] = (0, import_react.useState)("");
	const handleRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => () => handleRef.current?.stop(), []);
	if (!localTtsEnabled) return null;
	const busy = phase === "loading" || phase === "synthesizing" || phase === "writing" || phase === "ready" || phase === "playing";
	const start = () => {
		if (busy) return;
		setPhase("loading");
		setLabel("Starting local TTS engine…");
		const handle = speakLocal({
			text,
			profile: profile || void 0,
			localAddress: mode === "local" ? localAddress : void 0,
			unloadBeforeClone: Boolean(profile) && unloadBeforeClone,
			onEvent: (event) => {
				const activity = describeTtsEvent(event, profile || void 0);
				setPhase(activity.phase);
				setLabel(activity.label);
			},
			onEnded: () => {
				setPhase("idle");
				setLabel("");
				handleRef.current = null;
			}
		});
		handleRef.current = handle;
	};
	const stop = () => {
		handleRef.current?.stop();
		handleRef.current = null;
		setPhase("idle");
		setLabel("");
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-3",
		children: [busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			size: "sm",
			variant: "danger",
			onClick: stop,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Square, {
				className: "size-3.5",
				"aria-hidden": "true"
			}), "Stop"]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			size: "sm",
			onClick: start,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, {
				className: "size-3.5",
				"aria-hidden": "true"
			}), "Speak (local)"]
		}), label ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1.5 text-xs leading-relaxed text-muted",
			role: phase === "failed" ? "alert" : "status",
			"aria-live": phase === "failed" ? "assertive" : "polite",
			children: label
		}) : null]
	});
}
/**
* P1-5 (V8.5, user #12) — read-aloud through the BROWSER engine
* (speechSynthesis), rendered only when the local engine is off and browser
* read-aloud is enabled. The label says "Browser TTS" wherever the engine
* speaks, so a speechSynthesis voice is never presented as a local one. Speak
* uses the engine Settings selected (browser voice / saved profile).
*/
function BrowserSpeakControls({ text }) {
	const localTtsEnabled = useAppStore((s) => s.settings.localTtsEnabled);
	const textToSpeech = useAppStore((s) => s.settings.textToSpeech);
	const ttsVoice = useAppStore((s) => s.settings.ttsVoice);
	const ttsProfileId = useAppStore((s) => s.settings.ttsProfileId);
	const profiles = useAppStore((s) => s.voiceProfiles);
	const [speaking, setSpeaking] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const handleRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => () => handleRef.current?.stop(), []);
	if (localTtsEnabled || !textToSpeech) return null;
	const profile = ttsProfileId ? profiles.find((p) => p.id === ttsProfileId) : void 0;
	const start = () => {
		if (speaking) return;
		setError(null);
		const result = speak({
			text,
			voiceURI: profile ? void 0 : ttsVoice || void 0,
			profile,
			onEnd: (info) => {
				setSpeaking(false);
				handleRef.current = null;
				if (info.error) setError(info.error);
			}
		});
		if ("error" in result) {
			setError(result.error);
			return;
		}
		handleRef.current = result;
		setSpeaking(true);
	};
	const stop = () => {
		handleRef.current?.stop();
		handleRef.current = null;
		setSpeaking(false);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-3",
		children: [
			speaking ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				size: "sm",
				variant: "danger",
				onClick: stop,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Square, {
					className: "size-3.5",
					"aria-hidden": "true"
				}), "Stop (Browser TTS)"]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				size: "sm",
				onClick: start,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, {
					className: "size-3.5",
					"aria-hidden": "true"
				}), "Speak (Browser TTS)"]
			}),
			speaking ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1.5 text-xs leading-relaxed text-muted",
				role: "status",
				"aria-live": "polite",
				children: "Speaking (Browser TTS)"
			}) : null,
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1.5 flex items-start gap-1.5 text-xs leading-relaxed text-fg/90",
				role: "alert",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "mt-0.5 size-3 shrink-0 text-danger",
					"aria-hidden": "true"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Browser TTS failed: ", error] })]
			}) : null
		]
	});
}
var TASK_ICONS = {
	companion: Monitor,
	research: Globe,
	generate: Cpu,
	prepare: Paperclip
};
/**
* Activity block — a vertical list of the operations Oqe actually observed
* for this message. Every phase was written by a real event (browse resolved,
* first token arrived, companion reported a step); nothing here is invented.
*
* V10.39 — this is the SETTLED record only. While a run is in flight it draws
* nothing (see the note below), and once it settles the summary names what the
* run did in the past tense rather than repeating the live label with a state
* in brackets.
*/
function TaskBlock({ task }) {
	const Icon = TASK_ICONS[task.kind] ?? Monitor;
	const steps = taskStepViews(task);
	const accounting = accountViews(task, steps);
	const phaseTotal = accounting.planned;
	const stepLine = task.step != null && task.maxSteps != null ? `Step ${task.step} of ${task.maxSteps}` : task.step != null ? `Step ${task.step}` : null;
	const titleLine = (task.kind === "companion" ? "Plan: " : "") + settledTaskTitle(task) + (stepLine ? ` (${stepLine})` : "");
	const hasBody = Boolean(steps.length > 0 || task.detail || task.lastAction);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("mb-3 rounded-md px-3 py-2.5", task.state === "error" ? "plate-danger" : "plate"),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
			className: "group",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("summary", {
				className: "flex cursor-pointer list-none items-start gap-2.5 [&::-webkit-details-marker]:hidden",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
						className: "mt-0.5 size-4 shrink-0 text-muted",
						"aria-hidden": "true"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "min-w-0 flex-1 text-xs font-medium text-fg",
						children: titleLine
					}),
					phaseTotal > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "shrink-0 self-center text-meta text-muted",
						children: accounting.failed > 0 || accounting.retryAttempts > 0 || accounting.cancelled > 0 || accounting.blocked > 0 ? stepSummaryLine(accounting) : `${phaseTotal} steps`
					}) : null,
					hasBody ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, {
						className: "mt-0.5 size-3.5 shrink-0 text-muted transition-transform duration-150 group-open:rotate-180",
						"aria-hidden": "true"
					}) : null
				]
			}), hasBody ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-2 min-w-0 border-t border-border pt-2",
				children: [
					steps.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TaskPhases, { phases: steps }) : null,
					task.detail ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs leading-relaxed text-muted",
						children: task.detail
					}) : null,
					task.kind === "companion" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 flex flex-wrap items-center gap-x-1.5 gap-y-0.5 font-mono text-meta text-muted",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-accent",
								children: task.phase ?? "planning"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								"aria-hidden": "true",
								children: "·"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: stepLine ?? (task.maxSteps != null ? `of ${task.maxSteps} steps` : "step unknown") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								"aria-hidden": "true",
								children: "·"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["last action ", task.lastAction?.trim() ? task.lastAction : "—"] })
						]
					}) : task.lastAction ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-0.5 text-xs leading-relaxed text-muted",
						children: ["Last action: ", task.lastAction]
					}) : null
				]
			}) : null]
		})
	});
}
/**
* The real sequential-council transcript for this reply: one block per role
* that actually ran, naming the role and the model id that generated it. The
* Chair's text (or the completed passes when stopped) is the message content.
* Rendered only from real recorded passes — never synthesized.
*/
function CouncilBlock({ entries, createdAt }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
		className: "mb-4 border-y border-border py-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("summary", {
			className: "flex cursor-pointer list-none items-center gap-2 text-[0.8125rem] font-medium text-muted [&::-webkit-details-marker]:hidden",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-accent",
				children: "Multi-agent"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
				entries.length,
				" turn",
				entries.length === 1 ? "" : "s"
			] })]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-3 flex flex-col gap-3",
			children: entries.map((entry, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-[5.5rem_1fr] gap-x-3 border-b border-border pb-3 last:border-0 last:pb-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[0.8125rem] font-medium text-fg",
						children: entry.role
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 truncate font-mono text-meta text-muted",
						title: entry.model,
						children: entry.model
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-meta text-muted/70",
						children: formatAgentTime(createdAt)
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "min-w-0 text-xs leading-relaxed text-muted",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MarkdownView, { text: entry.message }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, { text: entry.message })]
					})
				})]
			}, `${entry.role}-${index}`))
		})]
	});
}
function formatAgentTime(timestamp) {
	return new Intl.DateTimeFormat(void 0, {
		hour: "numeric",
		minute: "2-digit"
	}).format(timestamp);
}
function CopyButton({ text }) {
	const [state, setState] = (0, import_react.useState)("idle");
	const copy = async () => {
		const result = await copyText(text);
		setState(result.ok ? "copied" : "failed");
		window.setTimeout(() => setState("idle"), 1800);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		className: "ml-auto inline-flex shrink-0 items-center rounded px-2 py-1 text-meta text-muted hover:bg-surface-2 hover:text-fg",
		onClick: () => void copy(),
		disabled: !text.trim(),
		"aria-label": state === "copied" ? "Copied" : "Copy final answer",
		title: state === "failed" ? "Clipboard blocked; select the answer to copy it manually" : "Copy final answer",
		children: state === "copied" ? "Copied" : state === "failed" ? "Copy failed" : "Copy"
	});
}
function TaskPhases({ phases }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "mt-1.5 flex flex-col gap-1",
		children: phases.map((p, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: cn("flex items-start gap-1.5 text-xs leading-relaxed", p.state === "current" ? "text-fg" : p.state === "pending" ? "text-muted/60" : p.state === "error" ? "text-danger" : p.state === "stopped" ? "text-muted line-through" : "text-muted"),
			children: [p.state === "done" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
				className: "mt-0.5 size-3 shrink-0 text-ok",
				"aria-hidden": "true"
			}) : p.state === "current" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
				className: "mt-0.5 size-3 shrink-0 animate-spin text-accent",
				"aria-hidden": "true"
			}) : p.state === "error" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {
				className: "mt-0.5 size-3 shrink-0",
				"aria-hidden": "true"
			}) : p.state === "stopped" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Circle, {
				className: "mt-0.5 size-3 shrink-0",
				"aria-hidden": "true"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Circle, {
				className: "mt-0.5 size-3 shrink-0 opacity-40",
				"aria-hidden": "true"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [p.state === "current" ? p.label : p.detail ?? p.label, p.state === "current" && p.detail ? ` — ${p.detail}` : ""] })]
		}, `${p.label}-${i}`))
	});
}
function formatBytes(size) {
	if (size < 1024) return `${size} B`;
	if (size < 1048576) return `${Math.round(size / 1024)} KB`;
	return `${(size / 1048576).toFixed(1)} MB`;
}
var FACT_TONE = {
	muted: "text-muted",
	signal: "text-signal/85",
	accent: "text-accent",
	danger: "text-danger"
};
function StatusLine() {
	const settings = useAppStore((s) => s.settings);
	const connection = useAppStore((s) => s.connection);
	const lastMetrics = useAppStore((s) => s.lastMetrics);
	const streamingId = useAppStore((s) => s.streamingId);
	const browsing = useAppStore((s) => s.browsing);
	const liveTask = useAppStore((s) => {
		if (!s.streamingId) return void 0;
		for (const c of s.conversations) {
			const m = c.messages.find((msg) => msg.id === s.streamingId);
			if (m) return m.task;
		}
	});
	const [online, setOnline] = (0, import_react.useState)(() => isOnline());
	(0, import_react.useEffect)(() => {
		const up = () => setOnline(true);
		const down = () => setOnline(false);
		window.addEventListener("online", up);
		window.addEventListener("offline", down);
		return () => {
			window.removeEventListener("online", up);
			window.removeEventListener("offline", down);
		};
	}, []);
	const inFlight = Boolean(streamingId) || browsing;
	const startedAt = liveTask?.startedAt;
	const [elapsed, setElapsed] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		if (!inFlight) return;
		const t0 = startedAt ?? Date.now();
		setElapsed(Math.max(0, Math.floor((Date.now() - t0) / 1e3)));
		const timer = setInterval(() => setElapsed(Math.max(0, Math.floor((Date.now() - t0) / 1e3))), 1e3);
		return () => clearInterval(timer);
	}, [inFlight, startedAt]);
	const facts = [];
	if (connection.kind === "error") facts.push({
		text: connection.message,
		tone: "danger"
	});
	const activityLabel = currentStepLabel(liveTask);
	if (browsing) facts.push({
		text: elapsed > 0 ? `${activityLabel ?? "Fetching pages"} · ${elapsed}s` : activityLabel ?? "Fetching pages",
		tone: "accent",
		ticks: true
	});
	else if (streamingId) facts.push({
		text: elapsed > 0 ? `${activityLabel ?? "Generating response"} · ${elapsed}s` : activityLabel ?? "Generating response",
		tone: "accent",
		ticks: true
	});
	else if (lastMetrics?.durationMs !== void 0) {
		facts.push({
			text: `${(lastMetrics.durationMs / 1e3).toFixed(1)}s`,
			tone: "signal"
		});
		if (lastMetrics.tokensPerSecond !== void 0) facts.push({
			text: `${lastMetrics.tokensPerSecond} tok/s`,
			tone: "signal"
		});
	}
	const offlineNote = offlineStatusNote(settings.mode, online);
	if (facts.length === 0 && !offlineNote) return null;
	const announced = facts.filter((fact) => !fact.ticks).map((fact) => fact.text).join(" · ");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		announced ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "sr-only",
			role: "status",
			"aria-live": "polite",
			children: announced
		}) : null,
		facts.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "readout mx-auto flex w-full max-w-[44rem] flex-wrap items-center gap-x-1.5 gap-y-0.5 px-5 pb-2",
			children: facts.map((fact, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "flex items-center gap-1.5",
				children: [index > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-muted/45",
					"aria-hidden": "true",
					children: "·"
				}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: FACT_TONE[fact.tone],
					children: fact.text
				})]
			}, `${fact.text}-${index}`))
		}) : null,
		offlineNote ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mx-auto w-full max-w-[44rem] px-5 pb-2 text-xs text-muted",
			role: "status",
			children: offlineNote
		}) : null
	] });
}
/**
* The icon for one real stage label. Order matters: the most specific
* patterns are checked first so "Verifying results" never falls into a
* generic bucket.
*/
function progressIconFor(label) {
	const text = label.trim().toLowerCase();
	if (!text) return "loader";
	if (/deliver|final answer/.test(text)) return "send";
	if (/verif/.test(text)) return "shield-check";
	if (/checkpoint/.test(text)) return "clipboard-check";
	if (/rebuild|context/.test(text)) return "refresh";
	if (/lead|re-evaluat|re-evaluation|weigh/.test(text)) return "brain";
	if (/plan|task accepted/.test(text)) return "list-checks";
	if (/browser assistant|searching|fetch|web/.test(text)) return "search";
	if (/desktop assistant|desktop|this pc|windows|companion/.test(text)) return "monitor";
	if (/other tools|tool/.test(text)) return "wrench";
	if (/execut|continu|more work/.test(text)) return "loader";
	return "loader";
}
/**
* Whether this stage is still moving. Only the stage's own recorded state
* decides — no timers, no guessing.
*/
function progressIconSpins(icon) {
	return icon === "loader";
}
/**
* The single honest live line for a set of stage labels + states: the
* current stage when one is current, otherwise the last one that ran. This
* replaces generic "Loading…/Thinking…/Answering…" copy — the text is always
* the task's own stage.
*/
function liveStageLabel(stages, fallback) {
	const current = [...stages].reverse().find((s) => s.state === "current");
	if (current) return current.label;
	const last = stages[stages.length - 1];
	return last ? last.label : fallback;
}
/**
* V9.2 — task-specific progress iconography. Each real stage gets its own
* icon (web work, desktop work, verification, checkpoints, context rebuilds,
* lead re-evaluation, delivery); only an unknown stage falls back to the
* generic loader.
*/
var STAGE_ICONS = {
	search: Search,
	monitor: Monitor,
	wrench: Wrench,
	"shield-check": ShieldCheck,
	"clipboard-check": ClipboardCheck,
	refresh: RefreshCw,
	brain: Brain,
	send: Send,
	"list-checks": ListChecks,
	loader: LoaderCircle
};
/**
* Project a live task's steps for the strip (order preserved).
*
* The model's plan / the reader's suggestion / the run's own recorded work, in
* that order of precedence, with the plumbing rows excluded — see
* `taskStepViews` in src/lib/activity.ts, which is where that rule lives so it
* can be tested without the DOM.
*/
function stepsFromTask(task) {
	return taskStepViews(task).map((view) => ({
		label: view.label,
		state: view.state,
		source: view.source,
		...view.detail !== void 0 ? { detail: view.detail } : {}
	}));
}
/** Project the companion's OWN loop status (never a client-side guess). */
function stepsFromCompanion(health) {
	const loop = health?.loop_status;
	if (!health?.loop_running && (!loop || loop.state === "idle")) return [];
	const stepLabel = loop?.step !== void 0 && loop.step > 0 ? `Desktop step ${loop.step}${loop.max_steps ? ` of ${loop.max_steps}` : ""}` : null;
	return [{
		label: loop?.detail?.trim() || loop?.last_action?.trim() || stepLabel || "Desktop control loop",
		state: loop?.state === "complete" ? "done" : loop?.state === "error" ? "error" : loop?.state === "stopped" ? "stopped" : "current"
	}];
}
/**
* V10.10 — the four states, as icons. Only the state the row is really in
* decides the glyph: an empty circle for queued work, a spinner for the step
* being done now, a green tick for a step that finished, a red cross for one
* that failed (or was stopped — the row's title says which, so a reader who
* pressed Stop is not told something broke).
*/
function StepGlyph({ state }) {
	if (state === "current") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
		className: "size-3.5 shrink-0 animate-spin text-accent",
		"aria-hidden": "true"
	});
	if (state === "done") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, {
		className: "size-3.5 shrink-0 text-ok",
		"aria-hidden": "true"
	});
	if (state === "error" || state === "stopped") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleX, {
		className: "size-3.5 shrink-0 text-danger",
		"aria-hidden": "true"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Circle, {
		className: "size-3.5 shrink-0 text-border-strong",
		"aria-hidden": "true"
	});
}
var STATE_WORD = {
	pending: "not started",
	current: "in progress",
	done: "done",
	error: "failed",
	stopped: "stopped"
};
/** Pending is faint; a finished or broken step is at full contrast. */
var STATE_TEXT = {
	pending: "text-muted/60",
	current: "text-fg font-medium",
	done: "text-fg",
	error: "text-fg",
	stopped: "text-fg"
};
function TaskProgressStrip() {
	const streamingId = useAppStore((s) => s.streamingId);
	const browsing = useAppStore((s) => s.browsing);
	const liveTask = useAppStore((s) => {
		if (!s.streamingId) return void 0;
		for (const c of s.conversations) {
			const m = c.messages.find((msg) => msg.id === s.streamingId);
			if (m) return m.task;
		}
	});
	/** The thread the live message belongs to — the editor writes through it. */
	const streamingConversationId = useAppStore((s) => {
		if (!s.streamingId) return null;
		for (const c of s.conversations) if (c.messages.some((m) => m.id === s.streamingId)) return c.id;
		return null;
	});
	const companionHealth = useAppStore((s) => s.companionHealth);
	const setTaskSteps = useAppStore((s) => s.setTaskSteps);
	const undoTaskSteps = useAppStore((s) => s.undoTaskSteps);
	const [editing, setEditing] = (0, import_react.useState)(false);
	const [draft, setDraft] = (0, import_react.useState)([]);
	const [collapsed, setCollapsed] = (0, import_react.useState)(false);
	const companionLoopRunning = companionHealth?.loop_running === true || companionHealth?.loop_status !== void 0 && companionHealth.loop_status !== null && companionHealth.loop_status.state === "running";
	if (!streamingId && !browsing && !companionLoopRunning) return null;
	const taskSteps = streamingId ? stepsFromTask(liveTask) : [];
	const renderSteps = taskSteps.length >= 2 ? [...taskSteps] : [];
	if (companionLoopRunning) renderSteps.push(...stepsFromCompanion(companionHealth));
	if (renderSteps.length === 0) return null;
	const currentLabel = liveStageLabel(renderSteps, "Working");
	const stageIcon = progressIconFor(currentLabel);
	const StageIcon = STAGE_ICONS[stageIcon];
	const hasPlan = renderSteps.some((step) => step.state === "pending");
	const phaseDone = renderSteps.filter((p) => p.state === "done").length;
	const phaseTotal = renderSteps.length;
	const progressPct = hasPlan && phaseTotal > 0 ? Math.round(phaseDone / phaseTotal * 100) : null;
	const title = liveTask?.title ?? "Working on it";
	const canEdit = Boolean(streamingId && liveTask && streamingConversationId);
	const mineShown = renderSteps.some((step) => step.source === "mine");
	function openEditor() {
		setCollapsed(false);
		setDraft(renderSteps.map((step) => step.label));
		setEditing(true);
	}
	/** Lift the row at `from` and drop it at `to` (the drag gesture's own move). */
	function moveStep(from, to) {
		setDraft((current) => {
			if (from === to || from < 0 || to < 0 || from >= current.length || to >= current.length) return current;
			const next = [...current];
			const [row] = next.splice(from, 1);
			if (row === void 0) return current;
			next.splice(to, 0, row);
			return next;
		});
	}
	function saveSteps() {
		if (!streamingId || !streamingConversationId) return;
		setTaskSteps(streamingConversationId, streamingId, draft);
		setEditing(false);
	}
	function undoSteps() {
		if (!streamingId || !streamingConversationId) return;
		undoTaskSteps(streamingConversationId, streamingId);
		setEditing(false);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mx-auto w-full max-w-[44rem] px-5 pt-2",
		role: "status",
		"aria-live": "polite",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "plate relative overflow-hidden rounded-lg px-3 pb-2 pt-1",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-0.5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "flex min-w-0 flex-1 items-center gap-2 rounded-md py-0.5 text-left",
							title,
							"aria-label": `Show the message in progress: ${currentLabel}`,
							onClick: () => {
								if (!streamingId || typeof document === "undefined") return;
								document.getElementById(`msg-${streamingId}`)?.scrollIntoView({
									behavior: "smooth",
									block: "start"
								});
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StageIcon, {
									className: `size-3.5 shrink-0 text-accent${progressIconSpins(stageIcon) ? " animate-spin" : ""}`,
									"aria-hidden": "true"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "truncate text-[12px] font-medium text-fg",
									children: title
								}),
								progressPct !== null && phaseTotal > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "ml-auto shrink-0 pr-1.5 font-mono text-meta tabular-nums text-muted/80",
									children: [
										phaseDone,
										"/",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-muted/40",
											children: phaseTotal
										})
									]
								}) : null
							]
						}),
						canEdit ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "inline-flex size-6 shrink-0 items-center justify-center rounded-md text-muted/70 transition-colors hover:bg-surface-2 hover:text-fg focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-accent/60",
							"aria-label": "Edit the steps for this run",
							title: "Edit the steps",
							"aria-expanded": editing,
							onClick: () => editing ? setEditing(false) : openEditor(),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, {
								className: "size-3",
								"aria-hidden": "true"
							})
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "inline-flex size-6 shrink-0 items-center justify-center rounded-md text-muted/70 transition-colors hover:bg-surface-2 hover:text-fg focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-accent/60",
							"aria-label": collapsed ? "Show the steps" : "Hide the steps",
							title: collapsed ? "Show the steps" : "Hide the steps",
							onClick: () => setCollapsed((current) => !current),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, {
								className: `size-3.5 transition-transform duration-200 ${collapsed ? "" : "rotate-180"}`,
								"aria-hidden": "true"
							})
						})
					]
				}),
				collapsed || editing ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-1 flex flex-col",
					children: renderSteps.map((step, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "relative flex items-start gap-2 py-[3px]",
						children: [
							index < renderSteps.length - 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "pointer-events-none absolute left-[6px] top-[16px] h-[calc(100%-13px)] w-px bg-border/70",
								"aria-hidden": "true"
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-[2px] shrink-0",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StepGlyph, { state: step.state })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: `min-w-0 flex-1 text-[12.5px] leading-[1.45] ${STATE_TEXT[step.state]}`,
								title: step.detail ? `${STATE_WORD[step.state]}: ${step.label} — ${step.detail}` : void 0,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "break-words",
									children: step.label
								}), step.source === "mine" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "ml-1.5 rounded-sm bg-surface-2 px-1 py-px font-mono text-[9px] text-muted/80",
									children: "yours"
								}) : null]
							})
						]
					}, `${step.label}-${index}`))
				}),
				editing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StepEditor, {
					draft,
					onChange: setDraft,
					onMove: moveStep,
					onSave: saveSteps,
					onUndo: undoSteps,
					onCancel: () => setEditing(false),
					canUndo: mineShown
				}) : null,
				progressPct !== null && phaseTotal > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "pointer-events-none absolute inset-x-0 bottom-0 h-px bg-border/40",
					"aria-hidden": "true",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block h-full bg-accent transition-[width] duration-300",
						style: { width: `${Math.max(progressPct, 4)}%` }
					})
				}) : null
			]
		})
	});
}
/**
* V10.10 — the pencil's editor: rename, add, remove and reorder the run's
* steps. Saving hands them to the agent as a suggestion, and the model's own
* steps come straight back on Undo — the reader's list never overwrites them.
*/
function StepEditor({ draft, onChange, onMove, onSave, onUndo, onCancel, canUndo }) {
	const kept = draft.filter((step) => step.trim().length > 0);
	const { dragging, over, rowProps } = useHoldDrag({
		count: draft.length,
		onMove
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-1.5 border-t border-border/60 pt-1.5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "flex flex-col",
				children: draft.map((text, index) => {
					const isDragging = dragging === index;
					const isTarget = dragging !== null && over === index && over !== dragging;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						...rowProps(index),
						className: `group relative flex items-center gap-2 rounded-md px-1.5 py-1 transition-[background-color,box-shadow] ${isDragging ? "z-10 cursor-grabbing bg-surface-2 shadow-lg ring-1 ring-accent/35" : "hover:bg-surface-2/50 focus-within:bg-surface-2/50 [&:hover_.step-remove]:opacity-100 [&:focus-within_.step-remove]:opacity-100"}`,
						style: { touchAction: isDragging ? "none" : "pan-y" },
						children: [
							isTarget ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "pointer-events-none absolute inset-x-1.5 -top-px h-px bg-accent",
								"aria-hidden": "true"
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "w-3 shrink-0 select-none text-right font-mono text-meta tabular-nums text-faint",
								"aria-hidden": "true",
								children: index + 1
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								id: `task-step-${index}`,
								className: "h-6 min-w-0 flex-1 border-0 bg-transparent p-0 text-label leading-6 text-fg outline-none placeholder:text-faint",
								value: text,
								maxLength: 120,
								placeholder: `Step ${index + 1}`,
								"aria-label": `Step ${index + 1}`,
								onChange: (e) => onChange(draft.map((row, i) => i === index ? e.target.value : row)),
								onKeyDown: (event) => {
									if (!event.altKey) return;
									if (event.key === "ArrowUp" && index > 0) {
										event.preventDefault();
										onMove(index, index - 1);
									} else if (event.key === "ArrowDown" && index < draft.length - 1) {
										event.preventDefault();
										onMove(index, index + 1);
									}
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "step-remove inline-flex size-5 shrink-0 items-center justify-center rounded text-muted/60 opacity-0 transition-[opacity,color] hover:text-danger focus:opacity-100",
								"aria-label": `Remove step ${index + 1}`,
								onClick: () => onChange(draft.filter((_, i) => i !== index)),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {
									className: "size-3",
									"aria-hidden": "true"
								})
							})
						]
					}, index);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-1 flex items-center justify-between gap-3 border-t border-border/40 pt-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "flex items-center gap-2 rounded-md px-1.5 py-0.5 text-meta text-muted transition-colors hover:text-fg",
					onClick: () => onChange([...draft, ""]),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "w-3 text-right font-mono text-meta text-accent/80",
						"aria-hidden": "true",
						children: "+"
					}), "Add step"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-1 text-meta",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "rounded-md px-1.5 py-0.5 text-muted transition-colors hover:text-fg",
							onClick: onCancel,
							children: "Cancel"
						}),
						canUndo ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "inline-flex items-center gap-1 rounded-md px-1.5 py-0.5 text-muted/70 transition-colors hover:text-fg",
							onClick: onUndo,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Undo2, {
								className: "size-3",
								"aria-hidden": "true"
							}), "Undo my edit"]
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "rounded-md px-2 py-0.5 font-medium text-accent transition-colors hover:bg-accent/10 disabled:opacity-40",
							disabled: kept.length === 0,
							onClick: onSave,
							children: "Save"
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 px-1.5 text-meta leading-snug text-muted/55",
				children: "Hold and drag a step to move it — a suggestion the agent may reorder or replace."
			})
		]
	});
}
function ChatPage() {
	const conversations = useAppStore((s) => s.conversations);
	const activeId = useAppStore((s) => s.activeId);
	const warning = useAppStore((s) => s.storageWarning);
	const active = conversations.find((c) => c.id === activeId);
	const scroller = (0, import_react.useRef)(null);
	const messages = active?.messages ?? [];
	const lastMessage = messages[messages.length - 1];
	const lastContent = lastMessage?.content;
	const lastStatus = lastMessage?.status;
	const lastTaskDetail = lastMessage?.task?.detail;
	const [panelOpen, setPanelOpen] = (0, import_react.useState)(() => readBoolPref(MESSAGE_PANEL_OPEN_KEY, true));
	(0, import_react.useEffect)(() => {
		writeBoolPref(MESSAGE_PANEL_OPEN_KEY, panelOpen);
	}, [panelOpen]);
	const openPanel = (0, import_react.useCallback)(() => setPanelOpen(true), []);
	const closePanel = (0, import_react.useCallback)(() => setPanelOpen(false), []);
	const armed = useAppStore((s) => s.multiAgentNextSend);
	const live = useAppStore((s) => s.multiAgentRunning);
	const hasCouncil = messages.some((message) => message.council && message.council.length > 0);
	const autoOpened = (0, import_react.useRef)(/* @__PURE__ */ new Set());
	const runWasActive = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		const active = armed || live;
		if (active && !runWasActive.current) setPanelOpen(true);
		runWasActive.current = active;
	}, [armed, live]);
	(0, import_react.useEffect)(() => {
		if (!activeId || !hasCouncil) return;
		if (autoOpened.current.has(activeId)) return;
		autoOpened.current.add(activeId);
		setPanelOpen(true);
	}, [activeId, hasCouncil]);
	const [nearBottom, setNearBottom] = (0, import_react.useState)(true);
	const following = (0, import_react.useRef)(true);
	const lastHeight = (0, import_react.useRef)(NaN);
	(0, import_react.useEffect)(() => {
		const el = scroller.current;
		if (!el) return;
		following.current = true;
		el.scrollTop = el.scrollHeight;
		lastHeight.current = el.scrollHeight;
	}, [activeId]);
	(0, import_react.useEffect)(() => {
		const el = scroller.current;
		if (!el) return;
		const height = el.scrollHeight;
		const move = shouldMoveView({
			following: following.current,
			height,
			lastHeight: lastHeight.current
		});
		lastHeight.current = height;
		if (!move) return;
		el.scrollTop = height;
	}, [
		messages.length,
		lastContent,
		lastStatus,
		lastTaskDetail
	]);
	const handleSendIntent = (0, import_react.useCallback)(() => {
		const el = scroller.current;
		if (!el) return;
		following.current = true;
		el.scrollTop = el.scrollHeight;
		lastHeight.current = el.scrollHeight;
	}, []);
	const handleScroll = (0, import_react.useCallback)(() => {
		const el = scroller.current;
		if (!el) return;
		const metrics = {
			scrollTop: el.scrollTop,
			scrollHeight: el.scrollHeight,
			clientHeight: el.clientHeight
		};
		following.current = nextFollowing(metrics);
		const atBottom = distanceFromBottom(metrics) < 48;
		setNearBottom((current) => current === atBottom ? current : atBottom);
	}, []);
	const empty = !active || messages.length === 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-0 flex-1",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex min-h-0 min-w-0 flex-1 flex-col",
			children: [
				warning ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "border-b border-border px-4 py-2 text-xs text-warn",
					role: "status",
					children: warning
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					ref: scroller,
					onScroll: handleScroll,
					className: "min-h-0 flex-1 overflow-y-auto",
					children: empty ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageList, {
						conversationId: active.id,
						messages
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "sticky bottom-0 z-20 shrink-0 bg-bg",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TaskProgressStrip, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusLine, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Composer, {
							nearBottom,
							onSendIntent: handleSendIntent
						})
					]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AgentPanel, {
			messages,
			open: panelOpen,
			armed,
			live,
			onOpen: openPanel,
			onClose: closePanel
		})]
	});
}
var SplitComponent = ChatPage;
//#endregion
export { SplitComponent as component };
