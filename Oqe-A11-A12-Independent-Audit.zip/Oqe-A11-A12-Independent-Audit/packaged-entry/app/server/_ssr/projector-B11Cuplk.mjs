import { i as __toESM } from "../_runtime.mjs";
import { H as require_jsx_runtime, V as require_react, y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { Dt as ChevronDown, Et as ChevronUp, G as Mic, U as Minimize, X as Maximize, _ as Snowflake, _t as CloudRain, gt as CloudSun, ht as Cloud, i as Wind, m as Sun, o as VolumeX, q as MicOff, s as Volume2, t as ZapOff, vt as CloudLightning, yt as CloudFog } from "../_libs/lucide-react.mjs";
import { Bt as hourLabel, Dn as readObservation, Ft as forecastUrlFor, Gn as startRecognition, Kn as stationNote, Ot as detectSpeechSupport, Pt as forecastLine, S as OqeSymbol, _t as currentActivityLabel, er as useAppStore, fn as observationUrl, nr as weatherLocation, rr as withForecastWeather, vn as parseForecast, x as OqeMark, zn as shouldShowWallAnswer } from "./router-CiIP6cPA.mjs";
import { r as transcribeAudio } from "./local-client-Cqz3VYgc.mjs";
import { n as wakeWord, t as routeTranscript } from "./session-XQZkns1t.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/projector-B11Cuplk.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* G4 (Prompt 19 audit) — the wall must not listen to its own voice.
*
* The projector reads answers aloud while its wake loop is open, and nothing
* stopped that loop from transcribing the wall's own speech: an answer
* containing “Oqe” could re-open a session with no one in the room speaking.
* These three questions are the policy, kept pure so the route's wiring cannot
* quietly drift from it:
*
*  - while speech is playing and the microphone is open, pause capture;
*  - resume only when the pause was OURS (never a reader's), the speech has
*    ended, and an engine is still available;
*  - never accept a transcript while speech is playing, which covers a chunk
*    already in flight when playback started.
*/
function wakePausesForSpeech(input) {
	return input.ttsSpeaking && input.wakeRunning;
}
function wakeResumesAfterSpeech(input) {
	return !input.ttsSpeaking && input.autoPaused && !input.pausedByUser && input.engineAvailable;
}
function acceptsWakeTranscript(ttsSpeaking) {
	return !ttsSpeaking;
}
function createProjectorWakeRunGuard() {
	let generation = 0;
	return {
		begin() {
			generation += 1;
			return generation;
		},
		cancel() {
			generation += 1;
		},
		isCurrent(run) {
			return run === generation;
		}
	};
}
/**
* Own exactly one local wake capture. `stop()` settles the active request and
* stops every track synchronously; if permission acquisition is still pending,
* a stream granted later is stopped before it can be recorded.
*/
function createProjectorWakeCaptureController(options = {}) {
	const getUserMedia = options.getUserMedia ?? (() => navigator.mediaDevices.getUserMedia({ audio: true }));
	const createRecorder = options.createRecorder ?? ((stream) => new MediaRecorder(stream));
	const setTimer = options.setTimer ?? ((callback, delayMs) => globalThis.setTimeout(callback, delayMs));
	const clearTimer = options.clearTimer ?? ((timer) => globalThis.clearTimeout(timer));
	let active = null;
	function settle(capture, blob, error) {
		if (capture.settled) return;
		capture.settled = true;
		if (capture.timer !== null) clearTimer(capture.timer);
		capture.timer = null;
		if (capture.signal && capture.abort) capture.signal.removeEventListener("abort", capture.abort);
		capture.stream?.getTracks().forEach((track) => track.stop());
		if (capture.recorder && capture.recorder.state !== "inactive") try {
			capture.recorder.stop();
		} catch {}
		if (active === capture) active = null;
		if (error !== void 0) capture.reject(error);
		else capture.resolve(blob);
	}
	return {
		async recordChunk(durationMs, signal) {
			if (active) settle(active, null);
			return await new Promise((resolve, reject) => {
				const capture = {
					settled: false,
					chunks: [],
					stream: null,
					recorder: null,
					timer: null,
					resolve,
					reject,
					signal
				};
				active = capture;
				capture.abort = () => settle(capture, null);
				if (signal?.aborted) {
					settle(capture, null);
					return;
				}
				signal?.addEventListener("abort", capture.abort, { once: true });
				(async () => {
					try {
						const stream = await getUserMedia();
						if (capture.settled) {
							stream.getTracks().forEach((track) => track.stop());
							return;
						}
						capture.stream = stream;
						const recorder = createRecorder(stream);
						capture.recorder = recorder;
						recorder.ondataavailable = (event) => {
							if (event.data.size > 0 && !capture.settled) capture.chunks.push(event.data);
						};
						const complete = () => {
							const first = capture.chunks[0];
							settle(capture, capture.chunks.length > 0 ? new Blob(capture.chunks, { type: first?.type || "audio/webm" }) : null);
						};
						recorder.onstop = complete;
						recorder.addEventListener?.("stop", complete, { once: true });
						recorder.start();
						capture.timer = setTimer(() => {
							if (capture.settled || recorder.state === "inactive") return;
							try {
								recorder.stop();
							} catch (error) {
								settle(capture, null, error);
							}
						}, durationMs);
					} catch (error) {
						settle(capture, null, error);
					}
				})();
			});
		},
		stop() {
			if (active) settle(active, null);
		}
	};
}
/**
* V10.40 — the next hours read as glyphs, not paragraphs. At three metres a
* word like "overcast" in 1rem is noise; a glyph is legible. The exact words
* stay reachable in the row's title. Ordered so a compound phrase lands on
* the most specific match: thunder first, then snow, fog, rain, a partly
* clear sky, cloud, and the clear/wind cases.
*/
var CONDITION_GLYPHS = [
	[/thunder|lightning|storm/i, CloudLightning],
	[/snow|sleet|hail|icy/i, Snowflake],
	[/fog|mist|haze/i, CloudFog],
	[/rain|drizzle|shower|wet/i, CloudRain],
	[/partly/i, CloudSun],
	[/cloud|overcast|dull|grey|gray/i, Cloud],
	[/sun|clear|bright|dry|fine/i, Sun],
	[/wind|breeze|gale/i, Wind]
];
function ForecastGlyph({ condition, now }) {
	const Icon = CONDITION_GLYPHS.find(([match]) => match.test(condition))?.[1] ?? Cloud;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
		className: `size-[clamp(1.15rem,2vw,1.55rem)] ${now ? "text-accent" : "text-muted"}`,
		"aria-hidden": "true"
	});
}
/**
* V7.8 /projector: the room's surface.
*
* V10.20 — the reader's report, and what changed:
*
*  1. “It is still the same ‘Tap the microphone and speak’ line.” The tap
*     control is gone. The wall listens for the wake word — the name, “Oqe” — from the
*     moment it opens, and a spoken name does exactly what the old microphone
*     tap did: the next words become one chat turn. The wake word is accepted
*     with or without its greeting (“Oqe, …” or “Hey Oqe, …”), and the session
*     closes again after the turn, so it never sits open by accident. A small
*     pause control remains for privacy; it is not the way to talk.
*  2. Every answer is read aloud. That is forced for the session by the store,
*     not left to the read-aloud setting.
*  3. The wall prints the answer only when reading it adds something (a
*     summary, a list, steps, code, a link, a long explanation). A spoken
*     “Playing the next episode.” stays off the screen — see
*     src/lib/wall-text.ts, where that rule is unit-tested. The text is
*     optional; the voice is not.
*  4. The weather is the measured temperature WITH a condition in words. The
*     Phoenix Park station publishes “N/A” as its description on every row, so
*     the wall fills the condition from the point forecast's current hour (see
*     `withForecastWeather`) and marks where it came from.
*  5. Entering the wall turns on full desktop access for the session (the store
*     saves the previous mode and restores it on exit).
*
* Unchanged from V7.8: no text composer, read-aloud stop control, answer
* history with ↑/↓, fullscreen and wake lock, honest idle states.
*/
/**
* The wall's weather is for the station the reader chose in Settings →
* Projector: Met Éireann's measurement from that station for the current
* reading, plus Met Éireann's own point forecast for the station's position for
* the current hour and the next five — which is also where the current
* condition words come from, because most stations publish no description.
*
* There is no default. With nothing chosen the wall says so and offers the way
* to choose, because borrowing the author's station (this used to be Phoenix
* Park) would be showing weather for a place the reader never picked. Invalid
* ids read back as unset for the same reason.
*
* Neither feed sends CORS headers a browser tab may use, and the point forecast
* is served over plain http only, so both are fetched through the app's own
* server probe route (the same one a page the reader supplies goes through) —
* the tab never talks to a third party directly. A URL set in Settings →
* Projector replaces BOTH.
*/
/** One local transcription window. Short enough that the name is heard quickly. */
var WAKE_CHUNK_MS = 4e3;
/** Breather before restarting the browser recognizer (avoids InvalidStateError). */
var RECOGNITION_RESTART_MS = 350;
/** Cancelled by the next mount — see the unmount effect in the page. */
var profileEndTimer = null;
function wait(ms) {
	return new Promise((resolve) => window.setTimeout(resolve, ms));
}
function ProjectorPage() {
	const conversations = useAppStore((s) => s.conversations);
	const activeId = useAppStore((s) => s.activeId);
	const projectorActive = useAppStore((s) => s.projectorActive);
	const projectorReason = useAppStore((s) => s.projectorReason);
	const setProjectorActive = useAppStore((s) => s.setProjectorActive);
	const settings = useAppStore((s) => s.settings);
	const streamingId = useAppStore((s) => s.streamingId);
	const ttsSpeaking = useAppStore((s) => s.ttsSpeaking);
	const stopTts = useAppStore((s) => s.stopTts);
	const setProjectorViewReady = useAppStore((s) => s.setProjectorViewReady);
	const endProjectorProfile = useAppStore((s) => s.endProjectorProfile);
	const projectorWeatherUrl = useAppStore((s) => s.settings.projectorWeatherUrl);
	const projectorWeatherLocation = useAppStore((s) => s.settings.projectorWeatherLocation);
	const sendUserMessage = useAppStore((s) => s.sendUserMessage);
	const liveTask = useAppStore((s) => {
		if (!s.streamingId) return void 0;
		for (const c of s.conversations) {
			const m = c.messages.find((msg) => msg.id === s.streamingId);
			if (m) return m.task;
		}
	});
	const navigate = useNavigate();
	const [fullscreen, setFullscreen] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setProjectorViewReady(true);
		return () => setProjectorViewReady(false);
	}, [setProjectorViewReady]);
	const weatherPlace = (0, import_react.useMemo)(() => weatherLocation(projectorWeatherLocation), [projectorWeatherLocation]);
	const [weather, setWeather] = (0, import_react.useState)(null);
	const [forecast, setForecast] = (0, import_react.useState)([]);
	const [weatherLines, setWeatherLines] = (0, import_react.useState)([]);
	const [weatherNote, setWeatherNote] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		const custom = projectorWeatherUrl.trim();
		let cancelled = false;
		async function probe(url) {
			const data = await (await fetch("/api/automations/probe", {
				method: "POST",
				headers: { "content-type": "application/json" },
				body: JSON.stringify({ url })
			})).json();
			return data.ok && typeof data.body === "string" ? data.body : null;
		}
		const place = weatherPlace;
		async function loadWeather() {
			try {
				if (!custom && !place) {
					if (cancelled) return;
					setWeather(null);
					setForecast([]);
					setWeatherLines([]);
					setWeatherNote("No weather location set — choose one in Settings → Projector.");
					return;
				}
				if (!custom && place) {
					const [observations, point] = await Promise.all([probe(observationUrl(place)), probe(forecastUrlFor(place))]);
					if (cancelled) return;
					const result = readObservation(observations ?? "", place);
					const hours = point ? parseForecast(point) : [];
					setForecast(hours);
					setWeatherLines([]);
					setWeather(result.ok ? result.reading : null);
					if (result.ok) setWeatherNote(null);
					else if (hours.length === 0) setWeatherNote(result.reason === "wrong-station" ? `Weather unavailable — Met Éireann answered for ${result.station ?? "another station"}, not ${place.station}.` : `Weather unavailable — ${place.station} is not reporting.`);
					else setWeatherNote(null);
					return;
				}
				const body = await probe(custom);
				if (cancelled) return;
				if (body === null) {
					setWeather(null);
					setWeatherLines([]);
					setForecast([]);
					setWeatherNote("Weather unavailable");
					return;
				}
				const lines = body.replace(/<[^>]+>/g, " ").split(/\s{2,}|\r?\n/).map((line) => line.trim()).filter((line) => line.length > 0 && /°|degree|weather|temperature|rain|snow|wind|cloud|sunny|storm|forecast|humid/i.test(line)).map((line) => line.slice(0, 160)).slice(0, 3);
				setWeather(null);
				setForecast([]);
				setWeatherLines(lines);
				setWeatherNote(lines.length > 0 ? null : "No weather line was found on that page.");
			} catch {
				if (!cancelled) {
					setWeather(null);
					setForecast([]);
					setWeatherLines([]);
					setWeatherNote("Weather unavailable");
				}
			}
		}
		loadWeather();
		const timer = setInterval(() => void loadWeather(), 9e5);
		return () => {
			cancelled = true;
			clearInterval(timer);
		};
	}, [projectorWeatherUrl, weatherPlace]);
	const shownWeather = (0, import_react.useMemo)(() => withForecastWeather(weather, forecast), [weather, forecast]);
	const [now, setNow] = (0, import_react.useState)(() => /* @__PURE__ */ new Date());
	(0, import_react.useEffect)(() => {
		const timer = setInterval(() => setNow(/* @__PURE__ */ new Date()), 3e4);
		return () => clearInterval(timer);
	}, []);
	const [wakeLockHeld, setWakeLockHeld] = (0, import_react.useState)(false);
	const wakeLockRef = (0, import_react.useRef)(null);
	const [viewIndex, setViewIndex] = (0, import_react.useState)(0);
	/**
	* V10.20 — wake listening state.
	*
	* `wakeRunning` is the mic being open for the wake word; `sessionOpen` is the
	* window between hearing the name and hearing the request. Both are shown in
	* the dock, and both are driven by the loop's own refs (the loop outlives
	* many renders, so it cannot read state).
	*/
	const [wakeRunning, setWakeRunning] = (0, import_react.useState)(false);
	const [sessionOpen, setSessionOpen] = (0, import_react.useState)(false);
	const [engine, setEngine] = (0, import_react.useState)(null);
	const [interim, setInterim] = (0, import_react.useState)("");
	const [voiceError, setVoiceError] = (0, import_react.useState)(null);
	const wakeStopRef = (0, import_react.useRef)(false);
	const wakeStartedRef = (0, import_react.useRef)(false);
	const wakeSessionRef = (0, import_react.useRef)(createProjectorWakeRunGuard());
	const wakeCaptureRef = (0, import_react.useRef)(createProjectorWakeCaptureController());
	const activeWakeAbortRef = (0, import_react.useRef)(null);
	const sessionRef = (0, import_react.useRef)(false);
	const browserStopRef = (0, import_react.useRef)(null);
	const recognitionFailedRef = (0, import_react.useRef)(false);
	const wakeAutoPausedRef = (0, import_react.useRef)(false);
	const wakePausedByUserRef = (0, import_react.useRef)(false);
	const [browserEngine, setBrowserEngine] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (profileEndTimer !== null) {
			window.clearTimeout(profileEndTimer);
			profileEndTimer = null;
		}
		return () => {
			wakeStopRef.current = true;
			browserStopRef.current?.();
			profileEndTimer = window.setTimeout(() => {
				profileEndTimer = null;
				endProjectorProfile();
			}, 0);
		};
	}, [endProjectorProfile]);
	const [prefersReducedMotion, setPrefersReducedMotion] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const query = window.matchMedia("(prefers-reduced-motion: reduce)");
		setPrefersReducedMotion(query.matches);
		const onChange = (event) => setPrefersReducedMotion(event.matches);
		query.addEventListener("change", onChange);
		return () => query.removeEventListener("change", onChange);
	}, []);
	const [chromeDimmed, setChromeDimmed] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		let timer;
		const arm = () => {
			setChromeDimmed(false);
			if (timer) clearTimeout(timer);
			timer = setTimeout(() => setChromeDimmed(true), 8e3);
		};
		arm();
		window.addEventListener("pointermove", arm);
		window.addEventListener("pointerdown", arm);
		window.addEventListener("keydown", arm);
		return () => {
			if (timer) clearTimeout(timer);
			window.removeEventListener("pointermove", arm);
			window.removeEventListener("pointerdown", arm);
			window.removeEventListener("keydown", arm);
		};
	}, []);
	const active = conversations.find((c) => c.id === activeId);
	/**
	* V10.20 — every settled answer, oldest first, each with the question that
	* produced it. The question decides whether the answer is text the room needs
	* to read (a requested summary) or a confirmation that was already spoken.
	*/
	const wallAnswers = (0, import_react.useMemo)(() => {
		const out = [];
		let question = "";
		for (const message of active?.messages ?? []) if (message.role === "user") question = message.content;
		else if (message.role === "assistant" && message.content.trim()) out.push({
			answer: message.content,
			question
		});
		return out;
	}, [active?.messages]);
	const current = wallAnswers[wallAnswers.length - 1 - Math.min(viewIndex, Math.max(0, wallAnswers.length - 1))];
	const streaming = Boolean(streamingId);
	(0, import_react.useEffect)(() => {
		setViewIndex(0);
	}, [wallAnswers.length]);
	const canGoOlder = wallAnswers.length > 1 && viewIndex < wallAnswers.length - 1;
	const canGoNewer = viewIndex > 0;
	const wallText = current ? shouldShowWallAnswer({
		question: current.question,
		answer: current.answer,
		policy: settings.projectorTextPolicy
	}) : null;
	const requestFullscreen = (0, import_react.useCallback)(async () => {
		try {
			await document.documentElement.requestFullscreen();
		} catch {}
	}, []);
	(0, import_react.useEffect)(() => {
		const onFsChange = () => setFullscreen(Boolean(document.fullscreenElement));
		document.addEventListener("fullscreenchange", onFsChange);
		return () => document.removeEventListener("fullscreenchange", onFsChange);
	}, [requestFullscreen]);
	(0, import_react.useEffect)(() => {
		const onPointer = () => {
			if (!document.fullscreenElement) requestFullscreen();
		};
		window.addEventListener("pointerdown", onPointer);
		return () => window.removeEventListener("pointerdown", onPointer);
	}, [requestFullscreen]);
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		const acquire = async () => {
			try {
				const nav = navigator;
				if (!nav.wakeLock) return;
				const lock = await nav.wakeLock.request("screen");
				if (cancelled) {
					lock.release();
					return;
				}
				wakeLockRef.current = lock;
				setWakeLockHeld(true);
				lock.addEventListener?.("release", () => setWakeLockHeld(false));
			} catch {
				setWakeLockHeld(false);
			}
		};
		const onVisible = () => {
			if (document.visibilityState === "visible" && !wakeLockRef.current) acquire();
		};
		acquire();
		document.addEventListener("visibilitychange", onVisible);
		return () => {
			cancelled = true;
			document.removeEventListener("visibilitychange", onVisible);
			wakeLockRef.current?.release().catch(() => {});
			wakeLockRef.current = null;
			setWakeLockHeld(false);
		};
	}, []);
	function exitProjector() {
		stopWakeListening();
		stopTts();
		setProjectorActive(false);
		if (document.fullscreenElement) document.exitFullscreen().catch(() => {});
		if (window.history.length > 1) history.back();
		else navigate({ to: "/" });
	}
	(0, import_react.useEffect)(() => {
		const onKey = (e) => {
			if (e.key === "Escape" && !document.fullscreenElement) exitProjector();
			if (e.key === "ArrowUp" && canGoOlder) {
				e.preventDefault();
				setViewIndex((index) => index + 1);
			}
			if (e.key === "ArrowDown" && canGoNewer) {
				e.preventDefault();
				setViewIndex((index) => Math.max(0, index - 1));
			}
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [canGoOlder, canGoNewer]);
	const send = (0, import_react.useCallback)((text) => {
		setInterim("");
		sendUserMessage(text).catch((error) => {
			setVoiceError(error instanceof Error ? error.message : "The message could not be sent.");
		});
	}, [sendUserMessage]);
	/**
	* One fixed-length chunk of microphone audio, or null when audio cannot be
	* captured at all (the caller then reports the honest reason once).
	*/
	async function recordWakeChunk(signal) {
		if (!navigator.mediaDevices?.getUserMedia || typeof MediaRecorder === "undefined") return null;
		return await wakeCaptureRef.current.recordChunk(WAKE_CHUNK_MS, signal);
	}
	/**
	* One heard phrase → the shared voice router → either a chat turn or a held
	* session.
	*
	* V10.20 — a turn CLOSES the session. The old behaviour kept listening until
	* the sleep phrase, which is not what the reader described: the wake word
	* should act like one microphone tap ("then it functions the same as if I
	* just clicked the microphone"). Saying “Oqe” alone opens the session for the
	* next utterance; saying “Oqe, play the next episode” sends that one turn and
	* goes back to waiting for the name.
	*/
	function handleHeard(heard, wakeDetected = false) {
		if (!acceptsWakeTranscript(useAppStore.getState().ttsSpeaking)) {
			setInterim("");
			return;
		}
		const decision = routeTranscript({
			transcript: wakeDetected ? `${settings.wakePhrase} ${heard}` : heard,
			sessionOpen: sessionRef.current,
			wakeSessionEnabled: true,
			wakePhrase: settings.wakePhrase,
			sleepPhrase: settings.sleepPhrase
		});
		if (decision.kind === "discard") {
			setInterim("");
			return;
		}
		if (decision.kind === "sleep") {
			sessionRef.current = false;
			setSessionOpen(false);
			setInterim("");
			return;
		}
		const text = decision.text.trim();
		setInterim("");
		if (text) {
			sessionRef.current = false;
			setSessionOpen(false);
			send(text);
			return;
		}
		sessionRef.current = true;
		setSessionOpen(true);
	}
	/** Local engine loop: fixed chunks, transcribed locally, nothing leaves the box. */
	async function runLocalWakeLoop(run) {
		while (!wakeStopRef.current && wakeSessionRef.current.isCurrent(run)) {
			const controller = new AbortController();
			activeWakeAbortRef.current = controller;
			const blob = await recordWakeChunk(controller.signal);
			if (activeWakeAbortRef.current === controller) activeWakeAbortRef.current = null;
			if (wakeStopRef.current || !wakeSessionRef.current.isCurrent(run)) break;
			if (!blob) {
				setVoiceError("This browser cannot capture microphone audio for local speech-to-text.");
				break;
			}
			const result = await transcribeAudio({
				blob,
				tier: settings.sttTier,
				wakePhrase: settings.wakePhrase,
				sleepPhrase: settings.sleepPhrase,
				signal: controller.signal
			});
			if (activeWakeAbortRef.current === controller) activeWakeAbortRef.current = null;
			if (wakeStopRef.current || !wakeSessionRef.current.isCurrent(run)) break;
			const heard = result.text.trim();
			if (!heard) continue;
			if (result.wakeDetected) setInterim(heard);
			handleHeard(heard, result.wakeDetected);
		}
	}
	/** The browser's own recognition: one utterance per run, restarted until stopped. */
	async function runBrowserWakeLoop(run) {
		while (!wakeStopRef.current && wakeSessionRef.current.isCurrent(run)) {
			const heard = await new Promise((resolve) => {
				let settled = false;
				const finish = (value) => {
					if (settled) return;
					settled = true;
					resolve(value);
				};
				const started = startRecognition({
					onInterim: (text) => {
						if (wakeSessionRef.current.isCurrent(run)) setInterim(text);
					},
					onFinal: (text) => finish(text),
					onError: (message) => {
						if (!wakeSessionRef.current.isCurrent(run)) return;
						recognitionFailedRef.current = true;
						setVoiceError(message);
						finish(null);
					},
					onEnd: () => finish(null)
				});
				if ("error" in started) {
					if (!wakeSessionRef.current.isCurrent(run)) return;
					recognitionFailedRef.current = true;
					setVoiceError(started.error);
					finish(null);
					return;
				}
				browserStopRef.current = started.stop;
			});
			browserStopRef.current = null;
			if (wakeStopRef.current || !wakeSessionRef.current.isCurrent(run)) break;
			if (recognitionFailedRef.current) break;
			if (heard === null) {
				await wait(RECOGNITION_RESTART_MS);
				continue;
			}
			setInterim("");
			handleHeard(heard);
		}
	}
	/**
	* V10.20 — the wall listens from the moment it opens. There is no tap to
	* start it: the reader asked for the wake word to be the way in. The engine
	* is the local bridge when the reader chose it (private, chunked), else this
	* browser's recognition (fast, but audio goes to the browser's service — the
	* dock says which one is live).
	*/
	const startWakeListening = (0, import_react.useCallback)(async () => {
		if (wakeStartedRef.current) return;
		const local = settings.localSttEnabled;
		if (!local && !browserEngine) {
			setVoiceError("Wake listening needs a speech engine: turn on Oqe's local speech-to-text in Settings → Voice, or use a browser with speech recognition.");
			return;
		}
		wakeStartedRef.current = true;
		wakeStopRef.current = false;
		const run = wakeSessionRef.current.begin();
		recognitionFailedRef.current = false;
		sessionRef.current = false;
		setSessionOpen(false);
		setInterim("");
		setVoiceError(null);
		setWakeRunning(true);
		setEngine(local ? "local" : "browser");
		try {
			if (local) await runLocalWakeLoop(run);
			else await runBrowserWakeLoop(run);
		} catch (error) {
			if (!wakeStopRef.current && wakeSessionRef.current.isCurrent(run)) setVoiceError(error instanceof Error && error.name === "NotAllowedError" ? "Microphone permission was denied. Allow it in the browser to use the wake word." : error instanceof Error ? error.message : "Wake listening stopped.");
		} finally {
			if (wakeSessionRef.current.isCurrent(run)) {
				wakeStartedRef.current = false;
				sessionRef.current = false;
				setWakeRunning(false);
				setSessionOpen(false);
				setInterim("");
			}
		}
	}, [
		browserEngine,
		send,
		settings.localSttEnabled,
		settings.sttTier,
		settings.wakePhrase,
		settings.sleepPhrase
	]);
	function stopWakeListening() {
		wakeStopRef.current = true;
		wakeSessionRef.current.cancel();
		wakeCaptureRef.current.stop();
		activeWakeAbortRef.current?.abort();
		activeWakeAbortRef.current = null;
		wakeStartedRef.current = false;
		sessionRef.current = false;
		setWakeRunning(false);
		setSessionOpen(false);
		setInterim("");
		browserStopRef.current?.();
		browserStopRef.current = null;
	}
	(0, import_react.useEffect)(() => {
		setBrowserEngine(detectSpeechSupport().recognition);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!projectorActive) return;
		startWakeListening();
		return () => stopWakeListening();
	}, [
		projectorActive,
		browserEngine,
		settings.localSttEnabled,
		settings.wakePhrase,
		settings.sleepPhrase
	]);
	(0, import_react.useEffect)(() => {
		if (!projectorActive) return;
		if (wakePausesForSpeech({
			ttsSpeaking,
			wakeRunning
		})) {
			wakeAutoPausedRef.current = true;
			stopWakeListening();
			return;
		}
		const engineAvailable = settings.localSttEnabled || browserEngine;
		if (wakeResumesAfterSpeech({
			ttsSpeaking,
			autoPaused: wakeAutoPausedRef.current,
			pausedByUser: wakePausedByUserRef.current,
			engineAvailable
		})) {
			wakeAutoPausedRef.current = false;
			startWakeListening();
		}
	}, [
		ttsSpeaking,
		wakeRunning,
		projectorActive,
		browserEngine,
		settings.localSttEnabled
	]);
	const engineAvailable = settings.localSttEnabled || browserEngine;
	const spokenWakeWord = wakeWord(settings.wakePhrase) || settings.wakePhrase;
	const dockHint = voiceError ? null : sessionOpen ? interim || "Listening — say what you want." : ttsSpeaking ? "Reading the answer aloud — the microphone is paused." : wakeRunning ? `Say “${spokenWakeWord}” to talk.` : engineAvailable ? "Wake word is paused." : "Wake listening needs a speech engine — see Settings → Voice.";
	if (!projectorActive) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full flex-col items-center justify-center gap-8 bg-bg px-6 text-center text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "hero-orb",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OqeSymbol, { className: "size-28" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "hero-title",
				children: "Projector mode is off."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "inline-flex min-h-12 items-center rounded-md bg-linear-to-b from-[#ffc76e] to-[#e89a2a] px-5 text-sm font-medium text-[color:var(--color-on-accent)] shadow-[0_0_0_1px_rgb(255_179_71_/_0.45),inset_0_1px_0_0_rgb(255_240_214_/_0.55)] hover:from-[#ffd387] hover:to-[#f2a935] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[color:var(--color-accent)]",
				onClick: () => {
					setProjectorActive(true, "Projector mode enabled manually.");
				},
				children: "Start projector mode"
			})
		]
	});
	const railDim = chromeDimmed ? "opacity-40" : "opacity-100";
	const wallIdle = !streaming && !(current && wallText?.show);
	const conditionTitle = !weatherPlace ? "No weather location set" : shownWeather?.conditionSource === "forecast" ? "Condition from Met Éireann's forecast for the current hour — the station publishes no description" : stationNote(weatherPlace);
	const weatherMeta = shownWeather ? [weatherPlace?.label, shownWeather.reported ? `measured ${shownWeather.reported}` : "forecast"].filter(Boolean).join(" · ") : "";
	const weatherMetaTitle = !weatherPlace ? "No weather location set" : shownWeather?.station && shownWeather.station !== weatherPlace.station ? `${stationNote(weatherPlace)} · via ${shownWeather.station}` : conditionTitle;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full flex-col bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: `flex flex-wrap items-center gap-x-4 gap-y-1 border-b border-border px-6 py-1.5 text-xs text-muted transition-opacity duration-500 ${railDim}`,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-center gap-2.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mark-tile",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OqeMark, {
								className: "size-3.5",
								state: streaming ? "working" : "idle"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "wordmark text-sm text-fg",
							children: "Oqe"
						})]
					}),
					projectorReason ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "readout min-w-0 flex-1 truncate",
						title: projectorReason,
						children: projectorReason
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "min-w-0 flex-1" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-center gap-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "readout flex min-h-11 items-center gap-1.5 px-1.5",
								title: settings.textToSpeech ? "Read-aloud on" : "Read-aloud forced on for the wall",
								children: settings.textToSpeech ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, {
									className: "size-4 text-ok",
									"aria-label": "Read-aloud on"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, {
									className: "size-4",
									"aria-label": "Read-aloud off"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "readout flex min-h-11 items-center gap-1.5 px-1.5",
								title: engine ? `${engine === "local" ? "Local speech-to-text" : "Browser speech recognition"} · ${sessionOpen ? "listening" : wakeRunning ? "waiting for the wake word" : "paused"}` : "Wake word not running",
								children: wakeRunning ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mic, {
									className: `size-4 ${sessionOpen ? "text-accent" : "text-ok"}`,
									"aria-label": "Wake word listening"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MicOff, {
									className: "size-4",
									"aria-label": "Wake word paused"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "readout flex min-h-11 items-center gap-1.5 px-1.5",
								title: wakeLockHeld ? "Screen stays awake" : "Wake lock unavailable",
								"aria-label": wakeLockHeld ? "Screen stays awake" : "Wake lock unavailable",
								children: wakeLockHeld ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "size-1.5 rounded-full bg-ok",
									"aria-hidden": "true"
								}), "awake"] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ZapOff, {
									className: "size-4",
									"aria-hidden": "true"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								"aria-pressed": fullscreen,
								className: "inline-flex min-h-11 items-center gap-2 rounded-md px-3 font-medium text-fg shadow-[0_0_0_1px_var(--color-border)] hover:bg-surface-2 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[color:var(--color-accent)]",
								onClick: () => document.fullscreenElement ? void document.exitFullscreen().catch(() => {}) : void requestFullscreen(),
								children: [fullscreen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minimize, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Maximize, { className: "size-4" }), fullscreen ? "Exit fullscreen" : "Fullscreen"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "inline-flex min-h-11 items-center rounded-md px-3 font-medium text-muted hover:bg-surface-2 hover:text-fg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[color:var(--color-accent)]",
								onClick: exitProjector,
								children: "Exit"
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: `flex min-h-0 flex-1 flex-col items-center px-[6vw] py-[5vh] text-center ${wallIdle ? "justify-center" : "overflow-y-auto"}`,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "wall-clock",
						children: new Intl.DateTimeFormat(void 0, {
							hour: "numeric",
							minute: "2-digit"
						}).format(now)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-[clamp(1.05rem,1.7vw,1.4rem)] tracking-[0.01em] text-muted",
						children: new Intl.DateTimeFormat(void 0, {
							weekday: "long",
							month: "long",
							day: "numeric"
						}).format(now)
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						role: "status",
						"aria-label": "Weather",
						className: "mt-[clamp(2rem,6vh,3.5rem)]",
						children: [shownWeather ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "flex flex-wrap items-baseline justify-center gap-x-4 gap-y-1",
							children: [shownWeather.temperature ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "wall-temp",
								children: [shownWeather.temperature, "°"]
							}) : null, shownWeather.condition || shownWeather.wind ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[clamp(1.05rem,1.6vw,1.35rem)] text-muted",
								title: conditionTitle,
								children: [shownWeather.condition, shownWeather.wind].filter(Boolean).join(" · ")
							}) : null]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "readout mt-2 text-signal/85",
							title: weatherMetaTitle,
							children: weatherMeta
						})] }) : weatherLines.length > 0 ? weatherLines.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[clamp(1.05rem,1.6vw,1.35rem)] leading-snug text-muted",
							children: line
						}, line)) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "readout text-muted",
							children: weatherNote ?? "Weather"
						}), !weatherPlace && !projectorWeatherUrl.trim() ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "/settings",
							className: "mt-3 inline-flex min-h-11 items-center rounded-md bg-surface-2 px-4 text-sm text-fg shadow-[inset_0_0_0_1px_var(--color-border)] hover:bg-surface",
							children: "Choose a weather location"
						}) : null] }), weatherPlace && forecast.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
							className: "mt-[clamp(1.3rem,3vh,2.2rem)] flex items-start justify-center gap-x-[clamp(1.4rem,4vw,3.5rem)]",
							"aria-label": "Hourly forecast",
							children: forecast.map((hour) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex flex-col items-center gap-1",
								title: forecastLine(hour) || void 0,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: hour.now ? "readout text-accent" : "readout text-muted",
										children: hour.now ? "now" : hourLabel(hour.at)
									}),
									hour.temperature ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-[clamp(1.15rem,1.9vw,1.7rem)] font-medium tabular-nums text-fg",
										children: [hour.temperature, "°"]
									}) : null,
									hour.condition ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ForecastGlyph, {
										condition: hour.condition,
										now: hour.now
									}) : null
								]
							}, hour.at))
						}) : null]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("hr", { className: "lampline mt-8 w-64 max-w-[70%]" }),
					streaming ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "readout mt-8 text-accent",
						role: "status",
						"aria-live": "polite",
						children: currentActivityLabel(liveTask) ?? "Working"
					}) : null,
					current && wallText?.show ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "wall-answer mt-8 max-w-[62ch] whitespace-pre-wrap text-left",
						"aria-live": streaming ? "off" : "polite",
						children: [current.answer, streaming ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: `ml-2 inline-block h-[1em] w-[3px] bg-accent align-[-0.1em] ${prefersReducedMotion ? "" : "animate-pulse"}`,
							"aria-hidden": "true"
						}) : null]
					}) : null
				]
			}),
			wallAnswers.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				className: `flex items-center justify-center gap-3 transition-opacity duration-500 ${railDim}`,
				"aria-label": "Answer history",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "inline-flex min-h-11 min-w-11 items-center justify-center rounded-full text-muted shadow-[0_0_0_1px_var(--color-border)] hover:bg-surface-2 hover:text-fg disabled:cursor-not-allowed disabled:opacity-30 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[color:var(--color-accent)]",
						"aria-label": "Previous answer (older)",
						disabled: !canGoOlder,
						onClick: () => setViewIndex((index) => index + 1),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronUp, {
							className: "size-5",
							"aria-hidden": "true"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "readout min-w-24 text-center text-muted",
						"aria-live": "off",
						children: [
							Math.min(viewIndex, wallAnswers.length - 1) + 1,
							" / ",
							wallAnswers.length
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "inline-flex min-h-11 min-w-11 items-center justify-center rounded-full text-muted shadow-[0_0_0_1px_var(--color-border)] hover:bg-surface-2 hover:text-fg disabled:cursor-not-allowed disabled:opacity-30 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[color:var(--color-accent)]",
						"aria-label": "Next answer (newer)",
						disabled: !canGoNewer,
						onClick: () => setViewIndex((index) => Math.max(0, index - 1)),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, {
							className: "size-5",
							"aria-hidden": "true"
						})
					})
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				className: `flex flex-col items-center gap-1 border-t border-border px-6 pt-3 pb-5 transition-opacity duration-500 ${railDim}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "min-h-6 max-w-[60ch] text-center text-lg text-fg",
					"aria-live": "polite",
					children: voiceError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-danger",
						children: voiceError
					}) : dockHint
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid w-full max-w-2xl grid-cols-[1fr_auto_1fr] items-center gap-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "justify-self-start",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								"aria-pressed": wakeRunning,
								className: ["inline-flex min-h-11 items-center gap-2 rounded-full px-4 text-sm font-medium shadow-[0_0_0_1px_var(--color-border)] hover:bg-surface-2 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[color:var(--color-accent)]", wakeRunning ? "text-muted" : "text-fg"].join(" "),
								title: wakeRunning ? "Close the microphone until you start it again" : ttsSpeaking ? "Wait until the answer finishes reading, then open the microphone" : "Open the microphone and wait for the wake word",
								disabled: !wakeRunning && ttsSpeaking,
								onClick: () => {
									if (wakeRunning) {
										wakePausedByUserRef.current = true;
										stopWakeListening();
									} else {
										wakePausedByUserRef.current = false;
										startWakeListening();
									}
								},
								children: [wakeRunning ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MicOff, {
									className: "size-4",
									"aria-hidden": "true"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mic, {
									className: "size-4",
									"aria-hidden": "true"
								}), wakeRunning ? "Pause wake word" : "Resume wake word"]
							}), ttsSpeaking ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "ml-2 inline-flex min-h-11 items-center gap-2 rounded-full px-4 text-sm font-medium text-fg shadow-[0_0_0_1px_var(--color-border)] hover:bg-surface-2 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[color:var(--color-accent)]",
								onClick: () => stopTts(),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, { className: "size-4" }), "Stop read-aloud"]
							}) : null]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "justify-self-center",
							"data-listening": sessionOpen ? "true" : "false",
							title: engine === "local" ? "Listening locally — audio never leaves this computer" : engine === "browser" ? "Listening with this browser's speech recognition" : void 0,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OqeSymbol, {
								className: "size-14",
								state: sessionOpen ? "working" : wakeRunning ? "idle" : "offline"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "justify-self-end" })
					]
				})]
			})
		]
	});
}
//#endregion
export { ProjectorPage as component };
