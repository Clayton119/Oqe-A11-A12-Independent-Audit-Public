/**
 * Verify MANIFEST-SHA256.txt against the files in this bundle, and check that
 * every file except the manifest itself is covered.
 *
 * Run: node reproduce/verify-manifest.mjs
 */
import { createHash } from "node:crypto";
import { readFileSync, readdirSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const bundle = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const manifestPath = path.join(bundle, "MANIFEST-SHA256.txt");
const lines = readFileSync(manifestPath, "utf8").split(/\r?\n/).filter(Boolean);
const entries = new Map();

for (const line of lines) {
  const match = /^([a-f0-9]{64})  (.+)$/.exec(line);
  if (!match) {
    console.error(`FAIL: malformed manifest line: ${line}`);
    process.exit(1);
  }
  entries.set(match[2], match[1]);
}

function walk(dir, prefix = "") {
  const found = [];
  for (const entry of readdirSync(dir, { withFileTypes: true })) {
    const rel = prefix ? `${prefix}/${entry.name}` : entry.name;
    if (entry.isDirectory()) found.push(...walk(path.join(dir, entry.name), rel));
    else found.push(rel);
  }
  return found;
}

const actual = new Set(walk(bundle).filter((rel) => rel !== "MANIFEST-SHA256.txt"));
let failures = 0;
for (const [rel, expected] of entries) {
  if (!actual.has(rel)) {
    console.error(`FAIL: manifest names a missing file: ${rel}`);
    failures++;
    continue;
  }
  const digest = createHash("sha256").update(readFileSync(path.join(bundle, rel))).digest("hex");
  if (digest !== expected) {
    console.error(`FAIL: hash mismatch: ${rel}`);
    failures++;
  }
}
for (const rel of actual) {
  if (!entries.has(rel)) {
    console.error(`FAIL: file is not in the manifest: ${rel}`);
    failures++;
  }
}

if (failures > 0) process.exit(1);
console.log(`PASS: ${entries.size} files match the manifest; every bundle file is covered`);
