/**
 * Recompute the packaged-entry transform from the raw generated entry and
 * compare it byte-for-byte with the packaged copy in this bundle.
 *
 * Run: node reproduce/apply-packaged-guard.mjs
 */
import { createHash } from "node:crypto";
import { readFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

import { guardPackagedEntry, PACKAGED_ENTRY_GUARD } from "../files/scripts/installer-lib.mjs";

const bundle = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const rawPath = path.join(bundle, "files/.output/server/index.mjs");
const packagedPath = path.join(bundle, "packaged-entry/app/server/index.mjs");
const raw = readFileSync(rawPath, "utf8");
const packaged = readFileSync(packagedPath, "utf8");
const expected = guardPackagedEntry(raw);

function sha256(text) {
  return createHash("sha256").update(text).digest("hex");
}

console.log(`guard: ${PACKAGED_ENTRY_GUARD}`);
console.log(`raw_sha256:      ${sha256(raw)}`);
console.log(`packaged_sha256: ${sha256(packaged)}`);
console.log(`expected_sha256: ${sha256(expected)}`);
console.log(`guard_is_first: ${packaged.startsWith(PACKAGED_ENTRY_GUARD)}`);
console.log(`body_matches_raw: ${packaged.slice(PACKAGED_ENTRY_GUARD.length + 1) === raw}`);
console.log(`transform_exact: ${packaged === expected}`);

if (packaged !== expected) {
  console.error("FAIL: the packaged entry is not the guardPackagedEntry transform of the raw entry");
  process.exit(1);
}
console.log("PASS");
