# Oqe — independent audit bundle for A-11 and A-12

Prepared 2026-10-27 from commit `4e744558fa48c19e95be9dd7c9d4b5ac719b0ebd`
(branch `main`). **This bundle has not been independently audited.** It is
material for review, not a release, a promotion, or a security sign-off.

## What this contains

- `AUDIT-EVIDENCE.md` — commit/status, changed files, exact commands and exit
  codes, test counts, the observed bare-`--host` output, guard ordering,
  execution limits, T3/T5 status, and release state.
- `files/` — current files with repository-relative paths:
  - A-11/A-12 implementation (`scripts/loopback-bind.mjs`,
    `scripts/loopback-preflight.mjs`, `scripts/installer-lib.mjs`,
    `scripts/build-installer.mjs`, `vite.config.ts`,
    `installer/Oqe-start.ps1`, `README-Windows.md`);
  - tests and helpers, including `scripts/loopback-bind.test.mjs`,
    `scripts/packaged-entry-guard.test.mjs`, `scripts/installer.test.mjs`;
  - peer/task security dependencies from `src/`;
  - build config (`package.json`, `tsconfig.json`, `eslint.config.mjs`);
  - the raw generated `.output/server/index.mjs`;
  - no `node_modules`, cache, `.git`, secrets or user data.
- `packaged-entry/` — the actual post-packaging tree for the generated server:
  `app/server/` (full `_libs`/`_ssr`/entry tree), `Oqe-preflight.mjs` and
  `loopback-bind.mjs` at the payload root. Its entry begins with
  `import "../../Oqe-preflight.mjs";`.
- `records/` — complete current copies of `AUDIT-CP-58.md`,
  `SCOPE-RESTORATION-PLAN.md`, `SCOPE-RESTORATION-REPORT.md`,
  `V11.1-ISSUES.md`, `CHECKPOINT-LOG.md`.
- `evidence/` — raw command logs and state captures.
- `reproduce/` — scripts to recompute the packaged-entry transform and verify
  the integrity manifest.

## Integrity

```bash
node reproduce/verify-manifest.mjs
node reproduce/apply-packaged-guard.mjs
```

`MANIFEST-SHA256.txt` lists every bundle file except itself, with relative path
and SHA-256.

## Reproducing the checks

The tests expect a full Oqe worktree with dependencies installed. This bundle
contains the relevant files, not the repository or `node_modules`; copy them
into a checkout of the same commit to rerun:

```bash
node --test scripts/loopback-bind.test.mjs
node --test scripts/packaged-entry-guard.test.mjs scripts/installer.test.mjs
node --experimental-strip-types --test src/lib/loopback-peer.test.ts \
  src/lib/local-request-security.test.ts \
  src/lib/companion/power-route.test.ts \
  src/lib/server-task-runner.test.ts
npm run typecheck
OQE_NITRO_PRESET=node-server npm run build
```

Expected results are recorded in `AUDIT-EVIDENCE.md`; the one full-suite failure
is the deliberately absent `RELEASE-V11.1.sha256`.

## Running the packaged entry

Non-loopback refusal is safe to check because the preflight exits before
`serve`:

```bash
NITRO_HOST=0.0.0.0 node packaged-entry/app/server/index.mjs   # expect exit 1
```

Only run this in an isolated environment. If the guard were broken, the
unauthenticated app would attempt to listen on every interface. The fixture
tests in `scripts/packaged-entry-guard.test.mjs` are the safe reproduction.

The repository's own dev server was left on `127.0.0.1:8080` (PID 10464) during
preparation and was not rebound.
