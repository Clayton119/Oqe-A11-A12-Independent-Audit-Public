# CP-58 independent security audit — A + C (Prompt 59, 2026-10-27)

Read-only audit of the Prompt 58 remediation. No product file, test, configuration, dependency, build
script or release artifact was changed. No consent was granted, no desktop action was executed, and the
P0 gate was not closed.

Environment: Windows, Node v24.19.0, branch `main`, HEAD `4e74455`, working tree 117 modified / 46 deleted
/ 141 untracked (the same tree CP-58 left). Built artefact: `.output/` from
`OQE_NITRO_PRESET=node-server npm run build` (CP-58, exit 0), which predates only a later comment-only
edit in `src/routes/api/companion.$.ts`.

## 1. Verdict

| Area | Verdict |
| --- | --- |
| **A — refuse non-loopback binding** | **PASS** for dev, preview and the installed launcher. One robustness defect (F-2) and one enforcement boundary that is launcher-only (F-3) |
| **C — companion proxy peer check** | **PASS** for every `/api/companion/*` route, including power controls |
| **C — "server-held credentials cannot be injected by untrusted clients"** | **FAIL** — a second server-side path attaches the same token behind a spoofable Host/Origin gate (F-1) |
| Overall P0 | **NOT CLOSED.** A is sound; C is incomplete as defence in depth. The supported install is not exposed, but the gate should not close on this evidence |

**Correction (Prompt 60):** F-1 is fixed — task dispatch now requires caller trust, with the peer gate on
both task routes. The verdicts above remain the audit of record; §8 records the correction.

## 2. Findings

### F-1 — HIGH — a second path injects the companion token, outside the peer-gated proxy

> **Status:** corrected in Prompt 60 — see §8. The analysis below is preserved as found.

**What.** The server task runner performs desktop actions by calling the companion directly and attaching
the app's session token:

- [`src/lib/server-task-runner.server.ts:528`](src/lib/server-task-runner.server.ts#L528) `const token = companionToken();`
- [`src/lib/server-task-runner.server.ts:539`](src/lib/server-task-runner.server.ts#L539) `fetch(`${companionOrigin()}/execute`, { … })`
- [`src/lib/server-task-runner.server.ts:544`](src/lib/server-task-runner.server.ts#L544) `"x-oqe-companion-token": token`

This is not the proxy and never calls `companionPeerRejected`.

**Reachability.** `POST /api/tasks/start` accepts a caller-supplied plan
([`src/routes/api/tasks.start.ts:42`](src/routes/api/tasks.start.ts#L42), validated at `:86`), and
`validateServerTaskWork` accepts `{"kind":"desktop","action":…}` for the actions in `COMPANION_ACTIONS`
(`move`, `click`, `drag`, `type`, `press`, `focus`, `hotkey`, `scroll`, `wait`, `done`) —
[`src/lib/server-task-runner.server.ts:267`](src/lib/server-task-runner.server.ts#L267) and
[`src/lib/server-task-runner.server.ts:290`](src/lib/server-task-runner.server.ts#L290). The runner
schedules the pump immediately (`:1093`, `:1152`).

The route's only gate is `serverTaskRequestRejected`
([`src/lib/server-task-runner.server.ts:398`](src/lib/server-task-runner.server.ts#L398)), which checks:

1. `new URL(request.url).hostname` is `127.0.0.1`/`localhost`/`::1` — derived from the **client's `Host`
   header**;
2. `localRequestRejected` — `Origin`/`Referer`/`Sec-Fetch-Site`, all client-chosen;
3. `x-oqe-tasks: 1` — a static marker any client can send.

Those are exactly the checks Prompt 56 demonstrated to be spoofable (`Host: 127.0.0.1` turned a 403 into
200 on the storage and task routes). The proxy's new peer check does not stand in front of this path.

**Impact.** Given a paired companion and a server bound to a non-loopback address, a LAN client could
enqueue desktop work that the server dispatches with its own token, without the proxy's peer refusal. The
companion's per-target consent, arm state and latching STOP still apply, and a target that was never
consented stays refused — so this is not unconditional desktop control. It is still a stronger capability
than the proxy would allow, and it contradicts CP-57 §C ("server-held companion credentials cannot be
injected into requests from untrusted network clients").

**Scope/severity reasoning.** Unreachable while A holds, so no supported configuration exposes it. It
becomes reachable exactly in the scenario C exists for — A bypassed (see F-3). Rated **HIGH**, not
critical, for that reason.

**Runtime status.** `NOT VERIFIED` — proving it would require `POST /api/tasks/start` with a desktop
effect against the live companion. That was deliberately not run. The finding rests on source, which is
unambiguous: no peer check exists on this path.

**Suggested correction (not implemented).** Apply the same peer predicate inside
`dispatchServerTaskEffect` before `companionToken()`/`fetch`, failing the item rather than dispatching;
prefer failing the task at `/api/tasks/start` too. Add a test with a stubbed dispatch that asserts no
token and no fetch for a non-loopback request. Bounded to one file plus its test.

### F-2 — MEDIUM — bare `--host` (boolean) crashes instead of refusing with a readable message

`normalizeHost` returns non-string values unchanged
([`scripts/loopback-bind.mjs:18`](scripts/loopback-bind.mjs#L18)), so `isLoopbackHost` reaches
`v4.split(".")` with a boolean ([`scripts/loopback-bind.mjs:36`](scripts/loopback-bind.mjs#L36)) and throws
a `TypeError`.

Reproduced: `npx vite dev --host --port 8096` → exit 1, **no listener** (so it fails closed), but the
output is `TypeError: … .split is not a function`, not the intended
`The Oqe dev server refuses to bind to …`. Vite represents a valueless `--host` (and `host: true`) as the
boolean `true`, i.e. "all interfaces".

The existing spawned-Vite test covers only string hosts
([`scripts/loopback-bind.test.mjs:181`](scripts/loopback-bind.test.mjs#L181)), so it does not catch this.

**Suggested correction.** Normalize non-strings to `String(value)` or reject them with
`LoopbackBindError`; add `--host` with no value to the spawn test. Not a bypass — it fails closed.

### F-3 — MEDIUM — A is launcher-enforced; direct entry binds all interfaces by default and is undocumented in product docs

The guard is a `--import` preflight plus the installer. The generated entry itself is unchanged:

- [`.output/server/index.mjs:965`](.output/server/index.mjs#L965) `var host = process.env.NITRO_HOST || process.env.HOST;`
- [`.output/server/index.mjs:969`](.output/server/index.mjs#L969) `serve({ …, hostname: host, … })`

With **no** environment at all, `hostname` is `undefined` (`node_modules/srvx/dist/_chunks/_utils2.mjs:1-8`
falls back only to an ambient `HOST`), and Node listens on every interface. Measured, not inferred:
running the entry with `NITRO_HOST`/`HOST` unset produced
`TCP 0.0.0.0:8099 LISTENING` **and** `TCP [::]:8099 LISTENING`, and the server printed
`Listening on: http://localhost:8099/ (all interfaces)`. So `node .output/server/index.mjs` — no
preflight, no variable — exposes the app by default, a weaker starting point than "a deliberate
`HOST=0.0.0.0`".

CP-58 documented this in the audit documents (`SCOPE-RESTORATION-PLAN.md` §10.5,
`SCOPE-RESTORATION-REPORT.md` §12.4) but **not** in product docs. `START-HERE.txt:15` says "Do not run the
server through 0.0.0.0", and `README-Windows.md` names `app\server\index.mjs` only as a file location;
neither says that running it directly skips the guard.

Supported paths are all guarded: `npm run dev` / `npm run preview` (Vite plugin), `START-OQE.cmd` →
`run-oqe-server.cmd` → `npm run dev`, and the installed `Oqe-start.ps1` (`--import` before the entry,
[`installer/Oqe-start.ps1:83`](installer/Oqe-start.ps1#L83)). So this is not a hole in a supported
launch; it is a missing second line of defence and a documentation gap.

**Suggested correction.** Post-build, wrap or rewrite the generated entry so it refuses a non-loopback
`hostname` (or defaults it to `127.0.0.1`) regardless of `--import`; in the meantime, state the direct-run
hazard in `README-Windows.md`/`START-HERE.txt`. Note the caveat that patching generated output must
survive a Nitro upgrade.

### F-4 — MEDIUM — tests do not prove the proxy refuses, only that a predicate exists

The peer logic is well unit-tested (12 bind cases, 8 peer cases, IPv4/IPv6/mapped/malformed). What is
**not** tested is the request-level gate:

1. No test calls `companionPeerRejected` with a stubbed peer. `if (peer) return peer;`
   ([`src/routes/api/companion.$.ts:88`](src/routes/api/companion.$.ts#L88)) could be reduced to
   `companionPeerRejected(request, …);` and every test still passes.
2. The route-order test asserts the peer call precedes the proxy forward and the injection, but **not**
   that it precedes the `/power/` dispatch (`:93`). Moving power handling above the gate would pass
   [`src/lib/loopback-peer.test.ts:69`](src/lib/loopback-peer.test.ts#L69) while exposing `/enable`,
   `/stop`, `/start`.
3. No automated forwarded-header test; the denial is established only by this audit's manual probe.
4. The `--host` boolean case (F-2) is untested.
5. `src/lib/loopback-peer.test.ts` resolves the route via `process.cwd()`, so it fails if the runner is
   started outside the repo root.

**Suggested correction.** Add (a) a unit test that injects a stub peer source, or export a
`companionPeerResponse(address)` that is tested to return 403/undefined; (b) an ordering assertion for
`/power/`; (c) a spawned-server integration test for `X-Forwarded-For` and `Host` spoofing; (d) the
boolean host case; (e) resolve the route from `import.meta.url`.

### F-5 — LOW — predicate/normalisation edge cases

- `::ffff:7f00:1` (hex IPv4-mapped loopback) is **refused**. Fails closed, but a stack that reports peers
  in that form would lock a legitimate user out of the companion bridge. Dotted-mapped is handled and was
  tested live.
- `bundleBindHost` treats **any** `HOST` value as a bind request. On a machine where `HOST` is set for
  unrelated tooling, the installed server would refuse to start (availability, not security).
- Dev keeps `allowUnknown: !import.meta.env.PROD`; the compiled bundle resolves it to `false` in
  production (verified in `.output/server/_ssr/router-*.mjs`), and the dev server was observed to populate
  the peer, so the fallback is currently unused. It remains a fail-open shape if a future dev adapter drops
  the address — acceptable only while the bind guard holds.

### F-6 — LOW — installed launch is asserted, not executed

`Oqe-start.ps1` is checked by source assertions
([`scripts/installer.test.mjs:135`](scripts/installer.test.mjs#L135)) but was not run here: PowerShell
`Start-Process … @("--import", "file:///…", "…")` on a clean Windows account is `NOT VERIFIED`. If Node
rejected the file-URL argument, the installed app would fail to start rather than expose anything.

## 3. Item-by-item results

| # | Item | Result |
| --- | --- | --- |
| 1 | Complete CP-58 diff against starting state | **PASS (with caveat).** The four tracked edits were reviewed hunk by hunk; `local-request-security.server.ts` is additive (67+/0−), the route is 15+/3− and confined to the peer call and token helper, the companion test is 10+/1−. `vite.config.ts` shows 22+/153− **against HEAD V11.0** because the auth/PWA removal predates CP-58; every removed line inspected is that earlier removal, and the surviving plugins (`longLivedStreamPlugin`, Tailwind, TanStack Start, conditional Nitro preset) are intact. The five new files and the three edited untracked installer files were read in full. No stray edits found |
| 2 | Peer identification on every supported path; headers cannot substitute | **PASS.** h3-v2 `getRequestIP` with `xForwardedFor: false` returns `event.req.context?.clientAddress || event.req.ip` (`node_modules/h3-v2/dist/h3-Bz4OPZv_.mjs:649-657`); srvx's `ip` getter only reads `x-forwarded-for` when `trustProxy` is set (`node_modules/srvx/dist/adapters/node.mjs:281-289`, `_chunks/_trust-proxy.mjs`), and the generated entry calls `serve({…})` without it. Live: LAN requests with `X-Forwarded-For: 127.0.0.1`, `X-Forwarded-For: ::1`, `X-Real-IP`, `Forwarded: for=127.0.0.1`, plus spoofed `Host`/`Origin`, all returned **403**; loopback returned 200 |
| 3 | Address forms | **PASS for security.** Unit: 127/8, `::1`, `0:0:0:0:0:0:0:1`, dotted IPv4-mapped accepted; LAN, link-local, public, `0.0.0.0`, `::`, malformed, missing refused. Live IPv6: `NITRO_HOST=::1` + preflight bound `[::1]:8099`, peer `::1` accepted → 200. Production missing-peer behaviour compiles to `allowUnknown: false`. Hex-mapped form refused (F-5) |
| 4 | Token selection/injection ordering on every `/api/companion/*` route | **FAIL overall.** The proxy is correct — peer check at `:87`/`:88` precedes `powerRoute` (`:93`), `companionToken()` (`:105`) and `fetch` (`:118`); `fromThisApp` remains a CSRF check. Loopback path probe: `/api/companion` and `/api/companion/` → 404, `/api/companion/health` → 200, `/api/companion/power/status` → 200 (read-only). But the runner path (F-1) injects the same token with no peer check |
| 5 | Vite hook checks resolved dev and preview hosts | **PASS (security).** `configResolved` is a plugin hook (`vite.config.ts:70-78`, registered `:95`). Live: `dev --host 0.0.0.0`, `dev --host 192.168.1.151`, `OQE_DEV_HOST=0.0.0.0`, `preview --host 0.0.0.0` all exit 1 with the refusal and no listener. Bare `--host` fails closed but with a `TypeError` (F-2) |
| 6 | Preflight before binding on every supported launch path | **PASS for supported paths.** Installed: `--import Oqe-preflight.mjs app\server\index.mjs` with `NITRO_HOST` pinned (`installer/Oqe-start.ps1:78-84`), payload ships both modules (`scripts/installer-lib.mjs:62-66`), build refuses a missing payload source. Dev/preview: Vite guard. Execution of the PowerShell launcher itself: `NOT VERIFIED` (F-6). Direct entry: unguarded (F-3) |
| 7 | Is direct `.output/server/index.mjs` genuinely unsupported, and is that documented? | **FAIL.** Nothing enforces it, and with no environment it binds all interfaces. Only the audit documents say so; product docs do not (F-3) |
| 8 | Full-suite failure exclusively the provenance assertion | **PASS.** `npm test` (CP-58 log): scripts 170/166 pass/4 skipped/0 fail; `src` 2985/2984 pass/**1 fail**; extension 78/78. The log lists exactly one failing test — `v89-release-provenance.test.ts:98`, `RELEASE-V11.1.sha256` absent. Re-ran that file alone: 14/15 pass, same single assertion. It reflects the deliberate non-promotion of V11.1, not a regression |
| 9 | Regression-test quality | **FAIL (gaps, no false green).** See F-4. Existing tests are honest: the Vite test spawns the real server, the preflight test spawns the real preflight, and both assert exit status plus message. But no test would catch a dropped `return`, a re-ordered power dispatch, or a forwarded-header regression |

## 4. What is established, and what is not

Established on this host: the bind refusal works for dev, preview, env and CLI (except the boolean form's
message); the unwrapped built entry binds `0.0.0.0` and `[::]` when no host is configured; the proxy rejects non-loopback requests for health, reads, writes, `/execute`, `/consent-target`,
`/enable` and power actions before forwarding; forwarded headers do not influence the peer; loopback use
still works in dev and in the built server; the production bundle fails closed on an unknown peer.

**NOT VERIFIED:** any request from a genuinely separate device (T3); a live token-injection denial with a
paired companion (T5); the F-1 task path at runtime (deliberately not exercised); a clean Windows install
and launch; Windows Firewall behaviour; that a future Nitro build keeps the entry shape that makes the
preflight sufficient.

## 5. Prerequisites for the three pending checks

**T3 — separate device.** A second machine on the same LAN with a browser or `curl`; the host running the
built server bound `0.0.0.0` (only for the duration) with the preflight **off** to test C in isolation, and
once with the preflight **on** to confirm A refuses to start at all. Expect: connection refused with A; 403
on every `/api/companion/*` and `/api/tasks/*` route with A removed. Record both machines' addresses and
the exact commands. Do not use this host's own Wi-Fi address as a substitute.

**T5 — token injection.** A disposable companion with a recorded token and no consented targets, the app
configured to point at it, and a stub `/execute` that logs headers. Assert: a refused (non-loopback)
request produces zero companion requests; a loopback request carries the token. Never pair against the
real desktop, never grant consent, and keep the stub's log out of the repository.

**Clean Windows.** A fresh user account or VM without Node, Python or Ollama; run the candidate installer,
launch from the Start menu, confirm the server binds `127.0.0.1` only (`netstat`), confirm the preflight
rejects a tampered `NITRO_HOST`, and confirm uninstall keeps user data.

## 6. Prioritised corrections (none implemented)

1. **F-1 (HIGH):** peer-gate `dispatchServerTaskEffect` (and reject at `/api/tasks/start`); add a stubbed
   dispatch test proving no token/fetch for a non-loopback request.
2. **F-3 (MEDIUM):** make the generated entry fail closed without the preflight, or document the direct-run
   hazard prominently in `START-HERE.txt`/`README-Windows.md` until it is wrapped.
3. **F-4 (MEDIUM):** request-level tests for the peer gate, `/power/` ordering, forwarded headers, and the
   boolean host case.
4. **F-2 (MEDIUM):** reject non-string hosts with `LoopbackBindError`; add the bare-`--host` spawn case.
5. **F-5 / F-6 (LOW):** hex-mapped IPv4 note, `HOST` collision note, and an executed PowerShell launch
   check.

Gate status: **A PASS; C incomplete.** The P0 gate remains open, V11.1 remains unpromoted, and no release
artifact was produced. This document is the only record added by the audit, together with the checkpoint
entry and register row.

## 7. Confirmation

Read-only inspection plus safe network probes: loopback and LAN `GET /api/companion/health`, spoofed
headers, IPv6 loopback, and Vite startup refusals. No consent, no desktop action, no task creation, no
secret read or logged, no product file edited, no test or configuration changed, no release metadata
regenerated. `git status` after the audit: 117 modified / 46 deleted / 141 untracked — unchanged from
CP-58.
## 8. Correction (Prompt 60, 2026-10-27)

The finding above is preserved as found. F-1 was corrected after this audit:

- `companionPeerRejected` was generalised to `loopbackPeerRejected` (the companion helper now delegates), so
  the proxy and the task routes share one predicate.
- `POST /api/tasks/start` and `POST /api/tasks/resume/$taskId` run that gate **before** their handlers and
  pass `trusted: true` only when it passes.
- The runner carries `trusted` into the pump (`start`, `resume`); it defaults to **false**, and a desktop
  effect on an untrusted run fails before the journal, before `companionToken()` and before any fetch.
  Boot recovery and cancel-triggered pumps are untrusted, so a recovered desktop item fails closed until a
  peer-checked resume.
- Tests added: untrusted start (0 dispatch, 0 fetch, failed with the guard message), trusted start still
  dispatches, bookkeeping needs no trust, untrusted resume of a queued desktop item, the gate fails closed
  under spoofed `Host`/`Origin`/`Referer`/`x-oqe-tasks`/`X-Forwarded-For`, both routes gate before the
  handler, and the guard precedes `dispatch` with token retrieval confined to the dispatcher.

Evidence: runner suite **35/35**; typecheck 0; eslint 0; build 0; `npm test` 2992 / 2991 pass, with the
pre-existing missing-checksum assertion as the only failure. Live, with the built server on `0.0.0.0:8099`
and the preflight off, a LAN request with spoofed `Host`, matching `Origin` and `x-oqe-tasks: 1` got **403**
from both `/api/tasks/start` and `/api/tasks/resume/task-x`; loopback `/api/tasks/start` reached the handler
(415 for `text/plain`), so local use is intact.

Residual after the correction: **T5** (real paired companion on the wire) and **T3** (separate device)
remain `NOT VERIFIED`; F-2..F-6 remain open; recovery of desktop work now fails closed by design. The gate
stays open and V11.1 stays unpromoted.

## 9. Independent re-audit of F-1 (Prompt 61, 2026-10-27)

Read-only re-verification of §8 from the current tree (`4e74455`, 117 modified / 46 deleted / 142 untracked).
The correction was not taken on trust: every trust-granting and dispatch path was traced, the runner tests
were re-run, and the live loopback boundary was exercised on the dev server at `127.0.0.1:8080`.

### 9.1 Call-path matrix

| Path | Where trust is decided | Default when absent | Can a client influence it? | Result |
| --- | --- | --- | --- | --- |
| `POST /api/tasks/start` | Route handler runs `loopbackPeerRejected(request)` first, then `handleTaskStart(request, { trusted: true })` (`src/routes/api/tasks.start.ts:114-122`) | Handler's `options` defaults to `{}`; `options.trusted === true` is false (`:41-44`, `:100`) | No. The body is read only for `title`, `items` and `taskId` (`:62-79`); `trusted` is a function argument, not a parsed field | PASS |
| `POST /api/tasks/resume/$taskId` | Same gate before `handleTaskResume` (`src/routes/api/tasks.resume.$taskId.ts:100-110`) | `options.trusted === true` false (`:75-77`) | No. Body is read only for `decision` (`:50-70`) | PASS |
| Runner `start` | `input.trusted === true` (`server-task-runner.server.ts:1176`) | false | No; internal API only | PASS |
| Runner `resume` | `options.trusted === true` (`:1287`) | false | No | PASS |
| Cancel-triggered pump | `void pump(taskId)` (`:1205`) | false — no trust parameter | No | PASS (fails closed) |
| Boot recovery | `void pump(task.id)` (`:1385`) | false | No | PASS (fails closed; intended) |
| Duplicate start | No new pump is scheduled (`:1168-1172`); the existing pump keeps its own trust | — | A duplicate cannot upgrade or downgrade an in-flight pump | PASS |
| Dispatch | `if (effect.kind === "desktop" && !trusted)` (`:967`) runs before the journal (`:985`), before `dispatch` (`:1024`), and token retrieval lives only inside `dispatchServerTaskEffect` (`:528`) | — | No | PASS |

### 9.2 Forging and persistence

- **Payload:** `validateServerTaskWork` (`:326`) accepts only `id`, `label` and an effect that passes the
  `COMPANION_ACTIONS` allowlist (`:267`, `:303`). It has no trust field to smuggle.
- **Persistence:** only `queueState` and `effectsState` are stored (`:1154-1163`); the row has no trust
  column, and `effectsState` is re-parsed into effects only (`:605`). A stored task cannot carry trust across
  a restart, which is why recovery is untrusted.
- **Journal:** entries record `taskId`, `operationId`, side-effect class and observations; nothing in the
  journal grants trust.
- **Headers:** `loopbackPeerRejected` ignores its `Request` argument for the decision (`void request;`,
  `local-request-security.server.ts:88-99`). It reads `getRequestIP({ xForwardedFor: false })`, so `Host`,
  `Origin`, `Referer`, `x-oqe-tasks`, `X-Forwarded-For`, `X-Real-IP` and `Forwarded` are all irrelevant.

### 9.3 Peer source

- h3 `getRequestIP` with `xForwardedFor: false` returns `event.req.context?.clientAddress || event.req.ip`
  (`node_modules/h3/dist/h3.mjs:647-656`) and never reads the header.
- srvx `NativeRequest.ip` resolves to `socket.remoteAddress` unless `trustProxy` is configured; with the
  default (`undefined`/`false`) the `x-forwarded-for` branch is not taken
  (`node_modules/srvx/dist/adapters/node.mjs:281-288`, `_chunks/_trust-proxy.mjs`). The generated entry sets
  no `trustProxy`.
- `isLoopbackPeer` accepts `127.0.0.0/8`, `::1`, `0:0:0:0:0:0:0:1`, and dotted `::ffff:127.x`; it refuses
  private, link-local, malformed and missing values (`local-request-security.server.ts:50-65`).

### 9.4 Findings

| ID | Severity | Finding | Status |
| --- | --- | --- | --- |
| R-1 | — | F-1 correction is structurally complete and fails closed on every path that can dispatch a desktop effect | **PASS** |
| R-2 | LOW | Route-level assertions are source-text checks (`server-task-runner.test.ts:1402-1425`), so a *new* unguarded handler or an earlier `/power/` dispatch could be added without the test noticing. The negative boundary itself is exercised at the runner level (real pump, mocked fetch, `globalThis.fetch` spy), not through a real HTTP request | **PASS with test gap** (F-4 remains) |
| R-3 | LOW | `handleTaskStart`/`handleTaskResume` still accept a caller-supplied `trusted` option. Any in-process module could pass `true`, but such a module can already call `serverTaskRunner().start({ trusted: true })` directly; there is no remote path to either. No change recommended | **INFO** |
| R-4 | LOW | Boot recovery and cancel pumps now fail queued desktop items closed instead of resuming them. Deliberate, user-visible behaviour change recorded in plan §11.1 | **INFO** |

### 9.5 Live checks (dev server, loopback only)

| Probe | Result |
| --- | --- |
| `GET /` on `127.0.0.1:8080` | **200** |
| `POST /api/tasks/start` with `x-oqe-tasks: 1`, JSON, `{"title":"audit","items":[]}` | **400** "a task needs at least one work item" — the peer gate passed and the handler's validation refused it. No task row created |
| Same without `x-oqe-tasks` | **400** "missing the local task header" (route-order check after the peer gate) |
| `GET /api/companion/power/status` | **200** `{running:false, paired:false, phase:"unpaired"}` |
| `GET /api/companion/health` | **200** `{ok:true, phase:"unpaired"}` |
| `POST /api/companion/execute` with `{}` and no app Origin | **401** from the companion ("Pair the browser … first"). No token was injected; with an unpaired companion the server may hold none, so this probe does **not** prove the injection gate either way — T5 still needs a paired companion |

The negative side (a non-loopback peer with spoofed headers) was **not re-run in this pass**: the running app
is bound to loopback by A, so there is no non-loopback peer to produce without starting a second,
unsafe-bound server. CP-60's live 403 on the preflight-off built server stands as the most recent negative
evidence; T3 and T5 remain `NOT VERIFIED`.

### 9.6 F-2 and F-3, re-confirmed without changing either

- **F-2 (MEDIUM, open):** `npx vite --host --port 8099` exits **1** without a listener, but the message is
  `TypeError: … .split is not a function` from `isLoopbackHost`. Vite maps bare `--host` to boolean `true`;
  `normalizeHost` returns the boolean unchanged and `isLoopbackHost` calls `.split` on it. The refusal is
  accidental, not the intended `LoopbackBindError`. `npx vite --host 0.0.0.0 --port 8099` exits **1** with
  the policy message and no listener, so the attack path is still refused.
- **F-3 (MEDIUM, open):** `.output/server/index.mjs:965` still reads
  `var host = process.env.NITRO_HOST || process.env.HOST;` and passes it to `serve`; the entry contains no
  preflight import (`grep -n "preflight\|loopback" .output/server/index.mjs` → no match). With neither
  variable set, Node listens on every interface — measured in CP-59. Only `installer/Oqe-start.ps1` loads
  `Oqe-preflight.mjs` (via `node --import`) and pins `NITRO_HOST=127.0.0.1`; there is no `npm start` script
  and no other supported launcher. Smallest safe correction (not implemented): during installer packaging,
  prepend `import "../../Oqe-preflight.mjs";` to the staged `app/server/index.mjs`, so direct execution
  fails closed too, plus a packaging test that runs the staged entry with `NITRO_HOST=0.0.0.0` and asserts
  it exits before listening.

### 9.7 Commands run

| Command | Result |
| --- | --- |
| `node --experimental-strip-types --test src/lib/loopback-peer.test.ts src/lib/local-request-security.test.ts src/lib/companion/power-route.test.ts` | **20/20 pass**, 0 fail |
| `node --experimental-strip-types --test src/lib/server-task-runner.test.ts` | **35/35 pass**, 0 fail |
| `npm run typecheck` | exit **0** |
| `npx eslint` on the seven security/launch files | exit **0** |
| `npx vite --host --port 8099` | exit **1**, `TypeError`, no listener |
| `npx vite --host 0.0.0.0 --port 8099` | exit **1**, `LoopbackBindError`, no listener |
| Live probes in §9.5 | as tabulated |

`npm test`, `npm run build` and the full-suite provenance failure were **not re-run**: no source, test or
configuration file changed in this prompt, and a build would overwrite the `.output` used by the running
dev server. The known single failure remains `RELEASE-V11.1.sha256 is missing`
(`src/lib/v89-release-provenance.test.ts`), unchanged from CP-60.

### 9.8 Verdict

**F-1: independently verified (structural, unit, and live positive path).** C is enforced on both task
routes and at the dispatch boundary, and no client-controlled value can grant trust. The route-level
runtime negative remains covered only by CP-60's live probe, and T3/T5 are still pending, so the P0 gate
stays **open**. F-2 and F-3 remain **open**; both are assessed here and neither is implemented. No product
code, test, configuration, dependency or release artifact was changed by this re-audit.

## 10. Corrections (Prompt 62, 2026-10-27)

F-2 and F-3 were approved and corrected after §9. The findings above are preserved as found.

- **F-2 (A-11):** `assertLoopbackBind` refuses boolean/non-string values before any string operation. A bare
  `--host` raises `LoopbackBindError` ("it means all interfaces … pass --host 127.0.0.1") instead of
  `TypeError`; `allowUnset` no longer covers a non-string. `isLoopbackHost(true)` returns `false`. The real
  dev server with bare `--host` exits 1 with the policy sentence and leaves no listener
  (`scripts/loopback-bind.test.mjs` 15/15).
- **F-3 (A-12):** packaging prepends `import "../../Oqe-preflight.mjs";` to the staged
  `app/server/index.mjs`, after the payload copy and before zipping, and fails the build if the preflight is
  missing or the entry did not take the guard. The launcher still uses `--import`; both paths share
  `Oqe-preflight.mjs`. `scripts/packaged-entry-guard.test.mjs` runs a disposable staged entry and proves
  non-loopback binds exit 1 before the entry body, loopback runs, a missing preflight fails closed, and
  repackaging does not duplicate the guard.

Verification: packaging/loopback suites **32/32**; peer/task suites **55/55**; typecheck **0**; eslint **0**;
`OQE_NITRO_PRESET=node-server npm run build` **0**; a dry stage of the fresh `.output` puts the guard first
with the server body unchanged. `npm test` leaves only the pre-existing missing `RELEASE-V11.1.sha256`
assertion. T3/T5 are still pending; P0 is **not closed** and V11.1 remains unpromoted.
