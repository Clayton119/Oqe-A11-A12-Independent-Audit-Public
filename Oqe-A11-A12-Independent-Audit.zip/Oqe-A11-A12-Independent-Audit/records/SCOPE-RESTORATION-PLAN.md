# Oqe — Scope Restoration Plan (removal and restoration of unapproved changes)

Companion to `SCOPE-CHANGE-AUDIT.md` (IDs SC-nn are defined there). Ordered by the sequence in
which the corrective edits were made. Written before the edits, kept as the record of *why* each
one was safe.

Baseline this restores to: **HEAD `4e74455`** (the V11.0 working state) for the four presentation
paths, and the approved scope of prompts 27–37 for everything else.

---

## R-1 — SC-09: the inverted V6.9 T8 contract test

| Field | Content |
| --- | --- |
| What is removed | The rewritten `describe("V6.9 T8 / Prompt 26 — library and evidence are reachable destinations")` block and its flipped assertions |
| Why outside approved scope | It reverses an existing, tested product contract ("no primary nav to library/evidence") that HEAD shipped. No retained prompt text authorises that reversal. A test change that *permits* what a contract forbade is the decision itself, not a side effect of storage work |
| Exact files | `src/lib/v69-contract.test.ts` (only the T8 block; `git diff --stat` = 20+/13−, all inside it) |
| Approved functionality that depends on it | Nothing depends on the *inverted* form. The original form guards SC-06/07/08 from drifting back |
| How that is preserved | `git checkout HEAD -- src/lib/v69-contract.test.ts` restores the original assertions, which then **fail** if the nav/pages return unauthorised — the guard is net stronger after the restoration |
| Tests that must change / remain | This file *is* the change. Its neighbouring T7 assertions (model tags) and the "V6.9 residual contracts" block are untouched and must keep passing |
| Rollback | `git checkout HEAD -- src/lib/v69-contract.test.ts` again, or re-apply the checkpoint copy `..\preflight-backups\2026-10-26\scope-audit\files\…` (note: that copy was taken *after* the Prompt-26 edit, so HEAD is the correct restore source for this file) |

## R-2 — SC-07: routes that render the unapproved pages

| Field | Content |
| --- | --- |
| What is removed | `component: LibraryPage` / `component: EvidencePage` and their Prompt-26 comment blocks |
| Why | HEAD's routes redirected home by contract; making them render is the surfacing decision that was never approved |
| Exact files | `src/routes/library.tsx`, `src/routes/evidence.tsx` (8 lines each) |
| Approved functionality that depends on it | None: the page components have no other importer (verified: `grep -rn "pages/evidence-page\|pages/library-page" src/` → only these two routes) |
| How that is preserved | The approved storage layer is untouched: `evidence-library.ts`, `evidence_items`, `/api/storage/evidence`, and their tests all remain |
| Tests that must change / remain | `storage.evidence.test.ts` (API-level, 3 suites) must still pass unchanged; the restored T8 asserts the redirect |
| Rollback | `git show HEAD:src/routes/evidence.tsx` is the pre-edit content; re-apply the checkpoint copies to return to the Prompt-26 form |

## R-3 — SC-06: the `Knowledge` navigation group

| Field | Content |
| --- | --- |
| What is removed | `<section aria-labelledby="knowledge-label">` with its `Library` and `Evidence` links, plus the now-unused `Library` / `ScrollText` icon imports |
| Why | A new labelled section in the primary rail is a product-visible feature; approving evidence storage did not authorise it, and HEAD's contract forbade it |
| Exact files | `src/components/sidebar.tsx` (the diff vs HEAD was *only* this: 21 insertions, 1 deletion — verified before checkout) |
| Approved functionality that depends on it | Studio (`/voice-studio`, `/automations`), Chat, thread list, search, settings — none touched |
| How that is preserved | Restored byte-identically to HEAD, so Studio and the rest are exactly as released |
| Tests that must change / remain | `v69-contract.test.ts` T8 (R-1) asserts absence; nothing else reads the nav |
| Rollback | `git checkout HEAD -- src/components/sidebar.tsx`, or re-apply the checkpoint copy to return to the Prompt-26 form |

## R-4 — SC-08: page titles for the two routes

| Field | Content |
| --- | --- |
| What is removed | `"/library": "Library"` and `"/evidence": "Evidence"` from `TITLES`, and the comment that justified them |
| Why | A header title for a screen the reader cannot open (HEAD's own stated rule). Presentation-only, no logic |
| Exact files | `src/components/app-shell.tsx` — **surgical edit only** |
| Approved functionality that depends on it | The same file carries V11.1 projector-notice and Prompt-35 automation-bridge work; those hunks were **not** touched (the edit was scoped to the `TITLES` block) |
| How that is preserved | `TITLES` remains a `Record<string,string>`; unknown paths already fall back to the generic title path |
| Tests that must change / remain | `v69-contract.test.ts` T8 restores the `doesNotMatch` assertions on `"/library"` / `"/evidence"` |
| Rollback | Re-add the two entries (they are quoted in `SCOPE-CHANGE-AUDIT.md` SC-08) |

## R-5 — SC-25: my own probe file

| Field | Content |
| --- | --- |
| What is removed | `.tmp-store-probe.ts` (untracked, 915 bytes, written by me while diagnosing a test; imported nowhere) |
| Why | It is my debugging debris, not product source; leaving it invites a future commit to pick it up |
| Exact files | `.tmp-store-probe.ts` (untracked, so deletion cannot lose repository history) |
| Dependencies | none (`grep -rn "tmp-store-probe" src/ scripts/` → no references) |
| Rollback | Not needed; it was a throwaway with no unique content |

---

## Deliberately **not** removed

| Item | Why it stays |
| --- | --- |
| SC-05 evidence model + `evidence_items` + `/api/storage/evidence` | The approved half of Prompt 26; deleting a schema version and an API with its own security gates is a migration decision, not a scope correction |
| SC-11 `evidence-page.tsx` / `library-page.tsx` bodies | Unreachable after R-2, so they cost nothing at runtime; deleting ~700 lines would destroy work you may yet approve. Full revert is one command and is offered, not taken |
| SC-10 recall control + explicit recall system turn | **BLOCKED — REVIEW REQUIRED**: removing it touches request assembly (`store.ts`), which is behaviour, not presentation, and "bounded recall" was part of Prompt 26's recorded subject. Three options recorded in the audit §7.3 |
| SC-20 profiles and the composer chip | Prompt 34 is quoted in Part I §6.2, but that quotation is **Tier 2**; Part III reclassifies it **E — pending confirmation** (§7.3 C-6). Removing it on doubt would delete work you may have asked for, so it stays |
| SC-12 `components/evidence/evidence-badges.tsx` | Still referenced by the recall control (SC-10), which is retained |
| SC-27 auth cluster | Pre-existing V11.1 work by you, untouched |

---

## Safety check performed on the plan itself

- No STOP, consent, pairing, token, capability-ceiling, journal-before-side-effect or task-ownership
  code is touched by any R-item. Every R-item is navigation, routing, page title, one test file, or
  my own scratch file.
- No database table, row, migration or stored user data is deleted. Records created while the pages
  were live stay in the database and remain readable through the approved API.
- No new UI is introduced to replace what is removed. The rail simply returns to its released shape.
- Reversal for every item is a single `git` operation, and each was verified as containing **only**
  the relevant hunks before it was applied.

---

## R-6 — SC-28: recall control's links to hidden routes (re-audit, 2026-10-27)

| Field | Content |
| --- | --- |
| What is removed | Three `<Link>` elements in `src/components/chat/recall-control.tsx` — `to="/evidence"` ("Save a record on the Evidence page"), `to="/library"` ("Open the library"), `to="/library"` ("What was used") — and the now-unused `Link` import |
| Why | Both routes redirect to `/` by the restored V6.9 T8 contract, so each link was a dead affordance that surfaced destinations the approved state keeps unreachable. This is the last such surface in the product |
| Exact files | `src/components/chat/recall-control.tsx` (presentation only) |
| What is preserved | The empty-state sentence ("Nothing is saved yet, so there is nothing to recall"), the chosen-items count, the last-recall readout, and the whole recall **request assembly** in `store.ts` guarded by `v67-contract.test.ts` |
| Dependencies | None. No test asserts the links (`grep` across the recall tests → none); `Link` is used nowhere else in the file after the edit, so the import goes too |
| Tests that must remain | `v67-contract.test.ts` (recall block bounded, explicit-only) and `v69-contract.test.ts` T8 — both re-run after the edit |
| Rollback | Restore `recall-control.tsx` from `..\preflight-backups\2026-10-27\scope-audit-post-52\` |

**Not done:** the recall control itself (SC-10) is unchanged apart from these links; removing the
control and its request-assembly turn stays blocked on your decision.

---

# 7. Part III — decision-ready plan after evidence recovery (2026-10-27)

Nothing here has been executed. Sections 1–6 record Phase 1 planning and the corrections applied in
Prompt 53. This section separates what the new evidence supports from what needs your word.

## 7.1 Already done (unchanged by this pass)

| # | Change | Status |
| --- | --- | --- |
| P1 | Knowledge nav group removed; rail restored to HEAD | done, verified absent |
| P2 | `/library` and `/evidence` redirect again | done, verified |
| P3 | `TITLES` entries for both paths removed | done, verified |
| P4 | `v69-contract.test.ts` T8 restored to the original assertions | done |
| P5 | Recall control's three links to the hidden routes removed | done in Prompt 53 |

This pass added documents only. No source file was touched.

## 7.2 Corrections now supported by *explicit* evidence

**None new.** Your Prompts 50–52 are the only Tier-1 text, and their work (installer, final gate,
packaging repair) is already implemented and verified. Everything below rests on Tier 2–4 evidence and
therefore needs your decision first.

## 7.3 Corrections that require approval

### C-1 — Recall control and its recall turn (SC-10)

| Field | Content |
| --- | --- |
| Change if approved | Delete `src/components/chat/recall-control.tsx`, its render site in `composer.tsx`, the `pendingRecall` / recall-turn hunk in `store.ts`, and the recall assertions in `v67-contract.test.ts` |
| Why not authorised now | No prompt text survives (T4); it also changes request assembly, not just presentation |
| Files | `recall-control.tsx`, `composer.tsx`, `store.ts`, `v67-contract.test.ts`, possibly `components/evidence/evidence-badges.tsx` |
| Must remain | Evidence storage, `/api/storage/evidence`, `evidence_items`, `evidence-library.ts` — independent of the control |
| Tests | `v67-contract.test.ts` (rewritten, not deleted), `storage.evidence.*`, `v69-contract.test.ts` |
| Rollback | Re-apply the four hunks from the Prompt-53 checkpoint copy |
| Safe without approval? | **No** |

### C-2 — Delete the two unreachable page components (SC-11)

| Field | Content |
| --- | --- |
| Change | Delete `src/components/pages/evidence-page.tsx` and `library-page.tsx` |
| Why it is safe technically | Zero importers after P1–P2; no behaviour can change |
| Why it still needs approval | It destroys work you may choose to surface later |
| Tests | none reference them; typecheck plus the unit suite |
| Rollback | `git checkout HEAD --` the two paths |
| Safe without approval? | **No**, though risk is nil |

### C-3 — Weather precedence (SC-15b, item D)

| Field | Content |
| --- | --- |
| Change if approved | Either (a) keep custom-URL-wins, document it and add a precedence test, or (b) reverse the precedence so the resolved location wins |
| Why not now | Precedence is unproven; reversing it silently changes what the projector displays |
| Files | `settings.ts`, `projector.tsx` (~186), `v76-projector.test.ts` |
| Rollback | one-commit revert |
| Safe without approval? | **No** |

### C-4 — Ignore `.tanstack/` (item E)

| Field | Content |
| --- | --- |
| Change | Add `.tanstack/` to `.gitignore` |
| Why | Regenerating build cache; today it can be committed accidentally |
| Files | `.gitignore` (one line) |
| Rollback | delete the line |
| Safe without approval? | Cosmetic, but your call |

### C-5 — Authentication posture (SC-27, item F)

Two mutually exclusive options. **C-5a is the recommended default** because the code is already
consistent with it.

**C-5a — keep local-first, no accounts (recommended)**

| Field | Content |
| --- | --- |
| Change | Fix the three stale references; record the posture in `CURRENT.md` / `V11.1-ISSUES.md`; optionally refuse a non-loopback `OQE_DEV_HOST` at startup |
| Files | `src/lib/systems-lab.ts:151` (point at `release-zip.mjs`), `scripts/install-resources.test.mjs:12` (drop the historical path), `QA-ON-DEVICE.md:585` (remove or rewrite the `npm run check:auth` row), `CURRENT.md`, `V11.1-ISSUES.md` |
| Why | The removal is coherent: no dangling imports, `package.json` pruned, loopback default intact, same-origin and fetch-metadata gates present |
| Tests | `systems-lab.test.ts` (protected-path expectations), `install-resources.test.mjs`, typecheck |
| Rollback | revert the four edits |
| Safe without approval? | **No** — it changes what the project claims about its security model |

**C-5b — restore sign-in**

| Field | Content |
| --- | --- |
| Change | `git checkout HEAD -- src/lib/auth src/routes/login.tsx src/components/pages/login-page.tsx migrations/auth/0001_auth.sql scripts/check-auth-invariant.mjs scripts/check-auth-invariant.test.mjs scripts/auth-mode.mjs scripts/sign-out-plan.mjs scripts/sign-out-plan.test.mjs scripts/migration-plan.mjs scripts/migration-plan.test.mjs src/lib/db.ts scripts/migrate.mjs scripts/app-env-plugin.mjs scripts/grok-pwa-plugin.mjs scripts/grok-pwa-shared.mjs scripts/grok-pwa-shared.d.mts server/middleware/grok-pwa.ts server/virtual-grok-og-identity.d.ts public/__grok` and re-add `check:auth` to `package.json`, then re-wire `__root.tsx` |
| Why it needs care | It reintroduces a session/consent surface on top of a tree that has been changed underneath it for a day; `__root.tsx` and `db.ts` were edited since |
| Tests | `check-auth-invariant.mjs`, a real sign-in round trip on device, `v87-consent` |
| Rollback | re-delete the same paths |
| Safe without approval? | **No** |

### C-6 — Record the Profile decision (SC-20)

No code change. Confirm the Prompt 34 selector, or request removal (chip, `profile-control.tsx`,
profile turn in `store.ts`, Settings panel). Until then it stays.

### C-7 — Prompts 38–49 reclassification

Supply the text (file, paste, or the original plan document) and those rows move from **E** to
**A/B/C/D** on evidence. No code change implied.

### C-8 — Stale references (SC-43)

Folded into C-5a; listed separately only because it is the one item whose correctness does not depend
on the posture decision. It is still not authorised without your word.

## 7.4 Cannot be resolved without missing source

| Item | Why | Consequence |
| --- | --- | --- |
| Prompts 1–29, 33–37 approval | Log truncated to 20 entries; no backup has CP-34 | All pre-38 rows stay **E**; nothing removed on that basis |
| Prompts 38–49 text | Absent from tree, logs, checkpoints and conversation | Stays **E**; implementations untouched |
| Authorship of the deletion set | No record beyond V111-13 | Needs your statement (C-5) |

## 7.5 Ordering, if several are approved

1. **C-5** first — the posture decision changes what every later check should assert.
2. **C-4** — one line, stops the cache entering a commit.
3. **C-1 / C-2** — behaviour, then dead code.
4. **C-3** — cosmetic but user-visible.
5. **C-6 / C-7** — record-keeping only.

Per step: edit, typecheck, run the covering tests, and only then consider packaging — as a separate,
explicitly requested step, because packaging regenerates release metadata this audit must not touch.

---

# 8. User decisions recorded (2026-10-27)

Five decisions were given explicitly. They are quoted verbatim below and then translated into actions.
Recording a decision is **not** an implementation approval unless the row says
`IMPLEMENTATION AUTHORISED`.

## 8.1 The decisions, verbatim

> **Decision 1 — Authentication**
> **Decision:** Keep the local-first/no-accounts posture. Investigate the security gap and fix stale
> references before release.

> **Decision 2 — General profile**
> **Decision:** Keep the General profile and selector provisionally. Approval remains unverified.

> **Decision 3 — Recall**
> **Decision:** Keep the recall control and underlying system unchanged.

> **Decision 4 — Evidence and Library components**
> **Decision:** Keep the Evidence and Library page components unreachable for now.

> **Decision 5 — Weather URL precedence**
> **Decision:** Leave the current behaviour unchanged until the original requirement is established.

## 8.2 How statuses are used

| Status | Meaning |
| --- | --- |
| `DONE — DOCUMENTATION ONLY` | Already recorded in this pass; no product file touched |
| `INVESTIGATION REQUIRED` | Evidence gathering authorised; no edit authorised |
| `IMPLEMENTATION NOT AUTHORISED` | Correction is known; a separate approval is required before any edit |
| `BLOCKED ON EVIDENCE` | Cannot proceed until an original record exists |
| `RELEASE BLOCKER` | The candidate must not be promoted while this is open |

The five required categories map as: (1) Prompt 53 removals — §1 and §7.1; (2) decisions now made —
§9.1 and §9.3; (3) investigation/documentation only — A-1, A-5, A-7, A-8, A-9; (4) needs separate
implementation approval — A-2, A-3, A-10; (5) unresolved because evidence is missing — A-5, A-8, A-9.

## 8.3 Action register

### A-1 — Verify the non-loopback boundary

| Field | Content |
| --- | --- |
| Priority | **P0 — RELEASE BLOCKER** |
| Status | `INVESTIGATION COMPLETE` (Prompt 56) → **A + C APPROVED AND IMPLEMENTED** in Prompt 58 — see §10; gate stays open pending cross-device evidence |
| Problem | The app has no accounts. Its protection is a loopback bind plus per-route request gates. Neither proves what happens when `OQE_DEV_HOST=0.0.0.0` is set, and the gates are origin/CSRF checks, not authentication |
| Measured (Prompt 56) | With the built server bound `0.0.0.0:8099`, from the Wi-Fi address `192.168.1.151`: a LAN request was refused (403) until `Host: 127.0.0.1:8099` was sent, then returned 200 for the conversation store (R3) and the task gate (R12); `/api/companion/health`, `/execute` and `/enable` returned 200 via the LAN address (R5/R9/R10); `POST /api/companion/power/disable` returned 200 with a LAN `Origin` and 403 with a foreign one (R7/R8). Companion token was `null` because no paired companion existed, so **injection was not exercised** |
| Evidence | `vite.config.ts:65,70` defaults `host` to `127.0.0.1`; `START-HERE.txt:15` says loopback only; `local-request-security.server.ts` accepts a request with **no** Origin/Referer (asserted by `local-request-security.test.ts`, "keeps direct local tooling without browser headers usable"); probe §9.4 shows a LAN URL passes that gate; storage/automation/tasks routes do check `request.url` hostname, so they reject a LAN-shaped URL; `companion/server.py:68` binds `127.0.0.1` and requires a token on privileged endpoints; `/api/companion/*` injects that token when `fromThisApp()` is true, and `fromThisApp()` compares `Origin` against `new URL(request.url).origin` |
| User decision | D1 — local-first stays; investigate the gap first |
| Files expected to change | **None in this pass.** A correction would touch whichever of: `vite.config.ts`, `scripts/with-app-env.mjs`, `src/routes/api/companion.$.ts`, `src/lib/local-request-security.server.ts`, `src/lib/automation-route-gate.server.ts`, `src/lib/server-task-runner.server.ts`, the storage routes |
| Must remain | Loopback default; same-origin gate; `x-oqe-storage`/`x-oqe-tasks` headers; bounded body reads; companion token never exposed to the browser; STOP and consent in the companion |
| Minimal correction (not authorised) | **Recommendation in §9.5: A + C.** (A) refuse any non-loopback bind at the dev/preview config and at the bundled-server preflight; (C) reject a non-loopback TCP peer in `/api/companion/*` before forwarding and inject the token only after that check. `Host`/`Origin` checks stay as CSRF defence, not as the boundary |
| Required tests / acceptance | (1) bound to `0.0.0.0`, a second host on the LAN cannot complete any `/api/storage/*`, `/api/companion/*`, `/api/automations/*`, `/api/tasks/*` GET/POST within a timeout; (2) a client sending `Host: 127.0.0.1` to the LAN address is rejected — **currently returns 200, so this is the failing acceptance test**; (3) `fromThisApp` refuses a non-loopback `Origin` — **currently accepts it**; (4) the suite still passes on loopback (it does: 65/65 focused today) |
| Rollback | Revert the single guard commit |
| Authorised now? | **No** — investigation only |

### A-2 — `systems-lab.ts:151` names a deleted script

| Field | Content |
| --- | --- |
| Priority | P3 |
| Status | `IMPLEMENTATION NOT AUTHORISED` |
| Problem | `PROTECTED_PATHS` still lists `scripts/build-upload-zip.mjs`, which is deleted; `scripts/release-zip.mjs` and `scripts/upload-zip-policy.mjs` are already listed, so the rule now protects nothing and the reason text is misleading |
| Evidence | `src/lib/systems-lab.ts:151`; `git status` shows `D scripts/build-upload-zip.mjs`; `src/lib/systems-lab.test.ts:383` and neighbours assert the list |
| Kind | **Executable** (runtime rule used by the Lab's diff reviewer) |
| User decision | D1 — fix stale references before release, but only after separate approval |
| Exact files | `src/lib/systems-lab.ts`, `src/lib/systems-lab.test.ts` |
| Must remain | Every other protected entry and the refusal behaviour |
| Minimal correction | **Remove** the deleted entry — its live equivalents (`release-zip.mjs`, `upload-zip-policy.mjs`) are already listed — and extend the test so every protected path must exist |
| Required tests | `systems-lab.test.ts` (protected-path expectations), plus a new assertion that every `PROTECTED_PATHS` entry resolves to an existing file or is a directory prefix |
| Rollback | Revert one commit |
| Authorised now? | **No** |

### A-3 — `QA-ON-DEVICE.md:585` still instructs `npm run check:auth`

| Field | Content |
| --- | --- |
| Priority | P3 |
| Status | `IMPLEMENTATION NOT AUTHORISED` (documentation edit) |
| Problem | The row is a dated record of a check whose script no longer exists; a reader following it gets a missing-script error |
| Evidence | `QA-ON-DEVICE.md:585`; `package.json` has no `check:auth`; `V11.1-ISSUES.md` V111-13 records the missing script |
| Kind | **Documentation** |
| User decision | D1 |
| Exact files | `QA-ON-DEVICE.md` (one table row) |
| Must remain | The historical record of what was and was not verified |
| Minimal correction | Annotate the row as retired with the reason (no auth surface remains; loopback bind plus request gates is the boundary) rather than deleting it |
| Required tests | none — docs; `npm run lint` unaffected |
| Rollback | Revert the row |
| Authorised now? | **No** |

### A-4 — `install-resources.test.mjs:12` is **not** stale (correction to the earlier audit)

| Field | Content |
| --- | --- |
| Priority | — |
| Status | `DONE — DOCUMENTATION ONLY` (reclassified, no edit) |
| Problem | The earlier report listed this line as a broken reference. It is not: it is a deliberate "History:" note explaining why the Grok PWA surface was removed, and the suite actively asserts that surface stays gone |
| Evidence | `scripts/install-resources.test.mjs:12-17` ("…removed in the V11 repair. This suite keeps it gone"), assertions at lines 83, 135 and 153 |
| User decision | D1 (which assumed three stale references) |
| Files | none |
| Minimal correction | None. The audit row is corrected instead (`SCOPE-AUDIT-POST-52.md` §8.4 F) |
| Authorised now? | Nothing to authorise |

### A-5 — General profile: record what is missing

| Field | Content |
| --- | --- |
| Priority | P2 |
| Status | `BLOCKED ON EVIDENCE` |
| Problem | The selector and profile system are kept provisionally, but the only approval basis is Part I's quotation of Prompt 34; no checkpoint entry survives |
| Evidence | `CHECKPOINT-LOG.md` has 20 entries and no CP-34; 22 backups contain none; `profiles.ts`, `profile-control.tsx`, `profile-panel.tsx`, `conversations.ts` implement it; `profileTurnContent("general") === ""` |
| User decision | D2 — keep, do not classify as approved |
| Exact files | none this pass |
| Must remain | Selector placement, profile routing, model instructions, tool access, execution behaviour — all unchanged |
| Minimal correction | none now; the classification stays **E** |
| What would resolve it | (a) the delivered Prompt 34 text, or (b) your explicit statement that the selector was requested. Either moves it to **A** |
| Required tests | none — no code changes while the classification stays **E** |
| Authorised now? | Nothing to authorise |

### A-6 — Recall: keep, with per-component classification

| Field | Content |
| --- | --- |
| Priority | P2 |
| Status | `DONE — DOCUMENTATION ONLY` |
| Problem | The system is kept, but retention is not approval, and the parts differ in visibility and risk |
| Evidence | See the component table in `SCOPE-AUDIT-POST-52.md` §8.4 A |
| User decision | D3 |
| Classification | visible control **E**; retrieval/selection **E**; request assembly **E**; data access **E**; automatic retrieval — **does not exist** (asserted by `v67-contract.test.ts`) |
| Must remain | The three removed dead links stay removed; no Evidence/Library navigation; no new visible UI; no change to when retrieval occurs |
| Authorised now? | Nothing to change |

### A-7 — Evidence/Library pages: keep unreachable; dependency map before any deletion

| Field | Content |
| --- | --- |
| Priority | P3 |
| Status | `DONE — DOCUMENTATION ONLY` (map below); a future deletion is `IMPLEMENTATION NOT AUTHORISED` |
| Problem | Two page components exist with no importer; deleting them is easy but destroys work, and the storage layer must not be touched with them |
| Evidence | Routes redirect (`src/routes/evidence.tsx`, `library.tsx`); `TITLES` has no entries; zero importers; storage, API, table v6, migrations and tests intact |
| User decision | D4 |
| Dependency map | pages → (nothing); pages read `evidence-library.ts` types → `storage.evidence.ts` → `evidence_items` (schema v6) → `evidence-library.test.ts`, `storage.evidence.test.ts`; recall control → `evidence-badges.tsx` → `evidence-library.ts` |
| Removal risk if ever approved | Deleting pages is behaviour-free; deleting the storage layer is a migration decision and would break the API, the recall system and five test suites |
| Required tests | none now. If deletion were ever approved: typecheck plus `storage.evidence.test.ts`, `evidence-library.test.ts`, `v67-contract.test.ts`, `v69-contract.test.ts` must stay green |
| Authorised now? | **No** |

### A-8 — Weather precedence: keep, and record what is unknown

| Field | Content |
| --- | --- |
| Priority | P3 |
| Status | `BLOCKED ON EVIDENCE` |
| Problem | The custom URL wins, but no requirement or test states that it should |
| Evidence | `projector.tsx:186` reads `projectorWeatherUrl`; branch at `:200` (`!custom && !place`), `:209` (`!custom && place`), `:236` (probe `custom`); the code comment at `:173-175` says "the chosen station and its forecast, **unless the reader set their own page in Settings**"; `v76-projector.test.ts:307-320` asserts only that the setting exists, ships empty and is coerced; `settings.ts` keeps both fields |
| User decision | D5 |
| Exact files | none now |
| Compatibility consideration | The field ships empty, so default behaviour is the station; only a reader who typed a URL is affected — which is why the code comment reads as intent, not accident |
| Must remain | Precedence unchanged; no configuration change |
| What would resolve it | the V10.3 Projector prompt text, or your statement of intended precedence |
| Required tests | none now. Any later change needs a precedence test in `v76-projector.test.ts` asserting which source wins when both are set |
| Authorised now? | **No** |

### A-9 — Prompts 38–49 and pre-38 approvals

| Field | Content |
| --- | --- |
| Priority | P2 |
| Status | `BLOCKED ON EVIDENCE` |
| Problem | 0 of 12 recovered verbatim; the log that recorded 1–37 is truncated |
| Evidence | `PROMPTS-38-49-RECOVERY.md`; CP-54 |
| User decision | D1–D5 do not touch these rows |
| Required tests | none — documentation only |
| Authorised now? | Nothing to change |

### A-10 — Optional bind hardening

| Field | Content |
| --- | --- |
| Priority | P1 if LAN use is ever intended; otherwise P3 |
| Status | `IMPLEMENTED` in Prompt 58 as part of A — see §10 (superseded; kept as the proposal record) |
| Problem | A single environment variable removes the only network-level protection |
| Evidence | `vite.config.ts:65,70`; `START-HERE.txt:15` warning |
| Minimal correction (not authorised) | Refuse to start when the resolved host is not loopback unless an explicit opt-in variable is also set, and print the reason |
| Required tests | unit test over a pure predicate; a start-up refusal test |
| Rollback | revert one guard |
| Authorised now? | **No** |

## 8.4 Boundary evidence gathered in this pass

Focused tests, current tree (exit 0): `local-request-security`, `storage.conversations`,
`storage.evidence`, `automation-scheduler` — **65 tests, 65 pass, 0 fail**.

Probe of the shipped gate functions with synthetic requests (`.tmp/boundary-probe.ts`, run once,
deleted afterwards):

| Input | Result |
| --- | --- |
| `http://192.168.1.50:8080/api/storage/conversations`, no Origin/Referer | origin gate **true** (passes) |
| same URL, `Origin: http://192.168.1.50:8080` | origin gate **true** |
| same URL, `Origin: http://evil.example` | origin gate **false** (403) |
| conversation host gate, LAN-shaped URL | **false** (403) |
| automation host gate, LAN-shaped URL | **false**; reject status **403** |
| automation, loopback URL, no `x-oqe-storage` | **400** |
| automation, loopback URL with `x-oqe-storage: 1` | **null** (allowed) |

Reading of that: the origin gate is a CSRF/browser gate and passes header-less clients by design; the
host gates reject a **LAN-shaped request URL**, but the URL is derived from the request's own Host, so
whether a client can present `Host: 127.0.0.1:8080` while dialling the LAN address is **NOT VERIFIED**
and is the first test A-1 must run.

**NOT VERIFIED:** any socket actually bound to `0.0.0.0`; any request arriving from another machine;
`fromThisApp()` with a LAN `Origin`; whether released artefacts set `OQE_DEV_HOST`.

## 8.5 Release gates for the unpromoted candidate

| Gate | Status | Evidence |
| --- | --- | --- |
| Non-loopback boundary verification (A-1) | **VERIFIED EXPOSED — OPEN, RELEASE BLOCKER** | bound `0.0.0.0`, Host-header bypass reproduced, companion proxy and `/execute` reachable; remediation proposed in §9, not authorised (report §10.3–10.4, §11) |
| Clean Windows install without preinstalled Python (V111-01) | **NOT VERIFIED** | `V11.1-ISSUES.md` |
| Companion consent → STOP → exact target (V111-02) | **NOT VERIFIED** | same |
| OS-enforced isolation (V111-03) | **DISABLED** | Systems Lab execution off; run/apply routes absent by design |
| `RELEASE-V11.1.sha256` absent (V111-04) | **OPEN, deliberate** | promotion not requested |
| Silent install `-Q` (V111-05) | **OPEN** | interactive path verified only |
| Voice start/stop (V111-06) | **NOT VERIFIED** | no TTS assets/mic here |
| Projector second display / HDMI (V111-07) | **NOT VERIFIED** | no second display |
| Ollama-absent behaviour (V111-08) | **NOT VERIFIED** | cannot stop Ollama here |
| Source provenance (V111-09) | **OPEN** | unrelated histories |
| MV3 live lane (V111-10) | **PARTIAL** | partial acceptance |
| Companion crash recovery (V111-11) | **NOT VERIFIED** | |
| Typecheck / lint / build / unit / packaging / provenance | **PASSED at CP-53**, which ran on this tree with the 46 deletions present; **not rerun this pass**. CP-52 predates the current tree state, so its numbers are not used as evidence for it | CP-53; 65 focused tests re-run green today (exit 0) |
| Stale references A-2/A-3 | **OPEN** | implementation not authorised |

No old green result is presented as verification of behaviour that has not been exercised, and none
covers the network boundary above.

**Addendum (Prompt 58, same day):** the first gate row changed from `VERIFIED EXPOSED` to
`IMPLEMENTED — VERIFIED ON THIS HOST; CROSS-DEVICE NOT VERIFIED`; the A-2/A-3 stale references remain
open and unauthorised; every other row is unchanged. Details in §10, evidence in report §12, and the
register row is `V111-19` in `V11.1-ISSUES.md`.

---

# 9. P0 remediation proposal (Prompt 57, 2026-10-27)

Proposal only. No fix, no test change, no configuration change. The P0 gate stays open and the release
stays blocked. Prompt 56's measurements are preserved in `SCOPE-RESTORATION-REPORT.md` §10; this section
adds the re-examination and the plan.

## 9.1 Evidence, in three classes

**Demonstrated (Prompt 56, reproduced):**
- With the server bound to `0.0.0.0:8099`, a request to the Wi-Fi address with its own `Host` was refused
  (403), and the same request with `Host: 127.0.0.1:8099` returned 200 for the conversation store and a
  404 (not 403) for the task gate — a working bypass of every `Host`-based check.
- `/api/companion/health`, `/execute` and `/enable` returned 200 through the LAN address, forwarded to a
  stub companion.
- `POST /api/companion/power/disable` returned 200 with a LAN `Origin` and 403 with a foreign one,
  showing `fromThisApp()` accepts an origin the client chose.
- `OQE_DEV_HOST=0.0.0.0` in the dev path binds all interfaces and advertises the Wi-Fi URL.

**Not demonstrated:**
- Server-held token injection with a real paired companion. The token was `null`, so no
  `x-oqe-companion-token` header was attached; the branch that would attach it is
  `api/companion.$.ts:94`, over the exact condition the power test proved reachable.
- Any request from a genuinely separate device. The Prompt 56 client ran on the same machine against its
  own non-loopback address; Windows Firewall was not exercised.
- Any real-world compromise, token theft or desktop control. None is claimed.

**Inferred risk:** *if* a companion is paired, a LAN client that reaches the port could drive
`/execute`, `/consent-target` and `/enable` with the app's token attached, leaving only the companion's
own consent and STOP gates in the way. The inference is one line over a demonstrated condition; its
impact is high, which is why the gate remains P0 even though the final step is unproven.

## 9.2 Facts found while re-examining (they change the recommendation)

| Fact | Source | Consequence |
| --- | --- | --- |
| The installed app already pins loopback | `installer/Oqe-start.ps1:75` `$env:NITRO_HOST = "127.0.0.1"`, asserted by `scripts/installer.test.mjs:133` | Default installations are not exposed; the demonstrated case needed an override |
| The override is **documented as a feature** | `vite.config.ts:60-62` comment "Override with OQE_DEV_HOST=0.0.0.0 … for a LAN preview"; `AGENTS.md:44` | A blanket refusal is a product decision, not a silent fix |
| `START-OQE.cmd:8` forces `127.0.0.1`; `run-oqe-server.cmd:4` only defaults, so a preset value survives | those files | Two launch paths; one already safe, one permissive by design |
| The production entry is generated | `.output/server/index.mjs` calls `serve({ hostname })` from `NITRO_HOST \|\| HOST` | A guard must run before that call, or check the connection per request |
| The TCP peer address is available | srvx `node.mjs` `get ip()` = `socket.remoteAddress`; h3 `getRequestIP` reads `event.req.ip` | A **client-address** check is feasible and cannot be forged by headers |
| No `server/middleware` seam survives | `server/` now holds only Python bridges; the removed Grok middleware came with a deleted Vite plugin | Do not plan around a middleware directory |
| Origin and Host are both client-supplied | `local-request-security.server.ts:8-25`; `automation-route-gate.server.ts:25-46`; `storage.conversations.ts:68-84` | Neither can be the boundary |

## 9.3 Candidate evaluation

### A — Refuse non-loopback binding (preferred)

Fail closed when the resolved bind address is anything but loopback. Enforce at the two seams the product
controls:

- **Dev/preview:** a `configResolved` guard in `vite.config.ts` sees the *resolved* config, including a
  `--host` CLI override, so `vite dev --host 0.0.0.0` fails too — not just the env var.
- **Bundled server:** a preflight module loaded with `node --import` (or equivalent) before
  `app/server/index.mjs`, refusing when `NITRO_HOST`/`HOST` is non-loopback. The installer already sets
  loopback; this makes a deliberate override fail instead of silently exposing.

Compatibility: removes the documented LAN preview. That is the honest consequence — without
authentication there is no safe LAN mode. A future remote-access mode would need its own design
(authentication, transport, threat model) and is out of scope.

Reliability: depends on the resolved address, not on the string `"0.0.0.0"`, so binding to a single LAN
address (`192.168.1.151`) is refused as well. Bypass requires editing the launch path, i.e. the operator
acting deliberately — outside the threat model of a LAN attacker.

### B — Correct host validation

Retain the `Host` checks only as CSRF/UX defence, and add a **connection-address** predicate as the real
boundary: reject when the TCP peer is not loopback (`127.0.0.0/8`, `::1`, `::ffff:127.*`). The peer
address comes from the socket (`srvx` `get ip()`), so `Host: 127.0.0.1` cannot influence it.
Limitation: availability in the Vite dev handler is unconfirmed — if `getRequestIP()` is `undefined`
there, the predicate must not be treated as "local". Dev is covered by A's bind guard, which is why the
combination works.

### C — Protect the companion proxy

Two changes, both small: apply the same connection-address predicate to every `/api/companion/*` route
before forwarding, and gate token injection on that predicate instead of (or in addition to) the
existing permissive-origin rule (`api/companion.$.ts:94`). Keep `fromThisApp()` for the POST power
routes as a CSRF check, but stop describing it as trust. Adding the existing `Host` check as well is
cheap but, on its own, cosmetic — Prompt 56 showed it is spoofable.

### D — Origin validation alone

Insufficient. `Origin` is client-supplied; comparing it with the address dialled is a tautology, since
the client chooses both. Keep it for browser CSRF; never count it as network access control.

## 9.4 Comparison

| Candidate | Security coverage | Blocks the demonstrated attack | Protects token injection | Compatibility impact | Regression tests | Remaining limitations |
| --- | --- | --- | --- | --- | --- | --- |
| **A — refuse non-loopback bind** | Complete for remote access: no non-loopback connection exists to attack | **Yes** | Yes, by removing reachability | Removes documented LAN preview; needs AGENTS/config comment update | T1, T2, T6, T8 | A local process can still reach loopback; a user who edits the launcher can re-enable exposure |
| **B — connection-address predicate** | Strong per route; independent of headers | **Yes**, for covered routes | Yes, if used to gate injection | None for local use; dev fallback unconfirmed | T3, T5, T6, T9 | Depends on the adapter populating `req.ip`; must fail closed when unknown |
| **C — proxy hardening (A+B applied to `/api/companion/*`)** | Closes the proxy specifically | **Yes**, if it rejects before forwarding | **Yes**, explicitly | None for local use | T4, T5, T7 | Only as good as its predicate; `Host`-only version is not enough |
| **D — Origin only** | None against network clients | No | No | None | — | Not a boundary |

## 9.5 Recommendation

**Adopt A as the boundary, and C as the one piece of defence in depth; implement B's predicate inside C
so both share a single function.**

Why this is the smallest defensible set:

- A alone closes the demonstrated attack for every route, including the ones with no host gate, because
  there is no remote connection to make. It needs no per-route edits.
- C is worth its ~30 lines because the token-injection branch is the highest-impact path and A can
  regress through a launcher or installer change; the proxy should fail closed on its own.
- B is not a separate refactor: the predicate is one function, used by C. Rewriting the six existing
  host checks is **not** part of the recommendation — they keep doing their CSRF/UX job.
- D remains as-is; documentation will stop implying it is access control.

**Not recommended:** authentication, a remote-access mode, an allow-list of LAN peers, a token-in-header
scheme, or cleaning up every route's gate. Those are separate products/decisions.

## 9.6 Files the implementation would touch (not now)

| File | Change |
| --- | --- |
| `src/lib/local-request-security.server.ts` | add `isLoopbackPeer(address)` and a `loopbackPeerRejected(request)` helper beside the existing origin gate |
| `src/routes/api/companion.$.ts` | call the peer guard before forwarding; gate the token injection on it; keep `fromThisApp` for power POSTs |
| `vite.config.ts` | `configResolved` refusal when the resolved dev/preview host is non-loopback; update the LAN-preview comment |
| `scripts/loopback-guard.mjs` (new, or inside an existing launcher) | preflight refusal for the bundled server, wired by the installer's start script |
| `installer/Oqe-start.ps1` | load the preflight before `app/server/index.mjs` |
| `AGENTS.md`, `START-HERE.txt`, `README-Windows.md` | remove/replace the LAN-preview instruction |
| `src/lib/local-request-security.test.ts`, `scripts/installer.test.mjs` | predicate cases and launcher assertions |
| `src/lib/companion-proxy-boundary.test.ts` (new) | proxy refusal and non-injection, with a stub companion |

## 9.7 Regression tests

| # | Test | Notes |
| --- | --- | --- |
| T1 | Default dev and preview startup binds `127.0.0.1` only | assert the resolved host and the listening address |
| T2 | `OQE_DEV_HOST=0.0.0.0`, a LAN address, or `vite --host 0.0.0.0` fails at startup with a clear message | covers the CLI override, not just the env var |
| T3 | `Host: 127.0.0.1` from a non-loopback peer is refused | needs a real connection from a non-loopback address; **PENDING** a second machine/firewall check for the cross-device half |
| T4 | `/api/companion/health` and `/execute` refuse a non-loopback peer before any forward | stub companion asserts zero requests |
| T5 | No `x-oqe-companion-token` is attached to a refused request; a local request still gets it | needs a test seam to set the token, or the predicate tested directly; **PENDING** the seam |
| T6 | Local requests still succeed for storage, tasks, companion, Systems Lab status | regression guard |
| T7 | Pairing, token compare, per-target consent, target verification and STOP are untouched | existing Python suites; **no real consent granted** |
| T8 | Dev and packaged launch paths enforce the same policy | installer test plus dev config test |
| T9 | Existing route behaviour and local workflows do not regress | full suite |

Tests will use the stub companion and a throwaway database, as Prompt 56 did. Nothing may grant real
consent or drive a real desktop.

## 9.8 Compatibility, uncertainties, approval

**Compatibility:** the LAN preview documented at `vite.config.ts:60` and `AGENTS.md:44` stops working.
That is the intended trade: without auth there is no safe LAN mode. Installer behaviour is unchanged
(it already pins loopback), so installed users see no difference.

**Uncertainties:** whether `getRequestIP()` is populated in the Vite dev handler (C's fallback must fail
closed); whether Windows Firewall blocks inbound traffic in practice (untested); whether a future Nitro
upgrade changes the generated entry (the preflight guard is entry-agnostic, which is why it is preferred
over a framework hook).

**Approval:** implementation is **not authorised**. A-1 stays `VERIFIED EXPOSED — OPEN, RELEASE BLOCKER`,
and the release gate stays closed. Approving this plan means approving A + C as described, including the
removal of LAN preview; it does not authorise authentication work or any other security refactor.

---

# 10. P0 remediation implemented (Prompt 58, 2026-10-27)

**Approval:** the user approved **A + C** from §9.5 in Prompt 58. That authorises the bind refusal and
the companion-proxy peer check described there, and nothing else. §9 is left intact as the proposal of
record; this section records what was actually built, what was measured, and what remains unverified.

## 10.1 What changed

| File | Change | Why |
| --- | --- | --- |
| `scripts/loopback-bind.mjs` (new) | Pure policy: `normalizeHost`, `isLoopbackHost`, `bundleBindHost`, `LoopbackBindError`, `assertLoopbackBind` | One rule shared by the Vite config, the bundled preflight and the tests, so the policy cannot drift |
| `scripts/loopback-preflight.mjs` (new) | Loaded with `node --import` before the server module; refuses a non-loopback `NITRO_HOST`/`HOST` and pins `127.0.0.1` when neither is set | The generated Nitro entry listens on every interface when no host is configured; the preflight runs before the listener exists |
| `vite.config.ts` | `loopbackBindPlugin()` with a **plugin** `configResolved` hook, registered first; the LAN-preview comment now states LAN access is unsupported | Guards the *resolved* host, so `--host`, `OQE_DEV_HOST` and `--preview.host` all pass through it |
| `src/lib/local-request-security.server.ts` | `isLoopbackPeer`, `peerTrustDecision`, `companionPeerRejected` beside the existing origin gate | The TCP peer (`getRequestIP({ xForwardedFor: false })`) cannot be chosen by a client; `Host`/`Origin` stay CSRF checks |
| `src/routes/api/companion.$.ts` | Peer guard runs first; token selection moved to a pure helper called only after it | Rejects before forwarding — health, reads, writes, `/execute`, `/consent-target`, `/enable`, power controls all share the one handler |
| `src/lib/companion/bridge-token.ts` (new) | `bridgeToken({ requestToken, fromApp, serverToken })` | The injection rule is now testable without a request; a caller-supplied token is forwarded, the server-held one only for the app's own page |
| `scripts/installer-lib.mjs` | Ships `loopback-bind.mjs` and `Oqe-preflight.mjs` in the payload | The installed start script must be able to load them |
| `installer/Oqe-start.ps1` | Runs `node --import Oqe-preflight.mjs app\server\index.mjs`; pins `NITRO_HOST`; fails with a readable message if the preflight is missing | Enforces the same boundary in the packaged product |
| `AGENTS.md` | LAN-preview instruction replaced with the refusal rule; companion paragraph names the peer check | The documented behaviour must match the code; a stale "override for LAN preview" would invite the exposure back |

New/updated tests: `scripts/loopback-bind.test.mjs` (new, 13 tests), `src/lib/loopback-peer.test.ts`
(new, 8 tests), `src/lib/companion/power-route.test.ts` (token-injection contract updated to the helper,
still asserting "own page only" and now also "after the peer check"), `scripts/installer.test.mjs`,
`scripts/run-tests.mjs` (the new `src` test registered — an unlisted test never runs).

## 10.2 A defect found and fixed during verification

The first `vite.config.ts` attempt put `configResolved` at the **top level of the config object**. Vite
accepts that key silently and never calls it, so `vite dev --host 0.0.0.0` bound `0.0.0.0:8097` and
advertised the Wi-Fi URL — the exact exposure A exists to stop. It was caught by running the real dev
server, not by the unit test, which is why the suite now spawns Vite itself (§10.3, T2). The guard was
moved into a plugin, and the same command now exits 1 before any listener appears.

A useful side observation from that failed run: while the dev server *was* mis-bound, a LAN request to
`/api/companion/health` still returned **403**, including with `Host: 127.0.0.1:8097` and a matching
`Origin`. C was working even when A was not, and the dev handler does expose the peer address.

## 10.3 Verification actually run

| Check | Command | Result |
| --- | --- | --- |
| Bind policy + preflight + real Vite refusal | `node --test scripts/loopback-bind.test.mjs` | **13/13 pass** |
| Peer predicate, token gate, route ordering | `node --experimental-strip-types --test src/lib/loopback-peer.test.ts` | **8/8 pass** |
| Companion contract tests | `node --experimental-strip-types --test src/lib/companion/power-route.test.ts` | **8/8 pass** |
| Installer payload/launch assertions | `node --test scripts/installer.test.mjs` | **11/11 pass** |
| Typecheck | `npm run typecheck` | exit **0** |
| Lint (all changed files) | `npx eslint <changed files>` | exit **0** |
| Packaging build | `OQE_NITRO_PRESET=node-server npm run build` | exit **0** |
| Full suite | `npm test` | exit **1** — see below |

`npm test`: scripts **170 tests / 166 pass / 4 skipped / 0 fail**; `src` **2985 / 2984 pass / 1 fail**;
extension **78 / 78 pass**. The single failure is the known, pre-existing release-provenance check
(`RELEASE-V11.1.sha256` absent because V11.1 is deliberately unpromoted — recorded at CP-20/CP-53). It is
not caused by this work and was not "fixed" by creating a release artifact.

Live checks (built server, `NODE_ENV=production`):

| Scenario | Result |
| --- | --- |
| `npx vite dev --host 0.0.0.0 --port 8097` | exit **1**, `LoopbackBindError … refuses to bind to "0.0.0.0"`, no listener |
| `npx vite dev --host 192.168.1.151` | exit **1**, refuses `"192.168.1.151"` |
| `OQE_DEV_HOST=0.0.0.0 npx vite dev` | exit **1**, refuses `"0.0.0.0"` |
| `npx vite dev --host 127.0.0.1` | listens `127.0.0.1:8097` only; `/` 200; LAN dial refused (curl exit 7); `/api/companion/health` 200 |
| `NITRO_HOST=127.0.0.1 node --import ./scripts/loopback-preflight.mjs .output/server/index.mjs` | `Listening on: http://127.0.0.1:8099/` (loopback only), `/` 200, `/api/companion/health` 200 |
| Built server bound `0.0.0.0:8099` **without** the preflight (the pre-fix configuration), dialled from `192.168.1.151` | `/api/companion/health`, `/execute`, `/enable`, `/consent-target` all **403** — with the LAN `Host`, with `Host: 127.0.0.1:8099`, and with a matching `Origin` |
| Same server, loopback `/api/companion/health` | 200 (peer gate passes; forwarding still works) |

The last two rows are the acceptance test §9.3 called "the failing acceptance test": the spoofed-`Host`
request that returned 200 at Prompt 56 now returns 403 before any forward.

Nothing granted consent, drove the desktop, or wrote a release artifact during these checks.

## 10.4 Test-plan status (T1–T9 from §9.7)

| # | Status |
| --- | --- |
| T1 default bind is loopback | **VERIFIED** — dev and bundled defaults, unit + live |
| T2 non-loopback env/CLI fails at startup | **VERIFIED** — three live runs, plus a spawned-Vite test in the suite |
| T3 `Host: 127.0.0.1` from a non-loopback peer is refused | **PARTIAL / PENDING** — refused on every companion route when dialled from this machine's Wi-Fi address; **a genuinely separate device was not used**, so the cross-machine half stays `NOT VERIFIED` |
| T4 proxy refuses before forwarding | **VERIFIED** for the demonstrated shape (403 before forward); no stub-companion counter was wired, the source-order test plus the live 403 stand in for it |
| T5 no token on a refused request; local request still gets it | **PARTIAL** — the pure gate and the "after the peer check" ordering are tested; injection with a **real paired companion** was not exercised (no consent granted, no token asserted on the wire) |
| T6 local requests still succeed | **VERIFIED** — `/` 200, companion `/health` 200 in both dev and built runs |
| T7 pairing/consent/target/STOP untouched | **Not modified**; companion Python suites unchanged and not run in this prompt |
| T8 dev and packaged paths agree | **VERIFIED** — same policy module, same refusal, one live run per path |
| T9 no regression | Full suite as above; the one failure is pre-existing |

## 10.5 Compatibility

LAN preview is gone. `OQE_DEV_HOST` remains a supported variable but only accepts loopback values; a
non-loopback value is a startup error naming the reason. Installed users are unaffected — the installer
already pinned `NITRO_HOST=127.0.0.1`, and now also passes it through a preflight that fails closed.

`OQE_DEV_HOST`/`HOST` overrides inside `run-oqe-server.cmd` no longer re-enable exposure: it launches
`npm run dev`, whose resolved host is guarded. `START-OQE.cmd` already forced loopback. In the installed
build the bundled entry is always loaded with the preflight.

Residual path, stated plainly: running `.output/server/index.mjs` **by hand** with `HOST=0.0.0.0`
skips the preflight. That is not a supported launch path (the installed launcher and the dev/preview
scripts are), and it requires the operator to reconstruct the exposure deliberately. It is recorded here
rather than left implicit. A future remote-access mode would be a new design (authentication, transport,
threat model) and is not implied by this change.

## 10.6 Remaining risk, and the gate

Open:

- **Cross-device test (T3)** — a second machine on the LAN has still not been used. Windows Firewall was
  not exercised.
- **Token injection with a paired companion (T5)** — inferred from ordering and unit tests, not observed
  end to end.
- **Install/launch on a clean Windows machine** with the new payload is not verified; `installer.test.mjs`
  asserts the file list and the launch arguments, not a real install.
- **A local process** can still reach the loopback port. That is inherent to a local-first app with no
  accounts and is unchanged by this work.

Gate: A-1 moves from `VERIFIED EXPOSED` to **`IMPLEMENTED — VERIFIED ON THIS HOST; CROSS-DEVICE
NOT VERIFIED`**. The P0 gate is **not closed**, the candidate is **not promoted**, and no release artifact
was created. Independent audit plus the T3/T5 evidence is the condition for closing it.

**Audit result (Prompt 59, `AUDIT-CP-58.md`):** **A — PASS** (dev, preview, env, and the installed
launcher's preflight; the unwrapped built entry binds `0.0.0.0`/`[::]` when no host is set, now measured).
**C — PASS for every `/api/companion/*` route, FAIL as defence in depth:** the server task runner
(`server-task-runner.server.ts:528-546`) injects the same token behind a `Host`/`Origin` gate. That path
is recorded as `V111-20` and was the first correction required before the gate can close. No correction
was implemented by the audit.

**F-1 corrected (Prompt 60, §11):** `POST /api/tasks/start` and `/resume/$taskId` now require a loopback
TCP peer before the handler runs, and the runner carries that caller-trust decision into dispatch, where a
desktop effect on an untrusted run fails before the journal, the token and the fetch. Live LAN probes with
spoofed headers now return 403; loopback use is intact. T5, T3 and F-2..F-6 remain open.

---

# 11. F-1 correction — task dispatch now requires caller trust (Prompt 60, 2026-10-27)

The CP-59 audit found that the server task runner could inject the app's companion token on a path the
companion proxy never saw. This section records the correction; §10 and `AUDIT-CP-58.md` keep the finding
as it was found.

## 11.1 What changed

| File | Change |
| --- | --- |
| `src/lib/local-request-security.server.ts` | `companionPeerRejected` was generalised into **`loopbackPeerRejected(request, { allowUnknown, message })`**; the companion helper now delegates to it. One predicate, two wordings |
| `src/routes/api/tasks.start.ts` | The route handler runs `loopbackPeerRejected(request)` **before** `handleTaskStart`, then calls it with `{ trusted: true }`. The handler passes `trusted: options.trusted === true` to `runner.start` |
| `src/routes/api/tasks.resume.$taskId.ts` | Same gate and the same `trusted` flag, because a resume can restart a pump that dispatches queued desktop items |
| `src/lib/server-task-runner.server.ts` | `start` accepts `trusted?: boolean` (default **false**); `resume` takes `options.trusted`; `pump`/`runPump` carry the flag. Before the journal, before `companionToken()` and before any fetch, a desktop effect on an untrusted run **fails the task closed** with "Desktop actions are dispatched only for a task started from this machine." |
| `src/lib/server-task-runner.test.ts` | Existing trusted-start tests now declare `trusted: true`; seven new tests cover the boundary |

Trust is per **run**, not per task, and is never persisted. `start`/`resume` without the flag,
cancel-triggered pumps, and **boot recovery** all default to untrusted: a desktop item recovered after a
restart fails instead of dispatching. That is a deliberate fail-closed change — continuing privileged work
after a restart now requires an explicit, peer-checked resume.

## 11.2 Why this is the right boundary

The runner's pump runs after the HTTP response, so there is no request context at dispatch time. Rather
than fabricate a peer address, the correction carries the decision from the only place it can be made —
the request handler that holds the h3 request context — into the run. The dispatch guard is the second
line: a future internal caller that forgets the flag gets the refusal, not authority.

`Host`, `Origin`, `Referer`, `x-oqe-tasks` and forwarded headers play no part in the peer decision; they
remain the route's CSRF/UX checks only.

## 11.3 Verification

| Check | Result |
| --- | --- |
| `node --experimental-strip-types --test src/lib/server-task-runner.test.ts` | **35/35 pass** |
| `npm run typecheck` | exit 0 |
| `npx eslint` on the five changed files | exit 0 |
| `OQE_NITRO_PRESET=node-server npm run build` | exit 0; compiled bundle contains the guard message and three `if (peer) return peer;` sites (companion, start, resume) |
| `npm test` | 2992 tests / 2991 pass / **1 fail** — only the pre-existing `RELEASE-V11.1.sha256` provenance check |
| Live, built server bound `0.0.0.0:8099` (preflight off), dialled from `192.168.1.151` with `Host: 127.0.0.1:8099`, matching `Origin` and `x-oqe-tasks: 1` | `POST /api/tasks/start` → **403** `{"error":"This local API is only available on this machine."}`; `POST /api/tasks/resume/task-x` → **403**. No task row was created |
| Same server, loopback `POST /api/tasks/start` with `text/plain` | **415** — the peer gate passed, so legitimate local use is not blocked |
| Untrusted desktop run (unit) | dispatch spy 0, `globalThis.fetch` 0, task/item failed with the guard message |

New tests: untrusted start cannot dispatch/fetch; trusted start still dispatches; bookkeeping work needs no
trust; untrusted resume cannot dispatch a queued desktop item; the peer gate fails closed with spoofed
`Host`/`Origin`/`Referer`/`x-oqe-tasks`/`X-Forwarded-For`; both routes gate before the handler and pass
trust; the guard precedes `dispatch` and token retrieval stays inside the dispatcher.

## 11.4 Residual

- **T5 with a real paired companion** is still `NOT VERIFIED`; the token-retrieval proof is structural
  (the guarded path is never reached) plus a global-fetch spy, not an observed wire request.
- **T3 cross-device** is still pending; the live check above is same-host-to-own-Wi-Fi-address.
- F-2 (boolean `--host` message), F-3 (direct-entry bind), F-4 (remaining test gaps), F-5/F-6 stay open.
- Boot recovery of a desktop task now fails closed; this is intended and recorded here, not a regression.
- No release artifact, no promotion, gate open.

## 11.5 Independent re-audit and next corrections (Prompt 61, 2026-10-27)

The F-1 correction was re-audited from the current tree, not from §11.3. Every trust-granting and dispatch
path was traced (start, resume, runner start/resume, cancel pump, boot recovery, duplicate start, dispatch),
and the trust flag was checked for forgeability through the request body, stored task, effects state and
journal. Findings are in `AUDIT-CP-58.md` §9; the result is **F-1 independently verified**, with T3/T5 still
pending and the P0 gate still open.

Two independent findings remain from CP-59 and were re-confirmed here without changing either:

| ID | Priority | Problem and evidence | Classification | Files expected to change (not now) | Proposed minimal correction | Required tests | Rollback | Authorised now? |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| A-11 (F-2) | MEDIUM, `RELEASE BLOCKER` (diagnostics, not exposure) | Bare `--host` is passed to Vite as boolean `true`; `normalizeHost` returns it unchanged and `isLoopbackHost` throws `TypeError: … .split is not a function`. Exit 1, no listener — fail-closed but the wrong failure. Reproduced: `npx vite --host --port 8099` → exit 1, `TypeError`, no listener; `--host 0.0.0.0` → exit 1 with the policy message | `IMPLEMENTATION NOT AUTHORISED` — needs user approval | `scripts/loopback-bind.mjs`, `scripts/loopback-bind.test.mjs` | In `assertLoopbackBind`, refuse any non-string value with a `LoopbackBindError` that names the case: "`--host` without a value means all interfaces; pass `--host 127.0.0.1`." Keep the existing policy for strings | The boolean case throws `LoopbackBindError` (not `TypeError`) with the readable message; a spawned `vite --host` exits non-zero, prints the policy sentence and opens no listener; `--host 127.0.0.1` still starts; existing 13 bind tests unchanged | Revert the two files; no data or schema change | **No** |
| A-12 (F-3) | MEDIUM, `RELEASE BLOCKER` | The generated Node entry reads `NITRO_HOST \|\| HOST` (`.output/server/index.mjs:965`) and passes it to `serve`; with neither set it listens on all interfaces. The entry contains no preflight, and only `installer/Oqe-start.ps1` loads `Oqe-preflight.mjs` via `node --import`. Direct `node app/server/index.mjs` therefore bypasses A; CP-59 measured `0.0.0.0` and `[::]`. Source-confirmed again here (no preflight string in the entry); runtime bind not repeated | `IMPLEMENTATION NOT AUTHORISED` — needs user approval | `scripts/build-installer.mjs` (staged entry), `scripts/installer.test.mjs`, `README-Windows.md` / `START-HERE.txt` wording | During packaging, prepend `import "../../Oqe-preflight.mjs";` to the staged `app/server/index.mjs` (the preflight is already copied to the payload root and resolves the same env), so any direct execution of the packaged entry fails closed before `serve`. Document that the entry is not a supported launch path | Packaging test asserts the staged entry imports the preflight before any other statement and that running it with `NITRO_HOST=0.0.0.0` exits 1 without a listener; packaged launcher still starts on loopback | Revert the packaging change and the doc sentence; rebuild the candidate. No release artifact is created by the tests | **No** |

A-12 does not reopen the CP-58 companion bypass: even on an all-interface bind, `/api/companion/*` and both task
routes now reject a non-loopback peer. It is still a release blocker because every other unauthenticated API
(conversations, storage, Ollama proxy) would be exposed, so the stated local-first boundary would not hold.

**Gate:** A-1 stays `IMPLEMENTED — VERIFIED ON THIS HOST; CROSS-DEVICE NOT VERIFIED`. P0 remains open pending
T3/T5 and a second-device run. Neither A-11 nor A-12 is implemented, and V11.1 remains unpromoted.

## 11.6 A-11 and A-12 implemented (Prompt 62, 2026-10-27)

Both corrections were approved after §11.5 and implemented there; the table above records the pre-approval
assessment and is not rewritten.

| ID | Status | Files changed | Change | Evidence |
| --- | --- | --- | --- | --- |
| A-11 (F-2) | **IMPLEMENTED — VERIFIED** | `scripts/loopback-bind.mjs`, `scripts/loopback-bind.test.mjs` | `assertLoopbackBind` rejects boolean and other non-string values before any string operation. A bare `--host` (`true`) raises a `LoopbackBindError` naming the case and `--host 127.0.0.1`; `allowUnset` still applies only to an absent value. `isLoopbackHost` also refuses non-strings instead of throwing | `node --test scripts/loopback-bind.test.mjs` **15/15**; the spawned `vite dev --host --port 8097` exits **1** with the policy sentence, no `TypeError`, and `127.0.0.1:8097` refuses a connection afterwards; `--host 0.0.0.0` still exits 1 with `refuses to bind` |
| A-12 (F-3) | **IMPLEMENTED — VERIFIED** | `scripts/installer-lib.mjs`, `scripts/build-installer.mjs`, `scripts/installer.test.mjs`, new `scripts/packaged-entry-guard.test.mjs`, `README-Windows.md` | `guardPackagedEntry` prepends `import "../../Oqe-preflight.mjs";` (after a shebang if one exists) and is idempotent; a different preflight path is refused. The installer build writes the guarded entry into the staged payload, proves the guard is first, and refuses to package if the preflight is missing. The launcher keeps its `--import`; both paths use the same policy file | Packaging tests **12/12** (including the new guard test) and the new runtime fixture **5/5**. A fresh `OQE_NITRO_PRESET=node-server npm run build` exited **0**; a dry stage of that `.output` produced `import "../../Oqe-preflight.mjs";` as the first line with the server body byte-identical. Synthetic staged entries: `NITRO_HOST=0.0.0.0`/`HOST=::`/LAN each exit **1** before the entry body; loopback executes; a missing preflight exits non-zero before the body |

`npm test` after both changes: scripts **178 tests / 174 pass / 4 skipped / 0 fail**; `src` **2992 / 2991 pass / 1 fail**; extension **78/78**. The single failure remains the pre-existing `RELEASE-V11.1.sha256` provenance assertion. Typecheck **0**; eslint on all changed files **0**.

The packaged real entry was not started on a non-loopback bind (it would expose the app if the guard regressed); its guard was verified statically on the fresh artifact, and execution was verified on the disposable fixture. A clean installer launch remains a separate QA gate. P0 stays open; T3/T5 are unchanged; V11.1 remains unpromoted.
