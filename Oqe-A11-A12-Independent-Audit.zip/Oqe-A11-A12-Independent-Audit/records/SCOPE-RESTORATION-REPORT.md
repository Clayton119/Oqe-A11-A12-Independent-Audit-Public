# Oqe — Scope Restoration Report

**Final classification: `SCOPE RESTORED — PARTIALLY VERIFIED`.**
The unapproved Knowledge navigation, page surfacing and its inverted contract test are removed and
verified by the restored contract test, typecheck, lint and build. One item (the composer Recall
control) is **BLOCKED — USER DECISION REQUIRED**, and no runtime/visual check was performed in this
environment.

Date: 2026-10-26 · HEAD `4e74455` · branch `main` · no commit made (none authorised).

---

## 1. What the audit found

Reviewed: prompts 1–37 (37 checkpoint entries cross-checked against the tree), the remaining plan
beyond 37 (Prompt 38 is named but was not supplied and was not started), and all 235 dirty paths.

| Classification | Count | Outcome |
| --- | --- | --- |
| **A** explicitly approved | 17 change groups | kept |
| **B** necessary detail | 3 | kept |
| **C** recommended, not approved | 1 (legacy weather URL overlap — pre-existing) | investigate, untouched |
| **D** unrequested expansion | 6 | 5 removed, 1 (page bodies) kept unreachable |
| **E** unclear | 5 | 4 kept (load-bearing storage/queue/journal/voice/auth), 1 blocked for your decision |

The one genuinely unapproved product change was the **Knowledge area**: Prompt 26's storage work was
its approved subject, but the visible section, the page surfacing and — decisively — the **reversal
of the existing V6.9 T8 contract** were not. That reversal is visible in the diff:

```
-describe("V6.9 T8 — no primary nav to library/evidence", () => {
+describe("V6.9 T8 / Prompt 26 — library and evidence are reachable destinations", () => {
```

`Profile: General` was **not** shown unapproved: Prompt 34's goal — as quoted in Part I, not verifiable
in the tree — asked for "a first-class selector and
consistent behavior for the five intended profiles" and to "make the active profile clear", with
"Ultron/general assistant" among the five. It is kept; Part III (§8.2) reclassifies it **E — approval unverified**, and the exact reversal is
documented if you want it anyway (`SCOPE-CHANGE-AUDIT.md` §6.3).

---

## 2. Removed, retained, blocked

### 2.1 Removed (restored to HEAD bytes)

| Path | Change |
| --- | --- |
| [sidebar.tsx](src/components/sidebar.tsx) | `Knowledge` section + its two links and icon imports gone — byte-identical to HEAD |
| [evidence.tsx](src/routes/evidence.tsx) | back to `throw redirect({ to: "/" })` |
| [library.tsx](src/routes/library.tsx) | back to `throw redirect({ to: "/" })` |
| [v69-contract.test.ts](src/lib/v69-contract.test.ts) | original `V6.9 T8 — no primary nav to library/evidence` restored and passing |
| [app-shell.tsx](src/components/app-shell.tsx) | the two `TITLES` entries and their Prompt-26 comment reverted **surgically**; the V11.1 projector notice and Prompt-35 automation-bridge hunks are untouched |
| `.tmp-store-probe.ts` | my own throwaway probe file deleted (untracked, referenced nowhere) |

### 2.2 Deliberately retained (approved or load-bearing)

- Evidence **storage layer**: `evidence-library.ts`, `evidence_items` (schema v6), `/api/storage/evidence`
  with its gates, and their tests. No table, row, migration or API was deleted.
- The two page components (`evidence-page.tsx`, `library-page.tsx`) — now unreachable, work preserved.
- `components/evidence/evidence-badges.tsx` — still used by the recall control.
- Profile system, all A/B prompt work (task runner, companion lease, weather location, model-gateway
  test, context capacity, tool loop, multi-agent, automations, universal output, inline images).
- Your pre-existing V11.1 work in its entirety (142 paths, including the whole `src/lib/auth/*`
  cluster and `routes/login.tsx`). Not one of those paths was modified by this task.

### 2.3 Blocked — needs your decision

**SC-10, the composer Recall control.** With `/library` and `/evidence` unreachable, no UI can add
saved records any more (`store.saveEvidenceItem` has no caller), so the panel would open an empty
library. I did not remove it because doing so changes **request assembly** (the explicit recall
system turn in `store.ts`, guarded by `v67-contract.test.ts`) — behaviour, not presentation — and
because "bounded recall" was part of Prompt 26's recorded subject. Options are in
`SCOPE-CHANGE-AUDIT.md` §7.3.

---

## 3. Checks actually run

All on the final tree, after every edit:

| Command | Result |
| --- | --- |
| `npm run typecheck` (`tsc --noEmit`) | **PASS** (`TYPECHECK_EXIT=0`) |
| `npm run lint` (`eslint .`) | **PASS** (`LINT_EXIT=0`) |
| `npm test` (`node scripts/run-tests.mjs`) | **1 failure**, pre-existing and unrelated — see below |
| `npm run build` (`vite build` via `with-app-env`) | **PASS** (`BUILD_EXIT=0`) |
| `git diff HEAD -- src/components/sidebar.tsx src/routes/evidence.tsx src/routes/library.tsx src/lib/v69-contract.test.ts` | **empty** — byte-identical to HEAD |
| `grep 'to="/library"\|to="/evidence"' src/components/sidebar.tsx` | **0 matches** |
| `V6.9 T8 — no primary nav to library/evidence` | **✔ passing** in the restored suite |

Test totals from that run: `scripts/**` 146 tests / 142 pass / 0 fail (4 skipped), `src/**` **2655
tests / 2654 pass / 1 fail**, `browser-extension/tests` 78 / 78 pass.

**The single failure is not caused by this task:**
`src/lib/v89-release-provenance.test.ts` → *"the checksum file at the repo root is the current
release's"*. It asserts `RELEASE-V${version}.sha256` exists, where `version` comes from
`companion/version.py`. That file already declares `11.1` (an existing modification from your
in-flight V11.1 work, untouched by me) and the root has checksums only through `RELEASE-V11.0.sha256`.
Fixing it would mean cutting a V11.1 release — a release-policy action this task does not authorise.
I did not weaken, skip or delete the test. It is already recorded as the same pre-existing failure
at CP-34, CP-35 and CP-36, i.e. it predates this task and is independent of it.

### Not verified (environment/runtime)

- **Live UI**: the rail without "Knowledge", and `/library` / `/evidence` redirecting in a running
  app. Statically proven by the restored T8 assertions + build, but **not** observed in a browser.
- **Composer with the profile chip**, wall weather, projector, companion, Windows desktop, Ollama —
  unchanged by this task and **NOT VERIFIED** here. Operator steps: `QA-ON-DEVICE.md`.

---

## 4. Data, migration and compatibility risk

- **No schema change** in this task; `DATABASE_SCHEMA_VERSION` is untouched (v6 from Prompt 26).
  Evidence rows written while the pages were live remain in `evidence_items` and are still readable
  through `/api/storage/evidence` — the pages are hidden, their data is not.
- **No migration** added or removed. No user data deleted, no localStorage or DB cleared.
- **Compatibility**: routes `/library` and `/evidence` now redirect (as in V11.0). Deep links open
  Chat instead of the page — that is the approved behaviour, and the contract test enforces it.
- **Nothing staged or committed**; the worktree carries your pre-existing diffs exactly as before,
  minus the six removals above.

---

## 5. Remaining changes that need your decision

1. **Recall control** (SC-10) — keep / also remove from the composer and request assembly / approve
   the pages after all.
2. **Page components** (SC-11) — currently kept unreachable; say if you want them deleted.
3. **Profile selector** (SC-20) — keep (approved), move to Settings only, or remove.
4. **Legacy weather URL** (SC-15b) — a set custom URL silently wins over the chosen location.
5. **`.tanstack/`** (SC-26) — untracked and not in `.gitignore`.
6. **V11.1 auth cluster** (SC-27) — yours, untouched, and it still holds the authentication boundary.

---

## 6. Confirmation

- The current prompt plan **was reviewed in full as far as it is legible**: prompts 1–37, each with
  its checkpoint entry and its files; the plan's continuation past 37 is noted but was not supplied.
  Prompts 1–25's exact wording is not available to me, which is why their rows are **E**, not **A**.
- No remaining feature prompt was started; **Prompt 38 was not begun**.
- No replacement UI, feature or architecture was introduced. No safety, consent, authentication,
  dispatch or STOP contract was weakened — every corrective edit is navigation, routing, a page
  title, one test file, or my scratch file.

**Operating rule acknowledged for all future prompts:** a recommendation is not approval, a default
is not approval, and any product-visible feature, material behaviour change, architectural expansion
or safety-contract change will stop and ask you first.

---

# Part II — Re-audit and restoration after Prompt 52 (2026-10-27)

**Result: `SCOPE RESTORED — ONE RESIDUAL REMOVED; DECISIONS PENDING`.**
Audit: [SCOPE-AUDIT-POST-52.md](SCOPE-AUDIT-POST-52.md). Plan: `SCOPE-RESTORATION-PLAN.md` R-6.
No release packaging, archive, checksum or pointer was touched; no feature prompt was started.

## II.1 What was found

The Part I restoration held through Prompts 38–52:

| Item | Evidence | State |
| --- | --- | --- |
| Knowledge nav group | `grep` in `sidebar.tsx` → 0 matches | absent |
| `/library`, `/evidence` | both `beforeLoad` → `redirect({ to: "/" })` | redirect |
| Page titles | `app-shell.tsx` `TITLES` | absent |
| V6.9 T8 contract | `v69-contract.test.ts` | present; **22/22 pass** |
| Page components | zero importers | kept, unreachable |
| Profile: General | chip at `composer.tsx:889`; Prompt 34 quotation is Tier 2, so Part III (§8.2) classifies it **E**, pending confirmation | retained |

One residual was found and removed: **SC-28** — the recall control still linked to the two hidden
routes ("Save a record on the Evidence page", "Open the library", "What was used"). Those links
bounced the reader to Chat.

## II.2 Removed

| Path | Change |
| --- | --- |
| [recall-control.tsx](src/components/chat/recall-control.tsx) | three `<Link>` elements to `/evidence` and `/library` removed, plus the now-unused `Link` import. The empty-state sentence, chosen-count, last-recall readout and the recall request assembly are untouched |

Rollback: `..\preflight-backups\2026-10-27\scope-audit-post-52\recall-control.tsx`.

## II.3 Deliberately retained

- Evidence storage/API/model (`evidence-library.ts`, `evidence_items`, `/api/storage/evidence`).
- The two unreachable page components (deleting them is a decision, not a scope correction).
- The recall control itself and its explicit-recall system turn (**SC-10 — your decision**).
- Profile system and the composer chip (approved).
- Everything from Prompts 38–52, classified **E** where their verbatim goal text is not available to
  me in this run; nothing was removed on a checkpoint heading alone.
- Your pre-existing auth/PWA cluster and all release artifacts.

## II.4 Checks actually run

| Command | Result |
| --- | --- |
| `npx tsc --noEmit` | **PASS** (`TSC:0`) |
| `npm run lint` | **PASS** (`LINT:0`) |
| `OQE_NITRO_PRESET=node-server npm run build` | **PASS** (`BUILD:0`, nitro output generated) |
| `node --experimental-strip-types --test src/lib/v67-contract.test.ts src/lib/v69-contract.test.ts` | **38/38 pass** |
| `npm run test` | **3,212 tests: 3,207 pass, 4 skipped, 1 fail** — the pre-existing `v89-release-provenance` checksum assertion (no V11.1 archive is promoted; not caused by this pass) |
| `grep -n "Link\|/library\|/evidence" src/components/chat/recall-control.tsx` | no route links remain (only `evidence-library`/`evidence-badges` imports) |

**Not verified:** the live UI in a browser (recall panel with an empty library, and the rail without
Knowledge). The static and contract evidence is green; the visual check is operator work and is
already listed in `QA-ON-DEVICE.md`.

## II.5 Data, safety and packaging

No schema, migration, table or row touched. No STOP, consent, pairing/token, capability, dispatch or
sandbox code touched. No dependency added. No release packaging, archive, sidecar or CURRENT.md
pointer changed, and V11.1 was not promoted.

---

# 8. Part III — evidence recovery and approval gate (2026-10-27)

Read-only pass. **No implementation, packaging or release change was made.** Section 7 records
Prompt 53's removals; this section records only what the audit found afterwards.

## 8.1 Prompt 38–49 recovery

Searched in order: the working tree (`**/*.md`, `*.txt`, `*.ts`, `*.tsx` with prompt attributions),
`CHECKPOINT-LOG.md`, all 22 `preflight-backups/**` snapshots, the release archive's root documents,
`Oqe v10.9.md` / `Oqe v11.0.md`, `.tmp/v11-authoritative-spec.md`,
`docs/ULTRON-V11-MASTER-FORENSIC-PRODUCTION-COMPLETION-SPEC.md`, `QA-ON-DEVICE.md`,
`ARCHITECTURE-FIT-MATRIX.md`, and the conversation record.

**Result: 0 of 12 recovered verbatim.** What exists is one heading per prompt (CP-38 … CP-49) that
paraphrases *results*. All twelve are marked `SOURCE NOT FOUND — APPROVAL UNVERIFIED` in
[PROMPTS-38-49-RECOVERY.md](PROMPTS-38-49-RECOVERY.md).

Two rows gain independent corroboration from text that *is* available: Prompt 51 names "Systems Lab
approval and rollback" and "Prompt 49" as expected artifacts. That supports those two existing; it
says nothing about what was intended inside them.

## 8.2 The evidence base got weaker, and this reports it

`CHECKPOINT-LOG.md` holds 20 entries (CP-30 … CP-32, CP-SCOPE, CP-38 … CP-53). **CP-1 … CP-29 and
CP-33 … CP-37 are gone**, including CP-26 (evidence storage) and CP-34 (profiles). No backup copy has
a CP-34 entry.

So the two rows Part I called **A** — evidence storage and the profile selector — rest on Part I's own
quotation of your text, unverifiable in the tree. They are reclassified **E — approval unverified,
pending your confirmation**. Nothing about the code changed; the proof did.

## 8.3 Register, final shape

| Class | Rows | Note |
| --- | --- | --- |
| **A — explicitly approved** | SC-38 (existence), SC-41, SC-42 | Tier-1 text or direct corroboration |
| **B — necessary implementation** | Prompt 52 packaging repairs; provenance badges (partial) | minimal, no scope change |
| **C — recommended, not approved** | composer placement of the profile chip; default choices | presentation only |
| **D — unrequested expansion** | SC-06…09 and SC-28 (both removed in Prompt 53), SC-11 (dead pages), SC-26 (`.tanstack/`), SC-43 (stale references) | |
| **E — approval unverified** | SC-01…05, SC-10, SC-12…25, SC-27, SC-29…37, SC-39, SC-40 | kept, untouched |

Evidence tiers (T1–T4) and the full table are in `SCOPE-AUDIT-POST-52.md` §8.1–8.3.

## 8.4 Outstanding items

| Item | Status | Finding |
| --- | --- | --- |
| A. Recall control / retrieval | **open** | Control, selection, request assembly and data access are each **E**; no automatic retrieval exists; the three dead links are gone |
| B. Evidence / Library pages | **open** | Routes redirect, no nav, no titles, zero importers; storage, API, table and tests intact and load-bearing |
| C. Profile: General | **open, corrected** | Evidence is Tier 2, so **E**; no routing, model, tool-access or behaviour change exists |
| D. Weather precedence | **open** | Custom URL wins at `projector.tsx:186`; no test asserts it; unchanged |
| E. `.tanstack/` | **reported** | One generated router bundle, ~16 KB, untracked, not ignored, not sensitive |
| F. Auth / PWA / tooling removals | **open — posture decision** | 46 deletions, internally consistent; app is now local-first with no accounts; three stale references left behind |

## 8.5 What the deletion cluster actually shows (item F)

Corrected from the preliminary reading, which treated it as an unexplained security regression.

- **46 files deleted vs `HEAD`, in three coherent groups**: 23 sign-in files (20 under
  `src/lib/auth/` with tests, plus `login.tsx`, `login-page.tsx` and the auth migration); 12 PWA/install
  files (`grok-pwa-*`, the server middleware, `install-page.html`, `public/__grok/**`); and 11 tooling
  files (`src/lib/db.ts`, `migrate.mjs`, `migration-plan*`, `sign-out-plan*`, `app-env-plugin.mjs`,
  `build-upload-zip.mjs`).
- **Nothing dangling**: no surviving module imports any deleted file; `src/lib/auth/` holds only
  `isolation.server.ts`, which imports nothing local; `package.json` no longer lists the removed
  scripts and is internally consistent.
- **Already on record**: `V11.1-ISSUES.md` V111-13 (Low, tooling) notes `check-auth-invariant.mjs` is
  gone.
- **Boundary that remains**: loopback-only default (`vite.config.ts:65,70`, `START-HERE.txt`), the
  same-origin gate in `local-request-security.server.ts`, and fetch-metadata isolation in
  `auth/isolation.server.ts`. There is no account, session or consent gate left.
- **The real risk**: with `OQE_DEV_HOST=0.0.0.0` nothing authenticates requests. On loopback the
  posture is coherent; off loopback it is not. That is the decision, not the diff.
- **Left unfinished**: `src/lib/systems-lab.ts:151` still protects `scripts/build-upload-zip.mjs`
  (deleted), `scripts/install-resources.test.mjs:12` cites the deleted `install-page.html`, and
  `QA-ON-DEVICE.md:585` still instructs `npm run check:auth`, which no longer exists.

## 8.6 Checks actually run

| Command | Result |
| --- | --- |
| `git rev-parse --short HEAD` | `4e74455` |
| `git status --porcelain=v1 --branch` | `main`; 295 entries — 113 modified, 46 deleted, 136 untracked |
| `git status --porcelain=v1 \| awk '{print $1}' \| sort \| uniq -c` | the counts above |
| `grep -n '^## CP-' CHECKPOINT-LOG.md` | 20 entries; CP-1…29 and CP-33…37 absent |
| `grep -c 'CP-34'` across `preflight-backups/**/CHECKPOINT-LOG.md` | 0 in 22 copies |
| `grep -rn` for prompt-38…49 text across tracked and untracked files | only headings and source attributions |
| `grep -rn` importers of `pages/evidence-page`, `pages/library-page` | 0 |
| `grep -rn` references to each deleted module across `src scripts server browser-extension .github` | 2 stale strings (§8.5) |
| `grep -n "import" src/routes/__root.tsx`, `ls src/lib/auth` | no auth import; one file remains |
| `grep -n "host" vite.config.ts` | `127.0.0.1` defaults at lines 65 and 70 |
| Reads of `local-request-security.server.ts`, `auth/isolation.server.ts`, `V11.1-ISSUES.md`, `projector.tsx` (line 186), `settings.ts`, `v76-projector.test.ts` | facts quoted above |

**NOT RUN:** unit suite, `pnpm typecheck`/`check`, packaging gate, release verification, browser and
on-device checks. A read-only audit does not require them, and the packaging gate would regenerate
release metadata this task forbids. Last recorded green state is CP-52/CP-53; it predates the auth
deletions, which no test now covers.

**NOT VERIFIED:** that the app starts and works end to end in the current tree (no `/login` route
exists to test), and whether any released artefact still ships the removed files.

## 8.7 Confirmation

- No feature work, no removals, no route or component deletions in this pass.
- No change to release packaging, no V11.1 promotion, no release-metadata regeneration.
- No database, migration or user-data change.
- Working-tree changes from this pass are documents only (`PROMPTS-38-49-RECOVERY.md`,
  `SCOPE-AUDIT-POST-52.md`, `SCOPE-RESTORATION-PLAN.md`, `SCOPE-RESTORATION-REPORT.md`).
- Nothing was treated as approved because tests pass, because code exists, or because a later prompt
  mentions an earlier feature.

---

# 9. Decisions recorded and boundary review (2026-10-27)

Documentation-only pass. No source, route, test, schema, installer, release file or generated state was
modified. V11.1 remains an unpromoted candidate.

## 9.1 The five decisions

| # | Decision (verbatim) | Effect recorded |
| --- | --- | --- |
| D1 | "Keep the local-first/no-accounts posture. Investigate the security gap and fix stale references before release." | posture kept; boundary investigation opened as **P0 release blocker**; stale references recorded, **not** edited |
| D2 | "Keep the General profile and selector provisionally. Approval remains unverified." | implementation unchanged; classification stays **E**, not **A** |
| D3 | "Keep the recall control and underlying system unchanged." | control, retrieval, assembly and data access retained; links stay removed; each component stays **E** |
| D4 | "Keep the Evidence and Library page components unreachable for now." | components retained with zero importers; storage, schema and tests untouched; deletion preconditions documented |
| D5 | "Leave the current behaviour unchanged until the original requirement is established." | custom-URL precedence untouched; requirement recorded as unproven |

The full wording, including each decision's constraints, is quoted in
[SCOPE-RESTORATION-PLAN.md](SCOPE-RESTORATION-PLAN.md) §8.1.

## 9.2 What changed in the classification

Nothing was upgraded. The profile and the recall system remain **E — approval unverified**; retention
is a decision, not evidence of approval. The earlier audit's "three stale references" was itself
partly wrong and is corrected: `scripts/install-resources.test.mjs:12` is a deliberate history note
backed by assertions that the Grok PWA surface stays gone, so it is accurate as written. Only
`src/lib/systems-lab.ts:151` names a deleted file in executable code, and
`QA-ON-DEVICE.md:585` is a dated record of a script that no longer exists.

## 9.3 The security gap, precisely

**The listener.** `vite.config.ts:65,70` bind to `process.env.OQE_DEV_HOST || "127.0.0.1"`.
`START-HERE.txt:15` says "Local mode is loopback-only. Do not run the server through 0.0.0.0."
The companion (`companion/server.py:68`) binds `127.0.0.1` unconditionally, so the companion itself
cannot be reached from another machine. The web server can be, if the variable is set.

**The gate matrix** (what each group actually checks):

| Route group | Loopback host check | Origin/CSRF gate | Extra header | Notes |
| --- | --- | --- | --- | --- |
| `storage.conversations`, `.evidence`, `.task-queue`, `.operation-journal`, `.voice-profiles`, `.artifacts` | yes (`request.url.hostname`) | yes | `x-oqe-storage` where required | tests green today |
| `automations.*` | yes | yes | `x-oqe-storage` | `403` for LAN-shaped URL, verified |
| `tasks.*` | yes | yes | `x-oqe-tasks` | gate lives in `server-task-runner.server.ts` |
| `api/companion/*` | **no** | yes, plus stricter `fromThisApp()` for POST power/injection | token injected server-side | allows `/execute`, `/consent-target`, `/enable` |
| `api/ollama`, `api/tts`, `api/images.generate`, `api/systems-lab.*`, `api/browser-attest` | **no** | yes | — | read/proxy routes |
| server functions (`app-data`, `browse-fetch`) | no | same-site assertion | upstream credentials | no local conversation data |

**The property that matters.** The origin gate passes a request with no `Origin` and no `Referer` — by
design, so local tools keep working (asserted by `local-request-security.test.ts`). Any non-browser
client on the LAN therefore satisfies it. The host gates are stronger, but they test the request's own
URL, which a client influences through `Host`. Whether that defeats them **is not verified here**.

**The privileged chain, by code reading only.** A client that can reach the server calls
`/api/companion/<path>`. The proxy accepts `/execute`, `/consent-target` and `/enable`; it injects the
companion token when `fromThisApp(request)` is true; and `fromThisApp` compares `Origin` with
`new URL(request.url).origin` — the address the client dialled. A LAN client that sets a matching
`Origin` is treated as the app, receives the injected token, and can then drive the desktop-control
endpoints subject only to the companion's own consent and STOP state. **NOT VERIFIED** end to end; it
is the single most important thing A-1 must exercise.

**What was verified this pass:** 65 focused tests green; the function-level probe results in
`SCOPE-RESTORATION-PLAN.md` §8.4; companion binding and token requirement by reading `main.py` and
`server.py`.

**What was not:** no socket was bound to `0.0.0.0`; no request was sent from another machine; no
browser or device check was run.

## 9.4 Evidence still needed

| Uncertainty | Record that would resolve it |
| --- | --- |
| Prompt 34 / profile selector | the delivered Prompt 34 text, or your explicit confirmation |
| Prompt 26 / evidence storage and recall scope | the delivered Prompt 26 text (CP-26's entry is gone) |
| Prompts 38–49 | the delivered prompt text, one row per prompt |
| Prompts 1–29, 33–37 | the untruncated `CHECKPOINT-LOG.md`, or the original prompt plan |
| Weather precedence | the V10.3 Projector prompt, or your statement of intent |
| Non-loopback behaviour | the A-1 test results on a machine with a second host |

## 9.5 Proposed implementation changes awaiting separate approval

| Action | Change | Status |
| --- | --- | --- |
| A-1 | verify, then possibly harden, the non-loopback boundary | `INVESTIGATION REQUIRED` — **release blocker** |
| A-2 | remove the deleted `scripts/build-upload-zip.mjs` entry from the Lab's protected paths, extend its test | `IMPLEMENTATION NOT AUTHORISED` |
| A-3 | annotate the retired `check:auth` row in `QA-ON-DEVICE.md` | `IMPLEMENTATION NOT AUTHORISED` |
| A-10 | optional start-up refusal for a non-loopback bind | `INVESTIGATION REQUIRED` |
| — | delete the two unreachable page components | **not requested**; D4 keeps them |
| — | remove the recall control or profile chip | **not requested**; D3/D2 keep them |

## 9.6 Release gates

V11.1 stays unpromoted. The gate list is in `SCOPE-RESTORATION-PLAN.md` §8.5: the non-loopback boundary
is the new P0 blocker; V111-01, -02, -06, -07, -08 and -11 remain NOT VERIFIED; V111-03 stays disabled;
V111-05 and V111-09 remain open; `RELEASE-V11.1.sha256` is deliberately absent because no promotion was
requested. Typecheck, lint, build, unit suite and packaging passed at **CP-53**, which ran on this source tree
with the deletion set present; they were **not rerun** here, and CP-52's numbers predate the current
state so they are not cited as evidence for it.

Systems Lab execution and apply remain disabled: no run route exists, the history route is read-only,
and `executionAvailable` is false until an isolation boundary reports itself proven.

## 9.7 Files changed by this task

| File | Change |
| --- | --- |
| `SCOPE-RESTORATION-PLAN.md` | §9 added — verbatim decisions, statuses, action register A-1…A-10, boundary evidence, release gates |
| `SCOPE-RESTORATION-REPORT.md` | this §9 |
| `SCOPE-AUDIT-POST-52.md` | §8.5 updated to record the decisions; SC-43 corrected (one executable stale reference, one documentation row, one non-issue) |
| `PROMPTS-38-49-RECOVERY.md` | §5 added — the record needed per prompt |
| `CHECKPOINT-LOG.md` | CP-55 added |

No other file was written. The temporary probe `.tmp/boundary-probe.ts` was run once and deleted;
`.tmp/` is ignored by `.gitignore`.

## 9.8 Commands run and results

| Command | Result |
| --- | --- |
| `git rev-parse --abbrev-ref HEAD` / `--short HEAD` | `main` / `4e74455` |
| `git status --porcelain=v1 \| awk '{print $1}' \| sort \| uniq -c` | 113 modified, 46 deleted, 136 untracked — unchanged before and after |
| `node --experimental-strip-types --test src/lib/local-request-security.test.ts src/lib/automation-scheduler.test.ts` | **32/32 pass, exit 0** |
| `node --experimental-strip-types --test src/lib/local-request-security.test.ts src/routes/api/storage.conversations.test.ts src/routes/api/storage.evidence.test.ts src/lib/automation-scheduler.test.ts` | **65/65 pass, exit 0** |
| `node --experimental-strip-types .tmp/boundary-probe.ts` | exit 0; table in plan §8.4 |
| `grep` sweeps for `localRequestRejected`, `isSameOriginLocalRequest`, `assertSameSiteRequest`, `new URL(request.url).hostname`, `only available on this machine` | gate matrix in §9.3 |
| `grep` of `companion/main.py` (`uvicorn.run`), `companion/server.py` (`_require_authorized`) | loopback bind; 401 without token |
| `grep` of `projector.tsx` weather branches, `v76-projector.test.ts` | precedence confirmed by code; no precedence test exists |
| `sed`/`grep` of the three reported stale references | A-2 real, A-3 documentation, A-4 a non-issue |
| **NOT RUN** | full `npm test`, `typecheck`, `lint`, `build`, packaging, release verification, browser, on-device, any `0.0.0.0` bind, any cross-device request |

## 9.9 Confirmation

- Five decisions recorded verbatim and applied as documentation only.
- No implementation, deletion, reconnection, security-control change or settings change.
- No code, route, test, schema, migration, installer or release artefact touched.
- No release pointer moved; `RELEASE-V11.1.sha256` not created; `Oqe-V11.1.zip` not produced.
- Nothing described as verified that was not exercised; the four `NOT VERIFIED` items in §9.3 remain
  so, and the boundary finding is labelled code-reading until A-1 runs.

---

# 10. Prompt 56 — companion boundary verification (2026-10-27)

Verification only. No product file was changed; the isolated test environment was created outside the
repository and deleted afterwards. V11.1 remains unpromoted.

## 10.1 Environment and method

| Item | Value |
| --- | --- |
| Source under test | HEAD `4e74455`, working tree as left by CP-55 (113 M / 46 D / 136 ??) |
| Server used | the existing `.output/server/index.mjs` node-server build (built 12:40 today, newer than the proxy source dated Oct 22) |
| Bind | `PORT=8099 NITRO_HOST=0.0.0.0 HOST=0.0.0.0` → `Listening on: http://localhost:8099/ (all interfaces)`; `netstat` shows `0.0.0.0:8099 LISTENING` |
| Interface used | the machine's Wi-Fi address, `192.168.1.151` |
| Database | `OQE_DB_PATH` pointed at a throwaway SQLite file under `%TEMP%\oqe-p56`, so no user data was read or migrated |
| Companion stand-in | a stub HTTP server on `127.0.0.1:8123`, selected with `OQE_COMPANION_PORT=8123`, which logs every forwarded request and answers `200`. **No Python companion was started, so no desktop action was possible** |
| Client | `curl` from the same machine, dialling both `127.0.0.1` and `192.168.1.151` |

The stub is what makes the companion half of this test safe: the proxy forwards to it, so `/execute`
and `/enable` can be exercised without touching a desktop.

## 10.2 The path, in source

| Step | File:line | Condition |
| --- | --- | --- |
| Web bind (dev) | `vite.config.ts:65,70` | `host: process.env.OQE_DEV_HOST \|\| "127.0.0.1"` — the override is the only thing that widens it |
| Web bind (built) | `.output/server/index.mjs` (`serve({ hostname })`) | derived from `NITRO_HOST` / `HOST`, no loopback assertion |
| Local origin gate | `src/lib/local-request-security.server.ts:8-25` | rejects cross-site `Sec-Fetch-Site`, wrong `Origin`, wrong `Referer`; **returns true when none are present** |
| Storage host gate | e.g. `storage.conversations.ts:68-84`, and `storage.{evidence,artifacts,operation-journal,task-queue,voice-profiles}.ts` | `new URL(request.url).hostname` must be `127.0.0.1` / `localhost` / `::1` |
| Task host gate | `server-task-runner.server.ts:399-421` | same rule, plus `x-oqe-tasks` on writes |
| Automation host gate | `automation-route-gate.server.ts:25-46` | same rule, plus `x-oqe-storage` |
| Companion proxy | `api/companion.$.ts:16-30, 70-110` | `localRequestRejected` then, for POST power actions, `fromThisApp` |
| `fromThisApp` | `api/companion.$.ts:50-61` | `Origin` (or `Referer`) must equal `new URL(request.url).origin` — the address the client dialled |
| Token injection | `api/companion.$.ts:94` | `token(request) \|\| (fromThisApp(request) ? companionToken() : null) \|\| ""` |
| Token source | `companion/supervisor.server.ts:274, 643, 804` | process memory, set only when this app spawned and paired a companion (`token = pairBody.token`) |
| Companion itself | `companion/main.py:30, 68` | port from `OQE_COMPANION_PORT`, `uvicorn.run(app, host="127.0.0.1", …)` — always loopback |
| Companion auth | `companion/server.py:369-377, 533, 541-563` | `_require_authorized` compares `x-oqe-companion-token` with the process token; `/pair` returns it |
| Routes with **no** host gate | `ollama.$.ts`, `tts.$.ts`, `images.generate.ts`, `systems-lab.status.ts`, `systems-lab.history.ts`, `browser-attest.ts` | origin gate only |

## 10.3 Measured results

All requests below were made against the `0.0.0.0`-bound server. `Host` defaults to the address
dialled unless overridden.

| # | Client → address | Headers | Endpoint | Status | Reading |
| --- | --- | --- | --- | --- | --- |
| R1 | `127.0.0.1:8099` | — | `GET /api/storage/conversations` | **200** | baseline works |
| R2 | `192.168.1.151:8099` | — | same | **403** | host gate refuses a LAN-shaped URL |
| R3 | `192.168.1.151:8099` | `Host: 127.0.0.1:8099` | same | **200** | **host gate bypassed by the Host header** |
| R4 | `192.168.1.151:8099` | `Host` + matching `Origin` | same | **200** | bypass survives the origin gate |
| R5 | `192.168.1.151:8099` | `Origin: http://192.168.1.151:8099` | `GET /api/companion/health` | **200** (stub saw `/health`) | companion proxy reachable over LAN |
| R6 | `192.168.1.151:8099` | spoofed `Host` + `Origin` | `GET /api/companion/health` | **200** | same, no host gate to bypass |
| R7 | `192.168.1.151:8099` | `Origin: http://192.168.1.151:8099` | `POST /api/companion/power/disable` | **200** | **`fromThisApp` accepted a LAN origin** (a refusal would be 403) |
| R8 | `192.168.1.151:8099` | `Origin: http://evil.example` | same | **403** | the origin gate itself still works |
| R9 | `192.168.1.151:8099` | spoofed `Host` + `Origin` | `POST /api/companion/execute` | **200** (stub saw `/execute`) | desktop-control endpoint reachable |
| R10 | `192.168.1.151:8099` | spoofed `Host` + `Origin` | `POST /api/companion/enable` | **200** (stub saw `/enable`) | arming route reachable |
| R11 | `192.168.1.151:8099` | spoofed `Host` | `GET /api/systems-lab/status` | **200** | no host gate |
| R12 | `192.168.1.151:8099` | spoofed `Host` | `GET /api/tasks/status/verify-invalid` | **404** (not 403) | task gate bypassed; id validation then answered |
| R13 | `127.0.0.1:8099` | `Origin: http://evil.example` | `GET /api/storage/conversations` | **403** | cross-origin browser blocked |
| R14 | `192.168.1.151:8099` | — | `GET /api/systems-lab/status` | **200** | read-only route open without any spoof |

The stub log shows the proxy forwarded `/health`, `/execute` and `/enable`, with
`x-oqe-companion-token: null` on each — expected, because no paired companion existed to supply a token.

**Dev-server path (`OQE_DEV_HOST`), run separately.** `OQE_DEV_HOST=0.0.0.0 npx vite dev --port 8098
--strictPort` bound `0.0.0.0:8098` and advertised both `Local: http://localhost:8098/` and
`Network: http://192.168.1.151:8098/`. From the Wi-Fi address, `Host: 127.0.0.1:8098` on
`/api/companion/health` passed the gates and reached the proxy, which answered
`502 {"error":"Local companion is unavailable: fetch failed"}` because nothing listened on the
configured companion port — i.e. the request was forwarded, not refused. The same run with the real
`Host` returned `403` for the conversation store. The dev path and the built path behave identically.

## 10.4 Findings

**F1 — High: the loopback host gates are Host-header checks, not network checks.**
R3/R4/R12 show that `new URL(request.url).hostname` follows the `Host` header. Any client that can reach
the port can present `Host: 127.0.0.1` and be treated as local by the conversation, evidence, artifact,
journal, task-queue, voice-profile, task and automation gates. The read paths were demonstrated; the
write paths share the same gate and would be reachable by the same request, but **writes were not
exercised**.

**F2 — High: the companion proxy has no host gate, and its `fromThisApp` check is not trust.**
It compares `Origin` with the address dialled, which the client controls. R7 demonstrates the check
passing from a non-loopback address; R8 shows it still stops a genuinely foreign origin, which is a
CSRF property, not authentication. R9/R10 show `/execute` and `/enable` are reachable this way.

**F3 — Critical *if* a companion is paired: server-side token injection completes the chain.**
`api/companion.$.ts:94` attaches `companionToken()` on exactly the branch R7 proved reachable. The token
lives only in app memory and is set when the app itself spawned and paired the companion — the normal
state for desktop control. With that state, a LAN client's `/execute` reaches the real companion bearing
the app's token, and the companion's own consent/STOP gates are the only remaining barriers.
**Not exercised with a live token**, because obtaining one requires spawning the real companion, which
this task forbids. The inference is one line of code over a condition that was exercised.

**F4 — Medium: six route groups have no loopback check at all** (`ollama`, `tts`, `images.generate`,
`systems-lab.status`, `systems-lab.history`, `browser-attest`). R11/R14 confirm read access to Systems
Lab status; the others are proxies/readers whose sensitivity is lower but non-zero (installed voices,
model use, change-set history).

**F5 — Scope: default installs are not exposed.** With no `OQE_DEV_HOST` (or `HOST`) override the server
binds `127.0.0.1` only, and the companion always binds `127.0.0.1`. `START-OQE.cmd:8` sets
`OQE_DEV_HOST=127.0.0.1`. The exposure requires the documented-but-discouraged override; the threat
actor must already reach the port on the LAN.

## 10.5 What is verified, and what is not

**Verified:** binding to all interfaces; reachability via the non-loopback Wi-Fi address; the Host-header
bypass of every loopback gate tested; the companion proxy's reachability and forwarding; `fromThisApp`
accepting a LAN origin while rejecting a foreign one; the absence of a host gate on six route groups;
token *absence* when unpaired.

**NOT VERIFIED:** any request originating on a **different device** (no second client was used, and
Windows Firewall may still block inbound traffic that this same-machine test bypasses); the presence of a
live token and an end-to-end `/execute` reaching a real companion; write operations.

## 10.6 Candidate corrections (not implemented)

Listed in dependency order; none is authorised by this task.

1. Refuse a non-loopback bind (or require an explicit second opt-in) and say so in the start-up output.
2. Make the host gates compare against a value the client cannot set — e.g. the socket's local address
   rather than the parsed `Host` — or drop them in favour of (1).
3. Give `/api/companion/*` the same host rule as the stores, and stop treating `fromThisApp` as though it
   established trust.
4. Decide whether Systems Lab status/history and the media proxies need a host rule of their own.

## 10.7 Cleanup and confirmation

Both test processes were terminated by PID (`taskkill /T`), `netstat` shows no `LISTENING` socket on
8099 or 8123, and `%TEMP%\oqe-p56` was deleted. `git status` is unchanged — 113 modified, 46 deleted,
136 untracked, HEAD `4e74455` — and no release artefact, checksum or pointer was created or moved.

---

# 11. P0 remediation plan (Prompt 57, 2026-10-27)

Planning only. No product code, test, configuration or build script was changed; the working tree is as
CP-56 left it. The P0 gate remains open and V11.1 remains unpromoted.

## 11.1 Recommendation

**Refuse non-loopback binding (A), and harden the companion proxy with a connection-address check (C).**
One shared predicate, no authentication work, no new mode.

- **A** removes the attack surface: with no non-loopback listener there is no remote request to spoof a
  `Host` for. Enforce where the address is chosen — a `configResolved` guard for dev/preview (which also
  catches `vite --host 0.0.0.0`) and a preflight refusal for the bundled server before
  `app/server/index.mjs` listens.
- **C** makes `/api/companion/*` fail closed on its own: reject when the TCP peer is not loopback, and
  attach the server-held token only to a request that passed that check. `fromThisApp()` stays as a CSRF
  check, no longer described as trust.
- **B** is satisfied inside C: the predicate is the connection's address, not the `Host` header.
- **D** is not a boundary. `Origin` is client-supplied; comparing it with the address dialled is a
  tautology.

**Why this is the smallest defensible set:** A closes the demonstrated bypass for every route without
touching them; C is roughly thirty lines and protects the highest-impact branch (token injection) if A
regresses. Rewriting the six existing `Host` checks is explicitly *not* proposed.

## 11.2 What the re-examination added

| Finding | Effect on the plan |
| --- | --- |
| `installer/Oqe-start.ps1:75` pins `NITRO_HOST=127.0.0.1`, asserted by `scripts/installer.test.mjs:133` | Default installs were never exposed; the demo needed an override, so the fix must target the override paths |
| `vite.config.ts:60-62` and `AGENTS.md:44` document `OQE_DEV_HOST=0.0.0.0` as a LAN-preview feature | A refusal is a deliberate product change and those instructions must change with it |
| `START-OQE.cmd:8` forces loopback; `run-oqe-server.cmd:4` only defaults | One launcher is already safe; the permissive one is a documented developer path |
| srvx exposes the socket peer as `request.ip`; h3's `getRequestIP` reads it | A header-independent check is feasible in the built server |
| No `server/middleware` seam remains in this tree | The guard must sit in the Vite config and the launch path, not a middleware directory |

## 11.3 Comparison, condensed

| Candidate | Blocks the demonstrated attack | Protects token injection | Compatibility | Verdict |
| --- | --- | --- | --- | --- |
| A — refuse non-loopback bind | Yes | Yes (by removing reachability) | Removes LAN preview | **Adopt** |
| B — connection-address predicate | Yes, per route | Yes if used at the injection point | None locally; dev fallback unconfirmed | **Adopt inside C** |
| C — proxy hardening | Yes, for `/api/companion/*` | Yes, explicitly | None locally | **Adopt** |
| D — Origin validation | No | No | None | Keep for CSRF only |

## 11.4 Tests and prerequisites

Nine regression tests are specified in `SCOPE-RESTORATION-PLAN.md` §9.7: default bind, refusal of every
non-loopback configuration including the CLI flag, `Host`-spoof refusal, proxy refusal before forwarding,
no token on a refused request, unchanged local workflows, untouched pairing/consent/STOP, parity between
dev and packaged paths, and the existing suite.

Two are **PENDING** and must not be recorded as passing without their prerequisites:

- **T3 cross-device** needs a second machine (or a firewall-level test) to prove a remote peer is
  refused; Prompt 56 only used this machine's own non-loopback address.
- **T5 token non-injection** needs a test seam or a paired companion; the token is process state today
  (`supervisor.server.ts:274`), so the predicate can be tested directly but the header path cannot be
  exercised end to end without one.

Everything else runs with the stub companion and a throwaway database. No test may grant real consent or
drive a real desktop.

## 11.5 Compatibility and remaining uncertainty

The LAN preview documented in `vite.config.ts` and `AGENTS.md` stops working. That is the intended
trade: without authentication there is no safe way to expose the app to a network, and a future remote
mode would be a separate design. Installed users are unaffected because the installer already pins
loopback.

Open uncertainties: whether `getRequestIP()` is populated in the Vite dev handler (the guard must fail
closed when the address is unknown; dev is covered by A regardless); whether Windows Firewall blocks
inbound traffic in practice (not tested, and it must not be relied on); whether a future Nitro upgrade
changes the generated entry (the preflight guard is entry-agnostic for that reason).

## 11.6 Confirmation

No product code, route, test, schema, installer, dependency, build script or configuration default was
modified. No release archive, checksum, tag or pointer was created. `git status` is unchanged at 113
modified / 46 deleted / 136 untracked on `4e74455`. The P0 is **not** marked fixed; the release gate is
**not** passed. Implementation waits for explicit approval of A + C.

---

# 12. P0 remediation implemented (Prompt 58, 2026-10-27)

Prompt 57 proposed A + C and the user approved exactly those two. This section records the
implementation, the defect found while verifying it, the live evidence, and what remains open.
Sections 10 and 11 are untouched: Prompt 56's measurements and CP-57's proposal remain the historical
record, including the parts that later turned out to be incomplete.

## 12.1 What was built

| Change | Where |
| --- | --- |
| One shared bind policy (pure, no I/O): loopback spellings accepted, everything else refused, unset allowed only for dev/preview | `scripts/loopback-bind.mjs` (new) |
| Bundled-server preflight loaded with `node --import` before the entry: refuses a configured non-loopback host, pins `127.0.0.1` when nothing is configured | `scripts/loopback-preflight.mjs` (new) |
| Vite guard as a **plugin** `configResolved` hook over the resolved `server.host` and `preview.host` | `vite.config.ts` |
| TCP-peer predicate (`127.0.0.0/8`, `::1`, `::ffff:127.x`; unknown fails closed in production) and a `companionPeerRejected` responder | `src/lib/local-request-security.server.ts` |
| Peer check before anything is forwarded; token selection moved behind it into a pure helper | `src/routes/api/companion.$.ts`, `src/lib/companion/bridge-token.ts` (new) |
| Installer ships the policy + preflight and loads the preflight before the server | `scripts/installer-lib.mjs`, `installer/Oqe-start.ps1` |
| Docs: LAN preview removed, peer boundary stated | `AGENTS.md` |
| Tests | `scripts/loopback-bind.test.mjs` (new), `src/lib/loopback-peer.test.ts` (new), `src/lib/companion/power-route.test.ts` (contract updated), `scripts/installer.test.mjs`, `scripts/run-tests.mjs` |

`fromThisApp()` is unchanged and still guards POST power actions as a CSRF check. `x-oqe-companion-token`
is never logged, and the existing gate is not duplicated in the browser.

## 12.2 The first attempt did not work, and the report says so

`configResolved` was initially a top-level config key. Vite ignores unknown keys there, so
`vite dev --host 0.0.0.0` still bound every interface; the unit test passed because it only read the
source. Running the real server exposed it. Moving the hook into a plugin (`oqe:loopback-bind`, registered
first) made the same command exit 1 before listening, and the suite now spawns Vite for real so the
regression cannot return silently.

Observation from the mis-bound run: `/api/companion/health` from the Wi-Fi address returned 403 even
then, with and without a spoofed `Host` — C held while A did not. It also showed the dev handler
populates the peer address, so `allowUnknown` in dev is a belt-and-braces fallback rather than the
reason dev is safe.

## 12.3 Evidence

| Check | Result |
| --- | --- |
| `node --test scripts/loopback-bind.test.mjs` | 13/13 pass (includes a real spawned dev server) |
| `node --experimental-strip-types --test src/lib/loopback-peer.test.ts` | 8/8 pass |
| `node --experimental-strip-types --test src/lib/companion/power-route.test.ts` | 8/8 pass |
| `node --test scripts/installer.test.mjs` | 11/11 pass |
| `npm run typecheck` | exit 0 |
| `npx eslint` on every changed file | exit 0 |
| `OQE_NITRO_PRESET=node-server npm run build` | exit 0 |
| `npm test` | exit 1 — scripts 170/166 pass/4 skipped, `src` 2985/2984 pass/1 fail, extension 78/78. The failure is the pre-existing `RELEASE-V11.1.sha256` provenance check |

Live, this host:

| Test | Result |
| --- | --- |
| `vite dev --host 0.0.0.0`, `--host 192.168.1.151`, `OQE_DEV_HOST=0.0.0.0` | exit 1 each, `refuses to bind to "…"`, no listener |
| `vite dev --host 127.0.0.1` | `127.0.0.1:8097` only, `/` 200, LAN dial refused (curl 7), companion health 200 |
| Built server **with** preflight, `NITRO_HOST=127.0.0.1` | listens loopback only, `/` 200, companion health 200 |
| Built server **without** preflight, `NITRO_HOST=0.0.0.0` (the pre-fix shape), dialled from `192.168.1.151` | `/api/companion/health`, `/execute`, `/enable`, `/consent-target` all **403** — plain, with `Host: 127.0.0.1:8099`, and with matching `Origin` |
| Same server, loopback companion health | 200 |

The spoofed-`Host` request that returned 200 at Prompt 56 now returns 403 before a forward. No consent
was granted and no desktop action was executed at any point.

## 12.4 What is still not verified

- **T3 cross-device:** every request originated on this machine against its own Wi-Fi address. No second
  device, and Windows Firewall was not exercised. `NOT VERIFIED`.
- **T5 token injection with a real paired companion:** the gate and its ordering are tested; an actual
  `x-oqe-companion-token` on the wire with a paired companion was not observed. `NOT VERIFIED`.
- **Clean Windows install** of the new payload: the installer test asserts the file list and arguments,
  not a real installation.
- **Local processes** can still reach the loopback port; that is inherent to the local-first design.
- **A hand-started `.output/server/index.mjs` with `HOST=0.0.0.0`** skips the preflight. It is not a
  supported launch path (dev, preview and the installed launcher are all guarded) and it requires the
  operator to rebuild the exposure deliberately, but it is a real residual and is named rather than
  glossed over.

## 12.5 Gate

A-1: `VERIFIED EXPOSED` → **`IMPLEMENTED — VERIFIED ON THIS HOST; CROSS-DEVICE NOT VERIFIED`**. The P0
gate is **not closed**; V11.1 is **not promoted**; no release archive, checksum, tag or pointer was
created. Closing the gate needs the T3/T5 evidence and an independent audit of the diff.

## 12.6 Files and state

Source/config: `scripts/loopback-bind.mjs`, `scripts/loopback-preflight.mjs`, `vite.config.ts`,
`src/lib/local-request-security.server.ts`, `src/routes/api/companion.$.ts`,
`src/lib/companion/bridge-token.ts`, `scripts/installer-lib.mjs`, `installer/Oqe-start.ps1`,
`package.json`/`package-lock.json` were already modified before this prompt and were not touched here.
Tests: the two new suites, the updated companion contract test, `scripts/installer.test.mjs`,
`scripts/run-tests.mjs`. Docs: `AGENTS.md`, this file, the plan, `CHECKPOINT-LOG.md`.

`git status` before this prompt: 113 modified / 46 deleted / 136 untracked on `4e74455`. After: 117
modified / 46 deleted / 141 untracked. The delta is four previously clean files that are now modified
(`vite.config.ts`, `local-request-security.server.ts`, `companion.$.ts`, `power-route.test.ts`), three
already-untracked files edited in place (`installer-lib.mjs`, `Oqe-start.ps1`, `installer.test.mjs`), and
five new files (`scripts/loopback-bind.mjs`, `scripts/loopback-preflight.mjs`,
`scripts/loopback-bind.test.mjs`, `src/lib/companion/bridge-token.ts`, `src/lib/loopback-peer.test.ts`).
`AGENTS.md` and `scripts/run-tests.mjs` were already modified before this prompt and changed again
without altering the count. No deletion, no unrelated edit, no release artifact. `npm run build` rewrote `.output/` (already-untracked build output); no release file
was produced.

---

# 13. F-1 correction implemented (Prompt 60, 2026-10-27)

CP-59's HIGH finding is preserved in `AUDIT-CP-58.md` §2. This section records the correction, the tests,
and what it does not prove.

## 13.1 The change

- Shared gate: `companionPeerRejected` became `loopbackPeerRejected` (plus a companion-worded wrapper), so
  the companion proxy and the task routes use one predicate.
- `POST /api/tasks/start` and `POST /api/tasks/resume/$taskId` run that gate **before** their handlers and
  pass `trusted: true` only when it passes.
- `serverTaskRunner().start`/`resume` accept `trusted` (default `false`); the pump carries it; a desktop
  effect on an untrusted run fails before the journal, before `companionToken()` and before any fetch.
- Boot recovery and cancel-triggered pumps are untrusted by default: a recovered desktop item fails closed
  until a peer-checked resume.

Why it is structured this way: the pump runs after the response, so the request context is gone by dispatch
time. The decision is made where the peer can actually be read and carried into the run; the dispatch guard
is the second check for any future internal caller.

## 13.2 Evidence

| Command / probe | Result |
| --- | --- |
| `node --experimental-strip-types --test src/lib/server-task-runner.test.ts` | 35/35 pass (seven new) |
| `npm run typecheck` | exit 0 |
| `npx eslint` on the five changed files | exit 0 |
| `OQE_NITRO_PRESET=node-server npm run build` | exit 0; bundle contains the guard text and three peer gates |
| `npm test` | 2992 / 2991 pass; the only failure is the pre-existing missing-V11.1-checksum assertion |
| Built server on `0.0.0.0:8099` (no preflight), LAN dial with spoofed `Host`+`Origin`+`x-oqe-tasks` | `/api/tasks/start` **403**, `/api/tasks/resume/task-x` **403**, no task created |
| Loopback `POST /api/tasks/start` with `text/plain` | **415** — gate passed, local workflows intact |

The untrusted unit test additionally replaces `globalThis.fetch` and asserts it is never called, so the
token-attachment path is unreachable rather than merely unused.

## 13.3 Limits

- **T5** (real paired companion on the wire) remains `NOT VERIFIED`; the proof is structural plus a fetch
  spy.
- **T3** remains `NOT VERIFIED`; the live probe is same-host-to-own-Wi-Fi-address.
- F-2, F-3, F-4 (remaining gaps), F-5, F-6 are untouched by this prompt.
- Recovery behaviour changed deliberately: desktop work after a restart fails closed.
- Gate stays open, V11.1 unpromoted, no release artifact.

# 14. Independent re-audit of F-1, F-2/F-3 assessment (Prompt 61, 2026-10-27)

Documentation-only pass. The app was left running on `127.0.0.1:8080` throughout; no product file, test,
configuration, dependency or release artifact was changed.

## 14.1 F-1 verdict — independently verified

| Scope item | Result |
| --- | --- |
| Trust is granted only from the actual peer | **PASS.** The two route handlers run `loopbackPeerRejected(request)` before their handlers; the handler default is `{}`, so `options.trusted === true` is false unless the route passes it |
| Trust cannot be forged by a client | **PASS.** The task body is parsed only for `title`, `items`, `taskId`; `validateServerTaskWork` has no trust field; the effect allowlist is unchanged. Existing trust is a function argument, not a field |
| Trust cannot come from storage | **PASS.** Only `queueState` and `effectsState` are persisted; no trust column exists; the journal records operations, not authority |
| Trust does not spread to later untrusted work | **PASS.** Trust is per pump/run. `cancel` and boot recovery pump with no flag; `resume` re-decides; a duplicate start does not schedule a new pump |
| Every desktop path is guarded before side effects | **PASS.** The guard (`server-task-runner.server.ts:967`) precedes the journal (`:985`), `dispatch` (`:1024`), and `companionToken()` inside the dispatcher (`:528`) |
| Headers cannot substitute for the peer | **PASS.** `getRequestIP({xForwardedFor:false})` resolves `socket.remoteAddress`; srvx honours `x-forwarded-for` only with `trustProxy`, which the generated entry does not set. `Host`, `Origin`, `Referer`, `x-oqe-tasks`, `X-Forwarded-For`, `X-Real-IP`, `Forwarded` are not read |
| Tests exercise the boundary | **PASS with gap.** The runner tests drive a real pump with a mocked store and a `globalThis.fetch` spy (0 calls for untrusted runs). The route-order assertions are source-text checks, so a new unguarded handler could evade them (F-4 remains) |

## 14.2 F-2 — confirmed, not fixed

`npx vite --host --port 8099` exits **1** with `TypeError: … .split is not a function` and opens no listener.
Vite passes boolean `true`; `isLoopbackHost` assumes a string. `npx vite --host 0.0.0.0` exits **1** with the
intended `LoopbackBindError`, so the refusal holds even though the message is wrong. Proposed correction and
tests are in plan §11.5 (A-11); **not authorised, not implemented**.

## 14.3 F-3 — confirmed, not fixed

`.output/server/index.mjs:965` is `var host = process.env.NITRO_HOST || process.env.HOST;`, passed to
`serve`; the entry has no preflight import. With neither variable set it binds all interfaces (measured in
CP-59). The installer launcher is safe (`NITRO_HOST=127.0.0.1` plus `node --import Oqe-preflight.mjs`), and no
other supported launcher exists. Runtime bind was **not repeated** in this pass to avoid exposing the app;
the source path is unambiguous. Smallest correction (prepend the preflight import to the staged entry during
packaging) and its tests are in plan §11.5 (A-12); **not authorised, not implemented**.

## 14.4 Checks run

| Command | Result |
| --- | --- |
| `node --experimental-strip-types --test src/lib/loopback-peer.test.ts src/lib/local-request-security.test.ts src/lib/companion/power-route.test.ts` | 20/20 pass |
| `node --experimental-strip-types --test src/lib/server-task-runner.test.ts` | 35/35 pass |
| `npm run typecheck` | exit 0 |
| `npx eslint` on the seven security/launch files | exit 0 |
| Live: dev server `/`, `/api/tasks/start` (with and without header), `/api/companion/power/status`, `/api/companion/health`, `/api/companion/execute` | 200 / 400 / 400 / 200 / 200 / 401 as detailed in `AUDIT-CP-58.md` §9.5 |
| `npx vite --host` and `--host 0.0.0.0` | both exit 1, no listener |

`npm test` and `npm run build` were **not re-run**: nothing changed since CP-60, and a build would overwrite
the `.output` behind the running app. The known `RELEASE-V11.1.sha256` provenance failure is unchanged.

## 14.5 Limits and gate

- **T3** (separate device) and **T5** (paired companion on the wire): `NOT VERIFIED`.
- F-2, F-3, F-4, F-5, F-6: open. A-11/A-12 await explicit approval.
- No desktop action, consent grant or real companion token was exercised; no secret was logged.
- P0 **not closed**; V11.1 **not promoted**; no archive, checksum, tag or release pointer created.

**Working tree:** `4e74455` on `main`; 117 modified / 46 deleted / 142 untracked, unchanged in shape. Files
written: `AUDIT-CP-58.md` §9, `SCOPE-RESTORATION-PLAN.md` §11.5, this section, `V11.1-ISSUES.md` note/row,
and CP-61 in `CHECKPOINT-LOG.md`.

# 15. A-11 and A-12 implemented (Prompt 62, 2026-10-27)

Both approved corrections are implemented, tested and recorded. The dev server stayed on
`127.0.0.1:8080` (reused, never restarted or rebound).

## 15.1 A-11 — bare `--host` now fails as policy

- `assertLoopbackBind` checks the value's type before `normalizeHost`: boolean `true` raises
  `LoopbackBindError` saying that a bare `--host` means all interfaces and to pass `--host 127.0.0.1`;
  other non-strings are refused; `allowUnset` applies only to `undefined`/`null`/blank.
- `isLoopbackHost(true)` returns `false` instead of throwing, so a direct call cannot produce a `TypeError`.
- Focused suite **15/15**. The spawned real dev server with `--host --port 8097` exits **1**, prints the
  policy sentence, shows no `TypeError`, and leaves no listener; `--host 0.0.0.0` is still refused with
  `refuses to bind to`.

## 15.2 A-12 — packaged entry loads the preflight

- `installer-lib.mjs` now exports `PACKAGED_ENTRY_GUARD` and `guardPackagedEntry`, which prepends
  `import "../../Oqe-preflight.mjs";` as the entry's first statement (after a shebang if present), is
  idempotent, and refuses a different preflight path.
- `build-installer.mjs` applies the guard to the staged `app/server/index.mjs` after copying the payload,
  before zipping, and refuses to continue if the staged preflight is missing or the entry did not take the
  guard. Rebuilding/repackaging therefore reapplies the same guard.
- `README-Windows.md` now says to use the Start-menu shortcut and that the packaged entry itself refuses a
  non-loopback bind.
- Tests: installer suite **12/12**, new packaging/runtime suite **5/5**. A disposable staged fixture with the
  real preflight exits **1** for `NITRO_HOST=0.0.0.0`, `HOST=::` and a LAN host before its entry body runs;
  loopback runs the body; a missing preflight exits non-zero before the body; the guard remains single after
  repackaging. The fresh generated entry takes the guard with its body unchanged.

## 15.3 Verification

| Command | Result |
| --- | --- |
| `node --test scripts/loopback-bind.test.mjs` | 15/15 pass |
| `node --test scripts/installer.test.mjs scripts/packaged-entry-guard.test.mjs` | 17/17 pass |
| `node --test` all three packaging/loopback suites | 32/32 pass |
| `node --experimental-strip-types --test` loopback-peer, local-request-security, power-route, server-task-runner | 55/55 pass |
| `npm run typecheck` | exit 0 |
| `npx eslint` on the six changed scripts/tests | exit 0 |
| `OQE_NITRO_PRESET=node-server npm run build` | exit 0 |
| Dry stage of the fresh `.output` | first line `import "../../Oqe-preflight.mjs";`; body byte-identical; preflight present |
| `npm test` | scripts 178 / 174 pass / 4 skipped / 0 fail; src 2992 / 2991 pass / **1 fail** (pre-existing `RELEASE-V11.1.sha256`); extension 78/78 |

## 15.4 Limits and gate

The real packaged entry was not started on `0.0.0.0` (that would expose the app if the guard regressed); the
fresh artifact's guard was verified statically and execution was verified on the disposable fixture. A clean
installer install/launch remains QA. **T3** (separate device) and **T5** (paired companion token flow) remain
`NOT VERIFIED`. P0 is **not closed**; V11.1 is **not promoted**; no archive, checksum, tag or pointer exists.

**Working tree:** `4e74455`; 117 modified / 46 deleted / 143 untracked (one new test file). Product files
changed: `scripts/loopback-bind.mjs`, `scripts/loopback-bind.test.mjs`, `scripts/installer-lib.mjs`,
`scripts/build-installer.mjs`, `scripts/installer.test.mjs`, `scripts/packaged-entry-guard.test.mjs`,
`README-Windows.md`. Documentation: this section, plan §11.6, `AUDIT-CP-58.md` §10, `V11.1-ISSUES.md`, CP-62.
