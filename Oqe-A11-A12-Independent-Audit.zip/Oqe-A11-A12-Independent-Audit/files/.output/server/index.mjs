globalThis.__nitro_main__ = import.meta.url;
import { a as toEventHandler, c as serve, i as defineLazyEventHandler, n as HTTPError, r as defineHandler, s as NodeResponse, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { i as withoutTrailingSlash, n as joinURL, r as withLeadingSlash, t as decodePath } from "./_libs/ufo.mjs";
import { promises } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/og.jpg": {
		"type": "image/jpeg",
		"etag": "\"e12f-buhwnqaswDGaGy4xBIIXkQDC6xY\"",
		"mtime": "2026-10-18T20:38:50.723Z",
		"size": 57647,
		"path": "../public/og.jpg"
	},
	"/assets/about-page-CF5k-fd6.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"19ad-MWWTxBTNRlDSxsVdyzYKgWW3tR4\"",
		"mtime": "2026-10-27T15:12:28.178Z",
		"size": 6573,
		"path": "../public/assets/about-page-CF5k-fd6.js"
	},
	"/brand/orb-character.webp": {
		"type": "image/webp",
		"etag": "\"a01c-zu8W+aC677NprCtEjhI9kOc1ziA\"",
		"mtime": "2026-10-15T22:20:01.532Z",
		"size": 40988,
		"path": "../public/brand/orb-character.webp"
	},
	"/favicon.svg": {
		"type": "image/svg+xml",
		"etag": "\"68a2-P10vabp0ds8A5ZXXnGbMH1vL8dw\"",
		"mtime": "2026-10-18T20:34:13.569Z",
		"size": 26786,
		"path": "../public/favicon.svg"
	},
	"/assets/about-BBcPbbou.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"88-5RESw1HLwiSa10duXysqdp1hHs8\"",
		"mtime": "2026-10-27T15:12:28.178Z",
		"size": 136,
		"path": "../public/assets/about-BBcPbbou.js"
	},
	"/assets/artifacts-Bp2OvpJc.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6ab-n0fxrVMknzwG/jv3X0lM8qlWdXE\"",
		"mtime": "2026-10-27T15:12:28.178Z",
		"size": 1707,
		"path": "../public/assets/artifacts-Bp2OvpJc.js"
	},
	"/assets/chevron-down-Dje9X847.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"72-9W9Y5mOthx78lMa1DvjgWDlOPss\"",
		"mtime": "2026-10-27T15:12:28.183Z",
		"size": 114,
		"path": "../public/assets/chevron-down-Dje9X847.js"
	},
	"/assets/cn-Bo35moy2.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8c6e-YRTJ+lLJeKqIPPd3AWOnuP+TFh4\"",
		"mtime": "2026-10-27T15:12:28.185Z",
		"size": 35950,
		"path": "../public/assets/cn-Bo35moy2.js"
	},
	"/assets/automations-Dm4GVO76.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"42f1-GY8VyMEBEk7iukNnVDlipodR4pc\"",
		"mtime": "2026-10-27T15:12:28.178Z",
		"size": 17137,
		"path": "../public/assets/automations-Dm4GVO76.js"
	},
	"/assets/copy-CViBgJMo.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"20c-yojElNrh+BUvDyY/m74e2GbC9JU\"",
		"mtime": "2026-10-27T15:12:28.186Z",
		"size": 524,
		"path": "../public/assets/copy-CViBgJMo.js"
	},
	"/assets/conversations-DnhqbJ4i.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"fc9-KPv9LtmBC5M6FCbqWhxPMZmFAMQ\"",
		"mtime": "2026-10-27T15:12:28.186Z",
		"size": 4041,
		"path": "../public/assets/conversations-DnhqbJ4i.js"
	},
	"/assets/ibm-plex-mono-cyrillic-400-normal-CEL4l2ZJ.woff": {
		"type": "font/woff",
		"etag": "\"1c24-wpeoT2YBcqJ4hbipsoiB1m58w98\"",
		"mtime": "2026-10-27T15:12:28.207Z",
		"size": 7204,
		"path": "../public/assets/ibm-plex-mono-cyrillic-400-normal-CEL4l2ZJ.woff"
	},
	"/assets/ibm-plex-mono-cyrillic-500-normal-Ael50iVv.woff": {
		"type": "font/woff",
		"etag": "\"1c28-50yap58S0sLYRB2B8AEk2dq82kg\"",
		"mtime": "2026-10-27T15:12:28.207Z",
		"size": 7208,
		"path": "../public/assets/ibm-plex-mono-cyrillic-500-normal-Ael50iVv.woff"
	},
	"/assets/ibm-plex-mono-cyrillic-500-normal-Bq9vWWag.woff2": {
		"type": "font/woff2",
		"etag": "\"210c-yqAnW+098RkHUvQzwj27Jo9sIUc\"",
		"mtime": "2026-10-27T15:12:28.209Z",
		"size": 8460,
		"path": "../public/assets/ibm-plex-mono-cyrillic-500-normal-Bq9vWWag.woff2"
	},
	"/assets/ibm-plex-mono-cyrillic-400-normal-BSMlKf0J.woff2": {
		"type": "font/woff2",
		"etag": "\"20a4-mDbzFbXDuciYuRDdYbcJkcocaWU\"",
		"mtime": "2026-10-27T15:12:28.207Z",
		"size": 8356,
		"path": "../public/assets/ibm-plex-mono-cyrillic-400-normal-BSMlKf0J.woff2"
	},
	"/assets/ibm-plex-mono-cyrillic-ext-400-normal-DMdlQ8Kv.woff": {
		"type": "font/woff",
		"etag": "\"16bc-GBHBT1lClOFRLkxzjkkoZV1QN+Y\"",
		"mtime": "2026-10-27T15:12:28.209Z",
		"size": 5820,
		"path": "../public/assets/ibm-plex-mono-cyrillic-ext-400-normal-DMdlQ8Kv.woff"
	},
	"/assets/ibm-plex-mono-cyrillic-ext-500-normal-BIfNGwUT.woff": {
		"type": "font/woff",
		"etag": "\"168c-gvDCX7ATl9g9LbPEKlQjJSXhRPw\"",
		"mtime": "2026-10-27T15:12:28.211Z",
		"size": 5772,
		"path": "../public/assets/ibm-plex-mono-cyrillic-ext-500-normal-BIfNGwUT.woff"
	},
	"/brand/orb-lamps.webp": {
		"type": "image/webp",
		"etag": "\"2adc8-QzM/LdVa0Y33UHwFYbtSPQ8AUJw\"",
		"mtime": "2026-10-16T10:37:22.103Z",
		"size": 175560,
		"path": "../public/brand/orb-lamps.webp"
	},
	"/assets/ibm-plex-mono-cyrillic-ext-400-normal-xuaO2J-f.woff2": {
		"type": "font/woff2",
		"etag": "\"1b00-w57wcK5m30ZZ4sBwsaWzlcI3F7c\"",
		"mtime": "2026-10-27T15:12:28.209Z",
		"size": 6912,
		"path": "../public/assets/ibm-plex-mono-cyrillic-ext-400-normal-xuaO2J-f.woff2"
	},
	"/assets/ibm-plex-mono-latin-400-normal-CvHOgSBP.woff": {
		"type": "font/woff",
		"etag": "\"3358-rWMSbc9cch7FBErQpfnWcshAYFM\"",
		"mtime": "2026-10-27T15:12:28.211Z",
		"size": 13144,
		"path": "../public/assets/ibm-plex-mono-latin-400-normal-CvHOgSBP.woff"
	},
	"/assets/ibm-plex-mono-latin-500-normal-CB9ihrfo.woff": {
		"type": "font/woff",
		"etag": "\"3364-S8wip5no4QO46BFh3FPzQKpIOec\"",
		"mtime": "2026-10-27T15:12:28.213Z",
		"size": 13156,
		"path": "../public/assets/ibm-plex-mono-latin-500-normal-CB9ihrfo.woff"
	},
	"/assets/ibm-plex-mono-latin-400-normal-DMJ8VG8y.woff2": {
		"type": "font/woff2",
		"etag": "\"3974-u4dQDjIEo6fGXWYzx5xchAw76NM\"",
		"mtime": "2026-10-27T15:12:28.211Z",
		"size": 14708,
		"path": "../public/assets/ibm-plex-mono-latin-400-normal-DMJ8VG8y.woff2"
	},
	"/brand/orb-body.webp": {
		"type": "image/webp",
		"etag": "\"862b2-1o0j4Mmmj9zcKuzLK3+66QEZp5g\"",
		"mtime": "2026-10-16T10:37:17.764Z",
		"size": 549554,
		"path": "../public/brand/orb-body.webp"
	},
	"/assets/ibm-plex-mono-cyrillic-ext-500-normal-BqneJy0T.woff2": {
		"type": "font/woff2",
		"etag": "\"1b3c-pFin0Xk9XlGLhqdo1+npFJkyQ5Y\"",
		"mtime": "2026-10-27T15:12:28.211Z",
		"size": 6972,
		"path": "../public/assets/ibm-plex-mono-cyrillic-ext-500-normal-BqneJy0T.woff2"
	},
	"/assets/ibm-plex-mono-latin-500-normal-DSY6xOcd.woff2": {
		"type": "font/woff2",
		"etag": "\"3a28-0y8OBwGsYgQ4QBMagAznF6huTuI\"",
		"mtime": "2026-10-27T15:12:28.213Z",
		"size": 14888,
		"path": "../public/assets/ibm-plex-mono-latin-500-normal-DSY6xOcd.woff2"
	},
	"/assets/ibm-plex-mono-latin-ext-400-normal-BmRBH3aV.woff2": {
		"type": "font/woff2",
		"etag": "\"3424-SvjO9SK9iRLLL61B4GuQJWQP62I\"",
		"mtime": "2026-10-27T15:12:28.218Z",
		"size": 13348,
		"path": "../public/assets/ibm-plex-mono-latin-ext-400-normal-BmRBH3aV.woff2"
	},
	"/assets/ibm-plex-mono-latin-ext-400-normal-D3D2R8hC.woff": {
		"type": "font/woff",
		"etag": "\"2df8-dfJwTWMZxHyGnUuJDGfpU4w2dLs\"",
		"mtime": "2026-10-27T15:12:28.219Z",
		"size": 11768,
		"path": "../public/assets/ibm-plex-mono-latin-ext-400-normal-D3D2R8hC.woff"
	},
	"/assets/ibm-plex-mono-latin-ext-500-normal-CAhNIIs5.woff2": {
		"type": "font/woff2",
		"etag": "\"3478-PpQvQo59iHxPLcEUBhJfmFmCPuA\"",
		"mtime": "2026-10-27T15:12:28.219Z",
		"size": 13432,
		"path": "../public/assets/ibm-plex-mono-latin-ext-500-normal-CAhNIIs5.woff2"
	},
	"/assets/ibm-plex-mono-vietnamese-400-normal-BulugwFq.woff2": {
		"type": "font/woff2",
		"etag": "\"16ec-bIkS18/YaTiWdOzfzp4pFXvLmqQ\"",
		"mtime": "2026-10-27T15:12:28.219Z",
		"size": 5868,
		"path": "../public/assets/ibm-plex-mono-vietnamese-400-normal-BulugwFq.woff2"
	},
	"/assets/ibm-plex-mono-vietnamese-400-normal-DDuiU_S-.woff": {
		"type": "font/woff",
		"etag": "\"15f4-LdRX2sBB3T5WDAsZLCwBlsMYXPw\"",
		"mtime": "2026-10-27T15:12:28.219Z",
		"size": 5620,
		"path": "../public/assets/ibm-plex-mono-vietnamese-400-normal-DDuiU_S-.woff"
	},
	"/assets/ibm-plex-mono-vietnamese-500-normal-C8zxqsMH.woff": {
		"type": "font/woff",
		"etag": "\"15f0-mGuZIt/ndQFiw5uxmCOkhhWSxi4\"",
		"mtime": "2026-10-27T15:12:28.219Z",
		"size": 5616,
		"path": "../public/assets/ibm-plex-mono-vietnamese-500-normal-C8zxqsMH.woff"
	},
	"/assets/ibm-plex-mono-latin-ext-500-normal-CZ70TYgx.woff": {
		"type": "font/woff",
		"etag": "\"2df8-73sb1BUyjMsq70ppsdZBHEqWrtE\"",
		"mtime": "2026-10-27T15:12:28.219Z",
		"size": 11768,
		"path": "../public/assets/ibm-plex-mono-latin-ext-500-normal-CZ70TYgx.woff"
	},
	"/assets/ibm-plex-sans-cyrillic-400-italic-Bf1n82Tb.woff": {
		"type": "font/woff",
		"etag": "\"3a7c-HPWq+UPATCkxM5v02pdkYFIeMGI\"",
		"mtime": "2026-10-27T15:12:28.219Z",
		"size": 14972,
		"path": "../public/assets/ibm-plex-sans-cyrillic-400-italic-Bf1n82Tb.woff"
	},
	"/assets/ibm-plex-mono-vietnamese-500-normal-DZ4AoWbu.woff2": {
		"type": "font/woff2",
		"etag": "\"1798-7VDjg0E2ggd9c0kJDHNRh+Fu5E0\"",
		"mtime": "2026-10-27T15:12:28.219Z",
		"size": 6040,
		"path": "../public/assets/ibm-plex-mono-vietnamese-500-normal-DZ4AoWbu.woff2"
	},
	"/assets/ibm-plex-sans-cyrillic-400-italic-D9J6q4_O.woff2": {
		"type": "font/woff2",
		"etag": "\"3f00-HP9zNEm6H3H5+nQS8iX6TqGPBt4\"",
		"mtime": "2026-10-27T15:12:28.219Z",
		"size": 16128,
		"path": "../public/assets/ibm-plex-sans-cyrillic-400-italic-D9J6q4_O.woff2"
	},
	"/assets/ibm-plex-sans-cyrillic-400-normal-BTotfTJu.woff": {
		"type": "font/woff",
		"etag": "\"34c8-8E1Ev9p8J5uSX9vKRfLb+EiMm6w\"",
		"mtime": "2026-10-27T15:12:28.219Z",
		"size": 13512,
		"path": "../public/assets/ibm-plex-sans-cyrillic-400-normal-BTotfTJu.woff"
	},
	"/assets/ibm-plex-sans-cyrillic-500-normal-ByOcLdNv.woff": {
		"type": "font/woff",
		"etag": "\"3620-gsU7yar7orQ5ck2+r3EzXhkJOOc\"",
		"mtime": "2026-10-27T15:12:28.226Z",
		"size": 13856,
		"path": "../public/assets/ibm-plex-sans-cyrillic-500-normal-ByOcLdNv.woff"
	},
	"/assets/ibm-plex-sans-cyrillic-400-normal-DZqxrq2p.woff2": {
		"type": "font/woff2",
		"etag": "\"39d0-4kqxLbZg17B/7aQB6xMRQ4D4rXI\"",
		"mtime": "2026-10-27T15:12:28.226Z",
		"size": 14800,
		"path": "../public/assets/ibm-plex-sans-cyrillic-400-normal-DZqxrq2p.woff2"
	},
	"/assets/ibm-plex-sans-cyrillic-600-normal-71GNu3SW.woff2": {
		"type": "font/woff2",
		"etag": "\"3ac0-dvocaGs2vJ0PDQLCVuNARcsjD58\"",
		"mtime": "2026-10-27T15:12:28.226Z",
		"size": 15040,
		"path": "../public/assets/ibm-plex-sans-cyrillic-600-normal-71GNu3SW.woff2"
	},
	"/assets/ibm-plex-sans-cyrillic-500-normal-CocWQlwt.woff2": {
		"type": "font/woff2",
		"etag": "\"3a98-NsluWReWjMVcTvwm33DoZM+0Q98\"",
		"mtime": "2026-10-27T15:12:28.226Z",
		"size": 15e3,
		"path": "../public/assets/ibm-plex-sans-cyrillic-500-normal-CocWQlwt.woff2"
	},
	"/assets/ibm-plex-sans-cyrillic-600-normal-BGq0mW3O.woff": {
		"type": "font/woff",
		"etag": "\"3640-suQYuW9YdevaJIEEvn8SDj1Vy6w\"",
		"mtime": "2026-10-27T15:12:28.226Z",
		"size": 13888,
		"path": "../public/assets/ibm-plex-sans-cyrillic-600-normal-BGq0mW3O.woff"
	},
	"/assets/ibm-plex-sans-cyrillic-ext-400-italic-BELOEI8R.woff2": {
		"type": "font/woff2",
		"etag": "\"3464-sXNfRvt8/OX6LqYLnYg87T2E3eQ\"",
		"mtime": "2026-10-27T15:12:28.230Z",
		"size": 13412,
		"path": "../public/assets/ibm-plex-sans-cyrillic-ext-400-italic-BELOEI8R.woff2"
	},
	"/assets/ibm-plex-sans-cyrillic-ext-400-italic-CfSXsIbO.woff": {
		"type": "font/woff",
		"etag": "\"2d84-l6Bh4nigLHokeR7ZPeqHTOZf7Yw\"",
		"mtime": "2026-10-27T15:12:28.230Z",
		"size": 11652,
		"path": "../public/assets/ibm-plex-sans-cyrillic-ext-400-italic-CfSXsIbO.woff"
	},
	"/assets/ibm-plex-sans-cyrillic-ext-400-normal-g30qAdWV.woff2": {
		"type": "font/woff2",
		"etag": "\"2f74-bWlkIo723LoZQ5CtmvGymXBCkGA\"",
		"mtime": "2026-10-27T15:12:28.233Z",
		"size": 12148,
		"path": "../public/assets/ibm-plex-sans-cyrillic-ext-400-normal-g30qAdWV.woff2"
	},
	"/assets/ibm-plex-sans-cyrillic-ext-400-normal-Dsrv2Tcn.woff": {
		"type": "font/woff",
		"etag": "\"2830-b+SzpJsjscfOvgTIzm8D+yEJGmY\"",
		"mtime": "2026-10-27T15:12:28.230Z",
		"size": 10288,
		"path": "../public/assets/ibm-plex-sans-cyrillic-ext-400-normal-Dsrv2Tcn.woff"
	},
	"/assets/ibm-plex-sans-cyrillic-ext-500-normal-Cs5J6C77.woff2": {
		"type": "font/woff2",
		"etag": "\"3014-6ivhYrlQVJhVmQeA128rXLij9vY\"",
		"mtime": "2026-10-27T15:12:28.236Z",
		"size": 12308,
		"path": "../public/assets/ibm-plex-sans-cyrillic-ext-500-normal-Cs5J6C77.woff2"
	},
	"/assets/ibm-plex-sans-cyrillic-ext-600-normal-Bz0x94Yp.woff": {
		"type": "font/woff",
		"etag": "\"2978-WjWlLSfd2TKm6s0LhKPuhFdcAeE\"",
		"mtime": "2026-10-27T15:12:28.238Z",
		"size": 10616,
		"path": "../public/assets/ibm-plex-sans-cyrillic-ext-600-normal-Bz0x94Yp.woff"
	},
	"/assets/ibm-plex-sans-cyrillic-ext-500-normal-DB5PtV2g.woff": {
		"type": "font/woff",
		"etag": "\"2960-4+cTltdKCIjMA7KZc7LgGnCWDXs\"",
		"mtime": "2026-10-27T15:12:28.236Z",
		"size": 10592,
		"path": "../public/assets/ibm-plex-sans-cyrillic-ext-500-normal-DB5PtV2g.woff"
	},
	"/assets/ibm-plex-sans-cyrillic-ext-600-normal-DUMzJB7m.woff2": {
		"type": "font/woff2",
		"etag": "\"3010-jcQNCUORMBhEZgWw5+McVtlnv5g\"",
		"mtime": "2026-10-27T15:12:28.238Z",
		"size": 12304,
		"path": "../public/assets/ibm-plex-sans-cyrillic-ext-600-normal-DUMzJB7m.woff2"
	},
	"/assets/ibm-plex-sans-greek-400-italic-BEZwmy7D.woff2": {
		"type": "font/woff2",
		"etag": "\"2968-+/V7tWMMfn+9t6067BNgEbbecdg\"",
		"mtime": "2026-10-27T15:12:28.238Z",
		"size": 10600,
		"path": "../public/assets/ibm-plex-sans-greek-400-italic-BEZwmy7D.woff2"
	},
	"/assets/ibm-plex-sans-greek-400-italic-CTYLy0lX.woff": {
		"type": "font/woff",
		"etag": "\"2544-ygQJG9DJDIRxJLX1E+TJa3w019M\"",
		"mtime": "2026-10-27T15:12:28.238Z",
		"size": 9540,
		"path": "../public/assets/ibm-plex-sans-greek-400-italic-CTYLy0lX.woff"
	},
	"/assets/ibm-plex-sans-greek-400-normal-_efipK4i.woff2": {
		"type": "font/woff2",
		"etag": "\"26d4-RltTub4e1KkEOLmqVk1BaHH7hXE\"",
		"mtime": "2026-10-27T15:12:28.238Z",
		"size": 9940,
		"path": "../public/assets/ibm-plex-sans-greek-400-normal-_efipK4i.woff2"
	},
	"/assets/ibm-plex-sans-greek-400-normal-D9ESIMu3.woff": {
		"type": "font/woff",
		"etag": "\"2238-g7QxO9Ok4VHpiMxW/jAQA04gcYI\"",
		"mtime": "2026-10-27T15:12:28.238Z",
		"size": 8760,
		"path": "../public/assets/ibm-plex-sans-greek-400-normal-D9ESIMu3.woff"
	},
	"/assets/ibm-plex-sans-greek-500-normal-CuWXN6rf.woff": {
		"type": "font/woff",
		"etag": "\"23bc-SWFMQMHOWs2fm48wqKbMdc1Q1vA\"",
		"mtime": "2026-10-27T15:12:28.238Z",
		"size": 9148,
		"path": "../public/assets/ibm-plex-sans-greek-500-normal-CuWXN6rf.woff"
	},
	"/assets/ibm-plex-sans-greek-500-normal-JMMifIXV.woff2": {
		"type": "font/woff2",
		"etag": "\"2888-x+m8uo9dp1ZJqvdJwcV1OhezD3A\"",
		"mtime": "2026-10-27T15:12:28.238Z",
		"size": 10376,
		"path": "../public/assets/ibm-plex-sans-greek-500-normal-JMMifIXV.woff2"
	},
	"/assets/ibm-plex-sans-greek-600-normal-D-CqTdkO.woff": {
		"type": "font/woff",
		"etag": "\"2404-yCHUfqMwDEPjQFX+Xg2yFXrXgWE\"",
		"mtime": "2026-10-27T15:12:28.238Z",
		"size": 9220,
		"path": "../public/assets/ibm-plex-sans-greek-600-normal-D-CqTdkO.woff"
	},
	"/assets/ibm-plex-sans-greek-600-normal-DzTrcv_p.woff2": {
		"type": "font/woff2",
		"etag": "\"2880-gTDMfy+d+XRNntMgV2c+IMJvyic\"",
		"mtime": "2026-10-27T15:12:28.238Z",
		"size": 10368,
		"path": "../public/assets/ibm-plex-sans-greek-600-normal-DzTrcv_p.woff2"
	},
	"/assets/ibm-plex-sans-latin-400-italic-CsGl1sm0.woff": {
		"type": "font/woff",
		"etag": "\"5de4-kW/T4ns7I6267s4IxJ6zhaUvDcc\"",
		"mtime": "2026-10-27T15:12:28.238Z",
		"size": 24036,
		"path": "../public/assets/ibm-plex-sans-latin-400-italic-CsGl1sm0.woff"
	},
	"/assets/ibm-plex-sans-latin-400-normal-CDDApCn2.woff2": {
		"type": "font/woff2",
		"etag": "\"583c-JIKJdEuBOmpyScxB1Wj6xAuBzn8\"",
		"mtime": "2026-10-27T15:12:28.238Z",
		"size": 22588,
		"path": "../public/assets/ibm-plex-sans-latin-400-normal-CDDApCn2.woff2"
	},
	"/assets/ibm-plex-sans-latin-400-italic-CZTNEAuW.woff2": {
		"type": "font/woff2",
		"etag": "\"5f24-ek5DKhAxRvDt8RYGy0RMfMdE4vo\"",
		"mtime": "2026-10-27T15:12:28.238Z",
		"size": 24356,
		"path": "../public/assets/ibm-plex-sans-latin-400-italic-CZTNEAuW.woff2"
	},
	"/assets/ibm-plex-sans-latin-400-normal-CYLoc0-x.woff": {
		"type": "font/woff",
		"etag": "\"5658-7KxncOwX60mn/7d32puu2VRrcXc\"",
		"mtime": "2026-10-27T15:12:28.246Z",
		"size": 22104,
		"path": "../public/assets/ibm-plex-sans-latin-400-normal-CYLoc0-x.woff"
	},
	"/assets/ibm-plex-sans-latin-500-normal-BgVn5rGT.woff": {
		"type": "font/woff",
		"etag": "\"5d6c-6mSK/D3BOKVnM2TEjppmzbpb3bM\"",
		"mtime": "2026-10-27T15:12:28.246Z",
		"size": 23916,
		"path": "../public/assets/ibm-plex-sans-latin-500-normal-BgVn5rGT.woff"
	},
	"/assets/ibm-plex-sans-latin-500-normal-6ng42L7E.woff2": {
		"type": "font/woff2",
		"etag": "\"5e78-TULHhbZFMSdm0F//zuV4e+2ICl8\"",
		"mtime": "2026-10-27T15:12:28.246Z",
		"size": 24184,
		"path": "../public/assets/ibm-plex-sans-latin-500-normal-6ng42L7E.woff2"
	},
	"/assets/ibm-plex-sans-latin-600-normal-CuJfVYMP.woff2": {
		"type": "font/woff2",
		"etag": "\"5ebc-kNnCJpfajLJyKwke0lTtYXoO10o\"",
		"mtime": "2026-10-27T15:12:28.253Z",
		"size": 24252,
		"path": "../public/assets/ibm-plex-sans-latin-600-normal-CuJfVYMP.woff2"
	},
	"/assets/ibm-plex-sans-latin-ext-400-italic-Du9zzoL2.woff2": {
		"type": "font/woff2",
		"etag": "\"4270-2GBmncYuBzQKVDA1rQ/c6nL7BFg\"",
		"mtime": "2026-10-27T15:12:28.253Z",
		"size": 17008,
		"path": "../public/assets/ibm-plex-sans-latin-ext-400-italic-Du9zzoL2.woff2"
	},
	"/assets/ibm-plex-sans-latin-600-normal-Cu4Hd6ag.woff": {
		"type": "font/woff",
		"etag": "\"5d44-30y9G0JG6op8xi1hIy2o+g60IIQ\"",
		"mtime": "2026-10-27T15:12:28.253Z",
		"size": 23876,
		"path": "../public/assets/ibm-plex-sans-latin-600-normal-Cu4Hd6ag.woff"
	},
	"/assets/ibm-plex-sans-latin-ext-400-italic-V_9i1P_m.woff": {
		"type": "font/woff",
		"etag": "\"3c74-NfCMTPx2fRSDumb3QVPm3l2CpGg\"",
		"mtime": "2026-10-27T15:12:28.253Z",
		"size": 15476,
		"path": "../public/assets/ibm-plex-sans-latin-ext-400-italic-V_9i1P_m.woff"
	},
	"/assets/ibm-plex-sans-latin-ext-400-normal-C5H60-Va.woff2": {
		"type": "font/woff2",
		"etag": "\"3e6c-wj6Yd51oeo16SMeFqR5S1fRFjbU\"",
		"mtime": "2026-10-27T15:12:28.253Z",
		"size": 15980,
		"path": "../public/assets/ibm-plex-sans-latin-ext-400-normal-C5H60-Va.woff2"
	},
	"/assets/ibm-plex-sans-latin-ext-400-normal-RBey6euL.woff": {
		"type": "font/woff",
		"etag": "\"3818-PUohXneAvLWIcuS7SyJJPTWSRVA\"",
		"mtime": "2026-10-27T15:12:28.253Z",
		"size": 14360,
		"path": "../public/assets/ibm-plex-sans-latin-ext-400-normal-RBey6euL.woff"
	},
	"/assets/ibm-plex-sans-latin-ext-500-normal-D0aIdm-b.woff": {
		"type": "font/woff",
		"etag": "\"3990-bkK8QuMsH2oJhFmn0dVSmOwYK8g\"",
		"mtime": "2026-10-27T15:12:28.253Z",
		"size": 14736,
		"path": "../public/assets/ibm-plex-sans-latin-ext-500-normal-D0aIdm-b.woff"
	},
	"/assets/ibm-plex-sans-latin-ext-500-normal-DakdToA3.woff2": {
		"type": "font/woff2",
		"etag": "\"4048-zM2hKwVRcOOkBzAtF9gSRifb1Xo\"",
		"mtime": "2026-10-27T15:12:28.253Z",
		"size": 16456,
		"path": "../public/assets/ibm-plex-sans-latin-ext-500-normal-DakdToA3.woff2"
	},
	"/assets/ibm-plex-sans-latin-ext-600-normal-DIrixKbi.woff": {
		"type": "font/woff",
		"etag": "\"39b4-O15LDVIYlp7aWv/XWQRKcOV0vGE\"",
		"mtime": "2026-10-27T15:12:28.253Z",
		"size": 14772,
		"path": "../public/assets/ibm-plex-sans-latin-ext-600-normal-DIrixKbi.woff"
	},
	"/assets/ibm-plex-sans-latin-ext-600-normal-DOrvGEcy.woff2": {
		"type": "font/woff2",
		"etag": "\"4040-LoT1batWuCCwsLJXNPobgf+1rYc\"",
		"mtime": "2026-10-27T15:12:28.253Z",
		"size": 16448,
		"path": "../public/assets/ibm-plex-sans-latin-ext-600-normal-DOrvGEcy.woff2"
	},
	"/assets/ibm-plex-sans-vietnamese-400-italic-78jqtfZH.woff": {
		"type": "font/woff",
		"etag": "\"1b4c-cJng4VThQfg4Dd6Qw0BBkkBbvik\"",
		"mtime": "2026-10-27T15:12:28.253Z",
		"size": 6988,
		"path": "../public/assets/ibm-plex-sans-vietnamese-400-italic-78jqtfZH.woff"
	},
	"/assets/ibm-plex-sans-vietnamese-400-italic-BbRnwouv.woff2": {
		"type": "font/woff2",
		"etag": "\"21f4-RelXNcBTPc5ZYdWNexcJNmAo66I\"",
		"mtime": "2026-10-27T15:12:28.253Z",
		"size": 8692,
		"path": "../public/assets/ibm-plex-sans-vietnamese-400-italic-BbRnwouv.woff2"
	},
	"/assets/ibm-plex-sans-vietnamese-400-normal-DG4YqDda.woff2": {
		"type": "font/woff2",
		"etag": "\"200c-ihteSoB/1gbKKbq0mkKT/6QRn4Y\"",
		"mtime": "2026-10-27T15:12:28.253Z",
		"size": 8204,
		"path": "../public/assets/ibm-plex-sans-vietnamese-400-normal-DG4YqDda.woff2"
	},
	"/assets/ibm-plex-sans-vietnamese-400-normal-fK1oJ5dG.woff": {
		"type": "font/woff",
		"etag": "\"18f8-0t4vvELEi/HvBYPqJmXzI0JsY9M\"",
		"mtime": "2026-10-27T15:12:28.253Z",
		"size": 6392,
		"path": "../public/assets/ibm-plex-sans-vietnamese-400-normal-fK1oJ5dG.woff"
	},
	"/assets/ibm-plex-sans-vietnamese-500-normal-e4dixQRQ.woff2": {
		"type": "font/woff2",
		"etag": "\"20e0-DULDUfRuBOp2x/SWSchYRnqK25w\"",
		"mtime": "2026-10-27T15:12:28.253Z",
		"size": 8416,
		"path": "../public/assets/ibm-plex-sans-vietnamese-500-normal-e4dixQRQ.woff2"
	},
	"/assets/ibm-plex-sans-vietnamese-500-normal-BEb3_waV.woff": {
		"type": "font/woff",
		"etag": "\"19bc-YnGSUO25duSgfRI8x83a7wnd+LY\"",
		"mtime": "2026-10-27T15:12:28.253Z",
		"size": 6588,
		"path": "../public/assets/ibm-plex-sans-vietnamese-500-normal-BEb3_waV.woff"
	},
	"/assets/input-EcM2CW5S.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"297-WlrAu1MbBpciE5ScIO0r/2jyCGY\"",
		"mtime": "2026-10-27T15:12:28.188Z",
		"size": 663,
		"path": "../public/assets/input-EcM2CW5S.js"
	},
	"/assets/pencil-CYIs44Ah.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"106-xmMOtuIIaZic97sGLzjuiuSzwq8\"",
		"mtime": "2026-10-27T15:12:28.190Z",
		"size": 262,
		"path": "../public/assets/pencil-CYIs44Ah.js"
	},
	"/assets/local-client-ytHvigO2.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"36b-Vz/cdhmgi4b8SnjKZRAlp1FrhRw\"",
		"mtime": "2026-10-27T15:12:28.188Z",
		"size": 875,
		"path": "../public/assets/local-client-ytHvigO2.js"
	},
	"/assets/projector-DeLzr4Zv.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5f2f-GB3fivmQXukRf8Y3EURuEqU39YY\"",
		"mtime": "2026-10-27T15:12:28.190Z",
		"size": 24367,
		"path": "../public/assets/projector-DeLzr4Zv.js"
	},
	"/assets/rolldown-runtime-hePW80VL.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2cc-fA8td6k29UVF6JoPfhOPkceTK1M\"",
		"mtime": "2026-10-27T15:12:28.190Z",
		"size": 716,
		"path": "../public/assets/rolldown-runtime-hePW80VL.js"
	},
	"/assets/index-BfY2OdIN.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"2fcb-hd0s5QrD6crKnJEdCErQ8i5IP3M\"",
		"mtime": "2026-10-27T15:12:28.264Z",
		"size": 12235,
		"path": "../public/assets/index-BfY2OdIN.css"
	},
	"/assets/ibm-plex-sans-vietnamese-600-normal-DgdngZtN.woff": {
		"type": "font/woff",
		"etag": "\"19b8-Eyzfs92Ow4wNtMPbmcdT83Aw7Lk\"",
		"mtime": "2026-10-27T15:12:28.253Z",
		"size": 6584,
		"path": "../public/assets/ibm-plex-sans-vietnamese-600-normal-DgdngZtN.woff"
	},
	"/assets/session-NufNktji.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"74c-F3BPWg0wNbDY3fAZn/ODQKhFY2Q\"",
		"mtime": "2026-10-27T15:12:28.190Z",
		"size": 1868,
		"path": "../public/assets/session-NufNktji.js"
	},
	"/assets/ibm-plex-sans-vietnamese-600-normal-DpPYBSTl.woff2": {
		"type": "font/woff2",
		"etag": "\"210c-PXlu61VbmVY4EJRIXnPFJRBwkRE\"",
		"mtime": "2026-10-27T15:12:28.253Z",
		"size": 8460,
		"path": "../public/assets/ibm-plex-sans-vietnamese-600-normal-DpPYBSTl.woff2"
	},
	"/assets/settings-cPBcLXij.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"19087-6gwxgWCDT0XrGTRu0xeaJAsmQ+I\"",
		"mtime": "2026-10-27T15:12:28.190Z",
		"size": 102535,
		"path": "../public/assets/settings-cPBcLXij.js"
	},
	"/assets/routes-DZf7rPy0.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5d1a1-mE0W/ZSs5S0NWZm9uoSy1j2gU4Q\"",
		"mtime": "2026-10-27T15:12:28.190Z",
		"size": 381345,
		"path": "../public/assets/routes-DZf7rPy0.js"
	},
	"/assets/systems-lab-WSP1ZaV3.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7688-p4s1+r1JORG2gP5LJsXAa0GO++w\"",
		"mtime": "2026-10-27T15:12:28.190Z",
		"size": 30344,
		"path": "../public/assets/systems-lab-WSP1ZaV3.js"
	},
	"/assets/toggle-KbNHucLR.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5e6-zEb3JldvbBFKpmL/rBof44xsgbY\"",
		"mtime": "2026-10-27T15:12:28.196Z",
		"size": 1510,
		"path": "../public/assets/toggle-KbNHucLR.js"
	},
	"/assets/trash-2-BQVQRuVg.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"158-xBxrPKgicykptrYIyrypYRH7JGU\"",
		"mtime": "2026-10-27T15:12:28.196Z",
		"size": 344,
		"path": "../public/assets/trash-2-BQVQRuVg.js"
	},
	"/assets/styles-DM4B1Pdl.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"16146-Hjx8ZBmGR/8UYvb0kD0zmiXqKDs\"",
		"mtime": "2026-10-27T15:12:28.266Z",
		"size": 90438,
		"path": "../public/assets/styles-DM4B1Pdl.css"
	},
	"/assets/use-hold-drag-CMhBl_Xj.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"923-F923ZCAOKBUSXjgK4VwpGFyca/c\"",
		"mtime": "2026-10-27T15:12:28.198Z",
		"size": 2339,
		"path": "../public/assets/use-hold-drag-CMhBl_Xj.js"
	},
	"/assets/voice-studio-C3LoWz7i.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4e-/JFYGzQOMhW0myG55X34HzlXQo4\"",
		"mtime": "2026-10-27T15:12:28.206Z",
		"size": 78,
		"path": "../public/assets/voice-studio-C3LoWz7i.js"
	},
	"/assets/voice-studio-CKezSz-K.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"80a2-LwmnSxL0UdK0CfPsS3qf9wcH2+M\"",
		"mtime": "2026-10-27T15:12:28.207Z",
		"size": 32930,
		"path": "../public/assets/voice-studio-CKezSz-K.js"
	},
	"/assets/__vite-browser-external-2W3EstLn.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"67-SVoBi+jCWjE3Mb8msJAJLl1TehE\"",
		"mtime": "2026-10-27T15:12:28.178Z",
		"size": 103,
		"path": "../public/assets/__vite-browser-external-2W3EstLn.js"
	},
	"/assets/index-BEV_6Cxw.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"d8718-hbqX/SFrzZ9bFxwknf3Icus/C90\"",
		"mtime": "2026-10-27T15:12:28.178Z",
		"size": 886552,
		"path": "../public/assets/index-BEV_6Cxw.js"
	}
};
//#endregion
//#region #nitro/virtual/public-assets-node
function readAsset(id) {
	const serverDir = dirname(fileURLToPath(globalThis.__nitro_main__));
	return promises.readFile(resolve(serverDir, public_assets_data_default[id].path));
}
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
function getAsset(id) {
	return public_assets_data_default[id];
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/static.mjs
var METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
var EncodingMap = {
	gzip: ".gz",
	br: ".br",
	zstd: ".zst"
};
var static_default = defineHandler((event) => {
	if (event.req.method && !METHODS.has(event.req.method)) return;
	let id = decodePath(withLeadingSlash(withoutTrailingSlash(event.url.pathname)));
	let asset;
	const encodings = [...(event.req.headers.get("accept-encoding") || "").split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(), ""];
	for (const encoding of encodings) for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
		const _asset = getAsset(_id);
		if (_asset) {
			asset = _asset;
			id = _id;
			break;
		}
	}
	if (!asset) {
		if (isPublicAssetURL(id)) {
			event.res.headers.delete("Cache-Control");
			throw new HTTPError({ status: 404 });
		}
		return;
	}
	if (encodings.length > 1) event.res.headers.append("Vary", "Accept-Encoding");
	if (event.req.headers.get("if-none-match") === asset.etag) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	const ifModifiedSinceH = event.req.headers.get("if-modified-since");
	const mtimeDate = new Date(asset.mtime);
	if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	if (asset.type) event.res.headers.set("Content-Type", asset.type);
	if (asset.etag && !event.res.headers.has("ETag")) event.res.headers.set("ETag", asset.etag);
	if (asset.mtime && !event.res.headers.has("Last-Modified")) event.res.headers.set("Last-Modified", mtimeDate.toUTCString());
	if (asset.encoding && !event.res.headers.has("Content-Encoding")) event.res.headers.set("Content-Encoding", asset.encoding);
	if (asset.size > 0 && !event.res.headers.has("Content-Length")) event.res.headers.set("Content-Length", asset.size.toString());
	return readAsset(id);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_Gz4QY2 = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_Gz4QY2
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
var globalMiddleware = [toEventHandler(static_default)].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new NodeResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~middleware"].push(...globalMiddleware);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		middleware.push(...h3App["~middleware"]);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/hooks.mjs
function _captureError(error, type) {
	console.error(`[${type}]`, error);
	useNitroApp().captureError?.(error, { tags: [type] });
}
function trapUnhandledErrors() {
	process.on("unhandledRejection", (error) => _captureError(error, "unhandledRejection"));
	process.on("uncaughtException", (error) => _captureError(error, "uncaughtException"));
}
//#endregion
//#region #nitro/virtual/tracing
var tracingSrvxPlugins = [];
//#endregion
//#region node_modules/nitro/dist/presets/node/runtime/node-server.mjs
var _parsedPort = Number.parseInt(process.env.NITRO_PORT ?? process.env.PORT ?? "");
var port = Number.isNaN(_parsedPort) ? 3e3 : _parsedPort;
var host = process.env.NITRO_HOST || process.env.HOST;
var cert = process.env.NITRO_SSL_CERT;
var key = process.env.NITRO_SSL_KEY;
var nitroApp = useNitroApp();
serve({
	port,
	hostname: host,
	tls: cert && key ? {
		cert,
		key
	} : void 0,
	fetch: nitroApp.fetch,
	plugins: [...tracingSrvxPlugins]
});
trapUnhandledErrors();
var node_server_default = {};
//#endregion
export { node_server_default as default };
