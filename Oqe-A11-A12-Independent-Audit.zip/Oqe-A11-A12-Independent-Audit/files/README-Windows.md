# Oqe on Windows — quick guide

Oqe is a local-first assistant that runs on your PC: a website (the UI), a
same-origin server proxy, an optional Windows companion for gated desktop
control, and optional local speech. Nothing is required in the cloud.

## 1. Web app (chat)

```cmd
START-OQE.cmd
```

That checks Ollama, installs dependencies if needed, starts the dev server on
`http://127.0.0.1:8080`, and opens your browser. `LAUNCH-OQE.cmd` delegates
to it. After setup (or an update), use the current V11.1 audit
`AUDIT-V11.1.md` and run the hardware/browser procedures in
`QA-ON-DEVICE.md`; inherited historical results are not V11.1 verification.
npm is the primary package manager (`npm install`, `npm test`,
`npm run typecheck`, `npm run build`). The repo is npm-only: `package-lock.json`
is the single lockfile the launchers and CI use (`bun.lock` was removed in
V8.3 — one resolver, no drift).

Chat model: pick one in Settings → Model. One model runs per request; images
need a vision-capable selection (see the Vision preset).

## 2. Windows companion (computer control)

The browser-only chat cannot click or type on the Windows desktop by itself.
Desktop input is available only when the app-owned Windows companion is
started locally: Settings → Access → **Start the app-owned companion** →
**Enable desktop automation** separately → confirm the target app → run, while
STOP is clear.
Pairing starts the bundled helper and keeps its session token in app-server
memory; the browser retains only a non-secret paired marker. The helper is
stopped explicitly by Unpair or by its idle timeout. Esc or Ctrl+Alt+K latches
STOP and revokes all target consent; clearing STOP leaves automation off, and
each target must be confirmed again. Consent expires (default 60 minutes), and
can be revoked per target or all at once. This is explicit Windows control, not
cloud-powered or unattended automation; Android has no Windows companion.

Environment variables (all optional):

- `OQE_COMPANION_PORT` — loopback companion port (default `8000`); the app and helper must use the same value.
- `OQE_COMPANION_PAIRING_CODE` — for manual companion launches only; the app-owned lifecycle generates its one-shot pairing code itself.
- `OQE_MANAGE_MODEL_MEMORY` — opt-in model memory management (default off)
- `OQE_COMPANION_ALLOW_MODEL_UNLOAD` — second gate for companion unloads
  (default off; also needs a disposable-model list)
- `OQE_EXECUTION_AUDIT` — `1` records one JSONL line per gated physical
  action (UTC timestamp, endpoint, action type, target, ok/error) to
  `%LOCALAPPDATA%\Oqe\execution-audit.jsonl`. Default OFF; contents are
  redacted and never include goal text, typed content, tokens, or pairing
  codes. Override the path with `OQE_EXECUTION_AUDIT_FILE`.

The companion's token file lives at `%LOCALAPPDATA%\Oqe\companion-token` and is written user-only (`icacls` inheritance removed). It applies to manual and app-owned launches alike: the helper creates it once and re-loads it on every start. The V11 app server keeps only its own copy in memory, never writes it, and never sends it to the browser — on restart it pairs again with a fresh one-shot code and receives the same persisted token. Unpair stops the helper and clears the app session; deleting the token file is what actually revokes it. See `companion/README.md` § Pairing persistence.

### Local schedules and webhook automations

Settings → Automations creates prompt jobs; this is separate from desktop
control and grants no extra computer access. **Every** is scheduled by the local
Oqe server, not Windows Task Scheduler: the server keeps the job, claims each
occurrence once and records every run in the local database. The prompt runs
through the app, so Oqe must be open and the selected Ollama connection/model
must be available for a prompt to complete; occurrences missed while Oqe was
not running are recorded as missed, never replayed in a burst. These jobs do not grant desktop access; if a prompt asks for desktop control, the optional companion must be paired and enabled, the target must have current consent, and STOP must not be latched.

**When** creates a webhook URL; Oqe does not poll the named page. A page,
service or script must POST to it. The local server can keep accepted events
on disk while the browser is away, but execution waits for an Oqe tab to come
back online, the job to remain enabled, and the app/model path to accept it. If its prompt requests a desktop action, the optional companion must be paired and enabled, the target must have current consent, and STOP must not be latched.
Stopping the local server prevents new webhook events from being accepted.
Webhook URLs contain a secret token; keep them private. No timer or webhook
continues as an OS service after required Oqe components stop.

## 3. Prompts (chat only)

Settings → Chat prompts has **System prompt** and **Personality prompt**.
Every request is composed in this exact order: System prompt → Personality
prompt → conversation. Empty or whitespace-only fields are omitted, and
"Reset to default" clears both to empty (Oqe ships no built-in prompt
text). Prompts cannot weaken companion safety.

## 4. Local TTS (Kokoro + Qwen3-TTS)

Settings → Voice (local engine), off by default. Kokoro speaks everyday
replies on CPU; a named voice folder (`voices\<Name>\ref.wav` + `ref.txt`,
e.g. Clayton) uses the Qwen3-TTS clone model. Speak/Stop appear on assistant
messages only when enabled; status lines come only from the real engine
process. The device-only verification procedure is in `QA-ON-DEVICE.md`.

## 5. Skills (local playbooks)

Settings → Skills lists the one shipped built-in skill:

- `/create-skill` (on by default) — guided authoring; type `/create-skill`
  in chat and the local model helps draft a playbook. Save the result under
  Settings → Skills → Add skill. This creates a user-defined skill; it does
  not add another built-in.

`/council` and `/plan` are not built-in triggers. Typing either is ordinary
chat text unless you separately create a custom skill with that trigger.
Multi-agent runs are a separate feature, configured in Settings → Multi-agent
(or armed for one send from the composer); they are not started by `/council`.

User-created skills are stored separately in this browser and appear under
Settings → Skills after you save them. Type a skill's trigger at the start of
a message to shape that one reply using your selected local model through the
normal chat path. Skills never call an online AI service and cannot authorize
desktop control or bypass companion consent. A disabled or unknown trigger is
ordinary text.

## 6. Installer candidate (no Node or Python needed)

`Oqe-Setup-V<version>-candidate.exe` is a per-user installer built by
`scripts/build-installer.mjs`. It is a **candidate**: not code-signed, not the
release archive, and not yet promoted.

What it installs, for the current Windows account only — no administrator
rights, nothing under `Program Files`:

| Part | Location |
| --- | --- |
| Program files for the version | `%LOCALAPPDATA%\Programs\Oqe\<version>` |
| Bundled Node runtime (`node\node.exe`) | inside that folder |
| App build (`app\server\index.mjs`) | inside that folder |
| Frozen companion (`companion\OqeCompanion`) | inside that folder, its own CPython inside |
| **Your data** — database, conversations, queue, journal, voice profiles, saved artifacts, logs | `%LOCALAPPDATA%\Oqe` |
| Start-menu entries | `Oqe` and `Oqe (stop)` |
| Uninstall entry | `HKCU\Software\Microsoft\Windows\CurrentVersion\Uninstall\Oqe` |

The package bundles Python: the companion ships as a PyInstaller onedir build,
so no system Python, virtualenv or `pip install` step is involved. TypeScript and
Vite dependencies are compiled into the app build; `npm` is never needed on the
installed machine.

Start Oqe from the Start-menu shortcut. The packaged `app\server\index.mjs`
loads `Oqe-preflight.mjs` before any server code, so it refuses a non-loopback
bind even if run directly; do not point a service manager or another launcher at
that file.

### Install, upgrade, repair, uninstall

- **Install / upgrade** — run the candidate. The same script installs and
  upgrades; the version folder is new, so an older version can stay next to it.
  The uninstall entry always points at the newest installed version.
- **Repair** — `install.ps1 -Repair` from the installed folder, or re-run the
  candidate.
- **Uninstall** — Settings → Apps → Oqe, or `install.ps1 -Uninstall`. This
  removes program files, shortcuts and the uninstall entry and **keeps
  `%LOCALAPPDATA%\Oqe`**.
- **Deleting data intentionally** — `install.ps1 -Uninstall -DeleteData`, or
  delete `%LOCALAPPDATA%\Oqe` yourself. Nothing else removes it, and the
  uninstaller prints the path it kept.

### What is not bundled

- **Ollama and model weights.** Local inference needs Ollama installed with a
  model pulled. Oqe still starts without it and shows its local-model-
  unavailable state; there is no paid cloud fallback.
- **Voice models.** Optional, downloaded separately under
  `%USERPROFILE%\Oqe-TTS` (see Settings → Voice).
- **A code signature.** Windows shows its unknown-publisher prompt.

The launcher runs the bundled runtime without a console window and writes
`%LOCALAPPDATA%\Oqe\oqe-server.log` and `oqe-server.err.log`; if startup fails it
opens `startup-error.txt` instead of pretending Oqe is running.

## 7. Requirements

### Running from this folder (development)

- Windows 10/11 with Ollama installed and a model pulled
- Node.js (npm) for the web app
- Optional TTS stack under `%USERPROFILE%\Oqe-TTS` (see Settings → Voice)
- Python 3.12 only if you rebuild the frozen companion

### Running the installer candidate

- Windows 10/11 (64-bit)
- Ollama with a model pulled, for local chat — not bundled
- No Node, no Python, no `npm install`

The candidate has **not** yet been verified on a clean Windows machine or
account without Python; see the report and `QA-ON-DEVICE.md` for the exact steps
that must pass before it is called self-contained.
