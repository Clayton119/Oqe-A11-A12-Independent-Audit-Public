import type { Plugin } from "vite";
import { defineConfig } from "vite";
import { tanstackStart } from "@tanstack/react-start/plugin/vite";
import viteReact from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import { nitro } from "nitro/vite";
import { assertLoopbackBind } from "./scripts/loopback-bind.mjs";

/**
 * Disable Node HTTP server idle/request timeouts for long Ollama streams.
 *
 * Node 18+ defaults `requestTimeout` to 300_000 ms. Combined with undici's
 * 300s bodyTimeout that previously sat on the Ollama hop, healthy local
 * thinking replies were cut around 5–10 minutes. Incoming sockets for
 * /api/ollama chat/generate must never idle-out; only the browser Stop
 * button (AbortSignal) should abort them.
 */
function longLivedStreamPlugin(): Plugin {
  const disarm = (httpServer: import("node:http").Server | null | undefined) => {
    if (!httpServer) return;
    httpServer.timeout = 0;
    httpServer.headersTimeout = 0;
    httpServer.requestTimeout = 0;
    httpServer.keepAliveTimeout = 0;
  };
  const middleware = (
    req: import("node:http").IncomingMessage,
    res: import("node:http").ServerResponse,
    next: () => void,
  ) => {
    const url = req.url ?? "";
    if (
      url.includes("/api/ollama/api/chat") ||
      url.includes("/api/ollama/api/generate") ||
      url.includes("/api/ollama/v1/chat") ||
      url.includes("/api/ollama/v1/completions") ||
      url.includes("/api/ollama/v1/responses")
    ) {
      req.setTimeout(0);
      res.setTimeout(0);
      req.socket?.setTimeout(0);
      req.socket?.setKeepAlive(true, 30_000);
    }
    next();
  };
  return {
    name: "oqe:long-lived-streams",
    configureServer(server) {
      disarm(server.httpServer);
      server.httpServer?.once("listening", () => disarm(server.httpServer));
      server.middlewares.use(middleware);
    },
    configurePreviewServer(server) {
      disarm(server.httpServer);
      server.httpServer?.once("listening", () => disarm(server.httpServer));
      server.middlewares.use(middleware);
    },
  };
}

// Prompt 58 (A) — Oqe is local-first and has no accounts, so the listening
// address is the only network boundary. The default stays 127.0.0.1 and a
// non-loopback value is refused below, including a `--host` CLI override;
// LAN access is not supported while there is no authentication.
//
// `configResolved` is a PLUGIN hook: as a plain config key Vite silently
// ignores it, which is exactly how a `--host 0.0.0.0` dev server started. It
// runs after the CLI and env are merged and before a listener exists, so this
// refuses the bind rather than merely warning about it.
function loopbackBindPlugin(): Plugin {
  return {
    name: "oqe:loopback-bind",
    enforce: "pre",
    configResolved(config) {
      assertLoopbackBind(config.server.host, "The Oqe dev server", { allowUnset: true });
      assertLoopbackBind(config.preview.host, "The Oqe preview server", { allowUnset: true });
    },
  };
}

export default defineConfig(({ command, isPreview }) => ({
  server: {
    host: process.env.OQE_DEV_HOST || "127.0.0.1",
    port: 8080,
    strictPort: true,
  },
  preview: {
    host: process.env.OQE_DEV_HOST || "127.0.0.1",
    port: 8081,
    strictPort: true,
  },
  resolve: { tsconfigPaths: true },
  plugins: [
    // First, so a refused host stops the server before anything else initialises.
    loopbackBindPlugin(),
    longLivedStreamPlugin(),
    tailwindcss(),
    tanstackStart(),
    ...(command === "build" || isPreview
      ? [
          // Prompt 50: the installed app is served by a bundled Node runtime, so the
          // packaging build asks nitro for its node-server output. Default stays
          // `vercel`; nothing changes unless the installer build sets the variable.
          nitro({ preset: process.env.OQE_NITRO_PRESET === "node-server" ? "node-server" : "vercel" }),
        ]
      : []),
    viteReact(),
  ],
}));
