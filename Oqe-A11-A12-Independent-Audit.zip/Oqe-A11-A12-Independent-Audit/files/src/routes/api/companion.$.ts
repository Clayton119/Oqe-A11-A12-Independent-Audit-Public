import { createFileRoute } from "@tanstack/react-router";
import { companionPeerRejected, localRequestRejected } from "@/lib/local-request-security.server";
import { readBoundedBody } from "@/lib/request-body-limit.server";
import { bridgeToken } from "@/lib/companion/bridge-token";
import {
  companionDisable,
  companionEnable,
  companionStart,
  companionStatus,
  companionStop,
  companionOrigin,
  companionToken,
  companionTouch,
  type CompanionPower,
} from "@/lib/companion/supervisor.server";

const ALLOWED = new Set([
  "/health",
  "/pair",
  "/enable",
  "/disable",
  "/stop",
  "/clear-stop",
  "/screenshot",
  "/execute",
  "/run-loop",
  "/consent-target",
  "/revoke-target",
  "/clear-targets",
]);

/** App-owned lifecycle actions. The app starts, arms, disarms and stops its own bundled companion. */
const POWER: Record<string, { method: "GET" | "POST"; run: () => Promise<CompanionPower> }> = {
  "/start": { method: "POST", run: companionStart },
  "/stop": { method: "POST", run: companionStop },
  "/enable": { method: "POST", run: companionEnable },
  "/disable": { method: "POST", run: companionDisable },
  "/status": { method: "GET", run: companionStatus },
};

function token(request: Request) {
  return request.headers.get("x-oqe-companion-token") ?? "";
}

/**
 * Strict browser check for the app's own pages. A request with no Origin and no
 * Referer is NOT trusted here, even though the general local guard allows it for
 * direct tools: the app's session token and desktop-control power actions must
 * never be reachable by an arbitrary local process.
 */
function fromThisApp(request: Request): boolean {
  const expected = new URL(request.url).origin;
  const origin = request.headers.get("origin");
  if (origin) return origin === expected;
  const referer = request.headers.get("referer");
  if (!referer) return false;
  try {
    return new URL(referer).origin === expected;
  } catch {
    return false;
  }
}

async function powerRoute(request: Request, action: string): Promise<Response> {
  const entry = POWER[action];
  if (!entry) return Response.json({ error: "Companion power action is not allowed." }, { status: 404 });
  if (request.method !== entry.method) return Response.json({ error: "Method not allowed." }, { status: 405 });
  // Read-only status may be polled by any local caller; every state change needs the app's own page.
  if (entry.method === "POST" && !fromThisApp(request)) {
    return Response.json({ error: "Companion power actions are only available from the app." }, { status: 403 });
  }
  try {
    const state = await entry.run();
    return Response.json({ ok: true, ...state }, { headers: { "cache-control": "no-store" } });
  } catch (error) {
    return Response.json(
      { error: error instanceof Error ? error.message : String(error) },
      { status: 409, headers: { "cache-control": "no-store" } },
    );
  }
}

async function proxyCompanion({ request }: { request: Request }) {
  // Prompt 58 (C) — the TCP peer, before anything is forwarded. If a dev handler
  // ever omits the address, `allowUnknown` defers to the bind refusal (Prompt 58 A)
  // instead of treating "unknown" as this machine.
  const peer = companionPeerRejected(request, { allowUnknown: !import.meta.env.PROD });
  if (peer) return peer;
  const rejected = localRequestRejected(request);
  if (rejected) return rejected;
  const incoming = new URL(request.url);
  const path = incoming.pathname.slice("/api/companion".length).replace(/\/+$/, "") || "/";
  if (path.startsWith("/power/")) return powerRoute(request, path.slice("/power".length));
  if (!ALLOWED.has(path)) return Response.json({ error: "Companion route is not allowed." }, { status: 404 });
  // This route is a same-origin, loopback-only bridge to the companion this
  // app started. It never accepts a user-supplied upstream URL.
  companionTouch();
  const headers = new Headers({ accept: request.headers.get("accept") ?? "application/json" });
  // The app's own session token is injected server-side, so the browser never
  // holds it. This runs only after `companionPeerRejected` proved the TCP peer
  // is this machine, so a network client cannot reach the injection branch.
  const supplied = bridgeToken({
    requestToken: token(request),
    fromApp: fromThisApp(request),
    serverToken: companionToken(),
  });
  if (supplied) headers.set("x-oqe-companion-token", supplied);
  const contentType = request.headers.get("content-type");
  if (contentType) headers.set("content-type", contentType);
  const init: RequestInit = { method: request.method, headers, redirect: "error", signal: request.signal };
  if (!["GET", "HEAD"].includes(request.method)) {
    // V9.5 — read with the cap applied DURING the read, so the bridge has a real memory bound.
    const body = await readBoundedBody(request);
    if (!body.ok) return Response.json({ error: body.error }, { status: body.status });
    init.body = body.bytes;
  }
  try {
    const response = await fetch(`${companionOrigin()}${path}${incoming.search}`, init);
    return new Response(response.body, { status: response.status, headers: response.headers });
  } catch (error) {
    return Response.json(
      { error: `Local companion is unavailable: ${error instanceof Error ? error.message : String(error)}` },
      { status: 502 },
    );
  }
}

export const Route = createFileRoute("/api/companion/$")({
  server: { handlers: { GET: proxyCompanion, POST: proxyCompanion } },
});
