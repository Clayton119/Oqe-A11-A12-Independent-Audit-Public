import { createFileRoute } from "@tanstack/react-router";

import { readBoundedBody } from "../../lib/request-body-limit.server.ts";
import { loopbackPeerRejected } from "../../lib/local-request-security.server.ts";
import {
  ensureServerTasksRecovered,
  isValidServerTaskId,
  MAX_SERVER_TASK_TITLE_CHARS,
  serverTaskRequestRejected,
  serverTaskRunner,
  validateServerTaskWork,
} from "../../lib/server-task-runner.server.ts";

/**
 * Prompt 27 — where a long task begins.
 *
 * The browser's entire role is in this one call: post a plan, get a task id
 * back, then poll. Nothing keeps running in the tab, so closing it, refreshing
 * it or losing the network cannot stop the work — and none of those events
 * reach this route as a cancellation, because cancellation is only ever the
 * explicit `/api/tasks/cancel/:taskId` request.
 *
 * `taskId` is the caller's idempotency key. Sending the same id twice — after a
 * lost response, a double click, or a retried request — returns the row that
 * already exists (`status: "duplicate"`) instead of queueing the work twice.
 *
 * The gate is the TCP peer (`loopbackPeerRejected`, Prompt 60) followed by
 * `serverTaskRequestRejected` (host, same origin, local header), and the body is
 * read with a hard cap, so an oversized plan is refused while it is being read
 * rather than after it is in memory. The peer check is what makes the other
 * three trustworthy: `Host`, `Origin` and `x-oqe-tasks` are all client-written.
 */

/** Above any acceptable plan (effects are capped at 200k chars) and still a hard bound. */
export const MAX_TASK_START_BODY_BYTES = 1024 * 1024;

function badRequest(reason: string): Response {
  return Response.json({ error: reason }, { status: 400 });
}

export async function handleTaskStart(
  request: Request,
  options: { trusted?: boolean } = {},
): Promise<Response> {
  const rejected = serverTaskRequestRejected(request, { needsHeader: true });
  if (rejected) return rejected;

  const contentType = request.headers.get("content-type") ?? "";
  if (!contentType.toLowerCase().includes("application/json")) {
    return Response.json({ error: "The task runner accepts JSON only." }, { status: 415 });
  }

  const body = await readBoundedBody(request, MAX_TASK_START_BODY_BYTES);
  if (!body.ok) return Response.json({ error: body.error }, { status: body.status });

  let parsed: unknown;
  try {
    parsed = JSON.parse(new TextDecoder().decode(body.bytes));
  } catch {
    return badRequest("The request body is not valid JSON.");
  }
  if (typeof parsed !== "object" || parsed === null || Array.isArray(parsed)) {
    return badRequest("The request body must be an object.");
  }
  const payload = parsed as Record<string, unknown>;

  const title = typeof payload.title === "string" ? payload.title : "";
  if (title.trim().length > MAX_SERVER_TASK_TITLE_CHARS) {
    return badRequest(`title may be at most ${MAX_SERVER_TASK_TITLE_CHARS} characters.`);
  }

  const work = validateServerTaskWork(payload.items);
  if (!work.ok) return badRequest(work.reason);

  const requestedId = payload.taskId;
  if (requestedId !== undefined && requestedId !== null && !isValidServerTaskId(requestedId)) {
    return badRequest("that task id is not one this build accepts.");
  }

  try {
    // One recovery per process, before a row can be created: a task left
    // running by the previous boot is reconciled first, so this start cannot
    // walk into a stale claim.
    await ensureServerTasksRecovered();
  } catch (error) {
    return Response.json(
      {
        error: `The task store could not be recovered: ${
          error instanceof Error ? error.message : String(error)
        }`,
      },
      { status: 503, headers: { "cache-control": "no-store" } },
    );
  }

  const result = await serverTaskRunner().start({
    title,
    items: work.items,
    // Prompt 60 — true only when the route proved the TCP peer is this machine.
    // Anything else (including a direct server-internal call that forgot it)
    // cannot dispatch a desktop action.
    trusted: options.trusted === true,
    ...(typeof requestedId === "string" ? { taskId: requestedId } : {}),
  });
  if (!result.ok) return badRequest(result.error);
  return Response.json(
    { ok: true, status: result.status, task: result.task },
    { headers: { "cache-control": "no-store" } },
  );
}

export const Route = createFileRoute("/api/tasks/start")({
  server: {
    handlers: {
      POST: ({ request }) => {
        // Prompt 60 (F-1) — the actual request boundary. A network client cannot
        // pass this with a spoofed Host/Origin/header, because neither is read.
        const peer = loopbackPeerRejected(request);
        if (peer) return peer;
        return handleTaskStart(request, { trusted: true });
      },
    },
  },
});
