import { createFileRoute } from "@tanstack/react-router";

import { readBoundedBody } from "../../lib/request-body-limit.server.ts";
import { loopbackPeerRejected } from "../../lib/local-request-security.server.ts";
import {
  ensureServerTasksRecovered,
  isValidServerTaskId,
  serverTaskRequestRejected,
  serverTaskRunner,
  type ServerTaskResumeDecision,
} from "../../lib/server-task-runner.server.ts";

export const MAX_TASK_RESUME_BODY_BYTES = 8 * 1024;

const DECISIONS = new Set<ServerTaskResumeDecision>(["verify", "skip", "retry-authorized"]);

/**
 * Prompt 27 — resuming and reconciling a task.
 *
 * A resume is the ONLY way an unknown outcome moves: with no decision, every
 * item whose in-flight effect did not settle stays `needs_reconciliation` and
 * the task is parked again (`needs_attention`) with the reason. A decision says
 * what the person actually observed:
 *
 *   "verify"          — they checked, and it happened;
 *   "skip"            — abandon the item (journaled as reconciled/skipped);
 *   "retry-authorized"— repeat it, which the journal only permits for an
 *                       at-most-once operation when the user authorized it.
 *
 * Nothing here replays a non-idempotent desktop action on its own. The pump
 * that runs afterwards picks up only items the engine now calls claimable.
 */

function badRequest(reason: string): Response {
  return Response.json({ error: reason }, { status: 400 });
}

export async function handleTaskResume(
  request: Request,
  taskId: string,
  options: { trusted?: boolean } = {},
): Promise<Response> {
  const rejected = serverTaskRequestRejected(request, { needsHeader: true });
  if (rejected) return rejected;
  if (!isValidServerTaskId(taskId)) {
    return badRequest("that task id is not one this build accepts.");
  }

  const body = await readBoundedBody(request, MAX_TASK_RESUME_BODY_BYTES);
  if (!body.ok) return Response.json({ error: body.error }, { status: body.status });

  let decision: ServerTaskResumeDecision | undefined;
  if (body.bytes.byteLength > 0) {
    let parsed: unknown;
    try {
      parsed = JSON.parse(new TextDecoder().decode(body.bytes));
    } catch {
      return badRequest("The request body is not valid JSON.");
    }
    if (typeof parsed !== "object" || parsed === null || Array.isArray(parsed)) {
      return badRequest("The request body must be an object.");
    }
    const raw = (parsed as Record<string, unknown>).decision;
    if (raw !== undefined && raw !== null) {
      if (typeof raw !== "string" || !DECISIONS.has(raw as ServerTaskResumeDecision)) {
        return badRequest('decision must be "verify", "skip" or "retry-authorized".');
      }
      decision = raw as ServerTaskResumeDecision;
    }
  }

  try {
    await ensureServerTasksRecovered();
  } catch {
    // A resume works on the row it names; a boot recovery that could not run is
    // not a reason to refuse it. The row's own claim guard is what protects it.
  }

  // Prompt 60 — a resume can restart a pump that dispatches pending desktop
  // items, so it carries the same caller-trust decision as a start.
  const result = await serverTaskRunner().resume(taskId, decision, {
    trusted: options.trusted === true,
  });
  if (!result.ok) {
    const missing = result.error.includes("no task has that id");
    return Response.json({ error: result.error }, { status: missing ? 404 : 409 });
  }
  return Response.json(
    {
      ok: true,
      task: result.task,
      resolved: result.resolved,
      unresolved: result.unresolved,
    },
    { headers: { "cache-control": "no-store" } },
  );
}

export const Route = createFileRoute("/api/tasks/resume/$taskId")({
  server: {
    handlers: {
      POST: ({ request, params }) => {
        // Prompt 60 (F-1) — same TCP-peer boundary as the start route.
        const peer = loopbackPeerRejected(request);
        if (peer) return peer;
        return handleTaskResume(request, String((params as { taskId?: string }).taskId ?? ""), {
          trusted: true,
        });
      },
    },
  },
});
