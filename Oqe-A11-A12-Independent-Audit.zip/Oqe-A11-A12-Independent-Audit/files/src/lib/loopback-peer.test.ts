/**
 * Prompt 58 (C) — the companion bridge's network-trust boundary.
 *
 * The peer address comes from the socket, so these cases are about what the
 * server does with a value a client cannot choose: loopback spellings are
 * trusted, every other value — including a missing one — is refused unless the
 * caller explicitly allows unknown peers (dev, where the bind refusal is the
 * boundary).
 */
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { join } from "node:path";
import { test } from "node:test";

import { bridgeToken } from "./companion/bridge-token.ts";
import { isLoopbackPeer, peerTrustDecision } from "./local-request-security.server.ts";

const ROUTE = readFileSync(join(process.cwd(), "src/routes/api/companion.$.ts"), "utf8");

test("loopback peers are trusted in both families, including IPv4-mapped IPv6", () => {
  for (const address of ["127.0.0.1", "127.0.0.53", "::1", "0:0:0:0:0:0:0:1", "::ffff:127.0.0.1"]) {
    assert.equal(isLoopbackPeer(address), true, `${address} should be loopback`);
    assert.equal(peerTrustDecision(address), true);
  }
});

test("a private-network address is never loopback, even though it is not public", () => {
  for (const address of [
    "192.168.1.151",
    "10.0.0.5",
    "172.16.0.9",
    "169.254.1.1",
    "::ffff:192.168.1.151",
    "fe80::1",
    "8.8.8.8",
    "0.0.0.0",
    "::",
  ]) {
    assert.equal(isLoopbackPeer(address), false, `${address} must not be loopback`);
  }
});

test("a malformed or missing peer fails closed", () => {
  for (const address of ["", "   ", "unknown", "127.0.0", "127.0.0.1:8080", "127.0.0.999", "::1%lo0", null, undefined]) {
    assert.equal(peerTrustDecision(address), false, `${String(address)} must be refused`);
  }
});

test("unknown peers are allowed only where the caller says the bind is the boundary", () => {
  assert.equal(peerTrustDecision(null, { allowUnknown: true }), true);
  assert.equal(peerTrustDecision(undefined, { allowUnknown: true }), true);
  assert.equal(peerTrustDecision("", { allowUnknown: true }), true);
  // A present, non-loopback address is refused whatever the option says.
  assert.equal(peerTrustDecision("192.168.1.151", { allowUnknown: true }), false);
});

test("a caller-supplied token is forwarded and never replaced", () => {
  assert.equal(bridgeToken({ requestToken: "from-caller", fromApp: true, serverToken: "server" }), "from-caller");
  assert.equal(bridgeToken({ requestToken: "from-caller", fromApp: false, serverToken: "server" }), "from-caller");
});

test("the server-held token is attached only to this app's own page", () => {
  assert.equal(bridgeToken({ requestToken: "", fromApp: true, serverToken: "server" }), "server");
  assert.equal(bridgeToken({ requestToken: "", fromApp: false, serverToken: "server" }), "");
  assert.equal(bridgeToken({ requestToken: "", fromApp: true, serverToken: null }), "");
  assert.equal(bridgeToken({ requestToken: "", fromApp: false, serverToken: null }), "");
});

test("every companion request passes the peer check before forwarding or injection", () => {
  const peerAt = ROUTE.indexOf("companionPeerRejected(request");
  const injectAt = ROUTE.indexOf("serverToken: companionToken()");
  const forwardAt = ROUTE.indexOf("await fetch(`${companionOrigin()}");
  assert.ok(peerAt > 0, "the route must call companionPeerRejected");
  assert.ok(injectAt > peerAt, "token injection must come after the peer check");
  assert.ok(forwardAt > peerAt, "forwarding must come after the peer check");
  // Power controls (/enable, /stop, /start ...) are dispatched inside the same
  // handler, so they are covered by the check above; both methods use it.
  assert.match(ROUTE, /server: \{ handlers: \{ GET: proxyCompanion, POST: proxyCompanion \} \}/);
  assert.match(ROUTE, /path\.startsWith\("\/power\/"\)/);
});

test("the route keeps fromThisApp as a CSRF check, not as the network boundary", () => {
  assert.match(ROUTE, /function fromThisApp\(request: Request\): boolean/);
  assert.match(ROUTE, /fromApp: fromThisApp\(request\)/);
  // A Host or Origin comparison must never be used in place of the peer check.
  assert.doesNotMatch(ROUTE, /headers\.get\("host"\)/i);
});
