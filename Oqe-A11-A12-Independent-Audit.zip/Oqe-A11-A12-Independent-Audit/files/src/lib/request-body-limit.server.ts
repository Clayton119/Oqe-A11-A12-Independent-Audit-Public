/**
 * V9.5 — bounded request-body reads for the local API routes.
 *
 * `await request.arrayBuffer()` buffers whatever the client sends BEFORE any
 * size check can run, so the limits those routes advertise did not actually
 * bound memory: a client could stream an arbitrarily large body into the
 * loopback bridge and only then be told it was too large. `readBoundedBody`
 * refuses a declared over-limit length up front and aborts the stream as soon
 * as the running total passes the cap, so the limit is enforced while reading.
 *
 * The cap is a rejection, never a truncation: a partially-read body is never
 * handed to a caller as if it were complete.
 */

/** Default cap for the local bridge bodies (companion actions are small JSON). */
export const MAX_LOCAL_BODY_BYTES = 2 * 1024 * 1024;

export type BoundedBodyResult =
  // An ArrayBuffer-backed view, so the bytes can be handed straight to fetch().
  | { ok: true; bytes: Uint8Array<ArrayBuffer> }
  | { ok: false; status: number; error: string };

export async function readBoundedBody(
  request: Request,
  limit = MAX_LOCAL_BODY_BYTES,
): Promise<BoundedBodyResult> {
  const declared = Number(request.headers.get("content-length") ?? "");
  if (Number.isFinite(declared) && declared > limit) {
    return { ok: false, status: 413, error: `The request body exceeds the local ${limit}-byte limit.` };
  }
  const body = request.body;
  if (!body) return { ok: true, bytes: new Uint8Array(new ArrayBuffer(0)) };
  const reader = body.getReader();
  const chunks: Uint8Array[] = [];
  let total = 0;
  try {
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      total += value.byteLength;
      if (total > limit) {
        try {
          await reader.cancel();
        } catch {
          // The client already went away; the cap still applies.
        }
        return { ok: false, status: 413, error: `The request body exceeds the local ${limit}-byte limit.` };
      }
      chunks.push(value);
    }
  } catch (error) {
    return {
      ok: false,
      status: 400,
      error: `The request body could not be read: ${error instanceof Error ? error.message : String(error)}`,
    };
  } finally {
    try {
      reader.releaseLock();
    } catch {
      // Already released by cancel(); nothing to do.
    }
  }
  const bytes = new Uint8Array(new ArrayBuffer(total));
  let offset = 0;
  for (const chunk of chunks) {
    bytes.set(chunk, offset);
    offset += chunk.byteLength;
  }
  return { ok: true, bytes };
}
