import assert from "node:assert/strict";
import { after, test } from "node:test";
import { mkdtempSync, readFileSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import type { DatabaseSync } from "node:sqlite";

import { loopbackPeerRejected } from "./local-request-security.server.ts";
import { handleTaskStart } from "../routes/api/tasks.start.ts";
import type {
  JournalEntry,
  JournalReconciliation,
  SideEffectOutcome,
} from "./operation-journal.ts";
import {
  createServerTaskRunner,
  isValidServerTaskId,
  MAX_SERVER_TASK_ITEMS,
  SERVER_TASK_HANDOVER_MS,
  serverTaskRequestRejected,
  type ServerTaskDispatchResult,
  type ServerTaskEffect,
  type ServerTaskJournal,
  type ServerTaskStore,
  type ServerTaskWorkInput,
} from "./server-task-runner.server.ts";
import {
  claimServerTask,
  clearServerTasks,
  createServerTask,
  finishServerTask,
  initializeDatabase,
  isFinishedServerTaskState,
  listServerTasks,
  openDatabase,
  readServerTask,
  recoverableServerTasks,
  releaseServerTask,
  requestServerTaskCancel,
  updateServerTaskProgress,
  MAX_SERVER_TASK_EFFECTS_CHARS,
  type StoredServerTask,
} from "./database.server.ts";
import { DATABASE_SCHEMA_VERSION } from "./database-schema.server.ts";
import {
  claimNextTaskItem,
  createTaskQueue,
  restoreTaskQueue,
  serializeTaskQueue,
} from "./task-queue.ts";
import { advanceLongTask, serializeLongTaskState, startLongTask } from "./long-task.ts";

/* ------------------------------------------------------------------ *
 * A store that behaves like the real one, in memory.
 *
 * The claim/epoch rules are the whole point of the real store, so the fake
 * implements them rather than accepting every write: a pump that lost its
 * claim must be refused exactly as it is in SQLite, otherwise these tests
 * would pass on behaviour the app does not have.
 * ------------------------------------------------------------------ */

type MemoryStore = ServerTaskStore & {
  rows: Map<string, StoredServerTask>;
  /** Refuse every progress write, the way a dead database would. */
  failWrites: boolean;
};

function memoryStore(): MemoryStore {
  const rows = new Map<string, StoredServerTask>();
  const store: MemoryStore = {
    rows,
    failWrites: false,
    clearServerTasks: () => {
      const count = rows.size;
      rows.clear();
      return count;
    },
    listServerTasks: () => [...rows.values()].sort((a, b) => b.createdAt - a.createdAt),
    recoverableServerTasks: () =>
      [...rows.values()]
        .filter((row) => ["queued", "running", "cancelling", "needs_attention"].includes(row.state))
        .sort((a, b) => a.createdAt - b.createdAt),
    readServerTask: (id) => {
      const row = rows.get(String(id).trim());
      return row ? { ...row } : null;
    },
    createServerTask: (input) => {
      const id = input.id.trim();
      if (!id) return { status: "refused", reason: "A server task needs an id." };
      const existing = rows.get(id);
      if (existing) return { status: "duplicate", task: { ...existing } };
      if (input.effectsState.length > MAX_SERVER_TASK_EFFECTS_CHARS) {
        return { status: "refused", reason: "A server task's work definition is too large." };
      }
      const row: StoredServerTask = {
        id,
        title: input.title.trim() || "Long-running task",
        state: "queued",
        stage: (input.stage ?? "task").trim() || "task",
        step: Math.max(0, Math.floor(input.step ?? 0)),
        total: input.total ?? null,
        queueState: input.queueState,
        effectsState: input.effectsState,
        taskState: input.taskState ?? null,
        owner: null,
        epoch: null,
        lastOperationId: null,
        pauseReason: null,
        error: null,
        cancelRequestedAt: null,
        resumeCount: 0,
        createdAt: input.now,
        startedAt: null,
        updatedAt: input.now,
        finishedAt: null,
        version: 0,
      };
      rows.set(id, row);
      return { status: "created", task: { ...row } };
    },
    claimServerTask: (input) => {
      const epoch = input.epoch.trim();
      if (!epoch) throw new Error("server task: claiming requires an epoch.");
      const row = rows.get(String(input.id).trim());
      if (!row) return { status: "not-claimable", task: null };
      if (isFinishedServerTaskState(row.state)) return { status: "not-claimable", task: { ...row } };
      if (row.epoch !== null && row.epoch !== epoch && input.takeover !== true) {
        return { status: "not-claimable", task: { ...row } };
      }
      const next: StoredServerTask = {
        ...row,
        state: row.state === "queued" ? "running" : row.state,
        epoch,
        owner: input.owner,
        startedAt: row.startedAt ?? input.now,
        updatedAt: input.now,
        version: row.version + 1,
      };
      rows.set(row.id, next);
      return { status: "claimed", task: { ...next } };
    },
    updateServerTaskProgress: (input) => {
      const row = rows.get(String(input.id).trim());
      if (!row) return { status: "stale", task: null };
      if (
        store.failWrites ||
        row.epoch !== input.epoch.trim() ||
        !["running", "cancelling", "needs_attention"].includes(row.state)
      ) {
        return { status: "stale", task: { ...row } };
      }
      const next: StoredServerTask = {
        ...row,
        state: input.state ?? row.state,
        stage: input.stage,
        step: Math.max(0, Math.floor(input.step)),
        total: input.total,
        queueState: input.queueState,
        taskState: input.taskState,
        lastOperationId: input.lastOperationId,
        pauseReason: input.pauseReason,
        error: input.error,
        updatedAt: input.now,
        version: row.version + 1,
      };
      rows.set(row.id, next);
      return { status: "updated", task: { ...next } };
    },
    requestServerTaskCancel: (input) => {
      const row = rows.get(String(input.id).trim());
      if (!row) return { status: "unchanged", task: null };
      if (isFinishedServerTaskState(row.state)) return { status: "unchanged", task: { ...row } };
      const immediate = row.state === "queued";
      const next: StoredServerTask = {
        ...row,
        state: immediate ? "cancelled" : "cancelling",
        cancelRequestedAt: row.cancelRequestedAt ?? input.now,
        pauseReason: row.pauseReason ?? input.reason ?? null,
        finishedAt: immediate ? input.now : null,
        epoch: immediate ? null : row.epoch,
        updatedAt: input.now,
        version: row.version + 1,
      };
      rows.set(row.id, next);
      return { status: immediate ? "cancelled" : "cancelling", task: { ...next } };
    },
    finishServerTask: (input) => {
      const row = rows.get(String(input.id).trim());
      if (!row) return { status: "missing", task: null };
      if (isFinishedServerTaskState(row.state)) return { status: "stale", task: { ...row } };
      if (input.epoch !== undefined && input.epoch !== null && row.epoch !== input.epoch) {
        return { status: "stale", task: { ...row } };
      }
      const terminal = input.state !== "needs_attention";
      const next: StoredServerTask = {
        ...row,
        state: input.state,
        stage: input.stage ?? row.stage,
        step: input.step === undefined ? row.step : Math.max(0, Math.floor(input.step)),
        total: input.total === undefined ? row.total : input.total,
        queueState: input.queueState ?? row.queueState,
        taskState: input.taskState ?? row.taskState,
        pauseReason: input.pauseReason ?? null,
        error: input.error ?? null,
        finishedAt: terminal ? input.now : null,
        epoch: null,
        owner: null,
        updatedAt: input.now,
        version: row.version + 1,
      };
      rows.set(row.id, next);
      return { status: "finished", task: { ...next } };
    },
    releaseServerTask: (input) => {
      const row = rows.get(String(input.id).trim());
      if (!row) return { status: "stale", task: null };
      if (
        row.epoch !== input.epoch.trim() ||
        ["cancelled", "complete", "failed"].includes(row.state)
      ) {
        return { status: "stale", task: { ...row } };
      }
      const next: StoredServerTask = {
        ...row,
        epoch: null,
        owner: null,
        state: input.state ?? row.state,
        updatedAt: input.now,
        version: row.version + 1,
      };
      rows.set(row.id, next);
      return { status: "released", task: { ...next } };
    },
  };
  return store;
}

type MemoryJournal = ServerTaskJournal & {
  entries: Map<string, JournalEntry>;
  /** Seed a journal row exactly as a crashed process would leave it. */
  seed: (entry: JournalEntry) => void;
};

function memoryJournal(options: { failStart?: boolean } = {}): MemoryJournal {
  const entries = new Map<string, JournalEntry>();
  const journal: MemoryJournal = {
    entries,
    seed: (entry) => entries.set(entry.operationId, entry),
    start: (input) => {
      if (options.failStart) {
        return { ok: false, warning: "the journal is unavailable; the side effect must not run." };
      }
      if (entries.has(input.operationId)) return { ok: true };
      entries.set(input.operationId, {
        operationId: input.operationId,
        itemId: input.itemId,
        taskId: input.taskId,
        executionId: input.executionId,
        sideEffectClass: input.sideEffectClass,
        idempotencyKey: input.idempotencyKey,
        phase: "started",
        startedAt: input.now,
      });
      return { ok: true };
    },
    observed: (operationId, observationRef, now) => {
      const entry = entries.get(operationId);
      if (!entry) return { ok: false, warning: "no journal entry for that operation" };
      entries.set(operationId, {
        ...entry,
        phase: "observed",
        observedAt: now,
        observationRef,
      });
      return { ok: true };
    },
    settled: (operationId, outcome: SideEffectOutcome, now) => {
      const entry = entries.get(operationId);
      if (!entry) return { ok: false, warning: "no journal entry for that operation" };
      entries.set(operationId, { ...entry, phase: "settled", settledAt: now, outcome });
      return { ok: true };
    },
    reconciled: (operationId, reconciliation: JournalReconciliation) => {
      const entry = entries.get(operationId);
      if (!entry) return { ok: false, warning: "no journal entry for that operation" };
      // The store's own at-most-once refusal, reproduced: an operation that may
      // run once is never re-authorized in place.
      if (entry.sideEffectClass === "at-most-once" && reconciliation === "retry-authorized-by-user") {
        return { ok: true, changed: false };
      }
      entries.set(operationId, { ...entry, reconciliation });
      return { ok: true, changed: true };
    },
    read: () => [...entries.values()],
  };
  return journal;
}

/* ------------------------------------------------------------------ *
 * Work plans.
 * ------------------------------------------------------------------ */

function desktop(label: string, overrides: Partial<ServerTaskWorkInput> = {}): ServerTaskWorkInput {
  return {
    id: label,
    label: `Do ${label}`,
    effect: { kind: "desktop", action: { action: "click", x: 10, y: 20 } },
    ...overrides,
  };
}

function bookkeeping(id: string): ServerTaskWorkInput {
  return { id, label: `Record ${id}`, effect: { kind: "none" } };
}

type Dispatched = { taskId: string; itemId: string; operationId: string; effect: ServerTaskEffect };

type Harness = {
  store: MemoryStore;
  journal: MemoryJournal;
  runner: ReturnType<typeof createServerTaskRunner>;
  dispatched: Dispatched[];
  schedule: (fn: () => void) => void;
};

/**
 * A runner whose pump never runs on its own.
 *
 * `schedule` collects the work instead of running it, so a test can inspect the
 * state a request left behind — and can then start the pump deliberately with
 * `runScheduled()`. This is also the honest model of the real thing: the route
 * answers the request BEFORE any pump runs.
 */
function harness(options: {
  store?: MemoryStore;
  journal?: MemoryJournal;
  epoch?: string;
  now?: () => number;
  dispatch?: (effect: ServerTaskEffect, context: Dispatched) => Promise<ServerTaskDispatchResult>;
  scheduled?: Array<() => void>;
  hold?: boolean;
}): Harness {
  const store = options.store ?? memoryStore();
  const journal = options.journal ?? memoryJournal();
  const dispatched: Dispatched[] = [];
  const scheduled = options.scheduled ?? [];
  const runner = createServerTaskRunner({
    now: options.now ?? (() => 1_000),
    epoch: options.epoch ?? "epoch-a",
    owner: "test",
    store,
    journal,
    schedule: (run) => {
      if (options.hold) return;
      scheduled.push(run);
    },
    dispatch: async (effect, context) => {
      dispatched.push({ ...context, effect });
      if (options.dispatch) return options.dispatch(effect, { ...context, effect });
      return { ok: true, observationRef: `companion:test:${context.itemId}` };
    },
  });
  return { store, journal, runner, dispatched, schedule: (run) => scheduled.push(run) };
}

/** Run every pump the requests scheduled, then wait for them to settle. */
async function runScheduled(scheduled: Array<() => void>): Promise<void> {
  for (let guard = 0; guard < 1000 && scheduled.length > 0; guard += 1) {
    const run = scheduled.shift();
    run?.();
    await new Promise((resolve) => setTimeout(resolve, 0));
  }
}

function itemState(store: MemoryStore, taskId: string, itemId: string): string | undefined {
  const row = store.readServerTask(taskId);
  if (!row) return undefined;
  const restored = restoreTaskQueue(row.queueState);
  if (!restored.ok) return undefined;
  return restored.queue.items.find((item) => item.id === itemId)?.state;
}

/**
 * Seed the row a KILLED process leaves behind.
 *
 * This is the crash window, written out: the queue says one item is
 * `in_progress`, the row still carries the dead process's epoch, and the journal
 * holds only the start record — no observation, no outcome. Nothing here is a
 * guess: the queue and pipeline documents are built by the real engines, so the
 * recovery path gets exactly what a crash produces.
 */
function seedCrashedTask(options: {
  store: MemoryStore;
  journal: MemoryJournal;
  taskId: string;
  items: ServerTaskWorkInput[];
  crashedItemId: string;
  deadEpoch?: string;
  at?: number;
}): string {
  const at = options.at ?? 1_000;
  const deadEpoch = options.deadEpoch ?? "epoch-dead";
  const queue = createTaskQueue(
    `Crash ${options.taskId}`,
    options.items.map((item) => ({
      id: item.id,
      label: item.label,
      ...(item.sideEffectClass ? { sideEffectClass: item.sideEffectClass } : {}),
    })),
    at,
  );
  const operationId = `op-${options.crashedItemId}`;
  const claimed = claimNextTaskItem(queue, operationId, at);
  assert.ok(claimed.item);
  assert.equal(claimed.item.id, options.crashedItemId);

  const created = options.store.createServerTask({
    id: options.taskId,
    title: `Crash ${options.taskId}`,
    queueState: serializeTaskQueue(claimed.queue),
    effectsState: JSON.stringify(
      Object.fromEntries(options.items.map((item) => [item.id, item.effect])),
    ),
    taskState: serializeLongTaskState(
      advanceLongTask(startLongTask(`Crash ${options.taskId}`, { total: options.items.length }), {
        type: "execute",
        label: claimed.item.label,
      }),
    ),
    total: options.items.length,
    now: at,
  });
  assert.equal(created.status, "created");
  const held = options.store.claimServerTask({
    id: options.taskId,
    epoch: deadEpoch,
    owner: "dead-process",
    now: at,
  });
  assert.equal(held.status, "claimed");
  options.journal.seed({
    operationId,
    itemId: claimed.item.id,
    taskId: options.taskId,
    executionId: deadEpoch,
    sideEffectClass: claimed.item.sideEffectClass,
    idempotencyKey: claimed.item.idempotencyKey,
    phase: "started",
    startedAt: at,
  });
  return operationId;
}

/** A restart long enough after the crash that the dead holder is presumed dead. */
function afterHandoverWindow(): () => number {
  return () => 1_000 + SERVER_TASK_HANDOVER_MS + 1;
}

/* ------------------------------------------------------------------ *
 * The server owns execution.
 * ------------------------------------------------------------------ */

test("the server runs the whole plan with no browser attached", async () => {
  const scheduled: Array<() => void> = [];
  const h = harness({ scheduled });
  const result = await h.runner.start({ trusted: true,
    title: "Two steps",
    items: [bookkeeping("one"), bookkeeping("two")],
  });
  assert.equal(result.ok, true);
  if (!result.ok) return;
  // The start request answered before any work ran: the browser is not the
  // execution context, so nothing it does from here can stop the task.
  assert.equal(h.runner.status(result.task.id)?.state, "queued");

  await runScheduled(scheduled);
  await h.runner.idle();

  const task = h.runner.status(result.task.id);
  assert.ok(task);
  assert.equal(task.state, "complete");
  // Bookkeeping steps settle as `verified` — there was nothing to verify.
  assert.equal(task.counts.verified, 2);
  assert.equal(task.counts.pending, 0);
  assert.equal(task.recovery.claimable, false);
});

test("a task that is never polled still finishes: no poll is not a cancel", async () => {
  const scheduled: Array<() => void> = [];
  const h = harness({ scheduled });
  const result = await h.runner.start({ trusted: true, title: "Unpolled", items: [desktop("a"), desktop("b")] });
  assert.equal(result.ok, true);
  if (!result.ok) return;

  await runScheduled(scheduled);
  await h.runner.idle();

  // Nobody read /status once, which is exactly what a closed tab looks like
  // from the server. The task is complete and no cancellation was recorded.
  const task = h.runner.status(result.task.id);
  assert.equal(task?.state, "complete");
  assert.equal(task?.cancelRequestedAt, null);
  assert.equal(h.dispatched.length, 2);
});

test("progress is persisted per item, so a later reader sees real numbers", async () => {
  const scheduled: Array<() => void> = [];
  const h = harness({ scheduled });
  const result = await h.runner.start({ trusted: true,
    title: "Three",
    items: [bookkeeping("a"), bookkeeping("b"), bookkeeping("c")],
  });
  assert.equal(result.ok, true);
  if (!result.ok) return;
  await runScheduled(scheduled);
  await h.runner.idle();

  // A brand-new runner over the same rows is a restart from the reader's point
  // of view: the state below came from the store, not from memory.
  const restarted = createServerTaskRunner({
    now: () => 2_000,
    epoch: "epoch-b",
    owner: "test",
    store: h.store,
    journal: h.journal,
    schedule: () => {},
    dispatch: async () => ({ ok: true }),
  });
  const task = restarted.status(result.task.id);
  assert.ok(task);
  assert.equal(task.state, "complete");
  assert.equal(task.counts.verified, 3);
  assert.equal(task.step, 3);
  assert.equal(task.total, 3);
  assert.deepEqual(
    task.items.map((item) => item.state),
    ["verified", "verified", "verified"],
  );
});

/* ------------------------------------------------------------------ *
 * Ordering, capacity and duplicate submissions.
 * ------------------------------------------------------------------ */

test("items run in queue order, one claim at a time", async () => {
  const scheduled: Array<() => void> = [];
  const h = harness({ scheduled });
  const result = await h.runner.start({ trusted: true,
    title: "Ordered",
    items: [desktop("first"), desktop("second"), desktop("third")],
  });
  assert.equal(result.ok, true);
  if (!result.ok) return;
  await runScheduled(scheduled);
  await h.runner.idle();

  assert.deepEqual(
    h.dispatched.map((entry) => entry.itemId),
    ["first", "second", "third"],
  );
  // One operation id per item: no item was dispatched twice.
  assert.equal(new Set(h.dispatched.map((entry) => entry.operationId)).size, 3);
});

test("a replayed start with the same id reports the existing task and runs nothing twice", async () => {
  const scheduled: Array<() => void> = [];
  const h = harness({ scheduled });
  const plan = { title: "Once", items: [desktop("only")], taskId: "task-once" };

  const first = await h.runner.start(plan);
  assert.equal(first.ok, true);
  if (!first.ok) return;
  assert.equal(first.status, "started");
  await runScheduled(scheduled);
  await h.runner.idle();
  const dispatchesAfterFirst = h.dispatched.length;

  const second = await h.runner.start(plan);
  assert.equal(second.ok, true);
  if (!second.ok) return;
  assert.equal(second.status, "duplicate");
  assert.equal(second.task.id, "task-once");
  await runScheduled(scheduled);
  await h.runner.idle();
  assert.equal(h.dispatched.length, dispatchesAfterFirst);
  assert.equal(h.store.rows.size, 1);
});

test("the queue's own capacity still refuses an oversized plan", async () => {
  const h = harness({});
  const items = Array.from({ length: MAX_SERVER_TASK_ITEMS + 1 }, (_unused, index) =>
    bookkeeping(`i${index}`),
  );
  const result = await h.runner.start({ trusted: true, title: "Too big", items });
  assert.equal(result.ok, false);
  if (result.ok) return;
  assert.match(result.error, /at most/);
  assert.equal(h.store.rows.size, 0);
});

test("a start that the queue engine refuses creates no row", async () => {
  const h = harness({});
  const result = await h.runner.start({ trusted: true,
    title: "Duplicate ids",
    items: [bookkeeping("same"), bookkeeping("same")],
  });
  assert.equal(result.ok, false);
  assert.equal(h.store.rows.size, 0);
});

/* ------------------------------------------------------------------ *
 * The journal comes first, and a failure is closed.
 * ------------------------------------------------------------------ */

test("fail-closed: a refused journal write means the side effect never runs", async () => {
  const scheduled: Array<() => void> = [];
  const h = harness({ scheduled, journal: memoryJournal({ failStart: true }) });
  const result = await h.runner.start({ trusted: true, title: "Blocked", items: [desktop("x")] });
  assert.equal(result.ok, true);
  if (!result.ok) return;
  await runScheduled(scheduled);
  await h.runner.idle();

  assert.equal(h.dispatched.length, 0);
  const task = h.runner.status(result.task.id);
  assert.equal(task?.state, "failed");
  assert.match(task?.error ?? "", /journal/i);
  assert.equal(itemState(h.store, result.task.id, "x"), "failed");
});

test("the journal row exists before the dispatch does", async () => {
  let journalAtDispatch = 0;
  const scheduled: Array<() => void> = [];
  const h = harness({
    scheduled,
    dispatch: async () => {
      journalAtDispatch = h.journal.read().filter((entry) => entry.phase !== "settled").length;
      return { ok: true };
    },
  });
  const result = await h.runner.start({ trusted: true, title: "Journaled", items: [desktop("y")] });
  assert.equal(result.ok, true);
  if (!result.ok) return;
  await runScheduled(scheduled);
  await h.runner.idle();

  assert.equal(journalAtDispatch, 1);
  const entries = h.journal.read();
  assert.equal(entries.length, 1);
  // A desktop action is settled as UNVERIFIED: the companion accepted it, and
  // nothing here proves the window changed.
  assert.equal(entries[0]?.phase, "settled");
  assert.equal(entries[0]?.outcome, "unverified");
  assert.equal(itemState(h.store, result.task.id, "y"), "executed_unverified");
});

test("a bookkeeping step is verified, because there was nothing to verify", async () => {
  const scheduled: Array<() => void> = [];
  const h = harness({ scheduled });
  const result = await h.runner.start({ trusted: true, title: "Bookkeeping", items: [bookkeeping("note")] });
  assert.equal(result.ok, true);
  if (!result.ok) return;
  await runScheduled(scheduled);
  await h.runner.idle();

  assert.equal(h.dispatched.length, 1);
  // No journal row: nothing external happened, so there is nothing to record.
  assert.equal(h.journal.read().length, 0);
  assert.equal(itemState(h.store, result.task.id, "note"), "verified");
});

/* ------------------------------------------------------------------ *
 * Failure and retries.
 * ------------------------------------------------------------------ */

test("a failed dispatch fails the item and the task; nothing is retried by itself", async () => {
  const scheduled: Array<() => void> = [];
  const h = harness({
    scheduled,
    dispatch: async () => ({ ok: false, error: "the companion is unavailable" }),
  });
  const result = await h.runner.start({ trusted: true, title: "Fails", items: [desktop("boom")] });
  assert.equal(result.ok, true);
  if (!result.ok) return;
  await runScheduled(scheduled);
  await h.runner.idle();

  assert.equal(h.dispatched.length, 1);
  const task = h.runner.status(result.task.id);
  assert.equal(task?.state, "failed");
  assert.match(task?.error ?? "", /companion is unavailable/);
  assert.equal(itemState(h.store, result.task.id, "boom"), "failed");
  const entry = h.journal.read()[0];
  assert.equal(entry?.outcome, "failed");
});

test("only an idempotently-retryable item returns to the queue after a failure", async () => {
  const scheduled: Array<() => void> = [];
  const h = harness({
    scheduled,
    dispatch: async (_effect, context) =>
      context.itemId === "retryable"
        ? { ok: false, error: "transient" }
        : { ok: false, error: "transient" },
  });
  const result = await h.runner.start({ trusted: true,
    title: "Classes",
    items: [
      desktop("once"),
      desktop("retryable", { sideEffectClass: "idempotently-retryable" }),
    ],
  });
  assert.equal(result.ok, true);
  if (!result.ok) return;
  await runScheduled(scheduled);
  await h.runner.idle();

  // The first failure ends the task, so the second item keeps its queue state.
  assert.equal(itemState(h.store, result.task.id, "once"), "failed");
  const row = h.store.readServerTask(result.task.id);
  const restored = row ? restoreTaskQueue(row.queueState) : null;
  assert.ok(restored?.ok);
  const retryable = restored.ok
    ? restored.queue.items.find((item) => item.id === "retryable")
    : undefined;
  assert.equal(retryable?.attempts, 0);
  assert.ok(["pending", "retry_pending"].includes(retryable?.state ?? ""));
});

/* ------------------------------------------------------------------ *
 * Cancellation and STOP.
 * ------------------------------------------------------------------ */

test("cancel is honoured at the boundary: the in-flight item finishes, the rest are cancelled", async () => {
  const scheduled: Array<() => void> = [];
  const h = harness({
    scheduled,
    dispatch: async () => {
      // The user asks to stop WHILE the first action is in flight.
      await h.runner.cancel("task-stop", "user asked");
      return { ok: true };
    },
  });
  const result = await h.runner.start({ trusted: true,
    title: "Stoppable",
    items: [desktop("a"), desktop("b"), desktop("c")],
    taskId: "task-stop",
  });
  assert.equal(result.ok, true);
  if (!result.ok) return;
  await runScheduled(scheduled);
  await h.runner.idle();

  const task = h.runner.status("task-stop");
  assert.equal(task?.state, "cancelled");
  // The action that was already dispatched is recorded, not denied: it ran,
  // and no evidence proves its effect, so it is `executed_unverified`.
  assert.equal(itemState(h.store, "task-stop", "a"), "executed_unverified");
  assert.equal(itemState(h.store, "task-stop", "b"), "cancelled");
  assert.equal(itemState(h.store, "task-stop", "c"), "cancelled");
  assert.equal(h.dispatched.length, 1);
  assert.notEqual(task?.cancelRequestedAt, null);
});

test("cancelling a queued task is immediate and truthful", async () => {
  const h = harness({ hold: true });
  const result = await h.runner.start({ trusted: true, title: "Queued", items: [desktop("q")], taskId: "task-q" });
  assert.equal(result.ok, true);
  if (!result.ok) return;

  const cancelled = await h.runner.cancel("task-q");
  assert.equal(cancelled.ok, true);
  if (!cancelled.ok) return;
  assert.equal(cancelled.status, "cancelled");
  assert.equal(cancelled.task.state, "cancelled");
  assert.equal(h.dispatched.length, 0);
});

test("a replayed cancel cannot change a finished task", async () => {
  const h = harness({ hold: true });
  await h.runner.start({ trusted: true, title: "Twice", items: [desktop("q")], taskId: "task-twice" });
  const first = await h.runner.cancel("task-twice");
  assert.equal(first.ok, true);
  const second = await h.runner.cancel("task-twice");
  assert.equal(second.ok, true);
  if (!second.ok) return;
  assert.equal(second.status, "unchanged");
  assert.equal(second.task.state, "cancelled");
});

test("cancel and status refuse an id this build does not accept", async () => {
  const h = harness({ hold: true });
  const cancelled = await h.runner.cancel("../../etc/passwd");
  assert.equal(cancelled.ok, false);
  assert.equal(h.runner.status("../../etc/passwd"), null);
  assert.equal(h.runner.status("does-not-exist"), null);
  assert.equal(isValidServerTaskId("task-1"), true);
  assert.equal(isValidServerTaskId("task/../1"), false);
});

/* ------------------------------------------------------------------ *
 * Restart, recovery and unknown outcomes.
 * ------------------------------------------------------------------ */

test("restart mid-effect parks the task instead of replaying a desktop action", async () => {
  const scheduled: Array<() => void> = [];
  const store = memoryStore();
  const journal = memoryJournal();
  seedCrashedTask({
    store,
    journal,
    taskId: "task-crash",
    items: [desktop("danger"), bookkeeping("after")],
    crashedItemId: "danger",
  });

  // The row a killed process leaves: one item in flight, a dead epoch on the
  // row, and a journal entry that only says the operation started.
  const stored = store.readServerTask("task-crash");
  assert.equal(stored?.state, "running");
  assert.equal(stored?.epoch, "epoch-dead");
  assert.equal(journal.read().length, 1);
  assert.equal(journal.read()[0]?.phase, "started");

  // A new process (new epoch) recovers. It must NOT dispatch anything again.
  const restarted = harness({ store, journal, epoch: "epoch-b", now: afterHandoverWindow() });
  const recovered = await restarted.runner.recover();
  await runScheduled(scheduled);
  await restarted.runner.idle();

  assert.deepEqual(recovered.parked, ["task-crash"]);
  assert.equal(restarted.dispatched.length, 0);
  const parked = restarted.runner.status("task-crash");
  assert.equal(parked?.state, "needs_attention");
  assert.deepEqual(parked?.recovery.needsReconciliation, ["danger"]);
  assert.match(parked?.pauseReason ?? "", /may already have run/);
});

test("recovery continues work that was never in flight", async () => {
  const store = memoryStore();
  const journal = memoryJournal();
  const scheduled: Array<() => void> = [];

  // A task created, then the process died BEFORE the first claim: queued work
  // with nothing in flight. That is safe to continue.
  const before = harness({ store, journal, hold: true });
  const result = await before.runner.start({ trusted: true,
    title: "Interrupted before start",
    items: [bookkeeping("a"), bookkeeping("b")],
    taskId: "task-safe",
  });
  assert.equal(result.ok, true);

  const after = harness({ store, journal, epoch: "epoch-b", scheduled });
  const recovered = await after.runner.recover();
  await runScheduled(scheduled);
  await after.runner.idle();

  assert.deepEqual(recovered.resumed, ["task-safe"]);
  const task = after.runner.status("task-safe");
  assert.equal(task?.state, "complete");
  assert.equal(task?.counts.verified, 2);
});

test("recovery never takes a task another epoch still holds", async () => {
  const store = memoryStore();
  const journal = memoryJournal();
  const held = harness({ store, journal, epoch: "epoch-a", hold: true });
  await held.runner.start({ trusted: true, title: "Held", items: [bookkeeping("a")], taskId: "task-held" });
  // Claim it without finishing, the way a running pump does.
  store.claimServerTask({ id: "task-held", epoch: "epoch-a", owner: "other", now: 1_000 });

  const other = harness({ store, journal, epoch: "epoch-b" });
  const recovered = await other.runner.recover();
  assert.deepEqual(recovered.parked, ["task-held"]);
  assert.equal(other.dispatched.length, 0);
});

test("resume without a decision keeps unknown work parked and says why", async () => {
  const store = memoryStore();
  const journal = memoryJournal();
  seedCrashedTask({
    store,
    journal,
    taskId: "task-unknown",
    items: [desktop("u")],
    crashedItemId: "u",
  });

  const restarted = harness({ store, journal, epoch: "epoch-b", now: afterHandoverWindow() });
  await restarted.runner.recover();
  const resumed = await restarted.runner.resume("task-unknown");
  assert.equal(resumed.ok, true);
  if (!resumed.ok) return;
  assert.equal(resumed.task.state, "needs_attention");
  assert.deepEqual(resumed.unresolved, ["u"]);
  assert.equal(restarted.dispatched.length, 0);
});

test("resume with verify settles an unknown desktop action from the journal", async () => {
  const store = memoryStore();
  const journal = memoryJournal();
  const scheduled: Array<() => void> = [];
  seedCrashedTask({
    store,
    journal,
    taskId: "task-verify",
    items: [desktop("v")],
    crashedItemId: "v",
  });

  // The user says: I checked, it happened. The journal records WHO decided, and
  // the item is settled from that record rather than from a retry.
  const restarted = harness({
    store,
    journal,
    epoch: "epoch-b",
    now: afterHandoverWindow(),
    scheduled,
  });
  await restarted.runner.recover();
  const resumed = await restarted.runner.resume("task-verify", "verify");
  assert.equal(resumed.ok, true);
  if (!resumed.ok) return;
  assert.deepEqual(resumed.resolved, ["v"]);
  assert.equal(restarted.dispatched.length, 0);
  assert.equal(journal.read()[0]?.reconciliation, "verified");

  await runScheduled(scheduled);
  await restarted.runner.idle();
  const task = restarted.runner.status("task-verify");
  assert.equal(task?.state, "complete");
  assert.equal(task?.items.find((item) => item.id === "v")?.state, "verified");
});

test("resume with skip abandons the item and lets the rest run", async () => {
  const store = memoryStore();
  const journal = memoryJournal();
  const scheduled: Array<() => void> = [];
  seedCrashedTask({
    store,
    journal,
    taskId: "task-skip",
    items: [desktop("first"), bookkeeping("second")],
    crashedItemId: "first",
  });

  const restarted = harness({
    store,
    journal,
    epoch: "epoch-b",
    now: afterHandoverWindow(),
    scheduled,
  });
  await restarted.runner.recover();
  const resumed = await restarted.runner.resume("task-skip", "skip");
  assert.equal(resumed.ok, true);
  if (!resumed.ok) return;
  assert.deepEqual(resumed.resolved, ["first"]);
  assert.equal(journal.read()[0]?.reconciliation, "skipped");

  await runScheduled(scheduled);
  await restarted.runner.idle();
  const task = restarted.runner.status("task-skip");
  assert.equal(task?.state, "complete");
  assert.equal(task?.items.find((item) => item.id === "first")?.state, "skipped");
});

test("retry-authorized is refused for an at-most-once operation, so it never replays", async () => {
  const store = memoryStore();
  const journal = memoryJournal();
  seedCrashedTask({
    store,
    journal,
    taskId: "task-retry",
    items: [desktop("r", { sideEffectClass: "at-most-once" })],
    crashedItemId: "r",
  });

  const restarted = harness({ store, journal, epoch: "epoch-b", now: afterHandoverWindow() });
  await restarted.runner.recover();
  const resumed = await restarted.runner.resume("task-retry", "retry-authorized");
  assert.equal(resumed.ok, true);
  if (!resumed.ok) return;
  // The store refused to re-authorize it, so the item stays exactly where it
  // is and the task is parked again — never silently re-dispatched.
  assert.deepEqual(resumed.unresolved, ["r"]);
  assert.equal(resumed.task.state, "needs_attention");
  assert.equal(restarted.dispatched.length, 0);
});

test("recovery does not re-run a task it already finished", async () => {
  const store = memoryStore();
  const journal = memoryJournal();
  const scheduled: Array<() => void> = [];
  const done = harness({ store, journal, scheduled });
  await done.runner.start({ trusted: true, title: "Done", items: [bookkeeping("a")], taskId: "task-done" });
  await runScheduled(scheduled);
  await done.runner.idle();

  const restarted = harness({ store, journal, epoch: "epoch-b", scheduled });
  const recovered = await restarted.runner.recover();
  assert.deepEqual(recovered.resumed, []);
  // A finished task is not "parked": there is nothing to decide.
  assert.deepEqual(recovered.parked, []);
  assert.equal(restarted.runner.status("task-done")?.state, "complete");
});

/* ------------------------------------------------------------------ *
 * The HTTP boundary.
 * ------------------------------------------------------------------ */

test("the task gate refuses a cross-origin write, a non-loopback host and a missing header", () => {
  const base = "http://127.0.0.1:8080/api/tasks/start";
  const headers = { "x-oqe-tasks": "1", "content-type": "application/json" };

  const crossOrigin = serverTaskRequestRejected(
    new Request(base, { method: "POST", headers: { ...headers, origin: "https://evil.example" } }),
    { needsHeader: true },
  );
  assert.equal(crossOrigin?.status, 403);

  const lan = serverTaskRequestRejected(
    new Request("http://192.168.1.10:8080/api/tasks/start", { method: "POST", headers }),
    { needsHeader: true },
  );
  assert.equal(lan?.status, 403);

  const noHeader = serverTaskRequestRejected(new Request(base, { method: "POST", headers: {} }), {
    needsHeader: true,
  });
  assert.equal(noHeader?.status, 400);

  const sameOrigin = serverTaskRequestRejected(
    new Request(base, {
      method: "POST",
      headers: { ...headers, origin: "http://127.0.0.1:8080", "sec-fetch-site": "same-origin" },
    }),
    { needsHeader: true },
  );
  assert.equal(sameOrigin, null);

  // A read-only status poll needs no header, but is still same-origin only.
  const status = serverTaskRequestRejected(
    new Request("http://127.0.0.1:8080/api/tasks/status/x", {
      headers: { origin: "https://evil.example" },
    }),
  );
  assert.equal(status?.status, 403);
});

test("the start route refuses an oversized or non-JSON body before touching the store", async () => {
  const oversized = await handleTaskStart(
    new Request("http://127.0.0.1:8080/api/tasks/start", {
      method: "POST",
      headers: {
        origin: "http://127.0.0.1:8080",
        "x-oqe-tasks": "1",
        "content-type": "application/json",
        "content-length": String(2 * 1024 * 1024),
      },
      body: "{}",
    }),
  );
  assert.equal(oversized.status, 413);

  const notJson = await handleTaskStart(
    new Request("http://127.0.0.1:8080/api/tasks/start", {
      method: "POST",
      headers: { origin: "http://127.0.0.1:8080", "x-oqe-tasks": "1", "content-type": "text/plain" },
      body: "{}",
    }),
  );
  assert.equal(notJson.status, 415);

  const malformed = await handleTaskStart(
    new Request("http://127.0.0.1:8080/api/tasks/start", {
      method: "POST",
      headers: { origin: "http://127.0.0.1:8080", "x-oqe-tasks": "1", "content-type": "application/json" },
      body: "{",
    }),
  );
  assert.equal(malformed.status, 400);

  const unknownAction = await handleTaskStart(
    new Request("http://127.0.0.1:8080/api/tasks/start", {
      method: "POST",
      headers: { origin: "http://127.0.0.1:8080", "x-oqe-tasks": "1", "content-type": "application/json" },
      body: JSON.stringify({
        title: "Bad",
        items: [{ id: "a", label: "A", effect: { kind: "desktop", action: { action: "format-disk" } } }],
      }),
    }),
  );
  assert.equal(unknownAction.status, 400);
});

/* ------------------------------------------------------------------ *
 * The real store, on a real SQLite file.
 *
 * Everything above drives the pump through an in-memory store so the crash and
 * recovery states can be made exact. These cases prove what the fake cannot:
 * that the schema, the claim/epoch writes and the progress documents really
 * survive a closed and reopened database file.
 * ------------------------------------------------------------------ */

const root = mkdtempSync(join(tmpdir(), "oqe-server-tasks-"));
after(() => {
  try {
    rmSync(root, { recursive: true, force: true, maxRetries: 10, retryDelay: 50 });
  } catch {
    // left in %TEMP%; the OS cleans it up
  }
});

/** The real store, bound to one connection (the runner's default opens its own). */
function realStore(db: DatabaseSync): ServerTaskStore {
  return {
    createServerTask: (input) => createServerTask(input, db),
    readServerTask: (id) => readServerTask(id, db),
    claimServerTask: (input) => claimServerTask(input, db),
    updateServerTaskProgress: (input) => updateServerTaskProgress(input, db),
    requestServerTaskCancel: (input) => requestServerTaskCancel(input, db),
    finishServerTask: (input) => finishServerTask(input, db),
    releaseServerTask: (input) => releaseServerTask(input, db),
    recoverableServerTasks: () => recoverableServerTasks(db),
    listServerTasks: () => listServerTasks(db),
    clearServerTasks: () => clearServerTasks(db),
  };
}

function planDocuments(title: string, ids: readonly string[], at = 1_000) {
  const queue = createTaskQueue(
    title,
    ids.map((id) => ({ id, label: `Step ${id}` })),
    at,
  );
  return {
    queueState: serializeTaskQueue(queue),
    effectsState: JSON.stringify(
      Object.fromEntries(ids.map((id) => [id, { kind: "none" as const }])),
    ),
    taskState: serializeLongTaskState(startLongTask(title, { total: ids.length })),
    total: ids.length,
  };
}

test("the schema stores a task and a restart reads it back", () => {
  const path = join(root, "tasks.sqlite");
  const first = initializeDatabase({ path });
  const docs = planDocuments("Restart", ["one", "two"]);
  try {
    assert.equal(first.schemaVersion, DATABASE_SCHEMA_VERSION);
    assert.ok(first.tables.includes("server_tasks"));
    const store = realStore(first.db);
    const created = store.createServerTask({ id: "task-real", title: "Restart", ...docs, now: 1_000 });
    assert.equal(created.status, "created");
    // A lost response and a retry must not create a second row.
    assert.equal(
      store.createServerTask({ id: "task-real", title: "Restart", ...docs, now: 1_000 }).status,
      "duplicate",
    );
    assert.equal(
      store.claimServerTask({ id: "task-real", epoch: "epoch-a", owner: "test", now: 1_000 }).status,
      "claimed",
    );
    assert.equal(
      store.updateServerTaskProgress({
        id: "task-real",
        epoch: "epoch-a",
        now: 1_001,
        stage: "execute",
        step: 1,
        total: 2,
        queueState: docs.queueState,
        taskState: docs.taskState,
        lastOperationId: null,
        pauseReason: null,
        error: null,
      }).status,
      "updated",
    );
  } finally {
    first.db.close();
  }

  const second = openDatabase({ path });
  try {
    const store = realStore(second);
    const row = store.readServerTask("task-real");
    assert.equal(row?.state, "running");
    assert.equal(row?.epoch, "epoch-a");
    assert.equal(row?.step, 1);
    // The unfinished task is exactly what boot recovery scans for.
    assert.deepEqual(
      store.recoverableServerTasks().map((task) => task.id),
      ["task-real"],
    );
    // A holder this boot did not create is refused...
    assert.equal(
      store.claimServerTask({ id: "task-real", epoch: "epoch-b", owner: "test", now: 5_000 })
        .status,
      "not-claimable",
    );
    // ...and only an explicit takeover may take it.
    assert.equal(
      store.claimServerTask({
        id: "task-real",
        epoch: "epoch-b",
        owner: "test",
        now: 5_000,
        takeover: true,
      }).status,
      "claimed",
    );
    assert.equal(
      store.finishServerTask({ id: "task-real", state: "complete", now: 5_001 }).status,
      "finished",
    );
    assert.deepEqual(store.recoverableServerTasks(), []);
    assert.equal(store.readServerTask("task-real")?.state, "complete");
  } finally {
    second.close();
  }
});

test("the pump writes real rows, so a second process sees the finished task", async () => {
  const path = join(root, "pump.sqlite");
  const first = initializeDatabase({ path });
  const scheduled: Array<() => void> = [];
  try {
    const runner = createServerTaskRunner({
      now: () => 1_000,
      epoch: "epoch-a",
      owner: "test",
      store: realStore(first.db),
      journal: memoryJournal(),
      schedule: (run) => scheduled.push(run),
      dispatch: async () => ({ ok: true, observationRef: "companion:test" }),
    });
    const started = await runner.start({ trusted: true,
      title: "Real pump",
      items: [desktop("click"), bookkeeping("note")],
      taskId: "task-pump",
    });
    assert.equal(started.ok, true);
    await runScheduled(scheduled);
    await runner.idle();
  } finally {
    first.db.close();
  }

  const second = openDatabase({ path });
  try {
    const restarted = createServerTaskRunner({
      now: () => 2_000,
      epoch: "epoch-b",
      owner: "test",
      store: realStore(second),
      journal: memoryJournal(),
      schedule: () => {},
      dispatch: async () => ({ ok: true }),
    });
    const task = restarted.status("task-pump");
    assert.equal(task?.state, "complete");
    // A desktop action ran but is not proven; the bookkeeping step is settled.
    assert.deepEqual(
      task?.items.map((item) => item.state),
      ["executed_unverified", "verified"],
    );
    assert.equal(task?.counts.executed_unverified, 1);
    assert.equal(task?.counts.verified, 1);
    assert.equal(task?.step, 2);
  } finally {
    second.close();
  }
});
/* ------------------------------------------------------------------ *
 * Prompt 60 — F-1: dispatch is caller-trust, not ambient server authority.
 * ------------------------------------------------------------------ */

test("an untrusted start cannot dispatch a desktop action, fetch, or reach the token", async () => {
  const scheduled: Array<() => void> = [];
  const h = harness({ scheduled });
  const originalFetch = globalThis.fetch;
  let fetchCalls = 0;
  globalThis.fetch = (async () => {
    fetchCalls += 1;
    throw new Error("the companion must not be fetched for an untrusted task");
  }) as typeof fetch;
  try {
    // No `trusted` flag: exactly what an internal caller that cannot prove its
    // own caller looks like. The old code dispatched here.
    const result = await h.runner.start({
      title: "Untrusted",
      items: [desktop("click")],
      taskId: "task-untrusted",
    });
    assert.equal(result.ok, true);
    await runScheduled(scheduled);
    await h.runner.idle();
  } finally {
    globalThis.fetch = originalFetch;
  }

  assert.equal(h.dispatched.length, 0, "dispatch must not be reached at all");
  assert.equal(fetchCalls, 0, "no companion fetch, so no token can be attached");
  const task = h.runner.status("task-untrusted");
  assert.equal(task?.state, "failed");
  assert.equal(task?.items[0]?.state, "failed");
  assert.match(task?.error ?? "", /only for a task started from this machine/);
  assert.equal(itemState(h.store, "task-untrusted", "click"), "failed");
});

test("a trusted start still dispatches, through the unchanged allowlist", async () => {
  const scheduled: Array<() => void> = [];
  const h = harness({ scheduled });
  const result = await h.runner.start({
    trusted: true,
    title: "Trusted",
    items: [desktop("click")],
    taskId: "task-trusted",
  });
  assert.equal(result.ok, true);
  await runScheduled(scheduled);
  await h.runner.idle();

  assert.equal(h.dispatched.length, 1);
  assert.equal(h.dispatched[0]?.effect.kind, "desktop");
  assert.equal(h.runner.status("task-trusted")?.state, "complete");
});

test("bookkeeping work still runs without caller trust (no privileged request)", async () => {
  const scheduled: Array<() => void> = [];
  const h = harness({ scheduled });
  const result = await h.runner.start({
    title: "Notes",
    items: [bookkeeping("note")],
    taskId: "task-notes",
  });
  assert.equal(result.ok, true);
  await runScheduled(scheduled);
  await h.runner.idle();

  // The runner still hands `kind:"none"` to the dispatcher, which returns
  // without contacting anything; what must never arrive there is a desktop
  // effect. (The real dispatcher has no companion call on the `none` branch.)
  assert.deepEqual(
    h.dispatched.map((entry) => entry.effect.kind),
    ["none"],
  );
  assert.equal(h.runner.status("task-notes")?.state, "complete");
  assert.equal(itemState(h.store, "task-notes", "note"), "verified");
});

test("an untrusted resume cannot dispatch a queued desktop item", async () => {
  const store = memoryStore();
  const journal = memoryJournal();
  // Created while the pump is held, so the desktop item is still queued when
  // the resume happens in a fresh runner (the post-restart shape).
  const held = harness({ store, journal, hold: true });
  const started = await held.runner.start({
    trusted: true,
    title: "Queued",
    items: [desktop("pending")],
    taskId: "task-resume-untrusted",
  });
  assert.equal(started.ok, true);

  const scheduled: Array<() => void> = [];
  const restarted = harness({ store, journal, epoch: "epoch-b", scheduled });
  const resumed = await restarted.runner.resume("task-resume-untrusted");
  assert.equal(resumed.ok, true);
  await runScheduled(scheduled);
  await restarted.runner.idle();

  assert.equal(restarted.dispatched.length, 0);
  const task = restarted.runner.status("task-resume-untrusted");
  assert.equal(task?.state, "failed");
  assert.match(task?.error ?? "", /only for a task started from this machine/);
});

test("the peer gate fails closed with no request context, whatever the headers say", async () => {
  const spoofed = new Request("http://127.0.0.1:8080/api/tasks/start", {
    method: "POST",
    headers: {
      host: "127.0.0.1:8080",
      origin: "http://127.0.0.1:8080",
      referer: "http://127.0.0.1:8080/",
      "x-oqe-tasks": "1",
      "x-forwarded-for": "127.0.0.1",
      "x-real-ip": "127.0.0.1",
    },
  });
  const rejected = loopbackPeerRejected(spoofed);
  assert.equal(rejected?.status, 403);
  const body = (await rejected?.json()) as { error?: string } | undefined;
  assert.match(body?.error ?? "", /only available on this machine/);
});

test("both task routes gate on the peer before the handler and pass caller trust", () => {
  const startRoute = readFileSync(new URL("../routes/api/tasks.start.ts", import.meta.url), "utf8");
  const startGate = startRoute.indexOf("loopbackPeerRejected(request)");
  const startHandler = startRoute.indexOf("handleTaskStart(request, { trusted: true })");
  assert.ok(startGate > 0, "the start route must run the peer gate");
  assert.ok(startGate < startHandler, "the gate must precede the handler");
  assert.match(startRoute, /trusted: options\.trusted === true/);
  assert.match(startRoute, /trusted\?: boolean/);

  const resumeRoute = readFileSync(
    new URL("../routes/api/tasks.resume.$taskId.ts", import.meta.url),
    "utf8",
  );
  const resumeGate = resumeRoute.indexOf("loopbackPeerRejected(request)");
  const resumeCall = resumeRoute.indexOf("handleTaskResume(request, String(");
  assert.ok(resumeGate > 0, "the resume route must run the peer gate");
  assert.ok(resumeGate < resumeCall, "the gate must precede the handler");
  assert.match(resumeRoute, /trusted: options\.trusted === true/);
  assert.match(resumeRoute, /trusted\?: boolean/);
});

test("the dispatcher cannot be reached before the trust guard, and token retrieval stays inside it", () => {
  const runner = readFileSync(new URL("./server-task-runner.server.ts", import.meta.url), "utf8");
  const guard = runner.indexOf('if (effect.kind === "desktop" && !trusted)');
  const dispatch = runner.indexOf("const result = await dispatch(effect");
  const dispatcher = runner.indexOf("async function dispatchServerTaskEffect(");
  const tokenRead = runner.indexOf("const token = companionToken()");
  assert.ok(guard > 0, "the dispatch trust guard must exist");
  assert.ok(guard < dispatch, "the guard must run before dispatch");
  assert.equal(
    (runner.match(/const token = companionToken\(\)/g) ?? []).length,
    1,
    "the token is retrieved in exactly one place",
  );
  assert.ok(dispatcher > 0 && tokenRead > dispatcher, "token retrieval stays inside the dispatcher");
});
