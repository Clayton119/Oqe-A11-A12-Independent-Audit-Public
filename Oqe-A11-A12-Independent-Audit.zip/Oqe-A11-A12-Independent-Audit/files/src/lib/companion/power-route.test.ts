import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { describe, it } from "node:test";

const here = dirname(fileURLToPath(import.meta.url));
const root = join(here, "..", "..", "..");
const read = (rel: string) => readFileSync(join(root, rel), "utf8");

describe("V11 — the app owns the companion lifecycle; its token never leaves the server", () => {
  const route = read("src/routes/api/companion.$.ts");

  it("a power action that changes state is refused unless it comes from the app's own page", () => {
    assert.match(route, /entry\.method === "POST" && !fromThisApp\(request\)/);
  });

  it("a request with neither Origin nor Referer is not treated as the app's page", () => {
    assert.match(route, /if \(!referer\) return false;/);
  });

  it("the session token is injected only for requests from the app's own page", () => {
    // Prompt 58 (C): the rule moved into `bridgeToken`, which the peers test
    // exercises case by case. The route must still be the one deciding "own
    // page" and "server-held token" — and only after the peer check.
    assert.match(route, /fromApp: fromThisApp\(request\)/);
    assert.match(route, /serverToken: companionToken\(\)/);
    assert.match(route, /import \{ bridgeToken \} from "@\/lib\/companion\/bridge-token"/);
    assert.ok(
      route.indexOf("companionPeerRejected(request") < route.indexOf("fromApp: fromThisApp(request)"),
      "token injection must stay behind the TCP-peer check",
    );
  });

  it("the power branch is handled before the companion allowlist is consulted", () => {
    const power = route.indexOf('path.startsWith("/power/")');
    const allowlist = route.indexOf("if (!ALLOWED.has(path))");
    assert.ok(power > 0 && allowlist > power, "power actions must not fall through to the proxy");
  });

  it("the companion's own enable and disable routes require the supervisor marker", () => {
    const server = read("companion/server.py");
    for (const route of ["enable", "disable"]) {
      const start = server.indexOf(`@app.post("/${route}")`);
      assert.ok(start >= 0, `/${route} route exists`);
      const end = server.indexOf("\n\n@app.", start + 1);
      const body = server.slice(start, end < 0 ? undefined : end);
      assert.match(body, /x-oqe-app-request/);
      assert.match(body, /app-owned-companion-v11/);
    }
  });

  it("the token is never serialized into a response body", () => {
    const supervisor = read("src/lib/companion/supervisor.server.ts");
    assert.doesNotMatch(
      supervisor,
      /export type CompanionPower = \{[^}]*\btoken\??\s*:/s,
      "CompanionPower must not carry the token",
    );
    assert.match(supervisor, /export type CompanionPower = \{[\s\S]*?\};/);
    const shape = /export type CompanionPower = \{([\s\S]*?)\};/.exec(supervisor)?.[1] ?? "";
    // Doc comments may explain the field set; only the field declarations are checked.
    const fields = shape.replace(/\/\*\*[\s\S]*?\*\//g, "");
    assert.doesNotMatch(fields, /token/);
  });
});

describe("V11 — the release zip leaves out the local venv, logs and device probes", () => {
  const releaseZip = read("scripts/release-zip.mjs");

  it("the .venv directory is excluded wherever it appears", () => {
    assert.match(releaseZip, /"\.venv"/);
  });

  it("runtime logs and local _probe_ diagnostics are refused by name", () => {
    assert.ok(releaseZip.includes("/\\.log$/"), "runtime logs must be refused");
    assert.ok(releaseZip.includes("/^_probe_/"), "device probes must be refused");
  });
});
