/**
 * Prompt 58 (C) — which token the companion bridge sends upstream.
 *
 * Pure and total: no state, no I/O. The route calls it only after the TCP peer
 * check has passed, so the "this app's own page" branch is unreachable from a
 * network client. Keeping the rule here lets a test prove that a caller-supplied
 * token is passed through while the server-held one is only attached for a
 * same-origin call.
 */
export type BridgeTokenInput = {
  /** A token the caller sent. It is forwarded, never invented. */
  requestToken: string;
  /** True when Origin/Referer match the address this request was sent to. */
  fromApp: boolean;
  /** The app's own paired-companion token, held in server memory. */
  serverToken: string | null;
};

/** The token to attach, or "" for none. Never logs or transforms a token. */
export function bridgeToken(input: BridgeTokenInput): string {
  if (input.requestToken) return input.requestToken;
  return input.fromApp && input.serverToken ? input.serverToken : "";
}
