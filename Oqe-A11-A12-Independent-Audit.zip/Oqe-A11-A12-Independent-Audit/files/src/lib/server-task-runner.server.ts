/**
 * Prompt 27 — the SERVER TASK RUNNER.
 *
 * WHY THIS FILE EXISTS. Until now the only long-running orchestrator was the
 * browser's: `runVerifiedLoopEngine` runs inside the page, so a refresh, a
 * closed tab or a killed renderer ended the work with it. The task's *state*
 * survived (the queue and journal are durable), but nothing was left running to
 * continue it. This module is the missing half: a server-owned pump that
 * executes a task's work items and writes real progress to the local database,
 * so the browser is a viewer of a task rather than its engine.
 *
 * THE BOUNDARY, STATED PLAINLY.
 *
 *   browser: start (a plan of work items) · poll status · request cancel · resume
 *   server:  claim the task · journal before each effect · perform it · verify
 *            what can be verified · record the outcome · checkpoint progress
 *
 * Nothing in this file waits on a request. `start` returns as soon as the row
 * exists and the pump is scheduled; the browser going away cannot cancel the
 * run, because the run never holds the request's abort signal and never reads
 * whether a client is still connected. That is why a closed tab is NOT a
 * cancellation: there is no code path that could read it as one.
 *
 * THE SAFETY RULES THIS FILE MUST KEEP, and where each one lives:
 *
 *  - Journal BEFORE the side effect, fail closed. `journalStart` runs before
 *    dispatch; if it cannot land, the item is failed and NOT dispatched
 *    (`journalStartOperation` is the store's own fail-closed write).
 *  - Never replay a non-idempotent effect. An item that was `in_progress` when
 *    the process died restores as `needs_reconciliation` (task-queue's rule),
 *    is never claimable, and is resolved only by an explicit decision that
 *    consults the journal — never by "try again and hope".
 *  - An unknown outcome is reported as unknown. `needs_attention` is a distinct
 *    state from `failed` precisely because the effect may have run.
 *  - A dispatched effect is never cut in half. Cancellation is a REQUEST: the
 *    pump finishes the item it is on and cancels the rest at its next boundary.
 *  - STOP, per-target consent and the companion's execute gate are NOT
 *    re-implemented here. A desktop item is dispatched to the companion this
 *    app already started, with the app's own session token exactly as the
 *    browser bridge uses it; the companion remains the authority that can refuse
 *    (`409`) because it is stopped or the target is not consented.
 *  - One pump per task. The row carries an epoch; a pump only writes while it
 *    still holds that epoch, so a previous boot's pump (or a second one) cannot
 *    overwrite live progress or double-execute.
 *
 * NO NETWORK DEPENDENCY: the only outbound call is to the loopback companion.
 */

import type { CompanionAction } from "./companion/client.ts";
import {
  companionOrigin,
  companionToken,
  companionTouch,
  withCompanionLease,
} from "./companion/supervisor.server.ts";
import {
  claimServerTask,
  clearServerTasks,
  createServerTask,
  finishServerTask,
  isFinishedServerTaskState,
  listServerTasks,
  readServerTask,
  recoverableServerTasks,
  releaseServerTask,
  requestServerTaskCancel,
  updateServerTaskProgress,
  journalObservedOperation,
  journalReconciledOperation,
  journalSettledOperation,
  journalStartOperation,
  readOperationJournal,
  MAX_SERVER_TASK_EFFECTS_CHARS,
  MAX_STORED_SERVER_TASKS,
  type ServerTaskState,
  type StoredServerTask,
} from "./database.server.ts";
import { createId } from "./ids.ts";
import { localRequestRejected } from "./local-request-security.server.ts";
import {
  advanceLongTask,
  restoreLongTaskState,
  serializeLongTaskState,
  startLongTask,
  type LongTaskState,
} from "./long-task.ts";
import type {
  JournalEntry,
  JournalReconciliation,
  SideEffectClass,
  SideEffectOutcome,
} from "./operation-journal.ts";
import {
  authorizeRetry,
  cancelPendingTaskItems,
  claimNextTaskItem,
  completeTaskItem,
  createTaskQueue,
  failTaskItem,
  readTaskQueue,
  restoreTaskQueue,
  serializeTaskQueue,
  skipTaskItem,
  taskQueueCounts,
  MAX_TASK_ITEMS,
  type TaskItem,
  type TaskItemState,
  type TaskQueue,
} from "./task-queue.ts";

/** One desktop action may not take longer than this before it is a failure. */
export const DESKTOP_ACTION_TIMEOUT_MS = 20_000;

/**
 * How long a task row must be quiet before a later process may take it over.
 *
 * The epoch on a row is what stops a second pump from executing the same side
 * effects. But a hard restart (or a power cut) leaves the DEAD process's epoch
 * on the row, and then no later claim could ever succeed — the task would look
 * busy forever. A live runner writes progress between items and no single
 * dispatch outlives DESKTOP_ACTION_TIMEOUT_MS, so a row that is quiet for three
 * of those cannot belong to a live runner. Recovery takes exactly that much and
 * no less: an early takeover would be a second execution.
 */
export const SERVER_TASK_HANDOVER_MS = 3 * DESKTOP_ACTION_TIMEOUT_MS;

/** How many items one start request may carry (the queue's own bound). */
export const MAX_SERVER_TASK_ITEMS = MAX_TASK_ITEMS;

/** Bounds on the request's own text, so a task row cannot be a document dump. */
export const MAX_SERVER_TASK_TITLE_CHARS = 200;
export const MAX_SERVER_TASK_ITEM_LABEL_CHARS = 300;
export const MAX_SERVER_TASK_ITEM_ID_CHARS = 80;

/**
 * What one work item DOES.
 *
 * `none` is a real category, not a placeholder: it is a bookkeeping step that
 * performs no external effect (a plan record, a boundary the reader asked to
 * see). It is completed as verified because there is nothing to verify — which
 * is only honest because there is also nothing that could have gone wrong.
 *
 * `desktop` is one action in the companion's own vocabulary. It is
 * NON-idempotent by nature: a click cannot be un-clicked, so it defaults to the
 * `at-most-once` class and is never automatically repeated.
 */
export type ServerTaskEffect =
  | { kind: "none" }
  | { kind: "desktop"; action: CompanionAction };

export type ServerTaskWorkInput = {
  id: string;
  label: string;
  sideEffectClass?: SideEffectClass;
  idempotencyKey?: string;
  effect: ServerTaskEffect;
};

export type ServerTaskView = {
  id: string;
  title: string;
  state: ServerTaskState;
  stage: string;
  step: number;
  total: number | null;
  createdAt: number;
  updatedAt: number;
  startedAt: number | null;
  finishedAt: number | null;
  cancelRequestedAt: number | null;
  pauseReason: string | null;
  error: string | null;
  resumeCount: number;
  /** Real per-state counts from the restored queue — never invented numbers. */
  counts: Record<TaskItemState, number> & { total: number };
  items: Array<{
    id: string;
    label: string;
    state: TaskItemState;
    attempts: number;
    operationId: string | null;
    sideEffectClass: SideEffectClass;
    error?: string;
    result?: { verified: boolean; note?: string };
  }>;
  /** What recovery is still holding: the in-flight operation, and what is stuck. */
  recovery: {
    lastOperationId: string | null;
    needsReconciliation: string[];
    claimable: boolean;
    finished: boolean;
  };
};

export type ServerTaskStartResult =
  | { ok: true; status: "started" | "duplicate"; task: ServerTaskView }
  | { ok: false; error: string };

export type ServerTaskResumeDecision = "verify" | "skip" | "retry-authorized";

export type ServerTaskResumeResult =
  | { ok: true; task: ServerTaskView; resolved: string[]; unresolved: string[] }
  | { ok: false; error: string };

export type ServerTaskCancelResult =
  | { ok: true; status: "cancelling" | "cancelled" | "unchanged"; task: ServerTaskView }
  | { ok: false; error: string };

/**
 * The store, the journal and the companion call are all injectable. The
 * defaults are the real ones; the tests drive the same code with a fake
 * dispatcher and a temporary database, which is why the crash and recovery
 * cases can be exercised without a desktop session.
 */
export type ServerTaskStore = {
  createServerTask: typeof createServerTask;
  readServerTask: typeof readServerTask;
  claimServerTask: typeof claimServerTask;
  updateServerTaskProgress: typeof updateServerTaskProgress;
  requestServerTaskCancel: typeof requestServerTaskCancel;
  finishServerTask: typeof finishServerTask;
  releaseServerTask: typeof releaseServerTask;
  recoverableServerTasks: typeof recoverableServerTasks;
  listServerTasks: typeof listServerTasks;
  clearServerTasks: typeof clearServerTasks;
};

export type ServerTaskJournal = {
  start: (input: {
    operationId: string;
    itemId: string;
    taskId: string;
    executionId: string;
    sideEffectClass: SideEffectClass;
    idempotencyKey: string;
    now: number;
  }) => { ok: boolean; warning?: string };
  observed: (operationId: string, observationRef: string, now: number) => { ok: boolean; warning?: string };
  settled: (operationId: string, outcome: SideEffectOutcome, now: number) => { ok: boolean; warning?: string };
  reconciled: (
    operationId: string,
    reconciliation: JournalReconciliation,
    now: number,
  ) => { ok: boolean; changed?: boolean; warning?: string };
  read: () => JournalEntry[];
};

export type ServerTaskDispatchResult =
  | { ok: true; observationRef?: string; note?: string }
  | { ok: false; error: string };

export type ServerTaskDependencies = {
  now: () => number;
  epoch: string;
  owner: string;
  store: ServerTaskStore;
  journal: ServerTaskJournal;
  dispatch: (effect: ServerTaskEffect, context: { taskId: string; itemId: string; operationId: string }) => Promise<ServerTaskDispatchResult>;
  schedule: (run: () => void) => void;
  log?: (line: string) => void;
};

/* ------------------------------------------------------------------ *
 * Validation of what a start request may ask the server to do.
 * ------------------------------------------------------------------ */

const COMPANION_ACTIONS = new Set([
  "move",
  "click",
  "drag",
  "type",
  "press",
  "focus",
  "hotkey",
  "scroll",
  "wait",
  "done",
]);

function isFiniteNumber(value: unknown): value is number {
  return typeof value === "number" && Number.isFinite(value);
}

/**
 * Validate one effect. A desktop action is checked for SHAPE only: whether the
 * target is consented and whether the companion is armed are the companion's
 * decisions and stay its decisions (see the module comment). What is checked
 * here is that this build is not storing a payload it could never dispatch.
 */
export function validateServerTaskEffect(value: unknown): { ok: true; effect: ServerTaskEffect } | { ok: false; reason: string } {
  if (typeof value !== "object" || value === null || Array.isArray(value)) {
    return { ok: false, reason: "an item effect must be an object" };
  }
  const rec = value as Record<string, unknown>;
  if (rec.kind === "none") return { ok: true, effect: { kind: "none" } };
  if (rec.kind !== "desktop") {
    return { ok: false, reason: 'an item effect must be {"kind":"none"} or {"kind":"desktop","action":…}' };
  }
  if (typeof rec.action !== "object" || rec.action === null || Array.isArray(rec.action)) {
    return { ok: false, reason: "a desktop effect needs an action object" };
  }
  const action = rec.action as Record<string, unknown>;
  if (typeof action.action !== "string" || !COMPANION_ACTIONS.has(action.action)) {
    return { ok: false, reason: "that desktop action is not one this build dispatches" };
  }
  for (const field of ["x", "y", "start_x", "start_y", "end_x", "end_y", "editor_x", "editor_y", "click_x", "click_y", "ms", "settle_ms"] as const) {
    if (action[field] !== undefined && action[field] !== null && !isFiniteNumber(action[field])) {
      return { ok: false, reason: `desktop action field ${field} must be a finite number` };
    }
  }
  for (const field of ["text", "title_contains", "target_title_contains", "key", "reason", "target"] as const) {
    if (action[field] !== undefined && action[field] !== null && typeof action[field] !== "string") {
      return { ok: false, reason: `desktop action field ${field} must be text` };
    }
  }
  if (typeof action.text === "string" && action.text.length > 20_000) {
    return { ok: false, reason: "desktop action text must be at most 20000 characters" };
  }
  if (action.keys !== undefined && (!Array.isArray(action.keys) || action.keys.length > 8 || action.keys.some((key) => typeof key !== "string"))) {
    return { ok: false, reason: "desktop action keys must be a short list of strings" };
  }
  return { ok: true, effect: { kind: "desktop", action: action as CompanionAction } };
}

/** Validate the whole work plan of a start request. */
export function validateServerTaskWork(
  value: unknown,
): { ok: true; items: ServerTaskWorkInput[] } | { ok: false; reason: string } {
  if (!Array.isArray(value)) return { ok: false, reason: "items must be an array" };
  if (value.length === 0) return { ok: false, reason: "a task needs at least one work item" };
  if (value.length > MAX_SERVER_TASK_ITEMS) {
    return { ok: false, reason: `a task may carry at most ${MAX_SERVER_TASK_ITEMS} work items` };
  }
  const seen = new Set<string>();
  const items: ServerTaskWorkInput[] = [];
  for (const [index, entry] of value.entries()) {
    if (typeof entry !== "object" || entry === null || Array.isArray(entry)) {
      return { ok: false, reason: `item ${index + 1} must be an object` };
    }
    const rec = entry as Record<string, unknown>;
    const id = typeof rec.id === "string" ? rec.id.trim() : "";
    if (!id || id.length > MAX_SERVER_TASK_ITEM_ID_CHARS || !/^[A-Za-z0-9][A-Za-z0-9._-]*$/.test(id) || id.includes("..")) {
      return { ok: false, reason: `item ${index + 1} needs a stable id this build could store` };
    }
    if (seen.has(id)) return { ok: false, reason: `duplicate work item id ${JSON.stringify(id)}` };
    seen.add(id);
    const label = typeof rec.label === "string" ? rec.label.trim() : "";
    if (!label || label.length > MAX_SERVER_TASK_ITEM_LABEL_CHARS) {
      return { ok: false, reason: `item ${JSON.stringify(id)} needs a label of at most ${MAX_SERVER_TASK_ITEM_LABEL_CHARS} characters` };
    }
    if (rec.sideEffectClass !== undefined && rec.sideEffectClass !== null) {
      if (
        rec.sideEffectClass !== "at-most-once" &&
        rec.sideEffectClass !== "idempotently-retryable" &&
        rec.sideEffectClass !== "at-least-once-with-reconciliation"
      ) {
        return { ok: false, reason: `item ${JSON.stringify(id)} names a side-effect class this build does not have` };
      }
    }
    if (rec.idempotencyKey !== undefined && rec.idempotencyKey !== null && typeof rec.idempotencyKey !== "string") {
      return { ok: false, reason: `item ${JSON.stringify(id)} has a non-text idempotency key` };
    }
    const effect = validateServerTaskEffect(rec.effect);
    if (!effect.ok) {
      return { ok: false, reason: `item ${JSON.stringify(id)}: ${effect.reason}` };
    }
    items.push({
      id,
      label,
      ...(typeof rec.sideEffectClass === "string"
        ? { sideEffectClass: rec.sideEffectClass as SideEffectClass }
        : {}),
      ...(typeof rec.idempotencyKey === "string" && rec.idempotencyKey.trim()
        ? { idempotencyKey: rec.idempotencyKey.trim() }
        : {}),
      effect: effect.effect,
    });
  }
  return { ok: true, items };
}

/**
 * The gate every task route runs before touching the store.
 *
 * The runner can perform desktop actions, so its routes are the most powerful
 * thing on the loopback API. Three refusals, for three different attackers:
 *
 *  - a non-loopback host: a LAN interface or a reverse proxy cannot reach it;
 *  - a cross-site browser request: `localRequestRejected` refuses it by
 *    Origin / Referer / Sec-Fetch-Site;
 *  - a missing `x-oqe-tasks: 1` on a state-changing call: a cross-origin form
 *    cannot set a custom header, so this forces a preflight this route never
 *    approves.
 *
 * A browser tab closing is NOT a cancellation and is not visible here at all:
 * nothing in this gate or below reads a request's lifetime as a task's.
 */
export function serverTaskRequestRejected(
  request: Request,
  options: { needsHeader?: boolean } = {},
): Response | null {
  let host: string;
  try {
    host = new URL(request.url).hostname;
  } catch {
    return Response.json({ error: "The task runner could not read that request." }, { status: 400 });
  }
  if (host !== "127.0.0.1" && host !== "localhost" && host !== "::1" && host !== "[::1]") {
    return Response.json(
      { error: "The task runner is only available on this machine." },
      { status: 403 },
    );
  }
  const crossOrigin = localRequestRejected(request);
  if (crossOrigin) return crossOrigin;
  if (options.needsHeader && request.headers.get("x-oqe-tasks") !== "1") {
    return Response.json(
      { error: "This request is missing the local task header." },
      { status: 400 },
    );
  }
  return null;
}

/** Task ids are opaque and validated before they reach the store or a query. */
export const SERVER_TASK_ID_RE = /^[A-Za-z0-9][A-Za-z0-9._-]{0,80}$/;

export function isValidServerTaskId(value: unknown): value is string {
  return typeof value === "string" && SERVER_TASK_ID_RE.test(value) && !value.includes("..");
}

/* ------------------------------------------------------------------ *
 * The runner.
 * ------------------------------------------------------------------ */

/** The default store: the real local database. */
const defaultStore: ServerTaskStore = {
  createServerTask,
  readServerTask,
  claimServerTask,
  updateServerTaskProgress,
  requestServerTaskCancel,
  finishServerTask,
  releaseServerTask,
  recoverableServerTasks,
  listServerTasks,
  clearServerTasks,
};

/**
 * The default journal: the Prompt 24 store, called DIRECTLY.
 *
 * Not through the browser route. A server pump that fetched its own HTTP route
 * would depend on the server answering its own request, and would put an
 * in-process write behind a network hop that can time out. The store's own
 * functions are the same fail-closed writes the route performs, so the rule is
 * identical: `journalStartOperation` throws or refuses, and the caller does not
 * dispatch.
 */
const defaultJournal: ServerTaskJournal = {
  start: (input) => {
    try {
      journalStartOperation({
        operationId: input.operationId,
        itemId: input.itemId,
        taskId: input.taskId,
        executionId: input.executionId,
        sideEffectClass: input.sideEffectClass,
        idempotencyKey: input.idempotencyKey,
        startedAt: input.now,
      });
      return { ok: true };
    } catch (error) {
      return {
        ok: false,
        warning: `the operation journal refused the start record (${
          error instanceof Error ? error.message : String(error)
        }); the side effect must not run.`,
      };
    }
  },
  observed: (operationId, observationRef, now) => {
    try {
      journalObservedOperation({ operationId, observationRef, observedAt: now });
      return { ok: true };
    } catch (error) {
      return { ok: false, warning: error instanceof Error ? error.message : String(error) };
    }
  },
  settled: (operationId, outcome, now) => {
    try {
      journalSettledOperation({ operationId, outcome, settledAt: now });
      return { ok: true };
    } catch (error) {
      return { ok: false, warning: error instanceof Error ? error.message : String(error) };
    }
  },
  reconciled: (operationId, reconciliation, now) => {
    try {
      const result = journalReconciledOperation({ operationId, reconciliation, now });
      return {
        ok: true,
        changed: result.status === "reconciled" || result.status === "retry-authorized",
      };
    } catch (error) {
      return { ok: false, warning: error instanceof Error ? error.message : String(error) };
    }
  },
  read: () => readOperationJournal().entries,
};

/**
 * The default dispatcher: one desktop action to the companion this app started.
 *
 * Same origin, same session token the browser bridge injects server-side, no
 * new privilege and no new authorization path. The companion answers `409` when
 * it is stopped (STOP is latched there) or when the target is not consented —
 * both are surfaced as the item's failure, never retried around.
 */
async function dispatchServerTaskEffect(
  effect: ServerTaskEffect,
  context: { taskId: string; itemId: string; operationId: string },
): Promise<ServerTaskDispatchResult> {
  if (effect.kind === "none") {
    return { ok: true, observationRef: `task:${context.taskId}:${context.itemId}:no-effect` };
  }
  companionTouch();
  const token = companionToken();
  // Prompt 28 — the idle timeout must not stop the companion underneath a
  // running task. The hold is taken for exactly this action (per task and item,
  // so two tasks never share or release each other's) and released in
  // `withCompanionLease`'s `finally`, whatever the action does. The lease only
  // delays the idle stop: the token, the companion's arm state, per-target
  // consent and STOP are all unchanged, and STOP still stops it immediately.
  const leased = await withCompanionLease({
    owner: `task:${context.taskId}:item:${context.itemId}`,
    run: async (): Promise<ServerTaskDispatchResult> => {
      try {
        const response = await fetch(`${companionOrigin()}/execute`, {
          method: "POST",
          headers: {
            "content-type": "application/json",
            accept: "application/json",
            ...(token ? { "x-oqe-companion-token": token } : {}),
          },
          body: JSON.stringify(effect.action),
          signal: AbortSignal.timeout(DESKTOP_ACTION_TIMEOUT_MS),
        });
        const body = (await response.json().catch(() => ({}))) as { error?: unknown; ok?: unknown };
        if (!response.ok) {
          const message = typeof body.error === "string" ? body.error : `the companion refused the action (${response.status})`;
          return { ok: false, error: message };
        }
        return { ok: true, observationRef: `companion:execute:${effect.action.action}:${response.status}` };
      } catch (error) {
        return {
          ok: false,
          error: `the companion is unavailable: ${error instanceof Error ? error.message : String(error)}`,
        };
      }
    },
  });
  return leased.ok ? leased.value : { ok: false, error: leased.reason };
}

export type ServerTaskRunner = {
  epoch: string;
  start: (input: {
    title: string;
    items: readonly ServerTaskWorkInput[];
    taskId?: string;
    /** True only for a request that passed the TCP-peer check (Prompt 60). */
    trusted?: boolean;
  }) => Promise<ServerTaskStartResult>;
  status: (taskId: string) => ServerTaskView | null;
  list: () => ServerTaskView[];
  cancel: (taskId: string, reason?: string) => Promise<ServerTaskCancelResult>;
  resume: (
    taskId: string,
    decision?: ServerTaskResumeDecision,
    options?: { trusted?: boolean },
  ) => Promise<ServerTaskResumeResult>;
  /** Boot recovery: safe work continues, unknown work is parked for a decision. */
  recover: () => Promise<{ resumed: string[]; parked: string[] }>;
  /** Test seam: resolves when no pump is running. */
  idle: () => Promise<void>;
};

export function createServerTaskRunner(overrides: Partial<ServerTaskDependencies> = {}): ServerTaskRunner {
  const now = overrides.now ?? (() => Date.now());
  const epoch = overrides.epoch ?? createId("epoch");
  const owner = overrides.owner ?? "oqe-server";
  const store = overrides.store ?? defaultStore;
  const journal = overrides.journal ?? defaultJournal;
  const dispatch = overrides.dispatch ?? dispatchServerTaskEffect;
  const schedule = overrides.schedule ?? ((run: () => void) => { setTimeout(run, 0); });
  const log = overrides.log ?? (() => {});

  const inFlight = new Set<string>();
  const pending = new Set<Promise<void>>();
  let recoveredForEpoch = false;

  function effectsOf(task: StoredServerTask): Record<string, ServerTaskEffect> {
    try {
      const parsed = JSON.parse(task.effectsState) as Record<string, unknown>;
      if (typeof parsed !== "object" || parsed === null || Array.isArray(parsed)) return {};
      const out: Record<string, ServerTaskEffect> = {};
      for (const [id, effect] of Object.entries(parsed)) {
        const checked = validateServerTaskEffect(effect);
        if (checked.ok) out[id] = checked.effect;
      }
      return out;
    } catch {
      return {};
    }
  }

  function view(task: StoredServerTask): ServerTaskView {
    // A STATUS read, not a resume: an item that is `in_progress` right now is
    // working, not stuck. `readTaskQueue` keeps the stored states.
    const restored = readTaskQueue(task.queueState, now());
    const queue: TaskQueue | null = restored.ok ? restored.queue : null;
    const items = queue?.items ?? [];
    return {
      id: task.id,
      title: task.title,
      state: task.state,
      stage: task.stage,
      step: task.step,
      total: task.total,
      createdAt: task.createdAt,
      updatedAt: task.updatedAt,
      startedAt: task.startedAt,
      finishedAt: task.finishedAt,
      cancelRequestedAt: task.cancelRequestedAt,
      pauseReason: task.pauseReason,
      error: task.error,
      resumeCount: task.resumeCount,
      counts: queue
        ? taskQueueCounts(queue)
        : ({ ...emptyCounts(), total: 0 } as Record<TaskItemState, number> & { total: number }),
      items: items.map((item) => ({
        id: item.id,
        label: item.label,
        state: item.state,
        attempts: item.attempts,
        operationId: item.operationId,
        sideEffectClass: item.sideEffectClass,
        ...(item.error ? { error: item.error } : {}),
        ...(item.result ? { result: item.result } : {}),
      })),
      recovery: {
        lastOperationId: task.lastOperationId,
        needsReconciliation: items.filter((item) => item.state === "needs_reconciliation").map((item) => item.id),
        claimable: !isFinishedServerTaskState(task.state) && task.state !== "needs_attention",
        finished: isFinishedServerTaskState(task.state),
      },
    };
  }

  function emptyCounts(): Record<TaskItemState, number> {
    return {
      pending: 0,
      in_progress: 0,
      completed: 0,
      failed: 0,
      skipped: 0,
      retry_pending: 0,
      cancelled: 0,
      verified: 0,
      executed_unverified: 0,
      needs_reconciliation: 0,
    } as Record<TaskItemState, number>;
  }

  /** Persist the pair of documents plus the numbers the status page reports. */
  function writeProgress(input: {
    task: StoredServerTask;
    queue: TaskQueue;
    state: LongTaskState;
    stateOverride?: ServerTaskState;
    lastOperationId: string | null;
    pauseReason?: string | null;
    error?: string | null;
  }): boolean {
    const written = store.updateServerTaskProgress({
      id: input.task.id,
      epoch,
      now: now(),
      ...(input.stateOverride ? { state: input.stateOverride } : {}),
      stage: input.state.stage,
      step: input.state.step,
      total: input.state.total,
      queueState: serializeTaskQueue(input.queue),
      taskState: serializeLongTaskState(input.state),
      lastOperationId: input.lastOperationId,
      pauseReason: input.pauseReason ?? input.task.pauseReason,
      error: input.error ?? null,
    });
    if (written.status !== "updated") {
      log(`task ${input.task.id}: progress write refused (the claim is gone); the pump stops.`);
      return false;
    }
    return true;
  }

  function finish(input: {
    task: StoredServerTask;
    state: Extract<ServerTaskState, "cancelled" | "complete" | "failed" | "needs_attention">;
    queue?: TaskQueue;
    pipeline?: LongTaskState;
    pauseReason?: string | null;
    error?: string | null;
  }): void {
    store.finishServerTask({
      id: input.task.id,
      epoch,
      state: input.state,
      now: now(),
      ...(input.queue
        ? {
            queueState: serializeTaskQueue(input.queue),
            step: input.pipeline?.step,
            total: input.pipeline?.total ?? null,
            stage: input.pipeline?.stage,
            taskState: input.pipeline ? serializeLongTaskState(input.pipeline) : null,
          }
        : {}),
      pauseReason: input.pauseReason ?? null,
      error: input.error ?? null,
    });
    log(`task ${input.task.id}: finished ${input.state}${input.error ? ` — ${input.error}` : ""}`);
  }

  /**
   * Settle one item from what the JOURNAL says actually happened.
   *
   * This is the whole reconciliation rule in one place:
   *   settled+verified    → the effect is proven       → verified
   *   settled+unverified  → it ran, unproven           → executed_unverified
   *   settled+failed      → it did not complete        → failed
   *   settled+cancelled   → it was abandoned           → cancelled
   *   observed            → it ran (evidence recorded) → executed_unverified
   *   started / missing   → UNKNOWN. Nothing is assumed. The item stays
   *                         `needs_reconciliation` and the task is parked.
   */
  function settleFromJournal(
    queue: TaskQueue,
    item: TaskItem,
    decision: ServerTaskResumeDecision | undefined,
  ): { queue: TaskQueue; resolved: boolean; reason?: string } {
    const operationId = item.operationId;
    if (!operationId) {
      // No binding survived: nothing can be proven, and nothing was replayed.
      return { queue, resolved: false, reason: "the item has no operation binding to reconcile" };
    }
    const entry = journal.read().find((candidate) => candidate.operationId === operationId);
    if (decision === "skip") {
      journal.reconciled(operationId, "skipped", now());
      return { queue: skipTaskItem(queue, item.id, now()), resolved: true };
    }
    if (decision === "verify") {
      // The person checked, and it happened. That IS evidence — but it is theirs,
      // not the runner's, so it is recorded as a reconciliation decision rather
      // than as an observation the runner never made.
      const recorded = journal.reconciled(operationId, "verified", now());
      if (!recorded.ok) {
        return {
          queue,
          resolved: false,
          reason: `the journal could not record your verification: ${recorded.warning ?? "unknown reason"}`,
        };
      }
      const completed = completeTaskItem(queue, item.id, {
        verified: true,
        note: "verified by you",
        now: now(),
      });
      return { queue: completed.queue, resolved: true };
    }
    if (decision === "retry-authorized") {
      const reconciled = journal.reconciled(operationId, "retry-authorized-by-user", now());
      if (!reconciled.ok || reconciled.changed !== true) {
        // The store refused: an at-most-once operation may not be repeated in
        // place. The item stays where it is, visibly, with the reason.
        return {
          queue,
          resolved: false,
          reason: "this effect is at-most-once: the journal refuses to authorize a repeat, so it stays unresolved",
        };
      }
      return { queue: authorizeRetry(queue, item.id, now()), resolved: true };
    }
    if (!entry) {
      // Fail-closed journaling means no start record = no dispatch. That is a
      // clean failure, never a silent success and never an automatic repeat.
      const failed = failTaskItem(queue, item.id, {
        error: "the operation journal has no record of this item, so it was never dispatched",
        now: now(),
      });
      return { queue: failed.queue, resolved: true };
    }
    if (entry.phase === "settled") {
      if (entry.outcome === "verified") {
        const completed = completeTaskItem(queue, item.id, { verified: true, note: "reconciled from the operation journal", now: now() });
        return { queue: completed.queue, resolved: true };
      }
      if (entry.outcome === "unverified" || entry.outcome === "cancelled" || entry.outcome === "failed") {
        if (entry.outcome === "unverified") {
          const completed = completeTaskItem(queue, item.id, {
            verified: false,
            note: "the operation was recorded as unverified",
            now: now(),
          });
          return { queue: completed.queue, resolved: true };
        }
        if (entry.outcome === "cancelled") {
          return { queue: skipTaskItem(queue, item.id, now()), resolved: true };
        }
        const failed = failTaskItem(queue, item.id, {
          error: entry.observationRef ? "the operation failed; see its observation reference" : "the operation failed",
          now: now(),
        });
        return { queue: failed.queue, resolved: true };
      }
    }
    if (entry.phase === "observed") {
      const completed = completeTaskItem(queue, item.id, {
        verified: false,
        note: "the effect was observed but not verified",
        now: now(),
      });
      return { queue: completed.queue, resolved: true };
    }
    // `started` alone, or an entry in a phase this build cannot settle: unknown.
    return {
      queue,
      resolved: false,
      reason: `operation ${operationId} is ${entry.phase} with no recorded outcome — whether it ran is unknown`,
    };
  }

  /** Reconcile every stuck item; report what is still unknown. */
  function reconcileStuck(
    task: StoredServerTask,
    queue: TaskQueue,
    decision: ServerTaskResumeDecision | undefined,
  ): { queue: TaskQueue; resolved: string[]; unresolved: string[] } {
    let next = queue;
    const resolved: string[] = [];
    const unresolved: string[] = [];
    for (const item of queue.items) {
      if (item.state !== "needs_reconciliation") continue;
      const before = item.state;
      const result = settleFromJournal(next, item, decision);
      next = result.queue;
      const after = next.items.find((candidate) => candidate.id === item.id)?.state ?? before;
      if (result.resolved && after !== "needs_reconciliation") resolved.push(item.id);
      else unresolved.push(item.id);
    }
    void task;
    return { queue: next, resolved, unresolved };
  }

  /** The pump. One per task, scheduled — never awaited by a request. */
  async function pump(taskId: string, trusted = false): Promise<void> {
    if (inFlight.has(taskId)) return;
    inFlight.add(taskId);
    const done = (async () => {
      try {
        await runPump(taskId, trusted);
      } catch (error) {
        log(`task ${taskId}: the pump stopped on an unexpected error — ${error instanceof Error ? error.message : String(error)}`);
        const task = store.readServerTask(taskId);
        if (task && !isFinishedServerTaskState(task.state)) {
          finish({
            task,
            state: "needs_attention",
            pauseReason: `the runner stopped unexpectedly: ${error instanceof Error ? error.message : String(error)}`,
          });
        }
      } finally {
        inFlight.delete(taskId);
        store.releaseServerTask({ id: taskId, epoch, now: now() });
      }
    })();
    pending.add(done);
    void done.finally(() => pending.delete(done));
  }

  async function runPump(taskId: string, trusted: boolean): Promise<void> {
    for (;;) {
      const current = store.readServerTask(taskId);
      if (!current) return;
      if (isFinishedServerTaskState(current.state)) return;

      // A task parked for attention is NOT pumped: its in-flight effect is
      // unknown, and no automatic path may resolve it.
      if (current.state === "needs_attention") return;

      const claim = store.claimServerTask({ id: taskId, epoch, owner, now: now() });
      if (claim.status !== "claimed" || !claim.task) {
        log(`task ${taskId}: not claimable (another runner, or it finished).`);
        return;
      }
      let task = claim.task;

      const restored = restoreTaskQueue(task.queueState, now());
      if (!restored.ok) {
        finish({ task, state: "failed", error: `the stored queue could not be restored: ${restored.error}` });
        return;
      }
      let queue = restored.queue;
      const pipelineRestored = restoreLongTaskState(task.taskState);
      let pipeline: LongTaskState = pipelineRestored.ok
        ? pipelineRestored.state
        : startLongTask(task.title, { total: task.total ?? undefined });
      if (pipeline.status !== "running") {
        // A stored pipeline that finished or stopped is not resurrected.
        finish({
          task,
          state: pipeline.status === "complete" ? "complete" : pipeline.status === "stopped" ? "cancelled" : "failed",
          queue,
          pipeline,
          ...(pipeline.status === "error" ? { error: task.error ?? "the stored pipeline is in an error state" } : {}),
        });
        return;
      }

      // Cancellation boundary: no effect is in flight here, so this is where a
      // request actually takes effect.
      if (task.cancelRequestedAt !== null) {
        queue = cancelPendingTaskItems(queue, now());
        pipeline = safeAdvance(pipeline, { type: "stop" });
        finish({ task, state: "cancelled", queue, pipeline, pauseReason: task.pauseReason ?? "Cancelled at your request." });
        return;
      }

      const effects = effectsOf(task);
      const operationId = createId("op");
      const claimed = claimNextTaskItem(queue, operationId, now());
      if (!claimed.item) {
        const stuck = queue.items.filter((item) => item.state === "needs_reconciliation");
        if (stuck.length > 0) {
          finish({
            task,
            state: "needs_attention",
            queue,
            pipeline,
            pauseReason: `${stuck.length} item${stuck.length === 1 ? "" : "s"} may already have run; resume to reconcile from the journal.`,
          });
          return;
        }
        pipeline = safeAdvance(pipeline, { type: "complete" });
        finish({ task, state: "complete", queue, pipeline });
        return;
      }
      queue = claimed.queue;
      const item = claimed.item;
      const effect = effects[item.id] ?? { kind: "none" };
      const needsJournal = effect.kind !== "none";

      // Prompt 60 (F-1) — the dispatch boundary. A desktop effect is refused
      // before the journal, before `companionToken()` and before any fetch when
      // this run was not started by a request whose TCP peer was this machine.
      // The task fails closed; nothing is queued for a later retry.
      if (effect.kind === "desktop" && !trusted) {
        const error = "Desktop actions are dispatched only for a task started from this machine.";
        queue = failTaskItem(queue, item.id, { operationId, error, now: now() }).queue;
        pipeline = safeAdvance(pipeline, { type: "error" });
        finish({ task, state: "failed", queue, pipeline, error });
        return;
      }

      // The pipeline enters `execute` when the unit actually STARTS, so the step
      // the status reports counts work that began — never work that was merely
      // planned. `checkpoint` is only legal from `execute`, which is what keeps
      // the stage machine from claiming a unit that never ran.
      pipeline = safeAdvance(pipeline, { type: "execute", label: item.label });

      // JOURNAL FIRST. A side effect with no durable start record is exactly
      // the crash window the journal exists to close, so the dispatch below
      // only happens if this write landed.
      if (needsJournal) {
        const started = journal.start({
          operationId,
          itemId: item.id,
          taskId: task.id,
          executionId: epoch,
          sideEffectClass: item.sideEffectClass,
          idempotencyKey: item.idempotencyKey,
          now: now(),
        });
        if (!started.ok) {
          queue = failTaskItem(queue, item.id, {
            operationId,
            error: started.warning ?? "the operation could not be journaled",
            now: now(),
          }).queue;
          pipeline = safeAdvance(pipeline, { type: "error" });
          finish({
            task,
            state: "failed",
            queue,
            pipeline,
            error: `Not started: ${started.warning ?? "the operation could not be journaled"}`,
          });
          return;
        }
      }

      // Persist the in-flight marker BEFORE the effect. A crash from here on
      // restores this item as `needs_reconciliation`, never as claimable work.
      const marked = writeProgress({
        task,
        queue,
        state: pipeline,
        lastOperationId: operationId,
        error: null,
      });
      if (!marked) return;
      task = store.readServerTask(task.id) ?? task;

      const result = await dispatch(effect, { taskId: task.id, itemId: item.id, operationId });

      if (!result.ok) {
        if (needsJournal) {
          journal.observed(operationId, `failure:${result.error.slice(0, 400)}`, now());
          journal.settled(operationId, "failed", now());
        }
        queue = failTaskItem(queue, item.id, {
          operationId,
          error: result.error,
          // Only an idempotently-retryable effect may return to the queue by
          // itself; a desktop action never does.
          retry: item.sideEffectClass === "idempotently-retryable",
          now: now(),
        }).queue;
        pipeline = safeAdvance(pipeline, { type: "error" });
        finish({
          task,
          state: "failed",
          queue,
          pipeline,
          error: `Item ${JSON.stringify(item.id)} failed: ${result.error}`,
        });
        return;
      }

      // The effect ran. Record the observation, then settle it honestly: a
      // desktop action is EXECUTED, not verified — nothing here proves the
      // window changed, and claiming otherwise would be the lie this product
      // refuses to tell.
      if (needsJournal) {
        journal.observed(operationId, result.observationRef ?? `companion:${effect.kind}`, now());
        journal.settled(operationId, "unverified", now());
      }
      const completed = completeTaskItem(queue, item.id, {
        operationId,
        verified: effect.kind === "none",
        ...(effect.kind === "desktop"
          ? { note: "the companion accepted the action; its effect is not proven" }
          : {}),
        now: now(),
      });
      if (!completed.ok) {
        // Someone else's operation owns the item — a stale pump. Stop rather
        // than overwrite another runner's work.
        log(`task ${task.id}: ${completed.error}`);
        return;
      }
      queue = completed.queue;

      // Walk the pipeline through a REAL completed unit so the progress the
      // status reports is the stage machine's own. The server runner does not
      // compact a browser prompt window, so `compacted` is honestly 0.
      pipeline = safeAdvance(pipeline, { type: "checkpoint", label: item.label, carried: 0, compacted: 0, queueState: serializeTaskQueue(queue) }, now()) ?? pipeline;
      pipeline = safeAdvance(pipeline, { type: "context-rebuild", compacted: 0 }) ?? pipeline;
      pipeline = safeAdvance(pipeline, { type: "continue" }) ?? pipeline;

      const written = writeProgress({
        task,
        queue,
        state: pipeline,
        lastOperationId: null,
        error: null,
      });
      if (!written) return;
    }
  }

  /**
   * Advance the pipeline, tolerating a stage the restored state cannot legally
   * leave (a document written by a build with a different rhythm). The runner
   * never invents a transition: when the machine refuses, the stage simply does
   * not move and the work does.
   */
  function safeAdvance(
    state: LongTaskState,
    event: Parameters<typeof advanceLongTask>[1],
    _now?: number,
  ): LongTaskState {
    try {
      return advanceLongTask(state, event);
    } catch (error) {
      log(`pipeline: ${error instanceof Error ? error.message : String(error)}`);
      return state;
    }
  }

  async function start(input: {
    title: string;
    items: readonly ServerTaskWorkInput[];
    taskId?: string;
    /**
     * Prompt 60 (F-1) — set only by an HTTP route after it has proved the TCP
     * peer is this machine. Defaults to false everywhere else, so an internal
     * caller that cannot prove its caller cannot dispatch a desktop action.
     */
    trusted?: boolean;
  }): Promise<ServerTaskStartResult> {
    const items = [...input.items];
    if (items.length === 0) return { ok: false, error: "a task needs at least one work item" };
    if (items.length > MAX_SERVER_TASK_ITEMS) {
      return { ok: false, error: `a task may carry at most ${MAX_SERVER_TASK_ITEMS} work items` };
    }
    const title = input.title.trim().slice(0, MAX_SERVER_TASK_TITLE_CHARS) || "Long-running task";
    const taskId = input.taskId ?? createId("task");
    if (!isValidServerTaskId(taskId)) {
      return { ok: false, error: "that task id is not one this build accepts" };
    }
    // The queue engine validates ids, duplicates and the capacity, so a plan
    // that cannot be a queue is refused before a row exists.
    let queue: TaskQueue;
    try {
      queue = createTaskQueue(
        title,
        items.map((item) => ({
          id: item.id,
          label: item.label,
          ...(item.sideEffectClass ? { sideEffectClass: item.sideEffectClass } : {}),
          ...(item.idempotencyKey ? { idempotencyKey: item.idempotencyKey } : {}),
        })),
        now(),
      );
    } catch (error) {
      return { ok: false, error: error instanceof Error ? error.message : String(error) };
    }
    if (queue.items.length > MAX_SERVER_TASK_ITEMS) {
      return { ok: false, error: `a task may carry at most ${MAX_SERVER_TASK_ITEMS} work items` };
    }
    const effects: Record<string, ServerTaskEffect> = {};
    for (const item of items) effects[item.id] = item.effect;
    const effectsState = JSON.stringify(effects);
    if (effectsState.length > MAX_SERVER_TASK_EFFECTS_CHARS) {
      return { ok: false, error: "that work plan is too large to store" };
    }
    const pipeline = startLongTask(title, { total: queue.items.length });
    const created = store.createServerTask({
      id: taskId,
      title,
      queueState: serializeTaskQueue(queue),
      effectsState,
      taskState: serializeLongTaskState(pipeline),
      total: queue.items.length,
      now: now(),
    });
    if (created.status === "refused") return { ok: false, error: created.reason };
    if (created.status === "duplicate") {
      // A lost response must not start the work twice. The row that already
      // holds this id is the answer, and it is not re-scheduled here: the pump
      // that owns it (or the boot recovery) continues it.
      return { ok: true, status: "duplicate", task: view(created.task) };
    }
    schedule(() => {
      void pump(taskId, input.trusted === true);
    });
    return { ok: true, status: "started", task: view(created.task) };
  }

  function status(taskId: string): ServerTaskView | null {
    if (!isValidServerTaskId(taskId)) return null;
    const task = store.readServerTask(taskId);
    return task ? view(task) : null;
  }

  function list(): ServerTaskView[] {
    return store.listServerTasks().map(view);
  }

  async function cancel(taskId: string, reason?: string): Promise<ServerTaskCancelResult> {
    if (!isValidServerTaskId(taskId)) return { ok: false, error: "that task id is not one this build accepts" };
    const existing = store.readServerTask(taskId);
    if (!existing) return { ok: false, error: "no task has that id" };
    const requested = store.requestServerTaskCancel({ id: taskId, now: now(), ...(reason ? { reason } : {}) });
    if (!requested.task) return { ok: false, error: "no task has that id" };
    if (requested.status === "unchanged") {
      return { ok: true, status: "unchanged", task: view(requested.task) };
    }
    if (requested.status === "cancelling") {
      // A pump is (or will be) running and will stop at its next boundary. If
      // there is no pump, start one so the request is honoured now rather than
      // at the next poll.
      schedule(() => {
        void pump(taskId);
      });
    }
    return { ok: true, status: requested.status, task: view(requested.task) };
  }

  async function resume(
    taskId: string,
    decision?: ServerTaskResumeDecision,
    options: { trusted?: boolean } = {},
  ): Promise<ServerTaskResumeResult> {
    if (!isValidServerTaskId(taskId)) return { ok: false, error: "that task id is not one this build accepts" };
    const task = store.readServerTask(taskId);
    if (!task) return { ok: false, error: "no task has that id" };
    if (isFinishedServerTaskState(task.state)) {
      return { ok: false, error: `that task is already ${task.state}` };
    }
    if (inFlight.has(taskId)) {
      return { ok: false, error: "that task is running; it will continue on its own" };
    }
    const restored = restoreTaskQueue(task.queueState, now());
    if (!restored.ok) return { ok: false, error: `the stored queue could not be restored: ${restored.error}` };
    let queue = restored.queue;
    const pipelineRestored = restoreLongTaskState(task.taskState);
    let pipeline = pipelineRestored.ok ? pipelineRestored.state : startLongTask(task.title, { total: task.total ?? undefined });
    if (pipeline.status !== "running") {
      // Resume re-opens the pipeline honestly: a stopped/errored document is
      // replaced by a fresh one that keeps the real step and checkpoint counts.
      pipeline = {
        ...pipeline,
        status: "running",
        stage: pipeline.stage === "complete" ? "continue" : pipeline.stage,
      };
    }

    const reconciled = reconcileStuck(task, queue, decision);
    queue = reconciled.queue;

    const stuck = queue.items.filter((item) => item.state === "needs_reconciliation");
    if (stuck.length > 0) {
      const parked = store.finishServerTask({
        id: task.id,
        state: "needs_attention",
        now: now(),
        queueState: serializeTaskQueue(queue),
        taskState: serializeLongTaskState(pipeline),
        pauseReason: `${stuck.length} item${stuck.length === 1 ? "" : "s"} could not be reconciled from the journal; decide with verify, skip or retry-authorized.`,
      });
      return {
        ok: true,
        task: view(parked.task ?? task),
        resolved: reconciled.resolved,
        unresolved: reconciled.unresolved,
      };
    }

    // Un-pause the queue so the work is claimable again, and hand the claim to
    // a fresh pump.
    const resumed = store.claimServerTask({ id: task.id, epoch, owner, now: now() });
    if (resumed.status !== "claimed" || !resumed.task) {
      return { ok: false, error: "another runner took that task before it could resume" };
    }
    const queued = { ...queue, paused: false, updatedAt: now() };
    const written = store.updateServerTaskProgress({
      id: task.id,
      epoch,
      now: now(),
      state: task.state === "needs_attention" ? "running" : task.state,
      stage: pipeline.stage,
      step: pipeline.step,
      total: pipeline.total,
      queueState: serializeTaskQueue(queued),
      taskState: serializeLongTaskState(pipeline),
      lastOperationId: null,
      pauseReason: null,
      error: null,
    });
    if (written.status !== "updated") {
      return { ok: false, error: "the task could not be re-opened for running" };
    }
    store.releaseServerTask({ id: task.id, epoch, now: now() });
    schedule(() => {
      void pump(task.id, options.trusted === true);
    });
    return {
      ok: true,
      task: view(store.readServerTask(task.id) ?? task),
      resolved: reconciled.resolved,
      unresolved: reconciled.unresolved,
    };
  }

  /**
   * Boot recovery.
   *
   * Three cases, and the difference between them is the whole safety story:
   *
   *  1. Nothing was in flight (or only idempotent work was): restore the queue
   *     and continue. A closed tab does not change this — it never owned the
   *     work.
   *  2. An `at-most-once` effect was in flight: the item restores as
   *     `needs_reconciliation`. Ask the journal. If it can settle it, do; if
   *     not, PARK the task as `needs_attention` and do not touch the item.
   *  3. The task was already parked: leave it parked. Recovery never resolves
   *     an unknown outcome on its own.
   */
  async function recover(): Promise<{ resumed: string[]; parked: string[] }> {
    if (recoveredForEpoch) return { resumed: [], parked: [] };
    recoveredForEpoch = true;
    const resumed: string[] = [];
    const parked: string[] = [];
    for (const task of store.recoverableServerTasks()) {
      if (task.state === "needs_attention" || isFinishedServerTaskState(task.state)) {
        parked.push(task.id);
        continue;
      }
      // A row another epoch holds is a LIVE runner until it goes quiet for longer
      // than one desktop action could take. Taking it earlier would be a second
      // execution of the same side effects; never taking it would leave a task
      // killed by a hard restart stuck forever.
      const foreignHolder = task.epoch !== null && task.epoch !== epoch;
      if (foreignHolder && now() - task.updatedAt <= SERVER_TASK_HANDOVER_MS) {
        log(`recovery: ${task.id} is held by ${task.epoch}; leaving it alone.`);
        parked.push(task.id);
        continue;
      }
      const restored = restoreTaskQueue(task.queueState, now());
      if (!restored.ok) {
        finish({ task, state: "failed", error: `the stored queue could not be restored on recovery: ${restored.error}` });
        parked.push(task.id);
        continue;
      }
      const reconciled = reconcileStuck(task, restored.queue, undefined);
      if (reconciled.unresolved.length > 0) {
        store.finishServerTask({
          id: task.id,
          state: "needs_attention",
          now: now(),
          queueState: serializeTaskQueue(reconciled.queue),
          pauseReason: `${reconciled.unresolved.length} item${reconciled.unresolved.length === 1 ? "" : "s"} may already have run before the restart; resume to reconcile from the journal.`,
        });
        parked.push(task.id);
        continue;
      }
      // Everything is settleable. Claim it (taking over only a holder we have
      // already decided is dead), write the reconciled queue, then hand the claim
      // to a fresh pump — which re-claims it itself.
      const claimed = store.claimServerTask({
        id: task.id,
        epoch,
        owner,
        now: now(),
        ...(foreignHolder ? { takeover: true } : {}),
      });
      if (claimed.status !== "claimed" || !claimed.task) {
        parked.push(task.id);
        continue;
      }
      const recovering = { ...reconciled.queue, paused: false, updatedAt: now() };
      const written = store.updateServerTaskProgress({
        id: task.id,
        epoch,
        now: now(),
        state: task.state === "cancelling" ? "cancelling" : "running",
        stage: task.stage,
        step: task.step,
        total: task.total,
        queueState: serializeTaskQueue(recovering),
        taskState: task.taskState,
        lastOperationId: null,
        pauseReason: null,
        error: null,
      });
      if (written.status !== "updated") {
        parked.push(task.id);
        continue;
      }
      store.releaseServerTask({ id: task.id, epoch, now: now() });
      resumed.push(task.id);
      schedule(() => {
        void pump(task.id);
      });
    }
    if (resumed.length > 0 || parked.length > 0) {
      log(`recovery: resumed ${resumed.length}, parked ${parked.length}`);
    }
    return { resumed, parked };
  }

  async function idle(): Promise<void> {
    // Drain until nothing is in flight; a pump may schedule more work as it
    // finishes an item, so this loops rather than awaiting one snapshot.
    for (let guard = 0; guard < 200; guard += 1) {
      if (pending.size === 0) return;
      await Promise.all([...pending]);
    }
  }

  return { epoch, start, status, list, cancel, resume, recover, idle };
}

/* ------------------------------------------------------------------ *
 * The process's runner.
 * ------------------------------------------------------------------ */

let singleton: ServerTaskRunner | null = null;

/** The server process's runner (one epoch per process). */
export function serverTaskRunner(): ServerTaskRunner {
  if (!singleton) singleton = createServerTaskRunner();
  return singleton;
}

/** Test seam: forget the singleton so a test can simulate a fresh process. */
export function resetServerTaskRunnerForTest(): void {
  singleton = null;
}

/**
 * The boot hook the routes call before doing anything else: one recovery per
 * process, idempotent. A failure here is surfaced to the caller (and the route
 * reports it) rather than swallowed — a task store that cannot be read is a
 * reason to say so, not to pretend no task exists.
 */
export async function ensureServerTasksRecovered(): Promise<{ resumed: string[]; parked: string[] }> {
  return serverTaskRunner().recover();
}

export const SERVER_TASK_MAX_STORED = MAX_STORED_SERVER_TASKS;
