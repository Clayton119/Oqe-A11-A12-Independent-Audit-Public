import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { isSameOriginLocalRequest } from "./local-request-security.server.ts";

describe("local API origin gate", () => {
  it("accepts same-origin browser requests", () => {
    assert.equal(
      isSameOriginLocalRequest(
        new Request("http://127.0.0.1:8080/api/ollama/api/chat", {
          method: "POST",
          headers: { origin: "http://127.0.0.1:8080" },
        }),
      ),
      true,
    );
  });

  it("rejects cross-origin Origin and Referer requests", () => {
    assert.equal(
      isSameOriginLocalRequest(
        new Request("http://127.0.0.1:8080/api/tts/speak", {
          method: "POST",
          headers: { origin: "https://evil.example" },
        }),
      ),
      false,
    );
    assert.equal(
      isSameOriginLocalRequest(
        new Request("http://127.0.0.1:8080/api/companion/execute", {
          method: "POST",
          headers: { referer: "https://evil.example/page" },
        }),
      ),
      false,
    );
  });

  it("rejects cross-site browser fetches even when Origin is omitted", () => {
    assert.equal(
      isSameOriginLocalRequest(
        new Request("http://127.0.0.1:8080/api/ollama/api/tags", {
          headers: { "sec-fetch-site": "cross-site" },
        }),
      ),
      false,
    );
  });

  it("keeps direct local tooling without browser headers usable", () => {
    assert.equal(
      isSameOriginLocalRequest(new Request("http://127.0.0.1:8080/api/tts/status")),
      true,
    );
  });
});
