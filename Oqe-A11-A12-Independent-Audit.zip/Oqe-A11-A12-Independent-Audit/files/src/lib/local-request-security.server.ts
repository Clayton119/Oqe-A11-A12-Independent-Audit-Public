import { getRequestIP } from "@tanstack/react-start/server";

/**
 * Browser-origin gate for local process/proxy routes.
 *
 * Same-origin browser requests carry Origin or Referer. A direct local tool
 * without browser headers remains supported. Sec-Fetch-Site closes the gap for
 * browser navigations that omit Origin on a GET.
 */
export function isSameOriginLocalRequest(request: Request): boolean {
  const fetchSite = request.headers.get("sec-fetch-site")?.toLowerCase();
  if (fetchSite === "cross-site" || fetchSite === "same-site") return false;

  const requestOrigin = new URL(request.url).origin;
  const origin = request.headers.get("origin");
  if (origin) return origin === requestOrigin;

  const referer = request.headers.get("referer");
  if (referer) {
    try {
      return new URL(referer).origin === requestOrigin;
    } catch {
      return false;
    }
  }

  return true;
}

export function localRequestRejected(request: Request): Response | null {
  return isSameOriginLocalRequest(request)
    ? null
    : Response.json({ error: "Cross-origin local API requests are not allowed." }, { status: 403 });
}

/* ------------------------------------------------------------------ *
 * Prompt 58 (C) — the TCP peer, not a header.
 *
 * `Host` and `Origin` are written by the client, so neither can prove where a
 * connection came from. The peer address is read from the socket by the server
 * adapter (srvx exposes it as `request.ip`), which a client cannot choose.
 * ------------------------------------------------------------------ */

/**
 * True only for an address that can only be the same machine: 127.0.0.0/8,
 * `::1`, or the IPv4-mapped `::ffff:127.x` form. Everything else — a LAN
 * address, a private range, a link-local address, a malformed string, or no
 * address at all — is not loopback.
 */
export function isLoopbackPeer(address: string | null | undefined): boolean {
  if (typeof address !== "string") return false;
  const value = address.trim().toLowerCase();
  if (!value) return false;
  if (value === "::1" || value === "0:0:0:0:0:0:0:1") return true;
  const mapped = /^::ffff:(\d{1,3}(?:\.\d{1,3}){3})$/.exec(value);
  const v4 = mapped ? mapped[1]! : value;
  const parts = v4.split(".");
  if (parts.length !== 4) return false;
  for (const part of parts) {
    if (!/^\d{1,3}$/.test(part)) return false;
    if (Number(part) > 255) return false;
  }
  return Number(parts[0]) === 127;
}

/**
 * The decision, separated from the request so it can be tested directly.
 *
 * `allowUnknown` exists for one case: the Vite dev handler does not put a peer
 * address on the Request. Dev is covered by the bind refusal (Prompt 58 A), so
 * an unknown address there is not a remote client; in production an unknown
 * address is refused.
 */
export function peerTrustDecision(
  address: string | null | undefined,
  { allowUnknown = false }: { allowUnknown?: boolean } = {},
): boolean {
  if (address === null || address === undefined || address === "") return allowUnknown;
  return isLoopbackPeer(address);
}

/**
 * 403 for a local API request that did not arrive over loopback (Prompt 58 C,
 * shared with the task runner in Prompt 60).
 *
 * `message` names the surface; nothing about the decision reads a header.
 */
export function loopbackPeerRejected(
  request: Request,
  options: { allowUnknown?: boolean; message?: string } = {},
): Response | null {
  void request; // the peer comes from the request context, never from Host/Origin/Forwarded
  let address: string | null = null;
  try {
    address = getRequestIP({ xForwardedFor: false }) ?? null;
  } catch {
    address = null;
  }
  if (peerTrustDecision(address, options)) return null;
  return Response.json(
    { error: options.message ?? "This local API is only available on this machine." },
    { status: 403, headers: { "cache-control": "no-store" } },
  );
}

/** The companion bridge's wording of the same boundary. */
export function companionPeerRejected(
  request: Request,
  options: { allowUnknown?: boolean } = {},
): Response | null {
  return loopbackPeerRejected(request, {
    ...options,
    message: "The companion bridge is only available to this machine.",
  });
}
