# Start the installed Oqe local server without a visible console.
#
# The server is the candidate's own production build (app\server\index.mjs) run
# by the bundled node.exe. It listens on loopback only: NITRO_HOST is pinned
# here and Oqe-preflight.mjs refuses any non-loopback value before the listener
# exists (Prompt 58 A). The browser is opened only after the server answers; if
# it does not, the log is opened instead of pretending Oqe started.
[CmdletBinding()]
param([int]$Port = 0)

$ErrorActionPreference = "Stop"
Set-StrictMode -Version 2.0

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$dataDir = Join-Path $env:LOCALAPPDATA "Oqe"
$node = Join-Path $root "node\node.exe"
$entry = Join-Path $root "app\server\index.mjs"
$preflight = Join-Path $root "Oqe-preflight.mjs"
$log = Join-Path $dataDir "oqe-server.log"
$errLog = Join-Path $dataDir "oqe-server.err.log"
$pidFile = Join-Path $dataDir "oqe-server.pid"
if ($Port -le 0) {
  $Port = 8080
  if ($env:OQE_PORT) {
    $parsed = 0
    if ([int]::TryParse($env:OQE_PORT, [ref]$parsed) -and $parsed -ge 1024 -and $parsed -le 65535) { $Port = $parsed }
  }
}

function Show-Problem([string]$Message) {
  $text = @()
  $text += "Oqe could not start."
  $text += ""
  $text += $Message
  $text += ""
  $text += "Log: $log"
  $text | Set-Content -LiteralPath (Join-Path $dataDir "startup-error.txt") -Encoding UTF8
  Start-Process -FilePath "notepad.exe" -ArgumentList (Join-Path $dataDir "startup-error.txt") | Out-Null
  exit 1
}

New-Item -ItemType Directory -Path $dataDir -Force | Out-Null
if (-not (Test-Path -LiteralPath $node)) { Show-Problem "The bundled Node runtime is missing at $node." }
if (-not (Test-Path -LiteralPath $entry)) { Show-Problem "The application build is missing at $entry." }
if (-not (Test-Path -LiteralPath $preflight)) { Show-Problem "The loopback preflight is missing at $preflight." }

# Already running from THIS install? Open it instead of starting a second copy.
try {
  $probe = Invoke-WebRequest -Uri ("http://127.0.0.1:$Port/") -UseBasicParsing -TimeoutSec 2
  if ($probe.StatusCode -eq 200) {
    Start-Process ("http://127.0.0.1:$Port/")
    exit 0
  }
} catch {
  # Not running (or not ours yet). Only our own recorded process may be replaced.
}

if (Test-Path -LiteralPath $pidFile) {
  $recorded = (Get-Content -LiteralPath $pidFile -Raw).Trim()
  $recordedPid = 0
  if ([int]::TryParse($recorded, [ref]$recordedPid)) {
    $existing = Get-Process -Id $recordedPid -ErrorAction SilentlyContinue
    $existingPath = ""
    if ($existing) { try { $existingPath = $existing.Path } catch { $existingPath = "" } }
    if ($existing -and $existingPath -and $existingPath.StartsWith($root, [StringComparison]::OrdinalIgnoreCase)) {
      Stop-Process -Id $recordedPid -Force -ErrorAction SilentlyContinue
      Start-Sleep -Milliseconds 400
    }
  }
  Remove-Item -LiteralPath $pidFile -Force -ErrorAction SilentlyContinue
}

# The server's own stdout/stderr go to the log; no console is shown to the user.
$env:OQE_APP_ROOT = $root
$env:NODE_ENV = "production"
$env:PORT = "$Port"
$env:NITRO_PORT = "$Port"
$env:NITRO_HOST = "127.0.0.1"
Remove-Item Env:NODE_OPTIONS -ErrorAction SilentlyContinue

# --import runs Oqe-preflight.mjs before the server module, so a non-loopback
# NITRO_HOST/HOST fails here instead of exposing the unauthenticated app.
$preflightUrl = ([System.Uri]$preflight).AbsoluteUri
$server = Start-Process -FilePath $node -ArgumentList @("--import", "`"$preflightUrl`"", "`"$entry`"") -WorkingDirectory $root `
  -WindowStyle Hidden -PassThru -RedirectStandardOutput $log -RedirectStandardError $errLog
if (-not $server) { Show-Problem "The server process could not be created." }
Set-Content -LiteralPath $pidFile -Value $server.Id -Encoding ASCII

$deadline = (Get-Date).AddSeconds(60)
while ((Get-Date) -lt $deadline) {
  if ($server.HasExited) {
    $tail = ""
    if (Test-Path -LiteralPath $log) { $tail = (Get-Content -LiteralPath $log -Tail 20) -join "`r`n" }
    Show-Problem ("The server exited with code " + $server.ExitCode + ".`r`n`r`n" + $tail)
  }
  try {
    $response = Invoke-WebRequest -Uri ("http://127.0.0.1:$Port/") -UseBasicParsing -TimeoutSec 2
    if ($response.StatusCode -eq 200) {
      Start-Process ("http://127.0.0.1:$Port/")
      exit 0
    }
  } catch {
    Start-Sleep -Milliseconds 700
  }
}

Show-Problem ("The server did not answer on http://127.0.0.1:$Port/ within 60 seconds.")
