/**
 * Prompt 58 (A) — the one rule that decides whether Oqe may bind here.
 *
 * Oqe is local-first and has no accounts. Its only network boundary is the
 * listening address, so the address is validated before it is used:
 *
 *   - `127.0.0.0/8`, `localhost`, `::1` and the IPv4-mapped `::ffff:127.x` form
 *     are loopback;
 *   - anything else is refused, including `0.0.0.0`, `::`, `true` (Vite's
 *     "all interfaces"), a single LAN address, and an unrecognised hostname;
 *   - an *absent* host means "the framework's own localhost default" and is
 *     allowed for the dev/preview config, but never for the bundled server,
 *     whose generated entry treats an absent host as "listen everywhere".
 *
 * Pure functions only: no `process`, no I/O. The Vite config, the preflight and
 * the tests all import this file, so the policy cannot drift between them.
 */

/** Trim, lowercase and strip IPv6 brackets. Returns null for "not set". */
export function normalizeHost(value) {
  if (value === undefined || value === null) return null;
  if (typeof value !== "string") return value;
  const text = value.trim().toLowerCase();
  if (!text) return null;
  return text.startsWith("[") && text.endsWith("]") ? text.slice(1, -1) : text;
}

/** True only for addresses that can only be reached from this machine. */
export function isLoopbackHost(value) {
  const host = normalizeHost(value);
  // A non-string (Vite's bare `--host` is boolean `true`) is never a host. The
  // refusal is thrown by `assertLoopbackBind`; this keeps a direct call safe.
  if (typeof host !== "string") return false;
  if (host === "localhost") return true;
  if (host === "::1" || host === "0:0:0:0:0:0:0:1") return true;
  const mapped = /^::ffff:(\d{1,3}(?:\.\d{1,3}){3})$/.exec(host);
  const v4 = mapped ? mapped[1] : host;
  const parts = v4.split(".");
  if (parts.length !== 4) return false;
  for (const part of parts) {
    if (!/^\d{1,3}$/.test(part)) return false;
    if (Number(part) > 255) return false;
  }
  return Number(parts[0]) === 127;
}

/**
 * The address the bundled server will actually use. Its generated entry reads
 * `NITRO_HOST || HOST`; when neither is set Node would listen on every
 * interface, so the product default is applied here instead.
 */
export function bundleBindHost(env = {}) {
  const configured = normalizeHost(env.NITRO_HOST) ?? normalizeHost(env.HOST);
  return configured ?? "127.0.0.1";
}

/** A container for a refused configuration, so callers can print one sentence. */
export class LoopbackBindError extends Error {
  constructor(message) {
    super(message);
    this.name = "LoopbackBindError";
  }
}

/**
 * Returns the host to use, or throws. `where` names the surface in the message.
 * An unset value is allowed only when `allowUnset` is true (dev/preview, where
 * the framework itself defaults to localhost).
 */
export function assertLoopbackBind(value, where, { allowUnset = false } = {}) {
  // Vite maps a bare `--host` to boolean `true` ("all interfaces"). It must be
  // refused with the policy message, not a `.split` TypeError, and `allowUnset`
  // must never turn it into "the framework's localhost default".
  if (typeof value === "boolean") {
    throw new LoopbackBindError(
      value
        ? `${where} refuses a bare --host: it means all interfaces. Oqe is local-first and has no ` +
            `accounts, so pass an explicit loopback address instead (--host 127.0.0.1).`
        : `${where} refuses the boolean host value "${String(value)}". Pass an explicit loopback address ` +
            `(127.0.0.1, localhost or ::1).`,
    );
  }
  if (value !== undefined && value !== null && typeof value !== "string") {
    throw new LoopbackBindError(
      `${where} refuses a ${typeof value} host value. Oqe is local-first and has no accounts, so pass ` +
        `an explicit loopback address (127.0.0.1, localhost or ::1).`,
    );
  }
  const host = normalizeHost(value);
  if (host === null) {
    if (allowUnset) return null;
    throw new LoopbackBindError(
      `${where} must name a loopback address (127.0.0.1, localhost or ::1); it was not set.`,
    );
  }
  if (!isLoopbackHost(host)) {
    throw new LoopbackBindError(
      `${where} refuses to bind to "${host}". Oqe is local-first and has no accounts: ` +
        `only 127.0.0.1, localhost or ::1 are allowed. LAN access is not supported.`,
    );
  }
  return host;
}
