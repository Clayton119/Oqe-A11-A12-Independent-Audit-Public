/**
 * Prompt 50 — the installer candidate's promises, tested without building it.
 *
 * These are source and policy checks. They cannot prove that a clean Windows
 * account installs and launches (that is QA-ON-DEVICE.md), but they do prove the
 * payload is a fixed list, the paths cannot escape it, the install is per-user,
 * user data is preserved, and the launch/stop scripts touch only this install.
 */
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import path from "node:path";
import test from "node:test";
import { fileURLToPath } from "node:url";

import {
  INSTALLER_FILES,
  PACKAGED_ENTRY_GUARD,
  assertSafeRelativePath,
  candidateName,
  guardPackagedEntry,
  isForbiddenPayloadPath,
  payloadPlan,
  renderSed,
  versionFromSource,
} from "./installer-lib.mjs";

const repo = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const read = (rel) => readFileSync(path.join(repo, rel), "utf8");

const version = versionFromSource(read("companion/version.py"));

test("the packaged version is the one the current docs name", () => {
  assert.match(version, /^\d+\.\d+(\.\d+)?$/);
  const current = read("CURRENT.md");
  assert.ok(current.includes(`Oqe-V${version}.zip`), "CURRENT.md names the release archive to build");
  assert.ok(current.includes(`RELEASE-V${version}.sha256`), "CURRENT.md names the checksum sidecar");
  assert.ok(read("README.md").includes(`AUDIT-V${version}.md`), "README.md points at the audit");
});

test("the candidate name carries the version and says candidate", () => {
  assert.equal(candidateName("11.1"), "Oqe-Setup-V11.1-candidate.exe");
  assert.throws(() => candidateName("11.1; rm -rf"), /invalid version/);
  assert.throws(() => candidateName("../../x"), /invalid version/);
});

test("payload paths cannot escape, name a device, or smuggle user data", () => {
  assert.equal(assertSafeRelativePath("app/server/index.mjs"), "app/server/index.mjs");
  for (const bad of [
    "../secrets.txt",
    "app/../../x",
    "C:/Windows/system32/x",
    "/etc/passwd",
    "app\\server\\index.mjs",
    "app/.env",
    "node_modules/react/index.js",
    ".git/config",
    "companion/.venv/Scripts/python.exe",
    "voices/Clayton/ref.wav",
    "oqe.sqlite",
  ]) {
    assert.equal(isForbiddenPayloadPath(bad), true, `${bad} must be refused`);
  }
});

test("the payload is an explicit list, not a wildcard of the repo", () => {
  const plan = payloadPlan({
    version,
    nodeExe: "C:/Program Files/nodejs/node.exe",
    companionDist: "companion/dist/OqeCompanion",
  });
  assert.equal(plan.version, version);
  assert.deepEqual(
    plan.dirs.map((dir) => dir.to).sort(),
    ["app", "companion/OqeCompanion"],
  );
  assert.deepEqual(
    plan.files.map((file) => file.to).sort(),
    [
      ...INSTALLER_FILES,
      "loopback-bind.mjs",
      "Oqe-preflight.mjs",
      "README-Windows.md",
      "companion/README.md",
    ].sort(),
  );
  assert.equal(plan.marker.text.trim(), version);
  assert.ok(!JSON.stringify(plan).includes("node_modules"));
  assert.ok(!JSON.stringify(plan).includes(".venv"));
});

test("the packaged entry loads the loopback preflight before any server code", () => {
  assert.equal(guardPackagedEntry("globalThis.x = 1;\n"), `${PACKAGED_ENTRY_GUARD}\nglobalThis.x = 1;\n`);
  // A shebang, if one ever appears, stays first for the launcher.
  assert.equal(
    guardPackagedEntry("#!/usr/bin/env node\nstart();\n"),
    `#!/usr/bin/env node\n${PACKAGED_ENTRY_GUARD}\nstart();\n`,
  );
  // Repackaging must not stack guards, and a different preflight reference is
  // refused rather than silently accepted.
  const once = guardPackagedEntry("start();\n");
  assert.equal(guardPackagedEntry(once), once);
  assert.equal(once.split(PACKAGED_ENTRY_GUARD).length - 1, 1);
  assert.throws(
    () => guardPackagedEntry('import "../Oqe-preflight.mjs";\n'),
    /different preflight path/,
  );
  assert.throws(() => guardPackagedEntry(""), /entry is empty/);

  const build = read("scripts/build-installer.mjs");
  assert.match(build, /guardPackagedEntry\(readFileSync\(entryPath/);
  assert.match(build, /writeFileSync\(entryPath, guardPackagedEntry/);
  assert.match(build, /missing Oqe-preflight\.mjs/);
  assert.match(build, /did not take the loopback preflight guard/);
  // The guard must be applied before the payload is zipped.
  assert.ok(
    build.indexOf("guardPackagedEntry") < build.indexOf("payload.zip"),
    "the entry is guarded before packaging",
  );
});

test("the IExpress definition is generated from the version and stage folder", () => {
  const sed = renderSed({
    version,
    targetExe: `C:\\out\\${candidateName(version)}`,
    sourceDir: "C:\\stage",
    files: ["install.cmd", "install.ps1", "payload.zip"],
  });
  assert.match(sed, /^Class=IEXPRESS$/m);
  assert.match(sed, new RegExp(`TargetName=C:\\\\out\\\\Oqe-Setup-V${version}-candidate\\.exe`));
  assert.match(sed, /AppLaunched=install\.cmd/);
  assert.match(sed, /TargetName=%TargetName%/, "IExpress options reference [Strings]");
  assert.match(sed, /AppLaunched=%AppLaunched%/, "IExpress options reference [Strings]");
  assert.match(sed, new RegExp(`FriendlyName=Oqe ${version} Setup Candidate`));
  assert.match(sed, /SourceFiles0=C:\\stage/);
  assert.match(sed, /FILE0="install\.cmd"/);
  assert.match(sed, /FILE2="payload\.zip"/);
  assert.equal((sed.match(/^%FILE\d+%=$/gm) ?? []).length, 3);
  assert.throws(
    () => renderSed({ version, targetExe: "relative\\x.exe", sourceDir: "s", files: ["install.cmd"] }),
    /absolute Windows path/,
  );
});

test("install is per-user, needs no admin, and never writes Program Files", () => {
  const script = read("installer/install.ps1");
  assert.match(script, /Join-Path \$env:LOCALAPPDATA "Programs\\Oqe"/);
  assert.match(script, /HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\Oqe/);
  assert.doesNotMatch(script, /\$env:ProgramFiles/);
  assert.doesNotMatch(script, /RunAs|runas|Start-Process[^\n]*-Verb/);
  assert.match(script, /-Uninstall/);
  assert.match(script, /UninstallString/);
  assert.match(script, /Oqe\.lnk/);
  assert.match(script, /Oqe \(stop\)\.lnk/);
});

test("uninstall keeps user data unless explicitly told to delete it", () => {
  const script = read("installer/install.ps1");
  assert.match(script, /if \(\$DeleteData\)/, "deletion is behind a switch");
  assert.match(script, /Your data was kept at/, "the default reports where the data is");
  assert.match(script, /Remove-Item -LiteralPath \$DataDir -Recurse -Force/, "only -DeleteData removes it");
  // The install path itself must not remove the data directory.
  const installSection = script.slice(script.indexOf("$resolved = Resolve-Version"));
  assert.doesNotMatch(installSection, /Remove-Item -LiteralPath \$DataDir/);
});

test("launch and stop use the bundled runtime and only this install's process", () => {
  const start = read("installer/Oqe-start.ps1");
  const stop = read("installer/Oqe-stop.ps1");
  assert.match(start, /Join-Path \$root "node\\node\.exe"/);
  assert.match(start, /Join-Path \$root "app\\server\\index\.mjs"/);
  assert.match(start, /NITRO_HOST = "127\.0\.0\.1"/);
  // Prompt 58 (A): the preflight runs before the server module can listen.
  assert.match(start, /Oqe-preflight\.mjs/);
  assert.match(start, /\[System\.Uri\]\$preflight\)\.AbsoluteUri/);
  assert.match(start, /@\("--import"/);
  assert.doesNotMatch(start, /npm|install -g|npx/);
  assert.doesNotMatch(start, /OQE_DB_PATH/);
  assert.match(stop, /StartsWith\(\$root, \[StringComparison\]::OrdinalIgnoreCase\)/);
  assert.match(stop, /taskkill\.exe \/pid \$recordedPid \/T \/F/);
  assert.match(stop, /Refused:/, "a process outside this install is refused");
});

test("the builder refuses to overwrite, refuses forbidden entries, and names the preset", () => {
  const build = read("scripts/build-installer.mjs");
  assert.match(build, /already exists; pass --force/);
  assert.match(build, /OQE_NITRO_PRESET: "node-server"/);
  assert.match(build, /isForbiddenPayloadPath/);
  assert.match(build, /CURRENT\.md does not name/);
  assert.match(build, /refusing to package/);
  assert.match(build, /iexpress\.exe/);
  // IExpress must be spawned with an argument array. Through cmd.exe its quoted
  // program path is mangled, it never sees /N /Q, and it either exits 1 or opens
  // its wizard; that failure mode is silent and looks like a bad definition.
  assert.match(build, /spawnSync\(exe, args/, "IExpress runs without a shell wrapper");
  assert.doesNotMatch(build, /iexpress\.exe" \/N \/Q/, "no shell-quoted IExpress command line");
  assert.doesNotMatch(build, /release-zip\.mjs/);
  assert.doesNotMatch(build, /git push|npm publish/);
});

test("the installer entry fails loudly instead of closing silently", () => {
  const cmd = read("installer/install.cmd");
  assert.match(cmd, /if not exist "%~dp0payload\.zip"/);
  assert.match(cmd, /pause/);
  assert.match(cmd, /exit \/b %OQE_INSTALL_CODE%/);
});

test("no installer file carries a credential or a user-data path into the payload", () => {
  for (const file of ["installer/install.ps1", "installer/Oqe-start.ps1", "installer/Oqe-stop.ps1", "scripts/build-installer.mjs"]) {
    const text = read(file);
    assert.doesNotMatch(text, /api[_-]?key\s*=\s*["'][A-Za-z0-9]/i, `${file} must not embed a key`);
    assert.doesNotMatch(text, /companion-token/i, `${file} must not read the companion token`);
    assert.doesNotMatch(text, /execution-audit\.jsonl/i, `${file} must not read the audit log`);
  }
});
