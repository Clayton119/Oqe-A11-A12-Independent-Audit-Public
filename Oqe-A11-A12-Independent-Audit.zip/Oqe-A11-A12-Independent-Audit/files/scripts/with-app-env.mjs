#!/usr/bin/env node
/**
 * Run a command with `.grok/app-env.json` merged into its environment.
 *
 * `dev`, `build` and `preview` all route through this wrapper, so the dev
 * server, the built bundle and the preview server see the same `VITE_`
 * environment — a divergence that only shows up as a built-output mismatch
 * long after the fact. Anything that starts Vite directly bypasses it.
 *
 * Only `VITE_`-prefixed keys are honored: the file is a build flag carrier, not
 * a secret store, and only `VITE_` vars reach the browser anyway. A real
 * `process.env` entry always wins, so an explicit override still works.
 *
 * That precedence also means the file governs this workspace only. A deployed
 * build runs with the provider's project env, so any deployed flag is the
 * platform's, not this file's.
 *
 * Vite picks the values up because `loadEnv` prefix-matches entries already in
 * `process.env`, which is why the merge has to happen before Vite starts.
 */
import { spawn } from "node:child_process";
import { existsSync, readFileSync, realpathSync } from "node:fs";
import { constants as osConstants } from "node:os";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

export const APP_ENV_REL_PATH = ".grok/app-env.json";

const VITE_PREFIX = "VITE_";

/**
 * Parse an app-env document, keeping only `VITE_`-prefixed string entries.
 * Anything unparseable is an empty environment — a workspace without the file
 * gets no overrides.
 */
export function parseAppEnv(text) {
  let parsed;
  try {
    parsed = JSON.parse(text);
  } catch {
    return {};
  }
  if (parsed === null || typeof parsed !== "object" || Array.isArray(parsed)) return {};
  const env = {};
  for (const [key, value] of Object.entries(parsed)) {
    if (!key.startsWith(VITE_PREFIX)) continue;
    if (typeof value !== "string") continue;
    env[key] = value;
  }
  return env;
}

/** The app env recorded under `root`, or `{}` when the file is absent. */
export function readAppEnv(root) {
  try {
    return parseAppEnv(readFileSync(join(root, APP_ENV_REL_PATH), "utf8"));
  } catch {
    return {};
  }
}

/** File values under the process environment: an explicit override wins. */
export function mergeAppEnv(appEnv, processEnv) {
  return { ...appEnv, ...processEnv };
}

/**
 * Translate a child's `exit` `(code, signal)` into this process's exit status.
 *
 * Do not re-raise the signal with `process.kill(process.pid, signal)`: under
 * qemu-user (amd64 image builds on an arm host) a self-directed signal is
 * routinely delivered as SIGSEGV to the wrong process, which takes down the
 * test worker and fails the image build. `128 + signo` is what a shell reports
 * for a signal-killed command, so a cancelled `vite build` is still a failure.
 */
export function exitStatusFromChild(code, signal) {
  if (signal) {
    const signo = osConstants.signals[signal];
    return 128 + (typeof signo === "number" ? signo : 1);
  }
  return code ?? 1;
}

/** The workspace root (this file lives in `<root>/scripts/`). */
export function projectRoot() {
  return dirname(dirname(fileURLToPath(import.meta.url)));
}

/**
 * Resolve a `node_modules/.bin` command (e.g. `vite`) to the package's bin JS.
 *
 * On Windows the .bin entry is only a `vite.cmd` / `vite.ps1` shim, and modern
 * Node refuses to spawn `.cmd`/`.bat` files without a shell (older Node just
 * failed with ENOENT — the historical "spawn vite ENOENT" on this machine).
 * Running the bin's own .js under this Node avoids a shell entirely and is
 * identical on every OS: `node node_modules/vite/bin/vite.js dev ...`.
 *
 * Returns null for anything that is not a locally installed bin (absolute
 * paths, PATH executables like `node` itself — callers then spawn directly).
 */
export function nodeBinEntry(command, root = projectRoot()) {
  if (!command || command.includes("\\")) return null;
  try {
    const manifest = JSON.parse(
      readFileSync(join(root, "node_modules", command, "package.json"), "utf8"),
    );
    const bin = manifest?.bin;
    const shortName = command.startsWith("@") ? (command.split("/").pop() ?? command) : command;
    const rel = typeof bin === "string" ? bin : bin?.[command] ?? bin?.[shortName];
    if (typeof rel !== "string" || !/\.m?js$/i.test(rel)) return null;
    const entry = join(root, "node_modules", command, rel);
    return existsSync(entry) ? entry : null;
  } catch {
    // V7.6 — clean CI / non-installed workspaces: no manifest on disk is a
    // normal condition. Return null so the caller falls back to the PATH
    // command (or process.execPath) instead of crashing the test harness.
    return null;
  }
}

/**
 * The `{ file, args }` `spawn()` should run for `command`. Local bins go
 * through `process.execPath` so Windows never touches a `.cmd` shim.
 */
export function spawnPlan(command, args, root = projectRoot()) {
  const entry = nodeBinEntry(command, root);
  return entry
    ? { file: process.execPath, args: [entry, ...args] }
    : { file: command, args };
}

/**
 * Whether `moduleUrl` is the script node was asked to run.
 *
 * Both sides are resolved through symlinks: node realpaths `import.meta.url`
 * but leaves `process.argv[1]` as typed, so comparing them raw makes a CLI
 * launched through a symlinked path (`/tmp` on macOS) a silent no-op.
 */
export function isMainModule(moduleUrl) {
  const entry = process.argv[1];
  if (!entry) return false;
  try {
    return realpathSync(entry) === fileURLToPath(moduleUrl);
  } catch {
    return false;
  }
}

function main(argv) {
  const [command, ...args] = argv;
  if (!command) {
    console.error("usage: node scripts/with-app-env.mjs <command> [args…]");
    process.exit(2);
  }
  const env = mergeAppEnv(readAppEnv(projectRoot()), process.env);
  const plan = spawnPlan(command, args);
  const child = spawn(plan.file, plan.args, {
    stdio: "inherit",
    env,
    windowsHide: true,
  });
  // The dev server is long-running and is stopped by signalling this wrapper.
  for (const signal of ["SIGINT", "SIGTERM", "SIGHUP"]) {
    process.on(signal, () => child.kill(signal));
  }
  child.on("error", (err) => {
    console.error(`[with-app-env] failed to run ${command}:`, err?.message || err);
    process.exit(127);
  });
  child.on("exit", (code, signal) => {
    process.exit(exitStatusFromChild(code, signal));
  });
}

if (isMainModule(import.meta.url)) {
  main(process.argv.slice(2));
}
