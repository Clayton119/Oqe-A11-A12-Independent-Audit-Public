/**
 * Prompt 58 (A) — the bundled server's bind preflight.
 *
 * Loaded before the server module with `node --import`, so it runs before the
 * listener exists. It refuses a non-loopback configuration and, when no host
 * was configured at all, pins the product default (`127.0.0.1`) instead of
 * letting Node listen on every interface.
 */
import { assertLoopbackBind, bundleBindHost, LoopbackBindError } from "./loopback-bind.mjs";

try {
  const host = bundleBindHost(process.env);
  assertLoopbackBind(host, "The bundled Oqe server");
  process.env.NITRO_HOST = host;
  if (!process.env.HOST) process.env.HOST = host;
} catch (error) {
  const message =
    error instanceof LoopbackBindError
      ? error.message
      : `The bundled Oqe server could not validate its bind address: ${
          error instanceof Error ? error.message : String(error)
        }`;
  console.error(`[oqe] ${message}`);
  process.exit(1);
}
