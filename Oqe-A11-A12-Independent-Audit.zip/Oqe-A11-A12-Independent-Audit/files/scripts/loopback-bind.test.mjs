/**
 * Prompt 58 (A) — the bind policy, and proof that the bundled server refuses a
 * non-loopback bind before anything can listen.
 *
 * The preflight runs in a child process exactly as `package.json` loads it
 * (`node --import scripts/loopback-preflight.mjs`): a refused configuration
 * must exit non-zero, and an unset one must be pinned to loopback rather than
 * inherited from Node's "listen everywhere" default.
 */
import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { existsSync, readFileSync } from "node:fs";
import { connect } from "node:net";
import { dirname, join } from "node:path";
import test from "node:test";
import { fileURLToPath, pathToFileURL } from "node:url";

import {
  LoopbackBindError,
  assertLoopbackBind,
  bundleBindHost,
  isLoopbackHost,
  normalizeHost,
} from "./loopback-bind.mjs";

const ROOT = join(dirname(fileURLToPath(import.meta.url)), "..");
const PREFLIGHT = pathToFileURL(join(ROOT, "scripts", "loopback-preflight.mjs")).href;

/** Run the preflight in a child Node and report what it did. */
function runPreflight(env) {
  const clean = { ...process.env };
  for (const key of ["NITRO_HOST", "HOST", "OQE_DEV_HOST"]) delete clean[key];
  return spawnSync(
    process.execPath,
    ["--import", PREFLIGHT, "-e", "process.stdout.write(process.env.NITRO_HOST || '')"],
    { encoding: "utf8", env: { ...clean, ...env }, timeout: 30_000 },
  );
}

test("normalizeHost trims, lowercases, unbrackets and treats blank as unset", () => {
  assert.equal(normalizeHost(" 127.0.0.1 "), "127.0.0.1");
  assert.equal(normalizeHost("[::1]"), "::1");
  assert.equal(normalizeHost("LocalHost"), "localhost");
  assert.equal(normalizeHost(""), null);
  assert.equal(normalizeHost("   "), null);
  assert.equal(normalizeHost(undefined), null);
  assert.equal(normalizeHost(null), null);
});

test("only loopback spellings are loopback", () => {
  for (const host of [
    "127.0.0.1",
    "127.0.0.53",
    "127.255.255.254",
    "localhost",
    "LOCALHOST",
    "::1",
    "[::1]",
    "0:0:0:0:0:0:0:1",
    "::ffff:127.0.0.1",
  ]) {
    assert.equal(isLoopbackHost(host), true, `${host} should be loopback`);
  }
});

test("wildcards, LAN, link-local, public and malformed hosts are not loopback", () => {
  for (const host of [
    "0.0.0.0",
    "::",
    "[::]",
    "true", // Vite's "all interfaces"
    "192.168.1.151",
    "10.0.0.5",
    "172.16.0.9",
    "169.254.1.1",
    "8.8.8.8",
    "fe80::1",
    "::ffff:192.168.1.151",
    "127.0.0.999",
    "127.0.0",
    "127.0.0.1.5",
    "127.0.0.1.evil.example",
    "127.0.0.1:8080",
    "http://127.0.0.1",
    "",
    "   ",
    null,
    undefined,
  ]) {
    assert.equal(isLoopbackHost(host), false, `${String(host)} must not be loopback`);
  }
});

test("a LAN address is refused with a readable reason", () => {
  assert.throws(
    () => assertLoopbackBind("0.0.0.0", "The Oqe dev server"),
    (error) => {
      assert.ok(error instanceof LoopbackBindError);
      assert.equal(error.name, "LoopbackBindError");
      assert.match(error.message, /The Oqe dev server refuses to bind to "0\.0\.0\.0"/);
      assert.match(error.message, /only 127\.0\.0\.1, localhost or ::1/);
      return true;
    },
  );
});

test("a loopback bind is returned normalized", () => {
  assert.equal(assertLoopbackBind("127.0.0.1", "The Oqe dev server"), "127.0.0.1");
  assert.equal(assertLoopbackBind(" [::1] ", "The Oqe preview server"), "::1");
  assert.equal(assertLoopbackBind("localhost", "The Oqe dev server"), "localhost");
});

test("an unset host is allowed only where the framework defaults to localhost", () => {
  assert.throws(() => assertLoopbackBind(undefined, "The bundled Oqe server"), LoopbackBindError);
  assert.equal(assertLoopbackBind(undefined, "The Oqe dev server", { allowUnset: true }), null);
  assert.equal(assertLoopbackBind("", "The Oqe preview server", { allowUnset: true }), null);
});

test("a bare --host (boolean) is refused as a policy error, not a TypeError", () => {
  // Vite's `--host` with no address arrives as `true`; `isLoopbackHost` must not
  // touch it as a string.
  assert.equal(isLoopbackHost(true), false);
  assert.equal(isLoopbackHost(false), false);
  assert.throws(
    () => assertLoopbackBind(true, "The Oqe dev server", { allowUnset: true }),
    (error) => {
      assert.ok(error instanceof LoopbackBindError);
      assert.equal(error.name, "LoopbackBindError");
      assert.match(error.message, /refuses a bare --host: it means all interfaces/);
      assert.match(error.message, /--host 127\.0\.0\.1/);
      assert.doesNotMatch(error.message, /split/);
      return true;
    },
  );
  // `allowUnset` is about an absent value, never a non-string one.
  for (const value of [false, 8080, {}, []]) {
    assert.throws(
      () => assertLoopbackBind(value, "The Oqe dev server", { allowUnset: true }),
      LoopbackBindError,
      `${String(value)} must be refused`,
    );
  }
});

test("the bundled default is loopback whenever nothing is configured", () => {
  assert.equal(bundleBindHost({}), "127.0.0.1");
  assert.equal(bundleBindHost({ NITRO_HOST: "", HOST: "" }), "127.0.0.1");
  assert.equal(bundleBindHost({ NITRO_HOST: "::1" }), "::1");
  assert.equal(bundleBindHost({ HOST: "127.0.0.1" }), "127.0.0.1");
  assert.equal(bundleBindHost({ NITRO_HOST: "0.0.0.0" }), "0.0.0.0");
});

test("the preflight refuses a non-loopback bind before the server starts", () => {
  for (const env of [
    { NITRO_HOST: "0.0.0.0" },
    { HOST: "::" },
    { NITRO_HOST: "192.168.1.151" },
    { NITRO_HOST: "true" },
    { NITRO_HOST: "oqe.example.com" },
  ]) {
    const result = runPreflight(env);
    assert.equal(result.status, 1, `${JSON.stringify(env)} must exit 1, got ${result.status}`);
    assert.match(result.stderr, /\[oqe\] The bundled Oqe server refuses to bind to/);
    assert.equal(result.stdout, "", "a refused bind must not print a host");
  }
});

test("the preflight pins loopback when no host is configured", () => {
  const result = runPreflight({});
  assert.equal(result.status, 0, result.stderr);
  assert.equal(result.stdout, "127.0.0.1");
});

test("the preflight accepts loopback hosts unchanged", () => {
  for (const host of ["127.0.0.1", "::1", "localhost"]) {
    const result = runPreflight({ NITRO_HOST: host });
    assert.equal(result.status, 0, result.stderr);
    assert.equal(result.stdout, host);
  }
});

const VITE = join(ROOT, "node_modules", "vite", "bin", "vite.js");

/** Run the real dev server; it must refuse before a listener exists. */
function runVite(...args) {
  return spawnSync(process.execPath, [VITE, "dev", ...args], {
    cwd: ROOT,
    encoding: "utf8",
    timeout: 90_000,
    env: { ...process.env, OQE_DEV_HOST: "" },
  });
}

test("the vite config guards the resolved host, so a CLI override cannot bypass it", () => {
  const source = readFileSync(join(ROOT, "vite.config.ts"), "utf8");
  // `configResolved` is only honoured as a plugin hook; as a top-level config
  // key Vite ignores it and binds anyway, which is how this test was written.
  assert.match(source, /function loopbackBindPlugin\(\): Plugin/);
  assert.match(source, /name: "oqe:loopback-bind"/);
  assert.match(source, /plugins: \[[\s\S]*?loopbackBindPlugin\(\)/);
  assert.match(source, /assertLoopbackBind\(config\.server\.host, "The Oqe dev server"/);
  assert.match(source, /assertLoopbackBind\(config\.preview\.host, "The Oqe preview server"/);
  // Both served surfaces default to loopback, and both pass through the guard.
  assert.equal(source.match(/OQE_DEV_HOST \|\| "127\.0\.0\.1"/g)?.length, 2);
});

test(
  "the real dev server refuses --host and OQE_DEV_HOST non-loopback values",
  { skip: !existsSync(VITE) && "vite is not installed" },
  () => {
    for (const args of [["--host", "0.0.0.0", "--port", "8096"], ["--host", "192.168.1.151", "--port", "8096"]]) {
      const result = runVite(...args);
      assert.equal(result.status, 1, `${args.join(" ")} must exit 1`);
      assert.match(result.stderr, /refuses to bind to/);
    }
    const fromEnv = spawnSync(process.execPath, [VITE, "dev", "--port", "8096"], {
      cwd: ROOT,
      encoding: "utf8",
      timeout: 90_000,
      env: { ...process.env, OQE_DEV_HOST: "0.0.0.0" },
    });
    assert.equal(fromEnv.status, 1);
    assert.match(fromEnv.stderr, /refuses to bind to "0\.0\.0\.0"/);
  },
);

/** True only while something accepts TCP on the loopback port. */
function isListening(port) {
  return new Promise((resolve) => {
    const socket = connect({ host: "127.0.0.1", port });
    const done = (value) => {
      socket.destroy();
      resolve(value);
    };
    socket.once("connect", () => done(true));
    socket.once("error", () => done(false));
    socket.setTimeout(1_000, () => done(false));
  });
}

test(
  "the real dev server refuses a bare --host before a listener exists",
  { skip: !existsSync(VITE) && "vite is not installed" },
  async () => {
    const port = 8097;
    const result = runVite("--host", "--port", String(port));
    assert.equal(result.status, 1, "bare --host must exit 1");
    assert.match(result.stderr, /refuses a bare --host: it means all interfaces/);
    assert.match(result.stderr, /--host 127\.0\.0\.1/);
    assert.doesNotMatch(result.stderr, /TypeError/);
    assert.equal(await isListening(port), false, "a refused bind must open no listener");
  },
);

test("the installed app ships the preflight and loads it before its entrypoint", () => {
  const lib = readFileSync(join(ROOT, "scripts", "installer-lib.mjs"), "utf8");
  assert.match(lib, /\{ from: "scripts\/loopback-bind\.mjs", to: "loopback-bind\.mjs" \}/);
  assert.match(lib, /\{ from: "scripts\/loopback-preflight\.mjs", to: "Oqe-preflight\.mjs" \}/);
  const start = readFileSync(join(ROOT, "installer", "Oqe-start.ps1"), "utf8");
  assert.match(start, /\$env:NITRO_HOST = "127\.0\.0\.1"/);
  assert.match(start, /--import", "`"\$preflightUrl`"", "`"\$entry`"/);
});
