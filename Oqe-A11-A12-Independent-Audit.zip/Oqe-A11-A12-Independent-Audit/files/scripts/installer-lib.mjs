/**
 * Prompt 50 — pure helpers for the Windows installer candidate.
 *
 * Nothing here writes files or runs commands: the build script does that, and
 * these functions are what its tests can prove without building 150 MB again.
 * The rules encoded here are the packaging promises:
 *   - the payload is a fixed list, so a stray `.env`, database, voice profile or
 *     source tree cannot be swept in by a wildcard;
 *   - every staged path is relative, forward-slashed and inside the payload;
 *   - the installer target is a per-user path, never Program Files;
 *   - the candidate name carries the version and the word "candidate".
 */

export const INSTALLER_FILES = [
  "install.ps1",
  "install.cmd",
  "Oqe.vbs",
  "Oqe-stop.vbs",
  "Oqe-start.ps1",
  "Oqe-stop.ps1",
];

/** Names that must never appear in a packaged payload, at any depth. */
const FORBIDDEN_SEGMENTS = new Set([
  ".git",
  ".venv",
  "node_modules",
  ".env",
  ".env.local",
  "oqe.sqlite",
  "oqe.sqlite-wal",
  "oqe.sqlite-shm",
  "companion-token",
  "execution-audit.jsonl",
  "automation-events.json",
  "voices",
  "secrets",
]);

/**
 * Prompt 62 (A-12) — the packaged entry must load the loopback preflight before
 * any server code runs.
 *
 * The generated Nitro entry reads `NITRO_HOST || HOST` and hands it to `serve`;
 * with neither set it listens on every interface. The installer launcher already
 * passes `--import Oqe-preflight.mjs`, but a direct run of the packaged entry
 * bypassed that. A static import in the entry itself is evaluated before the
 * entry body, so the same policy runs on both paths. The specifier is relative
 * to `app/server/index.mjs`, where the payload puts the entry.
 */
export const PACKAGED_ENTRY_PREFLIGHT = "../../Oqe-preflight.mjs";
export const PACKAGED_ENTRY_GUARD = `import "${PACKAGED_ENTRY_PREFLIGHT}";`;

/**
 * Return the entry with the guard as its first statement. Idempotent, so
 * rebuilding the same stage cannot stack imports; a different preflight
 * reference is refused rather than silently duplicated.
 */
export function guardPackagedEntry(source) {
  if (typeof source !== "string" || !source.trim()) {
    throw new Error("the packaged server entry is empty");
  }
  if (source.split(/\r?\n/).includes(PACKAGED_ENTRY_GUARD)) return source;
  if (/Oqe-preflight\.mjs/.test(source)) {
    throw new Error("the packaged server entry already references a different preflight path");
  }
  const eol = source.includes("\r\n") ? "\r\n" : "\n";
  const lines = source.split(eol);
  // Keep a shebang first if the generated entry ever grows one.
  const at = lines[0]?.startsWith("#!") ? 1 : 0;
  lines.splice(at, 0, PACKAGED_ENTRY_GUARD);
  return lines.join(eol);
}

export function candidateName(version) {
  if (!/^\d+\.\d+(\.\d+)?$/.test(String(version))) {
    throw new Error(`invalid version: ${version}`);
  }
  return `Oqe-Setup-V${version}-candidate.exe`;
}

/** The exact folder/file list the payload is assembled from. */
export function payloadPlan({ version, nodeExe, companionDist }) {
  return {
    version,
    node: {
      exe: nodeExe,
      license: `${nodeExe}.LICENSE`,
    },
    dirs: [
      { from: ".output", to: "app" },
      { from: companionDist, to: "companion/OqeCompanion" },
    ],
    files: [
      ...INSTALLER_FILES.map((name) => ({ from: `installer/${name}`, to: name })),
      // Prompt 58 (A) — the bind policy and its preflight are part of the product,
      // not build-time-only tooling: the installed start script loads them before
      // the server can listen.
      { from: "scripts/loopback-bind.mjs", to: "loopback-bind.mjs" },
      { from: "scripts/loopback-preflight.mjs", to: "Oqe-preflight.mjs" },
      { from: "README-Windows.md", to: "README-Windows.md" },
      { from: "companion/README.md", to: "companion/README.md" },
    ],
    marker: { name: "version.txt", text: `${version}\n` },
  };
}

/** Reject anything that could escape the payload or name a Windows device. */
export function assertSafeRelativePath(relative) {
  const value = String(relative);
  if (!value || value.length > 240) throw new Error(`unsafe payload path: ${value}`);
  if (/[\\:]/.test(value)) throw new Error(`payload paths use forward slashes: ${value}`);
  if (/^[a-zA-Z]:/.test(value) || value.startsWith("/")) throw new Error(`absolute payload path: ${value}`);
  if (value.includes("\0")) throw new Error("payload path contains NUL");
  const parts = value.split("/");
  for (const part of parts) {
    if (!part || part === "." || part === "..") throw new Error(`payload path escapes: ${value}`);
    if (FORBIDDEN_SEGMENTS.has(part.toLowerCase())) throw new Error(`forbidden payload entry: ${value}`);
  }
  return value;
}

/** True when a staged name is one this build refuses to ship. */
export function isForbiddenPayloadPath(relative) {
  try {
    assertSafeRelativePath(relative);
    return false;
  } catch {
    return true;
  }
}

export function renderSed({ version, targetExe, sourceDir, files }) {
  if (!/^\d+\.\d+(?:\.\d+)?$/.test(String(version))) throw new Error(`invalid version: ${version}`);
  if (!/^[A-Za-z]:\\/.test(targetExe)) throw new Error("TargetName must be an absolute Windows path");
  for (const file of files) assertSafeRelativePath(file);
  const strings = files.map((file, index) => `FILE${index}="${file}"`).join("\r\n");
  const sources = files.map((_, index) => `%FILE${index}%=`).join("\r\n");
  // IExpress's own format references [Strings] values from [Options]; that is the
  // form its own wizard writes and the only one proven to build here.
  const values = [
    "InstallPrompt=",
    "DisplayLicense=",
    "FinishMessage=",
    `TargetName=${targetExe}`,
    `FriendlyName=Oqe ${version} Setup Candidate`,
    "AppLaunched=install.cmd",
    "PostInstallCmd=<None>",
    "AdminQuietInstCmd=",
    "UserQuietInstCmd=",
  ].join("\r\n");
  return [
    "[Version]",
    "Class=IEXPRESS",
    "SEDVersion=3",
    "[Options]",
    "PackagePurpose=InstallApp",
    "ShowInstallProgramWindow=1",
    "HideExtractAnimation=0",
    "UseLongFileName=1",
    "InsideCompressed=0",
    "CAB_FixedSize=0",
    "CAB_ResvCodeSigning=0",
    "RebootMode=N",
    "InstallPrompt=%InstallPrompt%",
    "DisplayLicense=%DisplayLicense%",
    "FinishMessage=%FinishMessage%",
    "TargetName=%TargetName%",
    "FriendlyName=%FriendlyName%",
    "AppLaunched=%AppLaunched%",
    "PostInstallCmd=%PostInstallCmd%",
    "AdminQuietInstCmd=%AdminQuietInstCmd%",
    "UserQuietInstCmd=%UserQuietInstCmd%",
    "SourceFiles=SourceFiles",
    "[Strings]",
    values,
    strings,
    "[SourceFiles]",
    `SourceFiles0=${sourceDir.replace(/[\\/]+$/, "")}\\`,
    "[SourceFiles0]",
    sources,
    "",
  ].join("\r\n");
}

/** Read the single version source; a missing or non-numeric value is fatal. */
export function versionFromSource(pythonSource) {
  const match = /__version__\s*=\s*["'](\d+\.\d+(?:\.\d+)?)["']/.exec(String(pythonSource));
  if (!match) throw new Error("companion/version.py has no numeric __version__");
  return match[1];
}
