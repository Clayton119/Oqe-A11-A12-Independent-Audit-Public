#!/usr/bin/env node
// The previous "test" script chained the two Node test-runner invocations
// with `&&`. Node's test runner exits non-zero for the whole glob when any
// single test fails, so one pre-existing, unrelated scripts failure silently
// short-circuited the `&&` and skipped every test in src/lib/**/*.test.ts
// entirely, on every run, including all of the gateway/settings/client tests.
// This runner executes both groups unconditionally and reports a combined,
// honest exit code.
import { spawn } from "node:child_process";

/** @param {string[]} args */
function run(args) {
  return new Promise((resolve) => {
    // Same Windows rule as with-app-env.mjs: only use a shell on win32,
    // where locally-installed CLIs are .cmd/.ps1 shims that spawn() cannot
    // exec directly. Here we invoke `node` itself (a real executable on
    // every platform), so this is almost always a no-op — kept for
    // consistency and defense in depth, not because it is required.
    // Always invoke node by absolute execPath with shell:false.
    // shell:true on Windows splits `C:\Program Files\nodejs\node.exe` on the
    // space and fails with "'C:\Program' is not recognized". The Node test
    // runner expands its own globs, so cmd.exe glob expansion is not needed.
    const child = spawn(process.execPath, args, {
      stdio: "inherit",
      shell: false,
      windowsHide: true,
    });
    child.on("close", (code) => resolve(code ?? 1));
    child.on("error", () => resolve(1));
  });
}

// V10.9 context stress — runner platform refusal and live benchmark safety.
// Prompt 7 — no skip pattern: the retired V10.9 upload builder and its stale
// expectations are gone, so every registered script test runs. Tests skip
// themselves only for an explicitly optional, unshipped agent skill.
const scriptTestsCode = await run([
  "--test",
  "scripts/**/*.test.mjs",
  "scripts/run-model-capacity-stress-local.test.mjs",
  "scripts/release-zip-policy.test.mjs",
]);
const libTestsCode = await run([
  "--experimental-strip-types",
  "--test",
  "src/lib/app-data/app-data.test.ts",
  "src/lib/app-data/readiness-schedule.test.ts",
  "src/lib/safe-url.test.ts",
  "src/lib/safe-fetch.test.ts",
  "src/lib/safe-fetch-decoded-body.test.ts",
  "src/lib/safe-fetch-composition.test.ts",
  "src/lib/local-request-security.test.ts",
  "src/routes/api/ollama.body-limit.test.ts",
  "src/routes/api/browser-attest.body-limit.test.ts",
  // Prompt 22 — the conversation store's gates (loopback, origin, header,
  // size, shape) and its one-time import contract. Unlisted = unrun.
  "src/routes/api/storage.conversations.test.ts",
  // Prompt 23 — the same gates for the durable task-queue store, plus its
  // write/consume-once/import contract. Unlisted = unrun.
  "src/routes/api/storage.task-queue.test.ts",
  // Prompt 24 — the operation-journal store's gates (loopback, origin, header,
  // size, shape) and its write/transition/import contract. Unlisted = unrun.
  "src/routes/api/storage.operation-journal.test.ts",
  // Prompt 25 — the same gates for the voice-profile metadata store, plus its
  // sample read/write contract and its path-traversal refusals. Unlisted = unrun.
  "src/routes/api/storage.voice-profiles.test.ts",
  // Prompt 26 — the same gates for saved evidence, plus its source-file
  // read/write, duplicate, trim and traversal contract. Unlisted = unrun.
  "src/routes/api/storage.evidence.test.ts",
  // Prompt 26 — the pure model behind the Evidence and Library pages: record
  // validation, provenance, bounded search and bounded recall. Unlisted = unrun.
  "src/lib/evidence-library.test.ts",
  // Prompt 27 — the server-side task runner: the browser starts, polls and
  // cancels; the server owns execution; an interrupted effect is reconciled
  // from the journal and NEVER replayed automatically. Unlisted = unrun.
  "src/lib/server-task-runner.test.ts",
  // Prompt 36 — the UNIVERSAL OUTPUT foundation: the versioned envelope, ordered
  // mixed blocks, legacy text compatibility, and the degrade-don't-break rule for
  // unknown/malformed/disabled blocks. Unlisted = unrun.
  "src/lib/universal-output.test.ts",
  // Prompt 37 — TEMPORARY MEDIA: in-memory bytes behind opaque handles, the source
  // and authorization gates, reference counting, expiry/caps and tab-close cleanup.
  // Unlisted = unrun.
  "src/lib/transient-media.test.ts",
  // Prompt 37 — the image block's view states (ready/expired/unknown/oversized/
  // blocked/failed) and the wording each one shows. Unlisted = unrun.
  "src/lib/output-image.test.ts",
  // Prompt 39 — DIAGRAM layout: deterministic stages, branch ordering, loop routing,
  // label wrapping, and the honest refusals (too many stages / too wide / empty).
  // Unlisted = unrun.
  "src/lib/diagram-layout.test.ts",
  // Prompt 39 — CHART math: axis steps and ticks, zero-based bars vs data-range
  // lines, missing values as gaps (never zero), and the supplied/computed split.
  // Unlisted = unrun.
  "src/lib/output-chart.test.ts",
  // Prompt 41 — WALKTHROUGH session: step bounds, Back never wrapping, hint and
  // answer as separate per-step reveals, total reset, and a results model that
  // reports activity without grading. No DOM, no storage. Unlisted = unrun.
  "src/lib/walkthrough.test.ts",
  // Prompt 42 — INTERACTIVE ANSWERS: nothing pre-selected, the five control kinds,
  // required/length/range/selection-count rules, and the fixed submission text that
  // can never begin with "/" (so an answer cannot become a slash command). No DOM.
  // Unlisted = unrun.
  "src/lib/interactive-output.test.ts",
  // Prompt 40 — EXECUTION POLICY: three least-privilege profiles, fixed recipes
  // (never a command string), allowlisted environment, and the refusals for unknown
  // profiles, foreign recipes, hostile file names and over-long timeouts.
  // Unlisted = unrun.
  "src/lib/execution/policy.test.ts",
  // Prompt 40 — WORKSPACE rules: name/path containment, junction and reparse-point
  // refusal, the candidate copy's exclusion list, and quota refusals. Pure decisions.
  // Unlisted = unrun.
  "src/lib/execution/workspace.test.ts",
  // Prompt 40 — EXECUTION RECORDS: credential redaction, derived success (exit 0
  // only), capped excerpts and a bounded history. Unlisted = unrun.
  "src/lib/execution/records.test.ts",
  // Prompt 40 — BACKENDS: the container argv as a boundary document (no network,
  // read-only root, no capabilities, one mount, no host PATH), the tamper checks, and
  // the rule that only an `available` probe selects a backend. No engine is installed
  // here, so nothing in this suite proves isolation. Unlisted = unrun.
  "src/lib/execution/backends.test.ts",
  // Prompt 40 — THE SERVICE: fail-closed with no boundary (no workspace, no spawn),
  // validation before the gate, deadline/cancel/output caps, always-cleanup, redacted
  // records, orphan sweep, and the candidate copy's secret exclusion. The backend in
  // most of these cases is a TEST DOUBLE, not isolation. Unlisted = unrun.
  "src/lib/execution/service.test.ts",
  // Prompt 38 — IMAGE GENERATION: a loopback-only provider adapter (discovery,
  // bounded request, byte-identical response validation) and the capability record
  // that stays UNAVAILABLE until a real generation succeeds. The transport runs
  // against an injected fetch — no socket, no engine, no download. Unlisted = unrun.
  "src/lib/image-generation.test.ts",
  // Prompt 38 — the image route's gates: no-provider refusal, loopback-only
  // endpoints, cross-origin rejection, bounded body, and the exact bytes returned
  // only after validation. Unlisted = unrun.
  "src/routes/api/images.generate.test.ts",
  // Prompt 43 — SYNTAX HIGHLIGHTING as token data: languages this build knows,
  // keywords/strings/comments/numbers, `#` in a shell word versus a comment, and a
  // hard cap that falls back to plain text. Nothing here produces markup. Unlisted = unrun.
  "src/lib/syntax-highlight.test.ts",
  // Prompt 43 — DIFF / LOG / STRUCTURED decisions: counted lines, a level that is a
  // label or nothing, `JSON.parse` inside fixed bounds, and a YAML SUBSET whose
  // refusals (anchors, tags, block scalars, flow collections, tabs, duplicate keys)
  // are data rather than exceptions. Unlisted = unrun.
  "src/lib/technical-output.test.ts",
  // Prompt 43 — the new block types' SCHEMA: diff/logs/structured validation, the
  // line and character budgets, `startLine` bounds, and the disabled-capability
  // fallback through the shared policy. Unlisted = unrun.
  "src/lib/output-technical.test.ts",
  // Prompt 43 — SAVING a block: generated plain names, base64 of the block's own
  // text, the local storage header, oversize refused before encoding, and the
  // "the store says this file is gone" check before a download is offered.
  // Unlisted = unrun.
  "src/lib/artifact-client.test.ts",
  // Prompt 44 — PROTOTYPE + SIMULATION schemas: eight primitives only (every active
  // key is dropped), the depth/size/children bounds, a model allowlist and declared
  // parameters only, the two capabilities' fallback, and a source contract proving the
  // renderers cannot inject markup, execute code or reach a network. Unlisted = unrun.
  "src/lib/output-prototype.test.ts",
  // Prompt 44 — the four simulation MODELS: determinism, input clamping, the tick
  // clamp, one finite point per period, sampling that keeps both endpoints, and
  // formatting that invents no precision. Unlisted = unrun.
  "src/lib/simulation.test.ts",
  // Prompt 36 — artifact METADATA and the file store: opaque ids, an allowlisted
  // media type, bounded size, transient expiry, save-as-a-state-change, and the
  // reported-state behaviour for missing/corrupt/truncated files. Unlisted = unrun.
  "src/lib/artifacts.test.ts",
  // Prompt 36 — the artifact route's gates (loopback, origin, storage header,
  // bounded body) and its metadata-only responses. Unlisted = unrun.
  "src/routes/api/storage.artifacts.test.ts",
  // Prompt 35 — the durable SCHEDULE: the occurrence policy (one claim, bounded
  // miss recording, no burst replay), the real SQLite store behind it
  // (idempotent claims, expiry, one-time import, bounded history) and the route
  // gate (loopback, origin, storage header). Unlisted = unrun.
  "src/lib/automation-scheduler.test.ts",
  "src/lib/automations-webhook.test.ts",
  "src/lib/request-body-limit.test.ts",
  "src/lib/storage.test.ts",
  "src/lib/conversations.test.ts",
  // Prompt 21 — the local database foundation. Unlisted = unrun, so the new
  // suite is named here rather than left to a glob nobody expands.
  "src/lib/database.test.ts",
  // V10.34 — the context meter is anchored on the runtime's own token counts
  // (prompt_eval_count / eval_count), not characters divided by four. Same
  // rule: unlisted = unrun.
  "src/lib/token-accounting.test.ts",
  "src/lib/context-optimize.test.ts",
  "src/lib/context-integrity.test.ts",
  "src/lib/context-stress.test.ts",
  "src/lib/council.test.ts",
  "src/lib/no-secrets.test.ts",
  "src/lib/gateway/endpoint.test.ts",
  "src/lib/gateway/api-key.test.ts",
  "src/lib/gateway/ollama-proxy.test.ts",
  "src/lib/gateway/local-proxy.test.ts",
  "src/lib/gateway/essay.test.ts",
  "src/lib/gateway/think.test.ts",
  "src/lib/gateway/stream.test.ts",
  "src/lib/gateway/client.test.ts",
  "src/lib/gateway/resume-run.test.ts",
  "src/lib/gateway/repetition.test.ts",
  "src/lib/gateway/calc-verify.test.ts",
  "src/lib/gateway/wiring.test.ts",
  "src/lib/gateway/model-lifecycle.test.ts",
  "src/lib/gateway/router.test.ts",
  // Prompt 30 — the gateway's own claims as acceptance checks: loopback default
  // with no key, explicit-vs-Auto routing, no remote management paths, and a
  // model list that never survives a connection-mode change.
  "src/lib/v11-model-gateway.test.ts",
  // Prompt 32 — the tool loop's policy↔dispatch seam: ladder authority over
  // write actions, stable per-effect operation ids, and a client-safe journal.
  "src/lib/v11-tool-loop.test.ts",
  "src/lib/tts/voice-profiles.test.ts",
  "src/lib/tts/voice-studio.test.ts",
  // V10.36 — the Voice studio's one ordered voice list (top row = Oqe's voice).
  "src/lib/tts/voice-order.test.ts",
  "src/lib/tts/local-router.test.ts",
  "src/lib/tts/local-client.test.ts",
  // V10.40 — the name is spoken ("oak-e"), never spelled: both engine gates
  // pass their text through spokenNameText.
  "src/lib/tts/speak-name.test.ts",
  "src/lib/tts/tts-bridge.test.ts",
  "src/lib/activity-routing.test.ts",
  "src/lib/attachments.test.ts",
  "src/lib/model-capabilities.test.ts",
  "src/lib/model-tags.test.ts",
  "src/lib/zip.test.ts",
  "src/lib/activity.test.ts",
  "src/lib/companion/client.test.ts",
  "src/lib/companion/power-route.test.ts",
  "src/lib/companion/targets.test.ts",
  "src/lib/companion/status.test.ts",
  // Prompt 28 — the task-use lease that keeps the idle timeout from stopping the
  // companion under a running task: acquisition, per-task release, the holder
  // cap, TTL bounds, stale expiry and STOP clearing every hold. Unlisted = unrun.
  "src/lib/companion/supervisor.test.ts",
  "src/lib/pairing-draft.test.ts",
  "src/lib/browse.test.ts",
  // Prompt 18 — the live-view follow rule shared by the thread and the agent
  // panel (never move a reader who scrolled up; no layout work without growth).
  "src/lib/scroll-follow.test.ts",
  "src/lib/settings.test.ts",
  "src/lib/appearance.test.ts",
  "src/lib/local-root-adoption.test.ts",
  "src/lib/media.test.ts",
  "src/lib/weather.test.ts",
  "src/lib/wall-text.test.ts",
  "src/lib/copy.test.ts",
  "src/lib/stt/session.test.ts",
  "src/lib/skills.test.ts",
  // V10.35 — per-skill Multi-agent / Thinking / Model overrides.
  "src/lib/skill-settings.test.ts",
  // V10.37 — multi-agent skills: a mission, a lead model and a roster of its
  // own, invoked by naming the skill (the trigger, or "use /test skill").
  "src/lib/multi-agent-skills.test.ts",
  "src/lib/dev-host.test.ts",
  "src/lib/v63-contract.test.ts",
  "src/lib/v64-contract.test.ts",
  "src/lib/v66-contract.test.ts",
  "src/lib/v67-contract.test.ts",
  "src/lib/v68-contract.test.ts",
  "src/lib/v69-contract.test.ts",
  "src/lib/v7-contract.test.ts",
  "src/lib/v71-contract.test.ts",
  "src/lib/v72-contract.test.ts",
  "src/lib/v783-council.test.ts",
  "src/lib/v784-orchestrator.test.ts",
  "src/lib/v73-contract.test.ts",
  "src/lib/v74-contract.test.ts",
  "src/lib/v75-contract.test.ts",
  "src/lib/v76-contract.test.ts",
  "src/lib/v76-cleanup.test.ts",
  "src/lib/v76-projector.test.ts",
  "src/lib/projector-display.test.ts",
  "src/lib/projector-modes.test.ts",
  "src/lib/projector-sync.test.ts",
  "src/lib/projector-wake.test.ts",
  // V77 — built-in skill registry/defaults, docs and independent Multi-agent UI contract.
  "src/lib/v77-contract.test.ts",
  "src/lib/v78-contract.test.ts",
  "src/lib/v79-contract.test.ts",
  "src/lib/v791-capabilities.test.ts",
  "src/lib/v791-uploads.test.ts",
  "src/lib/v792-contract.test.ts",
  "src/lib/v81-contract.test.ts",
  "src/lib/v84-p01-desktop-intent.test.ts",
  "src/lib/v85-contract.test.ts",
  "src/lib/v86-contract.test.ts",
  "src/lib/v87-contract.test.ts",
  "src/lib/v87-consent.test.ts",
  "src/lib/v89-release-provenance.test.ts",
  "src/lib/capability-ceiling.test.ts",
  "src/lib/long-task.test.ts",
  "src/lib/verified-loop.test.ts",
  "src/lib/v92-contract.test.ts",
  "src/lib/task-queue.test.ts",
  "src/lib/v96-contract.test.ts",
  "src/lib/v97-contract.test.ts",
  "src/lib/v98-contract.test.ts",
  "src/lib/context-capacity.test.ts",
  "src/lib/context-controller.test.ts",
  // V10.8 — the model-published-steps protocol (the task strip's steps are
  // the running model's own). Registered here because this runner uses an
  // explicit list: a file that is not named here is a file that never runs.
  "src/lib/model-plan.test.ts",
  "src/lib/browser-assistant.test.ts",
  "src/lib/api-route-paths.test.ts",
  "src/lib/orb-assets.test.ts",
  "src/lib/orb-morph.test.ts",
  "src/lib/v10-network-policy.test.ts",
  "src/lib/v101-contract.test.ts",
  "src/lib/operation-journal.test.ts",
  "src/lib/evidence-contract.test.ts",
  "src/lib/capability-discovery.test.ts",
  "src/lib/v102-ollama-recovery.test.ts",
  "src/lib/v104-automations.test.ts",
  "src/lib/v104-storage-cas.test.ts",
  "src/lib/v106-fixes.test.ts",
  "src/lib/v108-contract.test.ts",
  // V10.10 — the run owns its steps: the model's plan is the strip's list, the
  // reader's pencil edit is a suggestion it may replace, and the transport's
  // own rows (a queued load, the wait) are never steps at all.
  "src/lib/v1010-steps.test.ts",
  // V10.7 — the Multi-agent rework (a role states its own model; the run has
  // one led style; the agent group chat appears whenever the feature is used).
  "src/lib/v107-multi-agent.test.ts",
  // V10.31 — Multi-agent is Off / On / Auto, and Auto decides per message from
  // the shape of the task. The decision is pure, so it is tested directly; the
  // wiring (persist, consume only On, state the choice in the strip) is pinned
  // in the same file. Same rule: unlisted = unrun.
  "src/lib/multi-agent-auto.test.ts",
  // V10.33 — the LEAD PICKER: one named model chooses which existing roster
  // role leads each run, before the lead's first turn. The protocol is pure
  // (prompt, reply parsing, lead marking), so it is tested directly; the
  // store wiring and the Settings control are pinned in the same file.
  "src/lib/lead-picker.test.ts",
  // Prompt 34 — the five work profiles: their shape, the prompt turn they add,
  // the fact that General adds NOTHING, and that a profile is instructions and
  // never a capability. Unlisted = unrun.
  "src/lib/profiles.test.ts",
  "src/lib/schedule.test.ts",
  // V10.22 — a "When" automation is a webhook now, and its event queue is what
  // holds an event until the device can run it. Registered here for the same
  // reason as every file above: an unlisted file never runs.
  "src/lib/v1022-webhook-queue.test.ts",
  // V10.23 — an accepted event is written to a durable journal before the route
  // answers 202, and recovery rebuilds the queue from it. Same rule: unlisted
  // means unrun.
  "src/lib/v1023-webhook-durability.test.ts",
  // V10.24 — delivery is claim → dispatch → acknowledge, so a lost response or
  // a crash costs a lease rather than the event. Same rule: unlisted = unrun.
  "src/lib/v1024-webhook-delivery.test.ts",
  "src/lib/v1025-webhook-idempotency.test.ts",
  "src/lib/v1026-webhook-queue-full.test.ts",
  "src/lib/v1027-webhook-event-id.test.ts",
  "src/lib/webhook-delivery-state.test.ts",
  // V10.28 — one event, one execution: the lease is renewed while a task runs,
  // the acknowledgement happens after it settles, and a lapsed lease is
  // uncertain rather than silently re-run. Same rule: unlisted = unrun.
  "src/lib/v1028-webhook-execution.test.ts",
  // Prompt 45 — the GEOMETRY RECIPE schema: four primitives, units converted to
  // millimetres once, and the refuse-by-name / non-finite / absurd-size / budget
  // gates before a vertex exists. Unlisted = unrun.
  "src/lib/geometry/recipe.test.ts",
  // Prompt 45 — the MESH: real triangles with outward winding, per-shape volume and
  // manifold checks, and the builder's own budget refusal. Unlisted = unrun.
  "src/lib/geometry/mesh.test.ts",
  // Prompt 45 — EXPORT: binary STL round trip, a 3MF package read back with the same
  // zip reader the composer uses, and safe names/media types. Unlisted = unrun.
  "src/lib/geometry/export.test.ts",
  // Prompt 45 — the MESH BLOCK through the output envelope: millimetres at the boundary,
  // code/paths/URLs dropped, refusals as one readable block, and the capability switch.
  // Unlisted = unrun.
  "src/lib/output-mesh.test.ts",
  // Prompt 46 — OUTPUT SETTINGS: one independent switch per implemented renderer, text-only
  // mode, the expensive-job threshold, migration from a pre-Prompt-46 document, and proof
  // that no output switch reaches a permission. Unlisted = unrun.
  "src/lib/output-settings.test.ts",
  // Prompt 47 — SYSTEMS LAB: the both-facts gate, the four allowlisted checks, the patch
  // reader's traversal/binary/rename/size refusals, protected safety paths, and the source
  // contract that the page can only READ the executor status. Unlisted = unrun.
  "src/lib/systems-lab.test.ts",
  // Prompt 58 (C) — the companion bridge's network boundary: only a loopback TCP
  // peer is trusted, malformed/missing peers fail closed, and the server-held
  // token is attached only after that check. Unlisted = unrun.
  "src/lib/loopback-peer.test.ts",
  // Prompt 48 — APPROVAL, HISTORY AND ROLLBACK: the approval is bound to one candidate, one diff
  // and one set of check results; protected and packaged files cannot be approved; the journal
  // round-trips, stays bounded and skips a torn line; the patch store refuses unsafe ids and a
  // reused id; a rollback refuses rather than overwrite a file that changed. Unlisted = unrun.
  "src/lib/systems-lab-history.test.ts",
]);

// V9.6: the private browser extension's pure protocol core (the MV3 service
// worker imports this exact module). It is plain ESM, so it runs in the
// untransformed group alongside scripts/.
const extensionTestsCode = await run([
  "--test",
  "browser-extension/tests/**/*.test.mjs",
]);

console.log(
  `\ntest summary: scripts/**/*.test.mjs exited ${scriptTestsCode}; src/lib/**/*.test.ts exited ${libTestsCode}; browser-extension/tests/**/*.test.mjs exited ${extensionTestsCode}`,
);
if (scriptTestsCode !== 0 || libTestsCode !== 0 || extensionTestsCode !== 0) {
  process.exit(1);
}
