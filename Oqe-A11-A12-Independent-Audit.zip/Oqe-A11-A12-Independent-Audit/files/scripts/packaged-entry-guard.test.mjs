/**
 * Prompt 62 (A-12) — the packaged server entry must load the loopback
 * preflight before any server code runs.
 *
 * These tests stage a disposable payload with the real `loopback-bind.mjs` and
 * `loopback-preflight.mjs`, apply the same `guardPackagedEntry` the installer
 * build uses, and run the entry in a child process. The synthetic entry writes
 * a marker instead of opening a listener, so a rejected bind is observable
 * without exposing anything on the network.
 */
import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import {
  cpSync,
  existsSync,
  mkdirSync,
  mkdtempSync,
  readFileSync,
  rmSync,
  writeFileSync,
} from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import test from "node:test";
import { fileURLToPath } from "node:url";

import { PACKAGED_ENTRY_GUARD, guardPackagedEntry } from "./installer-lib.mjs";

const repo = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");

const INDEX = [
  'import { writeFileSync } from "node:fs";',
  'writeFileSync(process.env.OQE_TEST_MARKER, "server-code-ran");',
  'process.stdout.write("server-code-ran");',
  "",
].join("\n");

/** Build a throwaway payload shaped like the installer stage. */
function stage({ preflight = true } = {}) {
  const root = mkdtempSync(path.join(tmpdir(), "oqe-packaged-entry-"));
  mkdirSync(path.join(root, "app/server"), { recursive: true });
  cpSync(path.join(repo, "scripts/loopback-bind.mjs"), path.join(root, "loopback-bind.mjs"));
  if (preflight) {
    cpSync(path.join(repo, "scripts/loopback-preflight.mjs"), path.join(root, "Oqe-preflight.mjs"));
  }
  const entry = path.join(root, "app/server/index.mjs");
  writeFileSync(entry, guardPackagedEntry(INDEX), "utf8");
  return { root, entry, marker: path.join(root, "server-code-ran.txt") };
}

function runEntry(entry, marker, env) {
  const clean = { ...process.env };
  for (const key of ["NITRO_HOST", "HOST", "OQE_DEV_HOST"]) delete clean[key];
  return spawnSync(process.execPath, [entry], {
    cwd: path.dirname(entry),
    encoding: "utf8",
    timeout: 30_000,
    env: { ...clean, OQE_TEST_MARKER: marker, ...env },
  });
}

test("a non-loopback packaged bind is refused before the entry body runs", () => {
  const staged = stage();
  try {
    for (const env of [{ NITRO_HOST: "0.0.0.0" }, { HOST: "::" }, { NITRO_HOST: "192.168.1.151" }]) {
      const result = runEntry(staged.entry, staged.marker, env);
      assert.equal(result.status, 1, `${JSON.stringify(env)} must exit 1: ${result.stderr}`);
      assert.match(result.stderr, /The bundled Oqe server refuses to bind to/);
      assert.equal(result.stdout, "", "no server code may run");
      assert.equal(existsSync(staged.marker), false, "the entry body must not execute");
    }
  } finally {
    rmSync(staged.root, { recursive: true, force: true });
  }
});

test("a loopback packaged entry still starts", () => {
  const staged = stage();
  try {
    const result = runEntry(staged.entry, staged.marker, { NITRO_HOST: "127.0.0.1" });
    assert.equal(result.status, 0, result.stderr);
    assert.equal(result.stdout, "server-code-ran");
    assert.equal(readFileSync(staged.marker, "utf8"), "server-code-ran");
  } finally {
    rmSync(staged.root, { recursive: true, force: true });
  }
});

test("a missing preflight fails closed before the entry body runs", () => {
  const staged = stage({ preflight: false });
  try {
    const result = runEntry(staged.entry, staged.marker, { NITRO_HOST: "127.0.0.1" });
    assert.notEqual(result.status, 0, "an unloadable guard must not start the server");
    assert.match(result.stderr, /Oqe-preflight\.mjs|ERR_MODULE_NOT_FOUND/);
    assert.equal(existsSync(staged.marker), false, "the entry body must not execute");
  } finally {
    rmSync(staged.root, { recursive: true, force: true });
  }
});

test("the guard is first in the staged entry and survives repackaging", () => {
  const staged = stage();
  try {
    const once = readFileSync(staged.entry, "utf8");
    assert.ok(once.startsWith(PACKAGED_ENTRY_GUARD), "the guard is the first statement");
    const twice = guardPackagedEntry(once);
    assert.equal(twice, once);
    assert.equal(twice.split(PACKAGED_ENTRY_GUARD).length - 1, 1);
  } finally {
    rmSync(staged.root, { recursive: true, force: true });
  }
});

test(
  "the real generated entry takes the guard without changing its body",
  { skip: !existsSync(path.join(repo, ".output/server/index.mjs")) && "no .output build present" },
  () => {
    const entry = readFileSync(path.join(repo, ".output/server/index.mjs"), "utf8");
    const guarded = guardPackagedEntry(entry);
    const eol = entry.includes("\r\n") ? "\r\n" : "\n";
    assert.ok(guarded.startsWith(`${PACKAGED_ENTRY_GUARD}${eol}`));
    assert.equal(guarded.slice(PACKAGED_ENTRY_GUARD.length + eol.length), entry);
    assert.ok(guarded.includes("NITRO_HOST || process.env.HOST"), "the server body is intact");
    // The preflight path resolves from app/server/index.mjs to the payload root.
    assert.equal(
      path.resolve(path.dirname(path.join(repo, "app/server/index.mjs")), "../../Oqe-preflight.mjs"),
      path.join(repo, "Oqe-preflight.mjs"),
    );
  },
);
