/**
 * Build the Oqe Windows installer candidate (Prompt 50).
 *
 * What it produces: one self-extracting .exe that installs the app, a bundled
 * Node runtime and the frozen companion into the current user's
 * %LOCALAPPDATA%\Programs\Oqe\<version>, creates Start-menu shortcuts and an
 * uninstall entry, and leaves user data under %LOCALAPPDATA%\Oqe untouched.
 *
 * What it does NOT do: publish, replace the release ZIP, or claim the build is
 * release-ready. There is no code signing here, so Windows will show its
 * unknown-publisher prompt.
 *
 * Usage:
 *   node scripts/build-installer.mjs [--skip-app-build] [--skip-companion-build]
 *                                    [--out <dir>] [--force]
 */
import { createHash } from "node:crypto";
import { cpSync, existsSync, mkdirSync, mkdtempSync, readFileSync, readdirSync, rmSync, statSync, writeFileSync } from "node:fs";
import os from "node:os";
import path from "node:path";
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";
import {
  candidateName,
  guardPackagedEntry,
  isForbiddenPayloadPath,
  PACKAGED_ENTRY_PREFLIGHT,
  payloadPlan,
  renderSed,
  versionFromSource,
} from "./installer-lib.mjs";

const repo = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const args = new Set(process.argv.slice(2));
const skipApp = args.has("--skip-app-build");
const skipCompanion = args.has("--skip-companion-build");
const force = args.has("--force");
const outIndex = process.argv.indexOf("--out");
const outValue = outIndex > -1 ? process.argv[outIndex + 1] : undefined;
if (outIndex > -1 && !outValue) die("--out needs a directory");
const outDir = path.resolve(repo, outValue ?? "dist/installer");

function log(message) {
  process.stdout.write(`[installer] ${message}\n`);
}

function die(message) {
  process.stderr.write(`[installer] FAILED: ${message}\n`);
  process.exit(1);
}

function run(command, options = {}) {
  log(`run: ${command}`);
  const result = spawnSync(command, { shell: true, stdio: "inherit", cwd: repo, ...options });
  if (result.status !== 0) die(`${command} exited ${result.status ?? "without a status"}`);
}

/**
 * Run a Windows executable with a real argument array, never through a shell.
 *
 * IExpress has to be launched this way. Through `cmd.exe` its quoted program
 * path is mangled, so it receives neither the switches nor a usable definition,
 * exits 1, or opens its wizard and waits for a human. With argv it builds.
 */
function runExe(exe, args, options = {}) {
  log(`run: ${exe} ${args.join(" ")}`);
  const result = spawnSync(exe, args, { stdio: "inherit", cwd: repo, ...options });
  if (result.error) die(`${exe} could not start: ${result.error.message}`);
  if (result.status !== 0) die(`${exe} exited ${result.status ?? "without a status"}`);
}

function sha256(file) {
  return createHash("sha256").update(readFileSync(file)).digest("hex");
}

function dirBytes(dir) {
  let total = 0;
  for (const entry of readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    total += entry.isDirectory() ? dirBytes(full) : statSync(full).size;
  }
  return total;
}

function walk(dir, prefix = "") {
  const found = [];
  for (const entry of readdirSync(dir, { withFileTypes: true })) {
    const rel = prefix ? `${prefix}/${entry.name}` : entry.name;
    if (entry.isDirectory()) found.push(...walk(path.join(dir, entry.name), rel));
    else found.push(rel);
  }
  return found;
}

if (process.platform !== "win32") die("the installer candidate is Windows-only");

const version = versionFromSource(readFileSync(path.join(repo, "companion/version.py"), "utf8"));
const current = readFileSync(path.join(repo, "CURRENT.md"), "utf8");
if (!current.includes(`Oqe-V${version}.zip`) || !current.includes(`RELEASE-V${version}.sha256`)) {
  die(`CURRENT.md does not name the ${version} artifacts; refusing to package a version the docs disagree with`);
}
const readme = readFileSync(path.join(repo, "README.md"), "utf8");
if (!readme.includes(`AUDIT-V${version}.md`)) {
  die(`README.md does not point at AUDIT-V${version}.md`);
}
log(`version ${version} (companion/version.py, CURRENT.md, README.md agree)`);

const targetExe = path.join(outDir, candidateName(version));
if (existsSync(targetExe) && !force) {
  die(`${targetExe} already exists; pass --force to replace this candidate (never a release archive)`);
}

const companionExe = path.join(repo, "companion/dist/OqeCompanion/OqeCompanion.exe");
if (!skipApp) {
  run("npm run build", { env: { ...process.env, OQE_NITRO_PRESET: "node-server" } });
}
if (!existsSync(path.join(repo, ".output/server/index.mjs"))) {
  die(".output/server/index.mjs is missing — the app build did not produce a Node server");
}
if (!skipCompanion && !existsSync(companionExe)) {
  const python = path.join(repo, "companion/.venv/Scripts/python.exe");
  if (!existsSync(python)) die("companion/.venv is missing; create it with Python 3.12 and the pinned requirements");
  run(`"${python}" build-companion.py`, { cwd: path.join(repo, "companion") });
}
if (!existsSync(companionExe)) die("the frozen companion was not built at companion/dist/OqeCompanion");

const stage = path.join(repo, "dist/installer/stage");
rmSync(stage, { recursive: true, force: true });
mkdirSync(path.join(stage, "payload"), { recursive: true });

const payload = path.join(stage, "payload");
const nodeExe = process.execPath;
if (path.basename(nodeExe).toLowerCase() !== "node.exe") die(`unexpected Node executable: ${nodeExe}`);
const plan = payloadPlan({ version, nodeExe, companionDist: path.join(repo, "companion/dist/OqeCompanion") });

mkdirSync(path.join(payload, "node"), { recursive: true });
cpSync(plan.node.exe, path.join(payload, "node/node.exe"));
const nodeLicense = path.join(path.dirname(nodeExe), "LICENSE");
if (existsSync(nodeLicense)) cpSync(nodeLicense, path.join(payload, "node/LICENSE"));
writeFileSync(
  path.join(payload, "node/NOTICE.txt"),
  [
    "This install bundles the Node.js runtime (MIT) so Oqe runs without a system Node.",
    "Ollama and model weights are NOT bundled: local inference needs Ollama installed and a model pulled.",
    "Windows may warn that this candidate is from an unknown publisher; it is not code-signed.",
    "",
  ].join("\r\n"),
  "utf8",
);

for (const dir of plan.dirs) {
  const from = path.isAbsolute(dir.from) ? dir.from : path.join(repo, dir.from);
  if (!existsSync(from)) die(`missing payload source: ${dir.from}`);
  cpSync(from, path.join(payload, dir.to), { recursive: true });
}
for (const file of plan.files) {
  const from = path.join(repo, file.from);
  if (!existsSync(from)) die(`missing payload file: ${file.from}`);
  mkdirSync(path.dirname(path.join(payload, file.to)), { recursive: true });
  cpSync(from, path.join(payload, file.to));
}
writeFileSync(path.join(payload, plan.marker.name), plan.marker.text, "utf8");

// Prompt 62 (A-12) — the payload's own entry loads the preflight before any
// server code, so a direct run cannot bypass the loopback policy. The launcher
// still passes `--import`; the two paths share the same policy file.
const entryPath = path.join(payload, "app/server/index.mjs");
const preflightPath = path.join(payload, "Oqe-preflight.mjs");
if (!existsSync(entryPath)) die("the staged payload is missing app/server/index.mjs");
if (!existsSync(preflightPath)) die("the staged payload is missing Oqe-preflight.mjs");
writeFileSync(entryPath, guardPackagedEntry(readFileSync(entryPath, "utf8")), "utf8");
if (!readFileSync(entryPath, "utf8").startsWith(`import "${PACKAGED_ENTRY_PREFLIGHT}";`)) {
  die("the staged server entry did not take the loopback preflight guard");
}

// The payload is a fixed list, but prove it: one forbidden name anywhere means
// stop, not "it is probably fine".
const staged = walk(payload);
for (const rel of staged) {
  if (isForbiddenPayloadPath(rel)) die(`refusing to package ${rel}`);
}
for (const required of [
  "node/node.exe",
  "app/server/index.mjs",
  "companion/OqeCompanion/OqeCompanion.exe",
  "version.txt",
]) {
  if (!staged.includes(required)) die(`staged payload is missing ${required}`);
}

const zipPath = path.join(stage, "payload.zip");
const tarExe = path.join(process.env.SystemRoot ?? "C:\\Windows", "System32", "tar.exe");
if (existsSync(tarExe)) {
  runExe(tarExe, ["-a", "-c", "-f", zipPath, "-C", payload, "."]);
} else {
  run(`powershell -NoProfile -ExecutionPolicy Bypass -Command "Compress-Archive -Path '${payload}\\*' -DestinationPath '${zipPath}' -CompressionLevel Optimal -Force"`);
}
if (!existsSync(zipPath)) die("payload.zip was not created");

for (const file of ["install.cmd", "install.ps1"]) {
  cpSync(path.join(repo, "installer", file), path.join(stage, file));
}
const sed = renderSed({
  version,
  targetExe,
  sourceDir: stage,
  files: ["install.cmd", "install.ps1", "payload.zip"],
});
// Keep the definition in its own temporary folder: IExpress silently declines to
// produce an exe when the .sed sits in the source folder it packs OR in the folder
// it writes the target into.
const sedPath = path.join(mkdtempSync(path.join(os.tmpdir(), "oqe-iexpress-")), "oqe-installer.sed");
writeFileSync(sedPath, sed, "utf8");

mkdirSync(outDir, { recursive: true });
if (existsSync(targetExe)) rmSync(targetExe, { force: true });
const iexpressExe = path.join(process.env.SystemRoot ?? "C:\\Windows", "System32", "iexpress.exe");
if (!existsSync(iexpressExe)) die(`IExpress is missing at ${iexpressExe}`);
runExe(iexpressExe, ["/N", "/Q", sedPath], { timeout: 900_000 });
if (!existsSync(targetExe)) die("IExpress did not produce the candidate .exe");

const size = statSync(targetExe).size;
const digest = sha256(targetExe);
writeFileSync(`${targetExe}.sha256`, `${digest}  ${path.basename(targetExe)}\r\n`, "utf8");
log(`candidate: ${targetExe}`);
log(`size: ${(size / 1024 / 1024).toFixed(1)} MB (payload ${(dirBytes(payload) / 1024 / 1024).toFixed(1)} MB unpacked)`);
log(`sha256: ${digest}`);
log("bundled: app build, Node runtime, frozen companion (no Python needed)");
log("not bundled: Ollama, model weights, voice models; no code signature");
log("NOT published, NOT a release ZIP, NOT release-ready while the OS sandbox is unverified");
