# Oqe A-11 / A-12 — audit evidence

Prepared: 2026-10-27 (Prompt 63). This bundle is assembled for an independent
review. **No independent audit has been performed yet.** Nothing in this bundle
is a V11.1 release artifact or a promotion record.

## 1. Git commit and branch

- Commit: `4e744558fa48c19e95be9dd7c9d4b5ac719b0ebd`
- Branch: `main`
- Full revision details: `evidence/git-commit.txt`

## 2. Working-tree status before bundling

- 117 modified, 46 deleted, 143 untracked (`306` porcelain lines).
- The complete `git status --porcelain=v1` output is
  `evidence/git-status-before-bundle.txt`; it was captured before any bundle
  file was written.
- This bundle did not reset, stash, revert, reformat or modify the worktree.

## 3. Files changed for A-11 and A-12

A-11 (bare `--host`):

- `scripts/loopback-bind.mjs`
- `scripts/loopback-bind.test.mjs`

A-12 (packaged entry guard):

- `scripts/installer-lib.mjs`
- `scripts/build-installer.mjs`
- `scripts/installer.test.mjs`
- `scripts/packaged-entry-guard.test.mjs` (new file)
- `README-Windows.md` (launch documentation)

No peer-validation or task-dispatch code was changed by Prompt 62. The five
security files are included unchanged so the reviewer can confirm that.

## 4. Test commands and actual exit codes

| Command | Exit |
| --- | --- |
| `node --test scripts/loopback-bind.test.mjs` | 0 |
| `node --test scripts/packaged-entry-guard.test.mjs scripts/installer.test.mjs` | 0 |
| `node --experimental-strip-types --test src/lib/loopback-peer.test.ts src/lib/local-request-security.test.ts src/lib/companion/power-route.test.ts src/lib/server-task-runner.test.ts` | 0 |
| `npm run typecheck` | 0 |
| `npx eslint scripts/loopback-bind.mjs scripts/loopback-bind.test.mjs scripts/installer-lib.mjs scripts/build-installer.mjs scripts/installer.test.mjs scripts/packaged-entry-guard.test.mjs` | 0 |
| `OQE_NITRO_PRESET=node-server npm run build` | 0 |
| `node node_modules/vite/bin/vite.js dev --host --port 8097` | 1 (expected refusal) |
| `npm test` | 1 (only the pre-existing provenance assertion) |

The raw exit-code table is `evidence/command-results.txt`; each command's full
output is the adjacent `.log` file.

## 5. Actual test counts

| Suite | Tests | Pass | Fail | Skipped |
| --- | ---: | ---: | ---: | ---: |
| `scripts/loopback-bind.test.mjs` | 15 | 15 | 0 | 0 |
| `scripts/packaged-entry-guard.test.mjs` + `scripts/installer.test.mjs` | 17 | 17 | 0 | 0 |
| Peer / origin / power-route / task-runner | 55 | 55 | 0 | 0 |
| `npm test` — scripts | 178 | 174 | 0 | 4 |
| `npm test` — `src` | 2992 | 2991 | **1** | 0 |
| `npm test` — browser extension | 78 | 78 | 0 | 0 |

The single `src` failure is the unchanged V11.1 release-provenance assertion in
`src/lib/v89-release-provenance.test.ts`, which requires
`RELEASE-V11.1.sha256`. That file was not created or edited; creating it would
certify an unpromoted release, which this task forbids. The assertion text is in
`evidence/provenance-failure.txt`, and the full suite output is
`evidence/npm-test.log`.

## 6. Typecheck, lint and build

- `npm run typecheck` — exit 0; full output `evidence/typecheck.log`.
- `npx eslint` on the six changed scripts/tests — exit 0; full output
  `evidence/eslint.log`.
- `OQE_NITRO_PRESET=node-server npm run build` — exit 0; full output
  `evidence/build.log`.
- Generated entry before packaging: `files/.output/server/index.mjs`,
  SHA-256 `700d58ac1b4d5333c75c20b80f11013892861e4729406865e7676ed762209607`,
  35,425 bytes.
- Packaged entry after the guard: `packaged-entry/app/server/index.mjs`,
  SHA-256 `2fdab7f3f9b0e141b99596edf6d244942e34f1f7da764433e7df790a1079a692`.
  The body is byte-identical to the raw entry; only the guard line is prepended.

## 7. Observed bare `--host` behaviour

Command run from the repository root:

```text
node node_modules/vite/bin/vite.js dev --host --port 8097
```

Observed output (full log `evidence/bare-host.log`):

```text
LoopbackBindError: The Oqe dev server refuses a bare --host: it means all
interfaces. Oqe is local-first and has no accounts, so pass an explicit
loopback address instead (--host 127.0.0.1).
exit=1
--- listener check on 8097 ---
none
```

This is the deliberate policy rejection. Before Prompt 62 the same command
produced `TypeError: (intermediate value)...split is not a function`; that
finding is preserved in `records/AUDIT-CP-58.md` §9.6 and §10. `--host
0.0.0.0` remains rejected by the same policy path (proven in
`scripts/loopback-bind.test.mjs`).

## 8. Packaged-entry guard test results

`scripts/packaged-entry-guard.test.mjs` stages a disposable payload containing
the **real** `loopback-bind.mjs` and `loopback-preflight.mjs`, applies the same
`guardPackagedEntry` function the installer build uses, and runs the entry in a
child process. Results from `evidence/packaged-entry-tests.log`:

1. `NITRO_HOST=0.0.0.0`, `HOST=::` and a LAN host each exit 1 with
   `The bundled Oqe server refuses to bind to ...` before the synthetic entry
   body writes its marker.
2. A loopback configuration runs the entry body normally.
3. Removing the preflight makes the guarded entry exit non-zero before the body
   runs (module resolution failure).
4. Reapplying the guard is idempotent: exactly one guard remains.
5. The real generated entry takes the guard with its body unchanged.

`scripts/installer.test.mjs` additionally proves the guard is applied to the
staged payload before the ZIP is built and that the build refuses a missing
preflight or a guard that did not land.

## 9. How the guard is inserted and ordering verified

`guardPackagedEntry(source)` in `files/scripts/installer-lib.mjs`:

- refuses an empty entry;
- returns the source unchanged when `import "../../Oqe-preflight.mjs";` is
  already present;
- refuses a different `Oqe-preflight.mjs` reference rather than duplicating it;
- inserts the exact guard as the first line, or after a shebang if the entry
  ever has one, preserving the source's line endings.

`files/scripts/build-installer.mjs` applies it to
`payload/app/server/index.mjs` **after** the payload directories and files are
copied and **before** `payload.zip` is created, then reads the staged file back
and aborts if it does not start with the guard. Because a static ESM import is
evaluated before the importing module's body, the preflight runs before
`serve(...)` in `.output/server/index.mjs`.

`reproduce/apply-packaged-guard.mjs` recomputes the transform from the raw
entry and compares it byte-for-byte with the packaged entry included here.

## 10. Was the final packaged entry executed?

- The **fixture** packaged entry was executed, including its non-loopback
  refusals and a loopback success (`evidence/packaged-entry-tests.log`).
- The **real** packaged entry was **not** executed on a non-loopback bind: if
  the guard regressed, that would expose the unauthenticated app. Its guard was
  verified statically on the fresh build, and the complete packaged server tree
  is included so the auditor can execute it in an isolated environment.
- The repository dev server was left running on `127.0.0.1:8080` (PID 10464);
  it was not rebound or exposed.

## 11. Clean Windows installation

**NOT PERFORMED.** No clean Windows account/machine install and launch was run
for this bundle. That remains V111-01 and is a release gate, not something this
bundle claims.

## 12. T3 and T5

- **T3 (separate-device refusal): NOT VERIFIED.** No second machine was used.
- **T5 (real paired-companion token flow): NOT VERIFIED.** No real companion
  token was exercised or read.

Both remain release blockers. The companion peer checks and task-dispatch trust
checks are included unchanged; no claim of end-to-end verification is made.

## 13. V11.1 release state

- V11.1 remains **unpromoted**.
- `RELEASE-V11.1.sha256`: absent.
- `Oqe-V11.1.zip`: absent.
- No `V11.1*` git tag.
- No release archive, checksum, tag or promotion pointer was created for this
  bundle. `MANIFEST-SHA256.txt` is an audit-bundle integrity manifest only.

Exact capture: `evidence/release-and-state.txt`.

## 14. Logs and raw evidence

All under `evidence/`:

- `git-commit.txt`, `git-status-before-bundle.txt`
- `command-results.txt`, `environment.txt`
- `loopback-bind-tests.log`, `packaged-entry-tests.log`,
  `peer-security-tests.log`
- `typecheck.log`, `eslint.log`, `build.log`, `npm-test.log`
- `bare-host.log`, `provenance-failure.txt`
- `release-and-state.txt`
- `guard-apply-check.txt` (produced by `reproduce/apply-packaged-guard.mjs`)

## Bundle contents and omissions

Included with repository-relative paths under `files/`:

- A-11/A-12 implementation: `scripts/loopback-bind.mjs`,
  `scripts/loopback-preflight.mjs`, `scripts/installer-lib.mjs`,
  `scripts/build-installer.mjs`, `vite.config.ts`,
  `installer/Oqe-start.ps1`, `README-Windows.md`.
- Tests and helpers: `scripts/loopback-bind.test.mjs`,
  `scripts/packaged-entry-guard.test.mjs`, `scripts/installer.test.mjs`,
  `scripts/preview.test.mjs`, `scripts/run-tests.mjs`,
  `scripts/with-app-env.mjs`, and the peer/task suites listed above.
- Security dependencies: `src/lib/local-request-security.server.ts`,
  `src/routes/api/companion.$.ts`, `src/routes/api/tasks.start.ts`,
  `src/routes/api/tasks.resume.$taskId.ts`,
  `src/lib/server-task-runner.server.ts`,
  `src/lib/companion/bridge-token.ts`,
  `src/lib/request-body-limit.server.ts`.
- Build configuration: `package.json`, `tsconfig.json`, `eslint.config.mjs`,
  `vite.config.ts`.
- Records: the complete current `AUDIT-CP-58.md`,
  `SCOPE-RESTORATION-PLAN.md`, `SCOPE-RESTORATION-REPORT.md`,
  `V11.1-ISSUES.md`, `CHECKPOINT-LOG.md` under `records/`.
- Raw build entry: `files/.output/server/index.mjs`.
- Executable packaged tree: `packaged-entry/` (full `app/server` tree plus
  `Oqe-preflight.mjs` and `loopback-bind.mjs` at its root).

Omitted deliberately:

- `node_modules`, caches, temporary directories, `.git`, secrets, user data,
  logs from the user's local data folder, and the 3.5 MB `public` assets tree
  (not imported by the server entry; not needed to audit the bind guard).
- The full raw `.output` tree. The raw **entry** is included; the full packaged
  server tree is included for execution.
